# Stage 8 — Invoice HTML, PDF workflow & printing

This stage adds authenticated, branch-scoped print views for sales and purchase invoices. The print view is HTML with print CSS; the user can use the browser's **Print → Save as PDF** function. This avoids introducing a native PDF engine dependency into the server and keeps the output usable on desktop browsers.

## Endpoints

- `GET /api/sales/invoices/:id/print` — requires `sales.view` and an assigned branch. Returns a printable sales invoice.
- `GET /api/purchases/invoices/:id/print` — requires `purchase.view` and an assigned branch. Returns a printable purchase invoice.
- Add `?size=80mm` to either endpoint for a narrow thermal receipt layout; default is A4-oriented layout.

Both endpoints reuse the same invoice records and line items as the JSON detail endpoints. They do not post, modify, or otherwise change invoice/accounting/stock data.

## Layout features

- Company name, address and phone configurable with `ANSARY_COMPANY_NAME`, `ANSARY_COMPANY_ADDRESS`, and `ANSARY_COMPANY_PHONE` environment variables.
- Invoice number, date, customer/supplier, currency, item quantities, batch/expiry details, subtotal, discount, tax, total, paid amount and balance.
- Escaped dynamic text to prevent HTML injection in printed invoice content.
- Browser print button, A4 print styling, and 80mm thermal styling.
- Responsive view for phone and desktop browsers.

## Important limitations

- This is a printable HTML view, not a server-generated binary PDF. Use browser Print → Save as PDF.
- No logo upload/settings screen, barcode image, signature image, or printer-driver integration yet.
- The existing invoice posting endpoints remain intentionally disabled (HTTP 501) until stock and accounting posting are made atomic. A draft invoice can be printed but is clearly marked `DRAFT`.
- The current schema's item and totals are printed as stored; this stage does not recalculate or change financial values.

## Validation

- The Stage 7 database/schema test suite is rerun as part of packaging.
- TypeScript build and HTTP integration tests require installing the workspace npm dependencies and are not claimed as passed in this environment.
