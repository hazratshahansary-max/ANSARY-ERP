# ANSARY ERP – Stage 5: Sales API Foundation

## Implemented
- `GET /api/sales/customers` – active customers visible to the authenticated user's assigned branches (plus unassigned/global customers).
- `GET /api/sales/invoices` – branch-scoped invoice list.
- `POST /api/sales/invoices` – create a draft cash or credit invoice. Credit requires a customer; cash payments above zero require a payment account.
- `GET /api/sales/invoices/:id` – invoice header and lines.
- `POST /api/sales/invoices/:id/items` – add a draft line after checking batch/medicine/branch match, batch status, expiry date, and available quantity. Unit cost is frozen from the batch at entry time.
- `DELETE /api/sales/invoices/:id/items/:itemId` – remove a draft line and recalculate totals.
- `POST /api/sales/invoices/:id/post` – intentionally returns `501 SALES_POSTING_NOT_READY`.

## Important limitations (not complete sales workflow)
- Invoice posting is deliberately disabled. Posting must atomically create the accounting journal, update customer receivables/cash receipts, reduce stock through append-only stock movements, and change invoice status. The current DatabaseAdapter has no transaction interface, so enabling a multi-step post operation would risk partial writes.
- Sales returns, invoice reversal, PDF/A4/thermal printing, UI screens, and customer statement reports are not implemented in this stage.
- `previous_balance` currently snapshots `customers.opening_balance`; it is not a live receivable balance. A customer subledger query must replace this before production use.
- The server's TypeScript build and API integration tests were not run because Node dependencies are not installed in this environment.

## Security and data safety
- All routes require authentication and permission codes.
- Invoice and line edits are limited to draft documents.
- Branch access is checked on every invoice read/write.
- This stage does not modify or delete existing business data or existing migrations.

## Run database tests
From the repository root: `python -m unittest discover -s database/tests -v`
