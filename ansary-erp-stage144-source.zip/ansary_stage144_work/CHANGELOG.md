## 0.126.0 — 2026-11-15
- Add multi-invoice allocation selection to customer receipts and supplier payments, with same-currency and aggregate-balance validation before submission.
- Add branch-protected consolidated customer/supplier allocation history with date filters and Excel-compatible UTF-8 CSV export.
- Fix installment-history SQL joins to resolve invoice linkage through installment_plans; verified both consolidated queries and per-voucher installment subqueries against migrated SQLite.
- Update all workspace/browser versions and PWA shell cache to stage126.
- Node 189/189, Python 251/251, and database 99/99 tests pass. Production TypeScript build remains blocked by missing server dependencies.

## 0.96.0 — 2026-11-15
- Added a bounded Node.js/npm runtime preflight to dependency setup; unsupported or unavailable versions now stop before installation and are recorded in the setup report.
- Added version parsing and validation tests for the declared Node.js >=20 and npm >=10 requirements.
- Fixed the dependency setup entrypoint to import its lockfile validation helper explicitly.
- Full API build remains blocked by the absent package lock/dependencies and unavailable npm registry DNS; no live API success is claimed.

## 0.93.0 — 2026-11-15
- Redact npm registry credentials and query secrets from environment-doctor reports while preserving hostname-based DNS checks.
- Support both workspace and standalone API layouts in environment diagnostics and lockfile validation.
- Include the dependency-setup helper required by the standalone API environment doctor.

## 0.88.0 — API listener startup diagnostics

- Added actionable startup messages for TCP port conflicts, permission failures, unavailable bind addresses, and unexpected listener errors.
- Close the database connection and set a failing process exit code when the HTTP listener cannot start.
- Added dependency-free tests for listener error classification and included the helper in TypeScript runtime output.
- Full API build and live listener tests still require the server workspace dependencies.

## 0.86.0 — API TCP port validation

- Validate the API `PORT` setting before database initialization; reject malformed and out-of-range values with actionable errors.
- Add dependency-free unit coverage for port parsing.

# Changelog

## 0.79.0 — Stage 79
- Fixed an API build-output defect: TypeScript imports several hand-written JavaScript runtime helpers, but the prior tsconfig did not explicitly include those files in compiler output.
- Added explicit TypeScript input entries for session policy, schema readiness, SQL placeholder conversion, and rate limiting helpers.
- Added a clean-build runner that removes stale `dist` output before compilation, deletes partial output after a failed compiler run, and verifies every local JavaScript import reachable from `dist/index.js`.
- Updated standalone API packaging to include the build runner and use it for `npm run build`.
- Added preflight checks and regression tests for JavaScript runtime emission and missing compiled imports.
- Dependency installation, full TypeScript type-check, live HTTP API, PostgreSQL, and device synchronization remain unverified because registry DNS is unavailable and server dependencies are not installed.

- Added accurate missing-dependency details and avoids requiring registry DNS when all dependencies are already installed locally.
- Hardened npm retry/timeout parsing against invalid environment values.
- Regenerated the standalone API source bundle and documented current environment blockers; no fabricated lockfile or false build-success claim was added.

## 0.74.0 — 2026-11-15
- Made server build preflight honor the configured npm registry (`ANSARY_NPM_REGISTRY`, npm config, or `.npmrc`) instead of hard-coding npmjs DNS.
- Added cache-first and explicit offline-cache dependency installation modes.
- Updated desktop app metadata to keep package versions aligned.
- Regenerated the standalone API source bundle; live dependency installation and TypeScript build remain blocked by unavailable registry DNS/network in this environment.

## 0.73.0 — 2026-11-15
- Added a disposable PostgreSQL 16 Docker Compose integration harness with a dedicated test database, readiness wait, concurrent migration-runner check, seed loading, SQL integrity suite, and automatic container/volume cleanup.
- Added static contract tests for harness isolation and execution flow.
- Live PostgreSQL integration remains unverified in this environment because Docker and psql are unavailable.

## 0.72.0 — 2026-11-15
- Hardened PostgreSQL migrations with transaction-scoped advisory locking, an in-transaction applied-state check, atomic DDL + checksum recording, and fail-closed checksum validation.
- Added PostgreSQL migration-runner contract tests using a fake psql client; live PostgreSQL remains unverified.

## 0.70.0 - 2026-11-15
- Align API master-data sync fields and optimistic locking with canonical SQLite/PostgreSQL schema.
- Add cross-dialect idempotency log migration for master-data apply.
- Make schema readiness dialect-aware; PostgreSQL no longer requires SQLite-local sync_state/sync_outbox.

## 0.62.0 — Stage 62
- Added `sync.manage` permission for administrator roles.
- Hardened device management endpoints with explicit permissions and branch checks.
- Added read-only device token audit API and Pashto UI actions for registration, rotation, and revocation.
- Device tokens are displayed once and are not stored in browser local storage.
- Financial and stock synchronization remain disabled.

## 0.60.0 — Stage 60

- Added a read-only Sync retry manager report with per-master-table pending/failed/sent counts and safe retry classifications.
- Corrected the retry advisor to distinguish due failed transient rows as candidates requiring explicit operator confirmation.
- The report never exposes raw errors or payloads, never mutates outbox rows, and never sends network requests; financial and stock events remain excluded.
- Added four Stage 60 regression tests; live server/PostgreSQL and two-device Sync remain unverified.

## 0.54.0 — Stage 54

- Corrected the Stage 53 sync-device contract audit to inspect the canonical SQLite and PostgreSQL migration directories instead of the explicitly legacy `server/db/migrations` snapshot.
- Audit now collects incremental `ALTER TABLE ... ADD COLUMN` fields as well as base `CREATE TABLE` fields.
- Both canonical dialects now statically satisfy the device API contract, including delivery cursor, token hash, relay events and token audit fields.
- This clears the false-positive static blocker only; disposable PostgreSQL/API and two-device runtime tests remain required.

## 0.48.0 — Stage 48

- Added a strict v1 transaction-event envelope builder and validator with an explicit event allowlist, canonical UUID, branch/device/actor identity, timezone-aware timestamp, positive device sequence, and canonical SHA-256 payload integrity.
- Rejects unknown envelope fields and payload tampering; validation is side-effect-free.
- Transaction sync remains disabled: no event delivery, server apply, financial writes, or stock writes were added.
- Verification scope and remaining production requirements are documented in `docs/STAGE48_TRANSACTION_EVENT_ENVELOPE.md`.

## 0.47.0 — Stage 47

- Added a read-only transaction-sync readiness audit for stock ledger, journal posting/reversal and invoice idempotency guards.
- Verified the current SQLite schema passes seven safety checks while keeping financial and inventory sync disabled.
- Documented the remaining server-authoritative event protocol, atomic parent/child application, PostgreSQL parity and two-device verification requirements.
- Verification: 161 Python tests, 80 database tests and seven schema checks pass; no live server or two-device test was performed.

## 0.46.0 — Stage 46

- Restricted local conflict resolution to the five supported master-data tables and explicit writable field allowlists.
- Server conflict payloads can no longer overwrite protected columns; the conflict record's server version is authoritative.
- Merged records receive `max(local_version, server_version) + 1`.
- Added a privacy-conscious conflict preview that reports changed field names without exposing business values.
- Local automated tests only; live server, PostgreSQL, and two-device end-to-end sync remain unverified.

## 0.44.0 — Stage 44

- Added a read-only local Sync health report for outbox, conflicts, cursors, pending ACKs, and master-data tombstones.
- Recent conflict metadata is reported without exposing raw business payloads or credentials.
- Added regression tests for counts, warning generation, privacy redaction, and missing-table behavior.
- The report does not resolve conflicts or claim live server/two-device status.

## 0.43.0 — Stage 43

- Connected outbound master-data sync to the authenticated `/api/sync/apply-master` endpoint before relaying events to other devices.
- Only server-applied events (or idempotent duplicates previously applied) are relayed; version conflicts remain pending locally and are not marked sent.
- Added regression tests for apply-before-relay ordering, conflict retention, and compatibility with earlier retry/tombstone behavior.
- Verification: 143 Python tests and 80 database tests pass; Python bytecode compilation passes. Live TypeScript build, PostgreSQL, and two-device end-to-end tests remain unverified.

## 0.42.0 — Stage 42
- Added SQLite migration 018 with durable, versioned tombstones for hard-deleted categories, companies, medicines, customers, and suppliers.
- Replaced the five master delete triggers so `OLD.version` is captured transactionally before the row disappears.
- Updated the HTTP sync client to push only deletes with an exact tombstone base version and remove the tombstone only after explicit relay acknowledgement.
- Legacy delete events without a tombstone remain pending; no version is inferred. Financial and inventory tables remain excluded.
- Added Stage 42 tombstone regression tests and migration documentation.
- Automated local tests pass; live server, PostgreSQL and two-device end-to-end sync are still unverified.

## 0.41.0 — Stage 41
- Extended the one-cycle HTTP sync client to push pending outbox events for the five allowlisted master-data tables to the authenticated relay.
- Persisted stable event UUIDs and base versions before network I/O; only server-acknowledged envelopes are marked sent.
- Added schema-name mapping and strict exclusion of financial/inventory outbox tables.
- Hard-delete outbox entries remain pending because their original base version is not retained; no unsafe version is guessed.
- Added Stage 41 mocked-transport regression tests and usage/limitations documentation.
- Relay acceptance is not proof of remote application; live deployment and two-device end-to-end verification remain outstanding.

## 0.36.0 — Stage 36
- Made master-data row changes and successful apply-log writes atomic per event.
- Added retry-safe conflict logging and Stage 36 contract tests.

# Changelog

## 0.31.0 — Stage 31
- Added manual conflict review and resolution choices: keep local, use server, merge, dismiss.
- Preserved the incoming event operation in `sync_conflicts.server_op` with SQLite/PostgreSQL migration 017.
- Server-wins application suppresses local sync echo; pending local outbox entries are marked failed with an audit explanation.
- Server deletes are limited to soft-delete tables; unsafe hard deletes are refused.
- Added Stage 31 regression tests and usage documentation.
- Live server-side business-table application and production multi-device sync remain out of scope.


## 0.32.0 — Stage 32
- Added authenticated, branch-scoped sync device and event monitoring endpoints.
- Added Pashto browser Sync monitor with potential multi-device row-change review.
- Bumped PWA shell cache version.
- Explicitly documented that central conflict resolution and canonical event application are not implemented.

## Stage 33 — guarded master-data sync application
- Added a SQLite event applier for categories, companies, medicines, customers, and suppliers only.
- Added strict field allowlists, branch guard for customers, optimistic version checks, idempotency log, conflict recording, and soft-delete behavior.
- Explicitly rejects stock and posted financial tables; this is not yet a live HTTP sync apply endpoint.
- Corrected sync relay table names to match the actual schema (`categories`, `companies`).

## 0.34.0 — Stage 34
- Added authenticated `POST /api/sync/apply-master` for allowlisted master-data rows.
- Added SQLite and PostgreSQL migrations for apply idempotency/conflict log.
- Enforced exact version checks, soft deletes, customer branch scope, and explicit field allowlists.
- Financial and stock tables remain excluded. Atomic apply+audit transaction and live DB integration remain follow-up work.

## 0.35.0 — 2026-11-15
- Fixed server master-data sync field allowlists to match the actual SQLite and PostgreSQL schemas.
- Corrected optimistic locking from `version` to `row_version`.
- Removed writes to nonexistent `origin_device_id` master columns.
- Added SQLite/PostgreSQL schema contract tests for master sync.

## 0.37.0 — Sync device onboarding
- Added a Pashto device-registration form to the Sync monitor.
- Registered device ID, device code, platform, branch and initial cursor are saved locally per user and branch.
- Clarified in the UI that registration alone does not start data synchronization.
- Added Stage 37 contract tests; no live multi-device replication claim is made.

## 0.38.0 — Inbound Sync pull preview
- Added a manual client action to fetch and preview inbound relay events for the currently registered device.
- Deliberately does not apply events, acknowledge cursors, or advance the local cursor until a durable local apply pipeline exists.
- Added contract tests to prevent accidental ACK/apply or cursor advancement in preview mode.

## 0.39.0 — Stage 39
- Added SQLite inbound master-data pull application utility.
- Added atomic cursor/data/inbox/conflict transaction, idempotency and local-pending conflict protection.
- Added five Stage 39 tests and usage documentation.

## 0.40.0 - 2026-11-15
- Added an authenticated HTTP pull/apply/ack client for master-data sync using standard-library HTTP transport.
- Added a durable pending-ACK cursor so a failed ACK is retried before the next pull.
- Added an explicit `scope=master` pull filter to avoid delivering unsupported financial/stock events to the master-data applier.
- Added payload field mapping for server/local schema aliases and explicit reporting of intentionally ignored server-only fields.
- Added transport and master-scope contract tests. Live server and two-device operation remain deployment tests.

## 0.49.0 — Stage 49
- Added a durable SQLite transaction-event inbox reference implementation.
- Added idempotent duplicate handling, event UUID content-collision rejection,
  per-device sequence uniqueness, and transactional rollback tests.
- Inbox acceptance is deliberately separate from business application; no
  production HTTP endpoint or financial/stock posting is enabled.

## 0.50.0 — Stage 50
- Added SQLite reference authentication/authorization for transaction sync devices and actors.
- Added explicit grants scoped to actor, device, branch, and event type; default deny.
- Added authorized inbox acceptance and tests for disabled identities, invalid credentials, branch/event denial, and token digest storage.
- Transaction events remain accepted-only; no financial or stock records are applied.

## 0.52.0 — Stage 52
- Added branch-scoped device-token rotation and revocation endpoints.
- Added token lifecycle audit migrations for SQLite and PostgreSQL.

## Stage 55 — SQLite Sync Runtime Validation
- Added disposable canonical SQLite migration/runtime verification and seven integration tests covering sync schema constraints, device audit, event idempotency, foreign keys, and migration idempotency.
- Confirmed all 22 canonical SQLite migrations apply cleanly to a fresh temporary database; integrity check is `ok` with zero foreign-key violations.
- Does not claim HTTP API, PostgreSQL, or two-device end-to-end validation.

## 0.56.0 — Stage 56
- Restricted server sync event validation to the five explicit master-data tables.
- Blocked financial and stock tables from `/push` and `/apply-master` until dedicated transaction-sync safety work is complete.
- Made `/pull` master-only by default and enforced the master-table filter even when a caller supplies `scope=all`.
- Added seven Stage 56 source-contract regression tests and updated the Stage 40 pull-scope regression to reflect the safer behavior.

## 0.57.0 — Stage 57
- Hardened `/api/sync/push` idempotency: an existing event UUID is acknowledged only when the stored device, table, row, operation, base version, and canonical payload match.
- Added explicit rejection for cross-device UUID reuse and same-device UUID content mismatch.
- Added six source-contract regression tests; financial and stock relay restrictions remain unchanged.


## 0.58.0 — Stage 58
- Changed `/api/sync/push` to return per-event acknowledgements and sanitized rejections instead of aborting the entire batch on an individual event failure.
- Added explicit retryable/permanent rejection codes without exposing database exception details.
- Updated the HTTP sync client to validate disjoint, known outcomes and mark only acknowledged outbox rows as sent.
- Rejected rows remain pending with their original event UUID and a bounded error code for safe retry or operator review.
- Added six Stage 58 tests for partial success, rejection handling, client state transitions, and continued financial/stock exclusions.
- Live TypeScript build remains unverified because Node/Express/Zod/database package dependencies and Node type definitions are not installed in this environment.

## 0.59.0 — Stage 59
- Added a read-only retry advisor for master-data Sync outbox rows.
- Added safe transient/permanent error categorization and capped exponential backoff (30 seconds to 1 hour).
- Reports due/wait/operator-review decisions without exposing raw error details or changing database state.
- Financial and stock rows remain excluded; no automatic retry or network request is performed.

## 0.61.0 – 2026-11-15
- Added permission-gated, branch-scoped, read-only Sync relay report API for `sync.view` users.
- Integrated received-event counts and recent safe relay details into the Pashto dashboard and Sync monitor.
- Kept financial, accounting, invoice, payment, batch and stock events excluded.
- Raw error messages and event payload values are not exposed by the new report.

## 0.63.0 — Stage 63
- Added a real-HTTP smoke-test harness for the compiled API health and database-readiness endpoints.
- Smoke test uses an isolated temporary SQLite file and clears DATABASE_URL to avoid touching a configured production database.
- Added `npm run smoke:server` and Stage 63 test/documentation files.
- Aligned root, server, and desktop app package versions at 0.63.0.
- Live server build/smoke execution remains pending dependency installation; see STAGE63_TEST_RESULTS.txt.

## 0.64.0 — Server build readiness diagnostics

- Added a read-only server build preflight for Node.js, npm lockfile, installed runtime dependencies, workspace version consistency, and npm registry DNS.
- Added deterministic Node.js tests for build-readiness diagnostics.
- Aligned root, server, client, desktop, desktop app, and shared package versions at 0.64.0.
- TypeScript build and live HTTP smoke remain blocked until npm dependencies can be installed.

## 0.65.0 — Server dependency recovery

- Added a scoped server dependency setup command that selects `npm ci` when a lockfile exists and `npm install` otherwise.
- Added bounded retry handling for transient npm registry network failures and a configurable trusted registry override.
- Added Node/npm engine requirements and npm package-manager metadata.
- Added deterministic tests for install-mode selection, workspace scope, retry classification, and actionable failure summaries.
- Documented Windows PowerShell and cross-platform setup/build/smoke-test steps.
- Dependency installation, TypeScript compilation, live HTTP, PostgreSQL, and two-device Sync remain unverified when npm registry DNS is unavailable.

## 0.66.0 — 2026-11-15
- Added read-only server database schema readiness validation for SQLite and PostgreSQL.
- API startup now fails closed when required ERP tables are missing; readiness endpoints no longer treat `SELECT 1` alone as a complete ERP database.
- Added schema-readiness tests and operator documentation.

## 0.67.0 — 2026-11-15

- Added process-local IP rate limiting to public authentication endpoints.
- Login is limited to 10 requests per 15-minute window per client IP.
- Initial setup is limited to 5 requests per 15-minute window per client IP.
- Added HTTP 429 responses, `Retry-After`, and `RateLimit-*` headers.
- Added five dependency-free Node.js tests.
- Full server build and live HTTP integration remain pending until npm dependencies can be installed.

## 0.68.0 — 2026-11-15
- Hardened failed-login lockout with an atomic counter update and no extension of active locks.
- Added idle/absolute session expiry checks and explicit session revocation reasons.
- Made successful login and security-sensitive session revocations transactional.
- Corrected login-history timestamp projection to the canonical SQLite/PostgreSQL schema.
- Added auth/session policy, schema contract, and SQLite SQL integration tests.

## 0.69.0 — 2026-11-15
- Added an isolated standalone API source-bundle generator, excluding Electron/client workspace dependencies.
- Pinned direct API dependency versions in the generated deployment manifest.
- Included canonical SQLite/PostgreSQL migrations, SQLite migration runner, environment example, and deployment notes.
- Added output overwrite safety and bundle-structure tests.

## 0.71.0 — SQLite migration atomicity

- Made each SQLite migration's schema changes and checksum ledger insert one transaction, eliminating the crash window that could leave applied DDL unrecorded.
- Added rollback, idempotency, checksum-tampering, and trigger-body regression tests for the SQLite migration runner.
- Ensured the command-line migration runner closes the database connection even when migration or seed execution fails.

## 0.76.0 — Portable server npm cache

- Added support for selecting an external, copied npm cache through `ANSARY_NPM_CACHE_DIR`.
- Validates the npm `_cacache` content store before starting installation.
- Passes the cache path to the child npm process without mutating global npm configuration.
- Added preflight reporting for configured external cache availability.
- Documented the online-to-offline cache transfer workflow and its completeness caveat.

## 0.77.0 — Reproducible offline server dependency preparation
- Added an online-computer preparation command that resolves the server workspace dependencies, creates the npm lockfile, and fills npm's local cache.
- Added a dependency manifest with a SHA-256 lockfile fingerprint and direct server dependency declarations.
- Added validation that the lockfile's server workspace entry matches the server package manifest; missing or inconsistent lockfiles fail closed.
- Added portable npm cache structure validation and explicit offline installation instructions.
- Added dependency-bundle unit tests. Actual dependency resolution and TypeScript build remain unverified in this DNS-restricted environment.

## 0.77.0 — Windows x64 offline API deployment preparation

- Added a guarded Windows x64 PowerShell workflow that creates an isolated API bundle, installs dependencies, generates a real npm lockfile, builds TypeScript, prunes development dependencies, verifies runtime modules, and creates a platform-specific ZIP with SHA-256.
- Added strict offline bundle validation for the package manifest, lockfile consistency, compiled entrypoint, environment example, and required runtime dependencies.
- Added a deployment manifest recording OS, architecture, Node/npm versions, lockfile version, and native-module portability limits.
- Added automated tests for valid bundles, missing artifacts/dependencies, and package-lock version mismatches.
- This environment still cannot resolve registry.npmjs.org (EAI_AGAIN), so the Windows packaging workflow is provided but has not been run here; no real lockfile or built deployment ZIP is claimed.

## 0.78.0 — Stage 78
- Fixed the live HTTP smoke-test preparation flow: it now applies all canonical SQLite migrations to an isolated temporary database before starting the API, so the API's startup schema gate can pass.
- Expanded live smoke coverage to include readiness, Helmet security headers, configured CORS, unauthenticated access rejection, and login payload validation.
- Added cross-platform Python 3 discovery (`py -3` / `python` on Windows; `python3` / `python` on Unix) with actionable migration errors.
- Added deterministic unit tests for Python discovery, interpreter fallback, migration failure handling, and missing-Python diagnostics.
- Live HTTP smoke remains conditional on a successful TypeScript build and installed runtime dependencies.


## 0.80.0 — Stage 80
- Added strict package-lock.json auditing against the root and server workspace manifests, including exact dependency/devDependency groups.
- Integrated lockfile manifest-alignment checks into server build preflight.
- Added a standalone lockfile verification command with actionable remediation guidance.
- Added regression tests for root version drift, missing lockfiles, and undeclared locked dependencies.

## 0.81.0 — 2026-11-15
- Added a server environment doctor that reports runtime compatibility, npm registry DNS status, lockfile validity, npm cache structure, and resolution of every declared server runtime/build package.
- Added a machine-readable `SERVER_ENVIRONMENT_REPORT.json` and a strict mode suitable for CI/deployment gates.
- Added tests proving missing dependencies, missing lockfiles, old Node/npm runtimes, and registry DNS failures are reported as blockers rather than being mistaken for a successful build.
- No lockfile was fabricated; dependency installation and live server build remain blocked until a valid npm lockfile and dependencies are available.

## 0.82.0 — Windows API setup hardening
- Added registry URL and DNS preflight to the Windows x64 standalone API preparation workflow.
- Added bounded npm install retries and explicit fetch timeouts.
- Added package-lock version checks and post-build entrypoint validation.
- Added structured setup logs, JSON reports, and SHA-256 output.
- Added Windows setup script contract tests.


## 0.83.0 — Windows API setup runner fix
- Fixed a fatal duplicate `-Append` parameter passed to `Tee-Object` in the Windows PowerShell setup runner.
- Replaced pipeline logging with explicit stdout/stderr capture and native exit-code checking.
- Added regression tests for command output handling and Stage 83 paths/report metadata.
- Renamed setup logs, JSON report, and deployment ZIP for Stage 83.
- Windows execution and dependency installation remain unverified on this Linux host.

## 0.84.0 — Windows offline API dependency installation

- Added explicit offline-cache mode to the Windows x64 API preparation script.
- Validates the copied npm cache structure (`_cacache/index-v5`) before installation.
- Skips registry DNS checks only when offline mode is explicitly enabled.
- Runs npm install and production prune with `--offline` in offline mode.
- Avoids pointless network retries when operating offline and records install mode/cache path in the JSON report.
- Updated standalone API deployment documentation with safe Windows cache-transfer instructions.
- Added regression tests for offline mode, cache validation, and DNS bypass boundaries.

Limits: No real npm cache or lockfile is present in this build environment; offline install, TypeScript build, and Windows execution remain unverified.

## 0.85.0 — API smoke-test port and diagnostics hardening

- Replaced the randomly guessed smoke-test TCP port with an OS-assigned ephemeral port (or an explicitly supplied `SMOKE_PORT`).
- Added validation for an invalid explicit smoke-test port.
- Bounded captured API stdout/stderr to the final 24 KB so a failing process cannot grow the smoke-test runner's memory indefinitely.
- Added regression tests for OS-assigned port discovery and invalid listener-address handling.
- Synchronized the Electron app package version with the root/workspace version.

Limits: The live HTTP smoke test still requires a successful server build and installed native/runtime dependencies; neither is available in this host because npm registry DNS resolution is failing.

## 0.88.0 — API dependency preflight
- Added a build-time inspection of every declared production and development dependency before invoking TypeScript.
- Build failures now list all missing packages in one actionable `SERVER_DEPENDENCIES_MISSING` diagnostic, instead of producing a long cascade of secondary TypeScript errors.
- Added tests proving that the compiler is not invoked when dependencies are incomplete.

## 0.89.0 — API dependency setup diagnostics

- Added structured `SERVER_DEPENDENCY_SETUP_REPORT.json` output for dependency installation success and failure.
- Sanitized npm registry credentials and query strings before writing diagnostics.
- Classified timeout, DNS, dependency conflict, permission and generic install outcomes with stable codes.
- Limited offline installation to one attempt; online retries remain bounded.
- Added regression tests for report-safe registry handling and error classification.

## 0.90.0 — Version-driven Windows API preparation

- Fixed stale Stage 84 paths embedded in the Windows API preparation script; bundle, ZIP, log, JSON report, and report version now derive from the root package version.
- Fixed standalone API README generation so offline cache-transfer instructions point to the matching release/server-stageN directory rather than a hard-coded old stage.
- Dependency setup JSON reports now read the project version from package.json instead of a stale literal.
- Added regression tests that ensure the generated deployment instructions and Windows setup metadata remain aligned with the current release version.
- This closes a packaging/documentation mismatch; it does not claim a real Windows run or successful npm dependency install.

## 0.92.0 — Stage 92

- Redact credential-bearing registry URLs and npm auth-token/password assignments from dependency-setup console diagnostics.
- Display sanitized registry and command diagnostics without changing the actual registry arguments passed to npm.
- Add regression coverage for console-output secret leakage.

## 0.93.0 — 2026-11-15
- Redact npm registry credentials and query secrets from environment-doctor reports.
- Keep DNS checks functional while sanitizing persisted registry metadata.
- Support environment diagnostics and lockfile validation in standalone API bundles.
- Include the dependency setup helper in the standalone API bundle.

## 0.94.0 — 2026-11-15
- Bound npm CLI diagnostics in the server environment doctor so missing or hanging npm commands cannot stall checks indefinitely.
- Made npm version and cache discovery independent and added structured JSON/report-path output.
- Added regression tests for npm timeouts, missing npm, and partial npm CLI failures.

## 0.95.0 — 2026-11-15
- Added a manifest/lockfile consistency gate before `npm ci` in server dependency setup.
- A stale or mismatched lockfile now stops before npm is invoked, reports the exact manifest mismatches, and writes a machine-readable setup report.
- Preserved first-time online `npm install` behavior when no lockfile exists.

## 0.97.0 — 2026-11-15
- Tightened portable npm cache validation: configured caches must contain both `_cacache` and `_cacache/index-v5`.
- Added a specific diagnostic for incomplete cache copies and regression coverage for missing index-v5.

## 0.100.0 — Stage 100
- Corrected stale package/UI version metadata and workspace description.
- Added automated package/browser version alignment checks.
- Fixed an unclosed migration SQL file handle in the database test suite.
- Added a release-readiness matrix with explicit API, PostgreSQL, sync, Windows, Android, and production blockers.

## 0.101.0 — 2026-11-15
- Performed a full regression pass over the Stage 100 source tree.
- Revalidated version alignment across all six workspace manifests and browser label.
- Regenerated the database schema outputs (39 files).
- Added a release-readiness audit that clearly separates passing source-level tests from blocked live acceptance work.
- Confirmed the API build remains blocked by missing npm dependencies, absent lockfile/cache, and npm registry DNS `EAI_AGAIN`; no successful build or installer is claimed.

## 0.103.0 — 2026-11-15
- Extended the read-only server build preflight with a bounded HTTP `/-/ping` probe after DNS resolution, distinguishing DNS, HTTP 5xx, transport, and authentication-required responses.
- Removed URL credentials, query parameters, and fragments before the probe; diagnostic output does not disclose registry secrets.
- Added regression tests for DNS-success/HTTP-failure and authentication-required registry responses.
- Fixed a stale version in `desktop/app/package.json` discovered by the full Python integration suite; all six manifests and the visible browser label now align.
- Verified 122 Node tests, 251 Python application tests, and 93 database tests. The API build remains blocked by missing dependencies, missing lockfile/cache, and registry DNS `EAI_AGAIN`.

## Stage 109 — Stock transfer API foundation
- Added branch-scoped transfer list/detail, draft creation, line entry, posting and draft cancellation API routes.
- Reused the existing schema posting trigger for transfer ledger movements and destination batches.
- Added 5 focused API contract tests.
- Build/runtime and installer/mobile acceptance remain unverified; see STAGE109_RELEASE.txt.

## 0.128.0 — Stage 128
- Added atomic draft-voucher allocation replacement and individual allocation deletion endpoints.
- Added branch-scoped allocation audit history using the existing immutable audit log.
- Kept posted and installment-linked allocations protected from generic edits.
- Corrected reservation calculations to count other draft allocations only, avoiding double-counting posted receipts already reflected in invoice balances.

## Stage 130 — npm cache coverage audit (2026-11-15)
- Added a read-only `audit:server-cache` command to inspect npm's actual cached package metadata and tarballs for every direct server dependency.
- When a valid `package-lock.json` exists, the audit also checks every resolved lockfile tarball against the cache; without a lockfile it explicitly refuses to claim transitive cache completeness.
- Added focused tests for scoped package names, direct dependency coverage, missing lockfile coverage, and missing tarballs.
- This is a diagnostic improvement only. It does not create a lockfile, install dependencies, or claim a successful TypeScript build.
