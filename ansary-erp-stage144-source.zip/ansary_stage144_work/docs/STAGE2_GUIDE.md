# Continuing with Stage 2 - Login, security, user permissions

## How to continue
Open a new session, upload `ansary-erp-stage1.zip`, and say: *"Continue ANSARY ERP with Stage 2 using the same architecture. Do not rebuild or change the database design; first run the Stage 1 tests, then run the PostgreSQL tests and fix any PostgreSQL issues in `tools/schema/`."*

## Step 0 (before any Stage 2 code)
1. Extract, run `python -m unittest discover -s database/tests -v` -> must be 80/80.
2. On a machine with PostgreSQL >= 14 run the three PG commands from README. Fix anything found **in `tools/schema/*.py`**, rebuild, re-test. Record the result in CHANGELOG.

## Stage 2 scope (server/ + shared/)
* Node.js 20 + TypeScript project; `server/` Express/Fastify REST API, `shared/` types + permission constants (generated from `database/seed`).
* Data-access layer that works on **both** PostgreSQL (`pg`) and SQLite (`better-sqlite3`) with one repository interface; migrations run by the existing runners.
* **First-run setup wizard** endpoint: create company profile + set the `admin` password (currently `'!'` = locked). No default password.
* Passwords: Argon2id (`password_algo`), min length from `settings`, `must_change_password`, lockout using `failed_attempts`/`locked_until` (settings `security.*`).
* Sessions: opaque random token, only SHA-256 stored in `user_sessions.token_hash`; idle timeout from `users.session_timeout_minutes`; revoke on logout/password change.
* RBAC middleware: effective permissions = role permissions +/- `user_permission_overrides`; branch scope from `user_branches`.
* Endpoints: login/logout/refresh, change password, users CRUD, activate/deactivate, roles & permission matrix, login history, activity/audit log queries.
* Writes to `login_history`; user changes are audited by DB triggers already.
* Tests: unit + API integration tests (lockout, expiry, permission denial, last-super-admin protection, audit entries).

## Acceptance for Stage 2
Run app on SQLite and PostgreSQL; all Stage 1 + Stage 2 tests green; a Viewer cannot call a posting endpoint; deactivating a user kills their sessions; no password or hash ever appears in logs/audit.
