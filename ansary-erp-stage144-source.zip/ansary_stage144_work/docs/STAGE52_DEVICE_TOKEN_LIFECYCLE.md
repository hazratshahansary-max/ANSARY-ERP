# Stage 52 — Device token rotation and revocation

## Endpoints

All endpoints require the existing authenticated API session and enforce the
user's branch membership for the target device.

- `POST /api/sync/devices/:deviceId/rotate-token`: rotates an active device's
  secret. The new raw token is returned once; only its SHA-256 digest is stored.
  A revoked device cannot be rotated (HTTP 409); it must be re-enrolled.
- `POST /api/sync/devices/:deviceId/revoke`: revokes the device and clears its
  token digest. Repeated revocation is idempotent.

Each successful lifecycle change writes an audit row with device, actor, action,
and timestamp. Raw tokens are never included in audit rows or list responses.

## Operational notes

After rotation, the old token stops authenticating immediately. The operator
must securely replace the token on the intended device. If a token is lost,
revoke the device and enroll it again. Existing push and master-apply routes
continue to require the device token. This stage does not add a UI for device
management and does not claim a live production-server test.
