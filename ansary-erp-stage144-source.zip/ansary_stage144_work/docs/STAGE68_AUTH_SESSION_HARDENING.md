# Stage 68 — Authentication and Session Hardening

## What changed

### Failed login lockout

`failedLoginUpdate` builds one conditional SQL update against the canonical `users` fields (`failed_attempts`, `locked_until`, `is_active`, `deleted_at`). The database increments the counter atomically. If a lock is still active, the update does not match and therefore does not extend the lock. Once the old lock expires, the next failed attempt starts the counter at 1. Threshold and duration values are clamped.

### Session expiry

`sessionExpiryReason` checks absolute expiry and idle expiry. Invalid dates, invalid timeout values, future activity timestamps, or an expiry earlier than last activity fail closed. `AuthService.authenticate` revokes expired sessions with `session_expired` or `idle_timeout`; inactive/deleted users have their sessions revoked with `user_inactive`. Session activity updates only when the session is still active and has not passed absolute expiry.

### Transactional security changes

Successful login groups failed-counter reset, session insertion, and successful login-history insertion in a database transaction. User deactivation and password changes revoke sessions in the same transaction as the corresponding account change.

### Schema contract

The API's login history returns `created_at AS attempted_at`; it no longer assumes a physical `attempted_at` column. Auth queries use canonical schema names including `default_branch_id`, `failed_attempts`, `last_seen_at`, and `revoked_reason`.

## Test commands

```bash
node --test server/src/auth/sessionPolicy.test.js server/tests/auth-schema-contract.test.js
python -m unittest tests.test_stage68_auth_session -v
```

## Limitations

These tests validate policy logic and the exact failed-login SQL against SQLite. They do not prove the TypeScript server builds, the HTTP routes run, or PostgreSQL behaves identically under live concurrent load. Those remain separate release gates.
