# Stage 20 — Workspace and integration hardening

## Included

- Added the missing `desktop/package.json` so every root npm workspace has a valid package manifest.
- Corrected the Express type package from `@types/express` 5.x to 4.x to match the Express 4 runtime dependency.
- Added root scripts for the browser JavaScript syntax check and Python test discovery.
- Replaced stale client/desktop workspace READMEs with current run instructions and explicit limitations.
- Added workspace contract tests covering package manifests, Express/type compatibility, and the Pashto RTL browser entry point.

## Validation

The workspace contract tests and browser JavaScript syntax check can run without installing npm dependencies. Python database and feature suites are run separately and are not a substitute for a TypeScript build or live API test.

## Still not verified / not implemented

- npm dependency installation and TypeScript compilation (the dependency installation attempt timed out in this environment).
- Live Express API integration against a migrated SQLite database.
- PostgreSQL migrations and runtime behavior.
- Browser end-to-end workflows.
- Customer/supplier CRUD forms and browser-side invoice posting controls.
- Offline browser mode, desktop wrapper/installer, Windows 7 compatibility, and Android APK.

Do not deploy publicly until dependency installation, TypeScript build, authenticated API tests, database migration checks, TLS, rate limiting, and production CORS/secrets are validated.
