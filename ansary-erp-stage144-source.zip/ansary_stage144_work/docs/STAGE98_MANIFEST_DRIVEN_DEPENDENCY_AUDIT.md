# Stage 98 — Manifest-driven server dependency audit

## Change
The environment doctor previously used a hard-coded list of server packages. That list could become stale when a dependency was added or removed from `server/package.json`, potentially reporting an inaccurate build-readiness result.

The doctor now reads `dependencies` and `devDependencies` directly from the server manifest and audits every declared package. The JSON report includes each package's requested version range, installation status, detected installed version when available, and resolved path. Aggregate installed/required counts are also included.

## Validation
- Added a regression test proving newly declared runtime and development dependencies are both audited.
- Confirmed a locally present package is resolved and its installed version is reported.
- Confirmed an absent declared package is listed as a blocker.

## Limitations
This audit improves accuracy; it does not install packages or bypass network restrictions. The real API build still requires a complete npm lockfile and dependencies. The current environment's npm registry lookup previously failed with `EAI_AGAIN`, so no successful dependency installation or live API claim is made.
