# Stage 42 — master-data delete tombstones

Stage 42 adds durable versioned tombstones for hard-deleted master records in
`categories`, `companies`, `medicines`, `customers`, and `suppliers`.

Migration `018_sync_master_tombstones.sql` creates `sync_master_tombstones` and
replaces the five local delete triggers. Each trigger captures `OLD.version`
inside the delete transaction. The HTTP sync client sends a delete event only
when this exact versioned tombstone exists; it never guesses a version for old
pending delete rows. The tombstone is removed only after the relay explicitly
acknowledges the event. Financial and inventory tables remain excluded.

Apply migrations with:

```bash
python scripts/migrate_sqlite.py data/ansary.db
```

Then run a sync cycle as documented in `STAGE40_RELEASE.txt`, using the
registered device ID and access token. This stage has automated SQLite tests;
it does not claim a live server or two-device end-to-end test.
