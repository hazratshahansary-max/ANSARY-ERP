# Stage 96 — Runtime preflight before server dependency installation

The server dependency setup command now checks the local runtime before it attempts to install packages.

- Node.js must satisfy the project engine minimum (`>=20.0.0`).
- npm must satisfy the project engine minimum (`>=10.0.0`).
- npm version detection is bounded to five seconds.
- If npm is missing or either version cannot be parsed, installation is not started.
- The machine-readable `SERVER_DEPENDENCY_SETUP_REPORT.json` records the detected versions and a clear runtime failure code.
- A passing runtime check is included in later lockfile and install reports.

This preflight does not install or upgrade Node.js/npm. It prevents a dependency install from starting under an unsupported runtime. It does not prove that server dependencies can be downloaded or that TypeScript can build.
