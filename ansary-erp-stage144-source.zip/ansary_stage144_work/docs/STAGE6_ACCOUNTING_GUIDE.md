# Stage 6 — Accounting & Finance foundation

This stage adds an authenticated accounting API over the existing accounting schema.

## Endpoints

- `GET /api/accounting/accounts` — chart of accounts (`accounts.view`).
- `GET /api/accounting/journals` — journal list for assigned branches (`accounts.view`).
- `POST /api/accounting/journals` — create a balanced **draft** journal (`accounts.journal`).
- `GET /api/accounting/journals/:id` — journal header and lines (`accounts.view`).
- `GET /api/accounting/expenses` and `POST /api/accounting/expenses` — expense drafts (`expense.view`, `expense.create`).
- `GET /api/accounting/payments` and `POST /api/accounting/payments` — receipt/payment drafts (`accounts.view`, `accounts.voucher`).
- `GET /api/accounting/reports/trial-balance` — posted journal balances only (`reports.financial`).

## Important safety boundary

Posting is deliberately not exposed in this stage. The current `DatabaseAdapter` has no transaction API, so multi-row posting of journal entries, stock movements, invoice balances and payment allocations cannot yet be made atomic. Do not manually change draft records to `posted`. A later stage must add adapter-level transactions for both SQLite and PostgreSQL, then implement idempotent posting, reversal and allocation workflows.

## Migration source

This stage reuses the existing canonical accounting and payments/expenses migrations. No existing table or migration is removed or rewritten.

## Validation still required

Run the server TypeScript build and integration tests against both SQLite and PostgreSQL in the target environment. The current chat environment may not have the Node dependencies or a PostgreSQL service installed.
