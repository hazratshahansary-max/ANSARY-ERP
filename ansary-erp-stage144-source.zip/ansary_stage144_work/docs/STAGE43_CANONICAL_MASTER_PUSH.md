# Stage 43 — canonical server apply before outbound relay

## Flow

1. The client creates/persists a stable `event_uuid` and `base_version` in `sync_outbox` before network I/O.
2. It submits the batch to authenticated `POST /api/sync/apply-master`.
3. The client validates that the response contains exactly one result for each submitted event.
4. `applied` events and `duplicate` events whose `original_status` is `applied` are eligible for relay.
5. `conflict` events, and duplicates whose original status was conflict, remain pending locally and are not sent to `/api/sync/push`.
6. Eligible events are sent to `/api/sync/push`; only event UUIDs returned in `acknowledged` are marked `sent`.

## Retry behavior

The same event UUID and base version are persisted before sending. If server apply succeeds but the response is lost, the next run retries the same event. The server apply endpoint's event UUID log makes this idempotent. If relay fails after apply, the client can safely retry apply (receiving an applied duplicate) and then retry relay.

## Scope and limitations

- Supported master tables: `categories`, `companies`, `medicines`, `customers`, `suppliers`.
- Financial and stock tables remain excluded.
- A server-side version conflict is retained in the local outbox with `MASTER_VERSION_CONFLICT`; automatic conflict resolution is not attempted.
- The relay acknowledgement means the event was accepted into the relay, not that another device applied it.
- Regression tests use mocked HTTP responses. No live Express API, PostgreSQL, or two-device end-to-end test was run.

## Verification

- `python -m unittest discover -s database/tests -v`: 80 passed.
- `python -m unittest discover -s tests -v`: 143 passed.
- `python -m py_compile scripts/sync_http_client.py scripts/sync_pull_apply.py`: passed.
