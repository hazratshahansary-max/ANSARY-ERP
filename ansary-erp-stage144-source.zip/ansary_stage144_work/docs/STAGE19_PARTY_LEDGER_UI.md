# Stage 19 — Browser-integrated customer and supplier ledgers

Stage 19 connects party-account reporting to the authenticated browser client.

## API

Both endpoints require a valid bearer token and the `reports.view` permission.

- `GET /api/reports/party-ledgers?type=customer|supplier&search=...&branchId=...`
  - Returns account code, party name, phone, currency, opening balance, debit,
    credit, and journal movement balance.
  - Customers are restricted to global customers (`branch_id IS NULL`) and
    customers assigned to a branch the user can access. Suppliers are global.
  - Journal movements are limited to the user's authorized branches.
- `GET /api/reports/party-ledgers/:type/:partyId?from=YYYY-MM-DD&to=YYYY-MM-DD&branchId=...`
  - Returns chronological journal rows, running balance, totals, and party data.
  - Date range and branch access are validated by the API.
  - Only posted/reversed journal entries are included. Draft entries are not shown.

The ledger movement uses debit-minus-credit for customers and credit-minus-debit
for suppliers. The `opening_balance` master-data field is shown separately. The
`opening` voucher type is excluded from movement so the opening amount is not
displayed twice. Reversal entries remain visible in journal movement.

## Browser client

After login, open **حسابونه** in the sidebar. Choose customers or suppliers,
search by name/code/phone, and open **تفصیل** on a party row. The detail panel
supports a date range and a print action. The print action opens a new A4
landscape RTL statement window and invokes the browser print dialog. Choose
**Save as PDF** to create a PDF. Allow pop-ups for the client origin.

## Validation and limits

- Client JavaScript syntax check passes.
- Four Stage 19 SQLite regression tests cover branch-scoped movements, opening
  voucher exclusion, customer balance direction, and supplier balance direction.
- Existing Python test suites pass (112 total).
- The TypeScript server build and live HTTP integration are not validated in this
  environment because Node dependencies and type packages are not installed.
- PostgreSQL runtime tests, browser manual QA, native PDF generation, and Windows/
  Android packaging remain pending.
