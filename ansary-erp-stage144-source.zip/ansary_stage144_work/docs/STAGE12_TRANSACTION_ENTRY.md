# Stage 12 — Transaction entry screens

## Added
- Pashto navigation entries for customers, suppliers, purchases, and sales.
- Customer and supplier read-only lists backed by existing authenticated API routes.
- Purchase draft creation form using the authenticated user's first assigned branch.
- Purchase draft item-entry form for medicine, batch number, expiry, quantity, free quantity, and unit purchase price.
- Sales draft creation form with sale type, payment type, customer, invoice date, and due date.
- Recent purchase and sales invoice lists.
- Responsive form-grid styling.

## Safety / functional boundaries
- Purchase invoices and their lines remain drafts. No purchase posting endpoint is implemented; therefore this screen does not claim to add stock.
- Sales invoices remain drafts. Sales posting endpoint deliberately returns HTTP 501; no stock deduction or accounting/payment posting occurs.
- Sales line entry is not exposed because the current UI/API combination does not yet provide a branch-scoped batch picker. Do not treat a sales draft as a completed sale.
- Customer and supplier screens are read-only. Create/edit forms are not implemented.
- This browser client requires the API server and internet/local network connection. It is not an offline-first client yet.
- Branch selection currently uses the first branch assigned to the signed-in user; a branch selector is still needed for multi-branch users.

## Validation
- `node --check client/src/app.js` passed.
- SQLite schema tests: 80 passed.
- Backup/restore tests: 4 passed.
- Sync primitive tests: 6 passed.
- These tests do not constitute end-to-end API/browser tests. The TypeScript server build, live database workflow, and Windows/Android packaging remain unverified.
