# Stage 54 — Canonical sync migration audit correction

## Finding

The Stage 53 audit reported a blocked API/schema contract because it scanned
`server/db/migrations/postgres`. That directory is explicitly documented as a
legacy, superseded snapshot and is not used by the active migration runners.
The active migration sources are `database/sqlite/migrations` and
`database/postgres/migrations`.

The Stage 54 audit now reads both canonical migration directories and collects
columns from both `CREATE TABLE` definitions and incremental `ALTER TABLE ...
ADD COLUMN` migrations. This matters for `sync_devices.last_delivered_seq` and
`sync_devices.token_sha256`, which are added after the base table definition.

## Result

Both canonical dialects satisfy the static API contract for:

- `sync_devices` including `last_acked_seq`, `last_delivered_seq`,
  `is_revoked`, and `token_sha256`;
- `sync_events` including its event identity, branch, device, actor, payload,
  operation and sequence fields;
- `sync_device_token_audit` including actor, action and timestamp fields.

The report status is `ready-for-runtime-tests` with no statically detected
missing fields. The legacy `server/db/migrations` snapshot is explicitly
excluded.

## Verification limits

This is a static source/migration audit plus a fresh SQLite migration run. It is
not proof of a live PostgreSQL deployment, API request behavior, or two-device
sync. Those require disposable PostgreSQL and API integration environments.
No financial or inventory event application has been enabled.
