# Stage 77 — Build a portable Windows x64 API deployment package

## Why this stage exists

The current development environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN`) and has no populated npm cache. It is therefore not possible to truthfully generate a dependency lockfile or compile the API here. Stage 77 adds a repeatable workflow that must be run on an internet-connected Windows x64 computer.

## Requirements

- Windows 10/11 x64 (this workflow does not claim Windows 7 support)
- Node.js 20+ x64
- npm 10+
- Internet access to the configured npm registry
- PowerShell 5.1 or newer

## Create the deployment ZIP

From the project root in PowerShell:

```powershell
npm run prepare:offline-api:windows
```

The script:

1. Creates an isolated API source bundle under `release/server-stage77`.
2. Installs its production and development dependencies and generates `package-lock.json`.
3. Compiles the TypeScript API into `dist/`.
4. Removes development-only dependencies while preserving runtime dependencies.
5. Verifies the lockfile, compiled entrypoint, environment template, and required runtime modules.
6. Writes `ANSARY_DEPLOYMENT_MANIFEST.json` with the Windows/Node/npm architecture metadata.
7. Creates `release/ansary-erp-api-windows-x64-offline.zip` and a SHA-256 sidecar file.

The resulting package is intended for the same platform and architecture on which it was built. Native modules such as `argon2` and `better-sqlite3` are platform-specific. Do not transfer this Windows x64 package to Linux, macOS, ARM, or 32-bit Windows.

## Validation

The verifier can also be run manually:

```powershell
node scripts/verify-offline-api-bundle.mjs release/server-stage77 --write-manifest
```

## Important limitations

- The workflow has not been executed in this Linux sandbox because npm registry DNS resolution fails here.
- A generated deployment ZIP is not proof of a production-ready application; after deployment, test `/health/live`, `/health/ready`, login, database writes, backups, and sync.
- PostgreSQL requires a separately configured PostgreSQL server and connection string.
- Windows 7 32-bit is not supported or verified by this workflow.
