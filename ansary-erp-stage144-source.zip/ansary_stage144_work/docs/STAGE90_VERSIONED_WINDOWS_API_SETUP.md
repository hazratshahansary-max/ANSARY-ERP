# Stage 90 — Version-driven Windows API setup

The Windows x64 API preparation workflow previously contained fixed Stage 84 paths and report metadata even though later source bundles were named for newer stages. That mismatch could cause a newer project to prepare, transfer, or report against the wrong release directory.

The script now reads the root `package.json` version and derives:

- `release/server-stageN` source bundle path;
- stage-specific API ZIP name;
- stage-specific setup log and JSON report paths;
- report format identifier, numeric stage, and semantic version.

The standalone API bundle generator uses the same root version when writing offline Windows transfer instructions. The generic dependency setup JSON report also reads the version from the root manifest.

## Validation boundary

Automated contract tests verify that paths and metadata are version-derived and that generated README instructions match the current stage. This is not equivalent to executing PowerShell on Windows. A connected Windows x64 run, npm install, TypeScript build, native-module packaging, and live API test remain outstanding.
