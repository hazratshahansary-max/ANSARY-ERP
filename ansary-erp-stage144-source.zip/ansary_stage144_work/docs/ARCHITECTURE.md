# ANSARY ERP - Architecture (frozen for all 12 stages)

## Technology
| Layer | Choice |
|---|---|
| Frontend | React + TypeScript (desktop-style ERP UI, English/Pashto RTL) |
| Backend | Node.js + secure REST API (+ WebSocket/SSE fed by PostgreSQL `LISTEN ansary_changes`) |
| Cloud DB | PostgreSQL >= 14 |
| Offline DB | SQLite >= 3.39 (needs RETURNING, generated columns, UPDATE..FROM, IS DISTINCT FROM) |
| Desktop | Electron (separate legacy build needed for Windows 7) |
| Android | Responsive PWA first; optional Capacitor wrapper |

## Decisions that later stages must not change
1. **One schema definition, two dialects.** `tools/schema/` generates PG and SQLite DDL, triggers and views.
2. **UUID primary keys** (`uuid` / lower-case text). Needed so offline devices can create rows without collisions. `currencies` uses its ISO code.
3. **Money = NUMERIC, never float, in application code use a decimal library** (decimal.js / Decimal). Base currency AFN; every document stores `currency_code` + `exchange_rate`; journal amounts are in base currency with the foreign amount kept on the line.
4. **Posting is enforced by the database.** Documents are created `draft`, become `posted` by a status change; triggers then create stock movements, batches, cost snapshots and verify totals. Posted rows are immutable; only a reversal changes history.
5. **Stock = immutable ledger.** `stock_movements` is append-only; `batches.qty_on_hand` is derived (trigger) and has `CHECK >= 0` (negative stock impossible).
6. **Costing = batch-specific (specific identification).** Each batch has `unit_cost`; re-purchasing the same batch re-averages that batch only. Sales freeze `cost_price`/`gross_profit` per line. Valuation = sum(qty x batch cost) and always equals ledger account 1100 (tested).
7. **Sub-ledgers via journal lines.** Customer/supplier balances = sum of posted journal lines tagged with `customer_id`/`supplier_id` (`v_customer_balance`, `v_supplier_balance`). Opening balances are posted as an `opening` journal entry; `opening_balance` on the party is the declared value for display.
8. **Document numbers** come from `number_sequences` keyed by branch + financial year + device code (`SI-HO-00-FY2026-000001`), so offline devices never collide.
9. **Derived columns are not synchronised** (`batches.qty_on_hand`, `last_movement_at`, user lock counters); movements are.

## Posting protocol (every service in Stages 3-7 must follow this exact order, inside ONE transaction)
```
BEGIN
 1  number   := UPDATE number_sequences SET next_number = next_number+1 ... RETURNING   (PG: next_doc_no())
 2  INSERT document (status='draft') + items (+ payment_allocations)
 3  INSERT journal_entries (draft, source_type=<table>, source_id=<doc id>, total_debit/credit) + journal_lines
 4  UPDATE journal_entries SET status='posted', posted_at, posted_by        -- DB verifies balance, FY open, accounts postable
 5  UPDATE <document> SET status='posted', posted_at, posted_by, journal_entry_id   -- DB verifies lines/totals/stock, writes movements
COMMIT   (any trigger error rolls back everything)
```
Reversal: post a mirror journal (`entry_kind='reversal'`, `reverses_entry_id`), mark the original journal `reversed`, then set the
document `status='reversed'` with `reversed_by/at/reason` and `reversal_entry_id`. The DB restores stock via `reversal` movements and refuses
when it would create negative stock, when posted returns/receipts still reference the document, or when the year is closed.

## Document lifecycle
`draft -> posted -> reversed` and `draft -> cancelled`. Anything else is rejected. `reversed` and `cancelled` are final.

## Module map (60 tables)
core (currencies, rates, branches, company profile, settings, tax, templates) · security (roles, permissions, users, sessions, login history, audit, attachments) ·
master (categories, dosage forms, units, companies, medicines, barcodes, price history, customers, suppliers) ·
accounting (financial years, numbering, chart of accounts, bank accounts, expense categories, journals) ·
inventory (batches, movements, adjustments, transfers, physical counts) · purchase (orders, GRN, invoices, returns) · sales (orders/quotations, invoices, returns) ·
vouchers (receipts, payments, contra, expense, income, allocations) · system (backup history, sync conflicts, sync log).
Full column catalog: [DATABASE_CATALOG.md](DATABASE_CATALOG.md).

## Known Stage-1 limitations (tracked, not hidden)
* PostgreSQL files not executed yet (see README).
* Stock transfers post in one step (no in-transit state yet). Credit-limit enforcement and costing-policy options are application-level (Stage 5).
* Goods-receipt notes are informational; the purchase invoice moves stock.
* Report logic beyond the 10 views (aging, cash-flow statement, balance sheet) arrives in Stages 7-8 on top of the journal.
* Pashto sort/collation for PG needs an ICU collation chosen at deployment.
