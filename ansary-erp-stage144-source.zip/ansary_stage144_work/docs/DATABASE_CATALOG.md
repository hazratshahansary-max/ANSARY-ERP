# ANSARY ERP - Database catalog

_Generated from `tools/schema/tables.py`. 64 tables per dialect (+ dialect-specific sync infrastructure)._

Sync mode: **full** = versioned, synchronised; **append** = insert-only, synchronised; **none** = device-local.

## Module: core

### `currencies`  (sync: full)

Supported currencies; exactly one base currency (AFN).

| Column | Type | Null | Notes |
|---|---|---|---|
| code | text |  | PK; check `length(code) = 3` |
| name | text |  |  |
| name_ps | text | yes |  |
| symbol | text |  |  |
| decimals | integer |  | check `decimals BETWEEN 0 AND 4` |
| is_base | boolean |  |  |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `exchange_rates`  (sync: full)

Exchange rate history (1 unit of from_currency = rate units of to_currency).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| from_currency | text |  | FK -> currencies.code |
| to_currency | text |  | FK -> currencies.code |
| rate | numeric(18,8) |  | check `rate > 0` |
| effective_date | date |  |  |
| source | text |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `branches`  (sync: full, soft-delete)

Business branches.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| address | text | yes |  |
| phone | text | yes |  |
| email | text | yes |  |
| is_head_office | boolean |  |  |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `company_profile`  (sync: full)

Single-row company profile used on invoices and reports.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| singleton | integer |  | check `singleton = 1` |
| name | text |  |  |
| name_ps | text | yes |  |
| tagline | text | yes |  |
| logo_path | text | yes |  |
| address | text | yes |  |
| phone | text | yes |  |
| email | text | yes |  |
| website | text | yes |  |
| tax_number | text | yes |  |
| license_number | text | yes |  |
| base_currency | text |  | FK -> currencies.code |
| date_format | text |  |  |
| language | text |  | check `language IN ('en','ps')` |
| invoice_footer | text | yes |  |
| invoice_save_dir | text | yes |  |
| developer | text |  |  |
| brand | text |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `settings`  (sync: full)

Key/value configuration (global, per branch or per user).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| scope_type | text |  | check `scope_type IN ('global','branch','user')` |
| scope_id | text |  |  |
| key | text |  |  |
| value | text | yes |  |
| value_type | text |  | check `value_type IN ('string','int','decimal','bool','json')` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `tax_rates`  (sync: full)

Tax configuration.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| rate_pct | numeric(7,4) |  | check `rate_pct >= 0 AND rate_pct <= 100` |
| is_default | boolean |  |  |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `invoice_templates`  (sync: full)

Customisable invoice/label templates (A4, thermal).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| doc_type | text |  | check `doc_type IN ('sales_invoice','purchase_invoice','receipt','label','statement')` |
| paper | text |  | check `paper IN ('A4','A5','thermal80','thermal58','label')` |
| config | jsonb |  |  |
| is_default | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: security

### `roles`  (sync: full)

Role definitions (8 built-in roles).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| description | text | yes |  |
| is_system | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `permissions`  (sync: full)

Permission catalogue (module.action).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| module | text |  |  |
| action | text |  |  |
| description | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `role_permissions`  (sync: full)

Role to permission grants.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| role_id | uuid |  | FK -> roles |
| permission_id | uuid |  | FK -> permissions |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `users`  (sync: full, soft-delete)

User accounts (password stored only as a salted hash).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| username | text |  | check `username = lower(username)` |
| password_hash | text |  |  |
| password_algo | text |  |  |
| full_name | text |  |  |
| email | text | yes |  |
| phone | text | yes |  |
| role_id | uuid |  | FK -> roles |
| default_branch_id | uuid | yes | FK -> branches |
| language | text |  | check `language IN ('en','ps')` |
| is_active | boolean |  |  |
| must_change_password | boolean |  |  |
| failed_attempts | integer |  | check `failed_attempts >= 0` |
| locked_until | timestamptz | yes |  |
| last_login_at | timestamptz | yes |  |
| password_changed_at | timestamptz | yes |  |
| session_timeout_minutes | integer |  | check `session_timeout_minutes >= 1` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `user_branches`  (sync: full)

Branches a user may access.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| user_id | uuid |  | FK -> users |
| branch_id | uuid |  | FK -> branches |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `user_permission_overrides`  (sync: full)

Per-user grant/deny on top of the role.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| user_id | uuid |  | FK -> users |
| permission_id | uuid |  | FK -> permissions |
| granted | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `user_sessions`  (sync: none)

Active sessions (device-local, never synchronised).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| user_id | uuid |  | FK -> users |
| token_hash | text |  |  |
| device_id | text | yes |  |
| ip_address | text | yes |  |
| user_agent | text | yes |  |
| created_at | timestamptz |  |  |
| last_seen_at | timestamptz |  |  |
| expires_at | timestamptz |  |  |
| revoked_at | timestamptz | yes |  |
| revoked_reason | text | yes |  |

### `login_history`  (sync: append)

Every login attempt (append-only).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| user_id | uuid | yes | FK -> users |
| username_attempted | text |  |  |
| success | boolean |  |  |
| failure_reason | text | yes |  |
| ip_address | text | yes |  |
| user_agent | text | yes |  |
| device_id | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |

### `audit_log`  (sync: append)

Immutable transaction audit trail.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| user_id | uuid | yes | FK -> users |
| branch_id | uuid | yes | FK -> branches |
| action | text |  |  |
| entity_type | text |  |  |
| entity_id | text | yes |  |
| ref_no | text | yes |  |
| old_values | jsonb | yes |  |
| new_values | jsonb | yes |  |
| ip_address | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |

### `attachments`  (sync: full)

File attachments metadata (files live on disk/object store).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| entity_type | text |  |  |
| entity_id | text |  |  |
| file_name | text |  |  |
| mime_type | text | yes |  |
| storage_path | text |  |  |
| sha256 | text | yes |  |
| size_bytes | bigint | yes | check `size_bytes IS NULL OR size_bytes >= 0` |
| uploaded_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: master

### `categories`  (sync: full, soft-delete)

Medicine categories.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| name_ps | text | yes |  |
| parent_id | uuid | yes | FK -> categories |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `dosage_forms`  (sync: full)

Tablet, Syrup, Injection...

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| name_ps | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `units`  (sync: full)

Units of measure.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `companies`  (sync: full, soft-delete)

Manufacturers / companies.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| kind | text |  | check `kind IN ('manufacturer','distributor','both')` |
| country | text | yes |  |
| address | text | yes |  |
| phone | text | yes |  |
| email | text | yes |  |
| contact_person | text | yes |  |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `medicines`  (sync: full, soft-delete)

Medicine master (designed and tested for 100,000+ rows).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| product_code | text |  |  |
| barcode | text | yes |  |
| name | text |  |  |
| name_ps | text | yes |  |
| generic_name | text | yes |  |
| brand_name | text | yes |  |
| manufacturer_id | uuid | yes | FK -> companies |
| company_id | uuid | yes | FK -> companies |
| category_id | uuid | yes | FK -> categories |
| composition | text | yes |  |
| strength | text |  |  |
| dosage_form_id | uuid | yes | FK -> dosage_forms |
| packing | text |  |  |
| unit_id | uuid | yes | FK -> units |
| box_quantity | numeric(14,3) |  | check `box_quantity > 0` |
| purchase_price | numeric(18,4) |  | check `purchase_price >= 0` |
| wholesale_price | numeric(18,4) |  | check `wholesale_price >= 0` |
| retail_price | numeric(18,4) |  | check `retail_price >= 0` |
| min_stock | numeric(14,3) |  | check `min_stock >= 0` |
| max_stock | numeric(14,3) |  | check `max_stock >= 0` |
| rack_number | text | yes |  |
| country_of_origin | text | yes |  |
| registration_number | text | yes |  |
| image_attachment_id | uuid | yes | FK -> attachments |
| is_active | boolean |  |  |
| notes | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `medicine_barcodes`  (sync: full)

Additional barcodes / formats per medicine.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| medicine_id | uuid |  | FK -> medicines |
| barcode | text |  |  |
| barcode_format | text |  | check `barcode_format IN ('EAN13','EAN8','UPCA','CODE128','CODE39','QR','DATAMATRIX','OTHER')` |
| is_primary | boolean |  |  |
| pack_qty | numeric(14,3) |  | check `pack_qty > 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `medicine_price_history`  (sync: append)

Price changes (filled by trigger; append-only).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| medicine_id | uuid |  | FK -> medicines |
| old_purchase_price | numeric(18,4) |  | check `old_purchase_price >= 0` |
| new_purchase_price | numeric(18,4) |  | check `new_purchase_price >= 0` |
| old_wholesale_price | numeric(18,4) |  | check `old_wholesale_price >= 0` |
| new_wholesale_price | numeric(18,4) |  | check `new_wholesale_price >= 0` |
| old_retail_price | numeric(18,4) |  | check `old_retail_price >= 0` |
| new_retail_price | numeric(18,4) |  | check `new_retail_price >= 0` |
| changed_by | uuid | yes | FK -> users |
| reason | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |

### `customers`  (sync: full, soft-delete)

Customers (opening_balance > 0 means the customer owes us).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| business_name | text | yes |  |
| phone | text | yes |  |
| address | text | yes |  |
| customer_type | text |  | check `customer_type IN ('retail','wholesale')` |
| opening_balance | numeric(18,4) |  |  |
| opening_balance_date | date | yes |  |
| credit_limit | numeric(18,4) |  | check `credit_limit >= 0` |
| contact_person | text | yes |  |
| notes | text | yes |  |
| currency_code | text |  | FK -> currencies.code |
| branch_id | uuid | yes | FK -> branches |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

### `suppliers`  (sync: full, soft-delete)

Suppliers (opening_balance > 0 means we owe the supplier).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| business_name | text | yes |  |
| company_id | uuid | yes | FK -> companies |
| phone | text | yes |  |
| address | text | yes |  |
| opening_balance | numeric(18,4) |  |  |
| opening_balance_date | date | yes |  |
| contact_person | text | yes |  |
| notes | text | yes |  |
| currency_code | text |  | FK -> currencies.code |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |
| deleted_at | timestamptz | yes |  |

## Module: accounting

### `financial_years`  (sync: full)

Financial years; closed years reject postings.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| start_date | date |  |  |
| end_date | date |  |  |
| is_closed | boolean |  |  |
| closed_at | timestamptz | yes |  |
| closed_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `number_sequences`  (sync: full)

Per branch/device/year document numbering (prevents offline number collisions).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| doc_type | text |  |  |
| branch_id | uuid |  | FK -> branches |
| financial_year_id | uuid |  | FK -> financial_years |
| device_code | text |  |  |
| prefix | text |  |  |
| padding | integer |  | check `padding BETWEEN 1 AND 12` |
| next_number | bigint |  | check `next_number >= 1` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `accounts`  (sync: full)

Chart of accounts.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| code | text |  |  |
| name | text |  |  |
| name_ps | text | yes |  |
| account_type | text |  | check `account_type IN ('asset','liability','equity','income','expense')` |
| normal_side | text |  | check `normal_side IN ('debit','credit')` |
| parent_id | uuid | yes | FK -> accounts |
| system_key | text | yes |  |
| is_postable | boolean |  |  |
| is_system | boolean |  |  |
| is_active | boolean |  |  |
| cash_flow_category | text |  | check `cash_flow_category IN ('operating','investing','financing','cash','none')` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `bank_accounts`  (sync: full)

Bank accounts mapped to ledger accounts (bankbook).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid | yes | FK -> branches |
| account_id | uuid |  | FK -> accounts |
| bank_name | text |  |  |
| account_number | text | yes |  |
| currency_code | text |  | FK -> currencies.code |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `expense_categories`  (sync: full)

Expense categories mapped to expense accounts.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| name | text |  |  |
| name_ps | text | yes |  |
| account_id | uuid |  | FK -> accounts |
| is_active | boolean |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `journal_entries`  (sync: full)

Double-entry journal headers.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| entry_no | text |  |  |
| entry_date | date |  |  |
| financial_year_id | uuid |  | FK -> financial_years |
| entry_kind | text |  | check `entry_kind IN ('manual','sales','purchase','sales_return','purchase_return','receipt','payment','contra','expense','income','adjustment','opening','reversal','fx')` |
| source_type | text | yes |  |
| source_id | uuid | yes |  |
| description | text | yes |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| status | text |  | check `status IN ('draft', 'posted', 'reversed')` |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| reverses_entry_id | uuid | yes | FK -> journal_entries |
| total_debit | numeric(18,4) |  | check `total_debit >= 0` |
| total_credit | numeric(18,4) |  | check `total_credit >= 0` |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `journal_lines`  (sync: full)

Journal lines; customer_id/supplier_id give the sub-ledgers.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| entry_id | uuid |  | FK -> journal_entries |
| line_no | integer |  | check `line_no >= 1` |
| account_id | uuid |  | FK -> accounts |
| debit | numeric(18,4) |  | check `debit >= 0` |
| credit | numeric(18,4) |  | check `credit >= 0` |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| amount_fx | numeric(18,4) | yes |  |
| customer_id | uuid | yes | FK -> customers |
| supplier_id | uuid | yes | FK -> suppliers |
| branch_id | uuid | yes | FK -> branches |
| description | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: inventory

### `batches`  (sync: full)

Batch-level stock. qty_on_hand is derived from stock_movements by trigger.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| medicine_id | uuid |  | FK -> medicines |
| batch_no | text |  |  |
| mfg_date | date | yes |  |
| expiry_date | date |  |  |
| unit_cost | numeric(18,4) |  | check `unit_cost >= 0` |
| qty_on_hand | numeric(14,3) |  | check `qty_on_hand >= 0` |
| wholesale_price | numeric(18,4) | yes | check `wholesale_price IS NULL OR wholesale_price >= 0` |
| retail_price | numeric(18,4) | yes | check `retail_price IS NULL OR retail_price >= 0` |
| supplier_id | uuid | yes | FK -> suppliers |
| is_blocked | boolean |  |  |
| block_reason | text | yes |  |
| last_movement_at | timestamptz | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `stock_movements`  (sync: append)

Immutable stock ledger. Every stock change is a row here.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| batch_id | uuid |  | FK -> batches |
| medicine_id | uuid |  | FK -> medicines |
| movement_type | text |  | check `movement_type IN ('purchase','sale','sales_return','purchase_return','adjustment_in','adjustment_out','transfer_in','transfer_out','damaged','expired','opening','count_variance','reversal')` |
| quantity_change | numeric(14,3) |  | check `quantity_change <> 0` |
| unit_cost | numeric(18,4) |  | check `unit_cost >= 0` |
| movement_date | date |  |  |
| source_type | text |  |  |
| source_id | uuid |  |  |
| source_line_id | uuid |  |  |
| user_id | uuid | yes | FK -> users |
| notes | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |

### `stock_adjustments`  (sync: full)

Stock adjustments, damaged/expired write-offs, opening stock.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| adj_no | text |  |  |
| adj_date | date |  |  |
| adj_type | text |  | check `adj_type IN ('adjustment','damaged','expired','reconciliation','opening')` |
| reason | text | yes |  |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `stock_adjustment_items`  (sync: full)

Adjustment lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| adjustment_id | uuid |  | FK -> stock_adjustments |
| line_no | integer |  |  |
| batch_id | uuid |  | FK -> batches |
| quantity_change | numeric(14,3) |  | check `quantity_change <> 0` |
| unit_cost | numeric(18,4) |  | check `unit_cost >= 0` |
| reason | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `stock_transfers`  (sync: full)

Branch-to-branch stock transfers.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| transfer_no | text |  |  |
| from_branch_id | uuid |  | FK -> branches |
| to_branch_id | uuid |  | FK -> branches |
| transfer_date | date |  |  |
| status | text |  | check `status IN ('draft', 'posted', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `stock_transfer_items`  (sync: full)

Transfer lines (dest_batch_id set at posting).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| transfer_id | uuid |  | FK -> stock_transfers |
| line_no | integer |  |  |
| batch_id | uuid |  | FK -> batches |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| dest_batch_id | uuid | yes | FK -> batches |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `physical_counts`  (sync: full)

Physical stock verification sessions.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| count_no | text |  |  |
| count_date | date |  |  |
| status | text |  | check `status IN ('draft', 'in_progress', 'completed', 'reconciled', 'cancelled')` |
| adjustment_id | uuid | yes | FK -> stock_adjustments |
| notes | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `physical_count_items`  (sync: full)

Counted vs system quantity per batch.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| count_id | uuid |  | FK -> physical_counts |
| batch_id | uuid |  | FK -> batches |
| system_qty | numeric(14,3) |  | check `system_qty >= 0` |
| counted_qty | numeric(14,3) |  | check `counted_qty >= 0` |
| variance | numeric(14,3) | yes | generated: `counted_qty - system_qty` |
| notes | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: purchase

### `purchase_orders`  (sync: full)

Purchase orders.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| po_no | text |  |  |
| supplier_id | uuid |  | FK -> suppliers |
| po_date | date |  |  |
| expected_date | date | yes |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| status | text |  | check `status IN ('draft', 'confirmed', 'partially_received', 'received', 'cancelled')` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| total | numeric(18,4) |  | check `total >= 0` |
| notes | text | yes |  |
| created_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `purchase_order_items`  (sync: full)

PO lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| order_id | uuid |  | FK -> purchase_orders |
| line_no | integer |  |  |
| medicine_id | uuid |  | FK -> medicines |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| free_quantity | numeric(14,3) |  | check `free_quantity >= 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| discount_pct | numeric(7,4) |  | check `discount_pct >= 0 AND discount_pct <= 100` |
| tax_pct | numeric(7,4) |  | check `tax_pct >= 0 AND tax_pct <= 100` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| received_quantity | numeric(14,3) |  | check `received_quantity >= 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `goods_receipts`  (sync: full)

Goods receiving notes (do not move stock; the invoice does).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| grn_no | text |  |  |
| purchase_order_id | uuid | yes | FK -> purchase_orders |
| supplier_id | uuid |  | FK -> suppliers |
| receipt_date | date |  |  |
| status | text |  | check `status IN ('draft', 'confirmed', 'cancelled')` |
| notes | text | yes |  |
| received_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `goods_receipt_items`  (sync: full)

GRN lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| receipt_id | uuid |  | FK -> goods_receipts |
| line_no | integer |  |  |
| po_item_id | uuid | yes | FK -> purchase_order_items |
| medicine_id | uuid |  | FK -> medicines |
| batch_no | text |  |  |
| mfg_date | date | yes |  |
| expiry_date | date |  |  |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| free_quantity | numeric(14,3) |  | check `free_quantity >= 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `purchase_invoices`  (sync: full)

Purchase invoices; posting adds stock.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| invoice_no | text |  |  |
| supplier_id | uuid |  | FK -> suppliers |
| supplier_invoice_no | text |  |  |
| purchase_order_id | uuid | yes | FK -> purchase_orders |
| goods_receipt_id | uuid | yes | FK -> goods_receipts |
| invoice_date | date |  |  |
| due_date | date | yes |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| additional_costs | numeric(18,4) |  | check `additional_costs >= 0` |
| round_off | numeric(18,4) |  |  |
| total | numeric(18,4) |  | check `total >= 0` |
| paid_amount | numeric(18,4) |  | check `paid_amount >= 0` |
| payment_status | text |  | check `payment_status IN ('unpaid','partial','paid')` |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `purchase_invoice_items`  (sync: full)

Purchase lines with batch, expiry and landed cost.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| invoice_id | uuid |  | FK -> purchase_invoices |
| line_no | integer |  |  |
| medicine_id | uuid |  | FK -> medicines |
| batch_id | uuid | yes | FK -> batches |
| batch_no | text |  |  |
| mfg_date | date | yes |  |
| expiry_date | date |  |  |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| free_quantity | numeric(14,3) |  | check `free_quantity >= 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| discount_pct | numeric(7,4) |  | check `discount_pct >= 0 AND discount_pct <= 100` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_pct | numeric(7,4) |  | check `tax_pct >= 0 AND tax_pct <= 100` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| additional_cost | numeric(18,4) |  | check `additional_cost >= 0` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| landed_unit_cost | numeric(18,4) |  | check `landed_unit_cost >= 0` |
| po_item_id | uuid | yes | FK -> purchase_order_items |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `purchase_returns`  (sync: full)

Purchase returns / supplier debit notes against an original invoice.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| return_no | text |  |  |
| original_invoice_id | uuid |  | FK -> purchase_invoices |
| supplier_id | uuid |  | FK -> suppliers |
| return_date | date |  |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| total | numeric(18,4) |  | check `total >= 0` |
| reason | text | yes |  |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `purchase_return_items`  (sync: full)

Purchase return lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| return_id | uuid |  | FK -> purchase_returns |
| line_no | integer |  |  |
| original_item_id | uuid |  | FK -> purchase_invoice_items |
| batch_id | uuid |  | FK -> batches |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| cost_price | numeric(18,4) |  | check `cost_price >= 0` |
| reason | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: sales

### `sales_orders`  (sync: full)

Sales quotations and sales orders.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| doc_type | text |  | check `doc_type IN ('quotation','order')` |
| doc_no | text |  |  |
| customer_id | uuid |  | FK -> customers |
| doc_date | date |  |  |
| valid_until | date | yes |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| total | numeric(18,4) |  | check `total >= 0` |
| status | text |  | check `status IN ('draft', 'confirmed', 'converted', 'cancelled', 'expired')` |
| notes | text | yes |  |
| created_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `sales_order_items`  (sync: full)

Order/quotation lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| order_id | uuid |  | FK -> sales_orders |
| line_no | integer |  |  |
| medicine_id | uuid |  | FK -> medicines |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| free_quantity | numeric(14,3) |  | check `free_quantity >= 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| discount_pct | numeric(7,4) |  | check `discount_pct >= 0 AND discount_pct <= 100` |
| tax_pct | numeric(7,4) |  | check `tax_pct >= 0 AND tax_pct <= 100` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `sales_invoices`  (sync: full)

Sales invoices (retail/wholesale, cash/credit); posting reduces stock.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| invoice_no | text |  |  |
| sale_type | text |  | check `sale_type IN ('retail','wholesale')` |
| payment_type | text |  | check `payment_type IN ('cash','credit')` |
| customer_id | uuid | yes | FK -> customers |
| sales_order_id | uuid | yes | FK -> sales_orders |
| invoice_date | date |  |  |
| due_date | date | yes |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| round_off | numeric(18,4) |  |  |
| total | numeric(18,4) |  | check `total >= 0` |
| previous_balance | numeric(18,4) |  |  |
| paid_amount | numeric(18,4) |  | check `paid_amount >= 0` |
| payment_method | text | yes | check `payment_method IS NULL OR payment_method IN ('cash','bank','cheque','transfer','card')` |
| payment_status | text |  | check `payment_status IN ('unpaid','partial','paid')` |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| balance_due | numeric(18,4) | yes | generated: `total - paid_amount` |
| account_balance_after | numeric(18,4) | yes | generated: `previous_balance + total - paid_amount` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `sales_invoice_items`  (sync: full)

Sales lines; cost_price/gross_profit are frozen at posting.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| invoice_id | uuid |  | FK -> sales_invoices |
| line_no | integer |  |  |
| medicine_id | uuid |  | FK -> medicines |
| batch_id | uuid |  | FK -> batches |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| free_quantity | numeric(14,3) |  | check `free_quantity >= 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| discount_pct | numeric(7,4) |  | check `discount_pct >= 0 AND discount_pct <= 100` |
| discount_amount | numeric(18,4) |  | check `discount_amount >= 0` |
| tax_pct | numeric(7,4) |  | check `tax_pct >= 0 AND tax_pct <= 100` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| cost_price | numeric(18,4) |  | check `cost_price >= 0` |
| gross_profit | numeric(18,4) |  |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `sales_returns`  (sync: full)

Sales returns / customer credit notes against an original invoice.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| return_no | text |  |  |
| original_invoice_id | uuid |  | FK -> sales_invoices |
| customer_id | uuid | yes | FK -> customers |
| return_date | date |  |  |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| subtotal | numeric(18,4) |  | check `subtotal >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| total | numeric(18,4) |  | check `total >= 0` |
| refund_method | text |  | check `refund_method IN ('credit_note','cash','bank')` |
| reason | text | yes |  |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `sales_return_items`  (sync: full)

Sales return lines.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| return_id | uuid |  | FK -> sales_returns |
| line_no | integer |  |  |
| original_item_id | uuid |  | FK -> sales_invoice_items |
| batch_id | uuid |  | FK -> batches |
| quantity | numeric(14,3) |  | check `quantity > 0` |
| unit_price | numeric(18,4) |  | check `unit_price >= 0` |
| tax_amount | numeric(18,4) |  | check `tax_amount >= 0` |
| line_total | numeric(18,4) |  | check `line_total >= 0` |
| cost_price | numeric(18,4) |  | check `cost_price >= 0` |
| reason | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: vouchers

### `vouchers`  (sync: full)

Receipts, payments, contra, expense and income vouchers.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| voucher_no | text |  |  |
| voucher_type | text |  | check `voucher_type IN ('cash_receipt','cash_payment','customer_receipt','supplier_payment','contra','expense','income')` |
| voucher_date | date |  |  |
| customer_id | uuid | yes | FK -> customers |
| supplier_id | uuid | yes | FK -> suppliers |
| expense_category_id | uuid | yes | FK -> expense_categories |
| cash_bank_account_id | uuid |  | FK -> accounts |
| counter_account_id | uuid | yes | FK -> accounts |
| payment_method | text |  | check `payment_method IN ('cash','bank','cheque','transfer','card')` |
| amount | numeric(18,4) |  | check `amount > 0` |
| currency_code | text |  | FK -> currencies.code |
| exchange_rate | numeric(18,8) |  | check `exchange_rate > 0` |
| reference | text | yes |  |
| description | text | yes |  |
| attachment_id | uuid | yes | FK -> attachments |
| status | text |  | check `status IN ('draft', 'posted', 'reversed', 'cancelled')` |
| notes | text | yes |  |
| posted_at | timestamptz | yes |  |
| posted_by | uuid | yes | FK -> users |
| reversed_at | timestamptz | yes |  |
| reversed_by | uuid | yes | FK -> users |
| reversal_reason | text | yes |  |
| journal_entry_id | uuid | yes | FK -> journal_entries |
| reversal_entry_id | uuid | yes | FK -> journal_entries |
| client_uuid | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `payment_allocations`  (sync: full)

Settlement of invoices by receipts/payments.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| voucher_id | uuid |  | FK -> vouchers |
| sales_invoice_id | uuid | yes | FK -> sales_invoices |
| purchase_invoice_id | uuid | yes | FK -> purchase_invoices |
| amount | numeric(18,4) |  | check `amount > 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `installment_plans`  (sync: full)

Customer installment plans for posted credit sales invoices; one active plan record per invoice.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| sales_invoice_id | uuid |  | FK -> sales_invoices |
| customer_id | uuid |  | FK -> customers |
| plan_no | text |  |  |
| currency_code | text |  | FK -> currencies.code |
| principal_amount | numeric(18,4) |  | check `principal_amount >= 0` |
| installment_count | integer |  | check `installment_count BETWEEN 2 AND 60` |
| frequency | text |  | check `frequency IN ('weekly','biweekly','monthly')` |
| first_due_date | date |  |  |
| status | text |  | check `status IN ('active', 'completed', 'cancelled')` |
| notes | text | yes |  |
| created_by | uuid | yes | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `installment_schedule`  (sync: full)

Dated customer installment schedule; payment settlement integration is a later stage.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| plan_id | uuid |  | FK -> installment_plans |
| installment_no | integer |  | check `installment_no >= 1` |
| due_date | date |  |  |
| amount | numeric(18,4) |  | check `amount >= 0` |
| paid_amount | numeric(18,4) |  | check `paid_amount >= 0` |
| balance_due | numeric(18,4) | yes | generated: `amount - paid_amount` |
| status | text |  | check `status IN ('scheduled', 'partial', 'paid', 'overdue', 'cancelled')` |
| paid_at | timestamptz | yes |  |
| notes | text | yes |  |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

### `installment_payment_allocations`  (sync: full)

Draft customer receipt allocations to individual installment schedule rows; applied when voucher posts.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| voucher_id | uuid |  | FK -> vouchers |
| installment_schedule_id | uuid |  | FK -> installment_schedule |
| amount | numeric(18,4) |  | check `amount >= 0` |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |
| updated_at | timestamptz |  |  |
| version | integer |  | check `version >= 1` |

## Module: system

### `backup_history`  (sync: none)

Backup and restore history (device-local).

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| kind | text |  | check `kind IN ('manual','automatic','scheduled','pre_upgrade','pre_conflict','restore_point')` |
| location | text |  | check `location IN ('local','cloud')` |
| file_path | text |  |  |
| size_bytes | bigint | yes |  |
| sha256 | text | yes |  |
| status | text |  | check `status IN ('started','completed','failed','verified','restored')` |
| integrity_result | text | yes |  |
| started_at | timestamptz |  |  |
| finished_at | timestamptz | yes |  |
| created_by | uuid | yes | FK -> users |
| note | text | yes |  |

### `sync_conflicts`  (sync: none)

Detected synchronisation conflicts awaiting or recording resolution.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| table_name | text |  |  |
| row_id | text |  |  |
| device_id | text | yes |  |
| local_version | integer | yes |  |
| server_version | integer | yes |  |
| local_payload | jsonb | yes |  |
| server_payload | jsonb | yes |  |
| reason | text |  |  |
| detected_at | timestamptz |  |  |
| resolution | text |  | check `resolution IN ('pending','local_won','server_won','merged','dismissed')` |
| resolved_by | uuid | yes | FK -> users |
| resolved_at | timestamptz | yes |  |
| backup_ref | text | yes |  |

### `sync_log`  (sync: none)

One row per synchronisation run.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| device_id | text | yes |  |
| direction | text |  | check `direction IN ('push','pull','full')` |
| started_at | timestamptz |  |  |
| finished_at | timestamptz | yes |  |
| pushed | integer |  |  |
| pulled | integer |  |  |
| conflicts | integer |  |  |
| status | text |  | check `status IN ('started','ok','partial','failed')` |
| error | text | yes |  |

### `due_reminder_history`  (sync: append)

Append-only manual customer due-reminder history; records contact attempts but never sends messages.

| Column | Type | Null | Notes |
|---|---|---|---|
| id | uuid |  | PK |
| branch_id | uuid |  | FK -> branches |
| sales_invoice_id | uuid |  | FK -> sales_invoices |
| customer_id | uuid |  | FK -> customers |
| channel | text |  | check `channel IN ('phone','sms','email','whatsapp','in_person')` |
| outcome | text |  | check `outcome IN ('recorded','sent','failed')` |
| notes | text | yes |  |
| reminded_at | timestamptz |  |  |
| created_by | uuid |  | FK -> users |
| origin_device_id | text | yes |  |
| created_at | timestamptz |  |  |

