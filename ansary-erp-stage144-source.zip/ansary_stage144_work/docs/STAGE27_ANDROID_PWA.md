# Stage 27 — Android-ready Progressive Web App (PWA)

## Added
- Web app manifest with Pashto language and RTL direction.
- Installable PWA metadata and SVG application icon.
- Service worker that caches only the static application shell (HTML, CSS, JavaScript, manifest, icon).
- Network-first navigation with cached app-shell fallback.
- Cache-first static assets.
- Install prompt button when the browser supports `beforeinstallprompt`.
- Compact mobile header adjustments.

## Important offline boundary
This stage does **not** make the ERP data layer offline-capable. API requests, login, inventory, invoices, reports, and financial data are never cached. When offline, the application shell can open, but live ERP functions require the API connection. This is intentional to avoid stale or unsafe financial data and cached authentication responses.

## Install on Android
1. Deploy the client over HTTPS and make the API reachable through a secure HTTPS address.
2. Open the client URL in Chrome on Android.
3. Use the visible **اپ نصب کړه** button when Chrome offers installation, or Chrome menu → Install app / Add to Home screen.
4. Open the installed app. Sign-in and all data operations still require the API server.

## Local testing
The service worker is available on HTTPS or `localhost` only. From the client directory, run a static server and open `http://localhost:5173`. Verify manifest loading, service-worker activation, app-shell caching, and offline navigation in browser developer tools.

## Not included / not validated
- No Android APK/AAB has been generated.
- No Play Store package or signing key.
- No offline database, queued writes, or sync conflict handling in the UI.
- No Android device installation test was possible in this workspace.
- The API server and PostgreSQL production deployment remain separate prerequisites.
