# Stage 32 — Sync monitoring and potential conflict review

The browser client now includes a **د Sync څارنه** page. It calls two authenticated, branch-scoped API endpoints:

- `GET /api/sync/devices` — lists registered devices visible to the signed-in user's assigned branches, including platform, last seen, event count, acknowledgement cursor, and revoked status.
- `GET /api/sync/events?limit=200` — lists recent relay events, optionally filterable by `deviceId` and `tableName`. The limit is bounded to 200.

The page groups events by table and row ID and highlights rows that have events from more than one device. This is a **potential concurrent-change indicator only**, not a definitive conflict detector: the current relay does not maintain a canonical row version or apply event payloads to the business tables. The UI therefore does not offer a misleading “resolve” button.

Actual conflict resolution remains the local SQLite `ConflictResolver` from Stage 31. It is not connected to the central relay API or browser client. Do not use this monitor to make financial or inventory corrections.

## Validation

Run:

```bash
node --check client/src/app.js
node --check client/sw.js
python -m unittest discover -s database/tests -v
python -m unittest discover -s tests -v
```

The TypeScript server build and live API/database tests require the project dependencies and a configured test database. They are not certified by the source-contract and SQLite test suites.
