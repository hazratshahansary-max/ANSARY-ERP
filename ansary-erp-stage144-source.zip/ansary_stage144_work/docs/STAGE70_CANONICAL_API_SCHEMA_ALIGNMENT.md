# Stage 70 — Canonical API schema alignment

## Problems found in the Stage 69 review

1. PostgreSQL readiness incorrectly required SQLite-local `sync_state` and `sync_outbox` tables, even though PostgreSQL uses `change_log` as its server-side change feed.
2. The API's master-data apply route used `row_version`, while the canonical SQLite/PostgreSQL master tables use `version`.
3. The API master-data allowlist used several legacy names (`company_type`, `customer_code`, `supplier_code`, `tax_rate`, `image_path`) that do not match the canonical table columns (`kind`, `code`, and the current medicine columns).
4. The `/api/sync/apply-master` route writes to `sync_master_apply_log`, but that table was not present in the canonical migration set copied into the Stage 69 standalone bundle.

## Changes

- Added canonical migration `021_sync_master_apply_log.sql` for SQLite and PostgreSQL.
- Updated the schema generator so the new migration and full schema snapshots are reproducible.
- Made schema readiness dialect-aware:
  - SQLite requires `sync_state` and `sync_outbox`.
  - PostgreSQL requires `change_log` instead.
  - Both require `sync_master_apply_log` and `sync_device_token_audit`.
- Updated the master-data allowlist to use canonical column names.
- Updated optimistic locking to use the canonical `version` column.
- Excluded local-only/unsupported foreign-key references and opening-balance fields from the current master sync allowlist. Financial and stock tables remain excluded.
- Updated migration-count and schema-parity tests.

## Validation

- Node tests: 34 passed.
- Python project tests: 248 passed.
- Database tests: 82 passed.
- Schema generator check: passed (39 generated files current).
- SQLite migration runner: 23 migrations applied; idempotency and checksum tamper detection passed.
- SQLite integrity and foreign-key checks: passed.
- Desktop package contract: passed.
- Standalone API bundle regenerated with 23 SQLite and 22 PostgreSQL migrations.

## Not yet verified

- Full TypeScript build: blocked because npm dependencies and `@types/node` are not installed.
- npm registry access: DNS lookup for `registry.npmjs.org` failed (`EAI_AGAIN`).
- PostgreSQL migrations were reviewed and contract-tested but not applied to a live PostgreSQL server.
- Live HTTP API, multi-device sync, Windows installer, and Android APK are not yet runtime-verified.

This stage corrects identified source/schema mismatches. It is not a claim that the entire ERP is production-ready.
