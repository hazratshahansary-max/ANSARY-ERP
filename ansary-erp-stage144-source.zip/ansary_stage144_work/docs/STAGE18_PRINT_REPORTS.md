# Stage 18 — Printable party statements

This stage adds `scripts/render_party_statement.py`, which turns the JSON output of `scripts/party_ledger.py` into a standalone, print-ready A4 landscape HTML statement. It supports English (LTR) and Pashto (RTL), customer/supplier headings, party metadata, date period, separate opening balance, posted journal rows, debit/credit totals, movement balance, transaction count, empty-state display, HTML escaping, and a browser Print / Save as PDF action.

## Usage

```bash
python scripts/party_ledger.py app.db --type customer --party-id CUSTOMER_ID > ledger.json
python scripts/render_party_statement.py ledger.json customer-statement.html --lang ps
```

Open the HTML file in Chrome, Edge, or Firefox and choose **Print → Save as PDF**. The tool deliberately produces HTML rather than claiming a native PDF engine; browser print is the PDF export path. For Pashto glyph shaping and fonts, the browser/device must have a suitable Arabic/Pashto font installed.

## Scope

- This is a standalone report renderer, not yet wired into the web client or TypeScript API.
- Opening balance remains explicitly separate from period journal movement, matching Stage 17 behavior.
- This does not add an opening-balance posting/reconciliation process, receipt/invoice PDF endpoint, or Windows/Android package.
