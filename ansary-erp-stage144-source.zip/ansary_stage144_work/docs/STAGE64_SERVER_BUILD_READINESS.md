# Stage 64 — Server build readiness

## Purpose

Stage 63 added a real HTTP smoke harness, but its compiled server could not be produced because npm dependencies were unavailable. Stage 64 adds a read-only diagnostic so the next machine can distinguish a missing toolchain, missing dependencies, unpinned installation, workspace version drift, and npm registry DNS failure before attempting a build.

## Commands

From the repository root:

```bash
npm run preflight:server
npm --workspace @ansary-erp/server run test:build-preflight
npm install
npm run build:server
npm run smoke:server
```

`preflight:server` returns exit code 2 when any prerequisite is missing. It does not install packages or change database files. The preflight checks Node.js 20+, root/server package version alignment, the presence of a package-lock file, installed server runtime dependencies, the build script, and DNS resolution for `registry.npmjs.org`.

## Stage 64 execution notes

- Workspace package versions were aligned to 0.64.0.
- Node built-in tests cover the readiness evaluator using isolated temporary fixtures.
- An npm workspace install was attempted in the build environment but timed out. Therefore TypeScript build and live HTTP smoke tests remain unverified.
- Do not treat a successful preflight as proof that TypeScript compiles; it only establishes that the prerequisites appear available. The actual build and smoke test must still pass.
