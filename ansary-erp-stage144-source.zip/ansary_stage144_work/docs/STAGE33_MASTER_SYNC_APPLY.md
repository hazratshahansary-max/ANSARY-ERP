# Stage 33 — guarded master-data event application

## What this stage adds

- `scripts/sync_master_apply.py` applies a bounded set of versioned events to a local SQLite database.
- Supported tables are `categories`, `companies`, `medicines`, `customers`, and `suppliers`.
- Every table has a fixed writable-field allowlist. Client-provided SQL identifiers are never used.
- Updates require an exact `base_version`; successful updates increment the row version.
- Stale updates and duplicate inserts are recorded as conflicts rather than overwriting existing rows.
- Event UUIDs are recorded in `sync_master_apply_log` so a replay is acknowledged idempotently.
- Customer records are restricted to the selected branch.
- Deletes are soft deletes (`deleted_at`); hard deletes are never issued.
- The relay allowlist was corrected to use actual schema names (`categories`, `companies`).

## Deliberate exclusions

This utility rejects batches, stock movements, purchase/sales invoices, receipts, payments, and journal tables. It does not apply financial or stock events. It is a local SQLite utility, **not a live server endpoint**, not a complete replication protocol, and not a substitute for server authorization. It must not be used for stock or posted financial records.

## Run

Prepare a JSON array of event envelopes using the existing sync envelope fields (`event_uuid`, `table_name`, `row_id`, `op`, `base_version`, `payload`), then run:

```bash
python scripts/sync_master_apply.py data/ansary.db events.json --device-id DEVICE_UUID --branch-id BRANCH_ID
```

A first insert uses `op: "insert"` and `base_version: null` (or `0`). An update/delete must carry the exact current row version in `base_version`. Review the returned `conflicts` and the `sync_master_apply_log` table before retrying.

## Tests and remaining work

Run `python -m unittest tests.sync.test_sync_master_apply -v` and the full test suite. PostgreSQL application, authenticated HTTP integration, device transport, and two-device end-to-end sync are not implemented or tested in this stage.
