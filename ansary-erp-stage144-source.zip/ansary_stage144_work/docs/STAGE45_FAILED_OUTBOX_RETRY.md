# Stage 45 — controlled retry of failed master-data Sync events

Stage 45 adds `scripts/sync_retry_outbox.py`, an explicit local recovery tool for failed Sync outbox entries.

## Safety rules

- Only `categories`, `companies`, `medicines`, `customers`, and `suppliers` can be re-queued.
- Only rows whose status is exactly `failed` can be changed. `pending` and `sent` rows are untouched.
- The operator must pass `--confirm` after reviewing the selected sequence IDs.
- Event UUID, payload, base version, and attempt count are preserved so the server idempotency/version checks remain meaningful.
- A `sync_retry_audit` record is written in the same transaction as each state change.
- `--all-failed` is capped at 500 rows. Financial, inventory, and unsupported rows are rejected, not silently skipped.
- The command does not contact the server; it only re-queues entries. Run the normal authenticated sync client afterward.

## Usage

Retry one reviewed event:

```bash
python scripts/sync_retry_outbox.py data/ansary.db --seq 123 --confirm
```

Retry multiple reviewed events:

```bash
python scripts/sync_retry_outbox.py data/ansary.db --seq 123 --seq 127 --confirm
```

Retry all failed master-data entries (maximum 500):

```bash
python scripts/sync_retry_outbox.py data/ansary.db --all-failed --confirm
```

Then run the existing one-cycle HTTP sync command with the configured server/device credentials. A re-queued event is not proof of successful delivery; inspect the next Sync status report.

## Verification limits

Automated SQLite unit tests verify selection restrictions, preservation of event identity/payload/version/attempt count, audit logging, and rejection of financial or already-sent rows. This does not constitute a live API, PostgreSQL, Windows installer, Android, or two-device end-to-end test.
