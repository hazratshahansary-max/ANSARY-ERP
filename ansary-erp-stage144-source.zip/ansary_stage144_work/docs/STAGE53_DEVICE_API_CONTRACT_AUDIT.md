# Stage 53 — Device-management API contract audit

## Result: BLOCKED (static audit)

The existing `server/src/routes/sync.ts` contains device-management endpoints,
but its SQL contract does not match the checked-in PostgreSQL migration schema.
The migration defines `sync_devices.device_name` and `device_type`, while the
route uses `name` and `platform`. The route also references lifecycle and cursor
columns that are absent from the checked-in `sync_devices` migration. The
migrations do not define the `sync_events` and `sync_device_token_audit` tables
referenced by the route.

The audit is static only: it reads checked-in source and migration files. It
does not connect to, alter, or test a live database. No claim is made that the
current device-management endpoints work at runtime.

## Required before enabling device management

1. Design a forward-only migration for the missing sync device columns and
   event/audit tables, with SQLite and PostgreSQL parity.
2. Align registration/list/rotation/revocation SQL with the canonical column
   names and platform enum.
3. Add integration tests using disposable SQLite and PostgreSQL databases.
4. Verify branch scoping, token rotation/revocation, and event pagination.
5. Only then expose device-management controls in the UI.

Report: `reports/stage53-device-api-contract-audit.json`.
