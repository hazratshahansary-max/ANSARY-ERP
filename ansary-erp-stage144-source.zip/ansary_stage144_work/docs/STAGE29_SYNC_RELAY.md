# Stage 29 — authenticated sync event relay foundation

## Added
- `POST /api/sync/devices`: registers a named Windows/Android/Web/Server device for one of the authenticated user's assigned branches.
- `POST /api/sync/push`: accepts up to 100 idempotent event envelopes per request. Events are limited to an explicit business-table allowlist and 64 KiB JSON payloads.
- `GET /api/sync/pull`: returns up to 500 branch-scoped events after a cursor, excluding events originating from the requesting device.
- `POST /api/sync/ack`: records a monotonic per-device acknowledged cursor and rejects cursors ahead of the server.
- SQLite and PostgreSQL migration `015_sync_event_relay.sql` adds device/event relay storage.

## Security properties
- Every route requires a valid ERP bearer session.
- A device is restricted to a branch already assigned to the authenticated user.
- Revoked or unknown devices are rejected.
- Table names are checked against a fixed allowlist; payloads are bounded and schema-validated.
- `event_uuid` is unique for idempotent retries. Reusing another device's UUID is rejected.
- Events are stored as envelopes; they are not dynamically applied as SQL.

## Critical limitations
This is an authenticated **event relay**, not yet full database replication. The server stores and distributes change envelopes, but does not apply their payloads to business tables, perform authoritative version conflict resolution, or validate every payload against each table's business schema. Therefore it must not yet be used to synchronize posted financial transactions or production stock. Device-side `SyncEngine` still needs an HTTP transport adapter and an end-to-end test against a deployed server. PostgreSQL migration and live server tests are not run in this environment.

## Migration
SQLite: `python scripts/migrate_sqlite.py data/ansary.db`
PostgreSQL: apply `database/postgres/migrations/015_sync_event_relay.sql` after migrations 001–014.
