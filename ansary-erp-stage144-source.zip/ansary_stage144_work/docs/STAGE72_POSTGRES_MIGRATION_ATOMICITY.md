# Stage 72 — PostgreSQL migration atomicity and concurrency safety

## Problem addressed
The PostgreSQL runner previously checked whether a migration was applied in one `psql` session and applied it in another. Two installers starting at the same time could both observe a missing migration and race to execute the same DDL. The old loop also relied on separate command-line operations to associate the migration body with its checksum record.

## Changes
- Each migration now runs in one `psql` session and one explicit transaction.
- A transaction-scoped PostgreSQL advisory lock serializes migration runners.
- The applied-state check is made after acquiring the lock, preventing a concurrent runner from applying the same migration twice.
- Migration SQL and its SHA-256 ledger row commit together; on SQL failure, closing the `psql` session rolls the transaction back.
- Already-applied migrations are checked against their current SHA-256 checksum and fail closed if changed.
- Migration filenames are validated before being embedded in SQL.
- The runner checks for `psql`, the migration directory, non-empty migrations, required seed files, and unknown command-line options with clear errors.
- `PSQL_BIN` can select a non-default psql executable for controlled environments and tests.
- Added no-live-database contract tests using a fake `psql` executable.

## Validation scope
The fake-client tests validate runner orchestration, per-migration transaction boundaries, advisory-lock/checksum contract, stop-on-failure behavior, and argument validation. They do **not** prove PostgreSQL server compatibility or execute the SQL against a real PostgreSQL instance. A disposable PostgreSQL integration run remains required before production use.

## Run
```bash
python -m unittest database.tests.test_postgres_migration_runner -v
python -m unittest discover -s database/tests -v
```

Example:
```bash
PGHOST=127.0.0.1 PGPORT=5432 PGUSER=ansary PGDATABASE=ansary_erp \
  scripts/migrate_pg.sh ansary_erp --seed
```

Do not use `--sample` on a production database.
