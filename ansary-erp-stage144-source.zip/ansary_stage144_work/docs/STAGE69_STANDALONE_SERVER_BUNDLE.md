# Stage 69 — Standalone API source bundle

## Why

The root npm workspace contains Electron and client workspaces. The API server needs a smaller deployment surface and should not require installing the desktop application dependencies merely to build the HTTP API.

## What changed

- Added `scripts/package-server.mjs` to generate an isolated API source bundle.
- The bundle contains only server source, the canonical SQLite/PostgreSQL migration trees and seed data, the SQLite migration runner, and a standalone package manifest.
- Direct runtime and development dependency versions are pinned to exact versions derived from the server workspace manifest.
- The generated package has no npm workspaces and does not pull Electron or client dependencies.
- Added a safe output guard: existing directories are not overwritten unless `--force` is explicitly passed.
- Added `.env.example` and deployment notes.

## Build the source bundle

From the project root:

```bash
npm run package:server
```

Output: `release/server/`.

If that folder already exists, remove it manually or run:

```bash
node scripts/package-server.mjs release/server --force
```

## Build the API on a network-enabled machine

```bash
cd release/server
npm install --no-audit --no-fund
npm run build
```

Then apply the appropriate database migrations, configure environment variables, and run `npm start`.

## Validation boundary

The source bundle generator and its structure are tested locally. This environment has no cached npm package metadata and cannot resolve `registry.npmjs.org`; therefore it cannot create a lockfile, install dependencies, run the TypeScript compiler with real dependency types, or prove the API starts. The generated bundle is not an installer and not a tested production release.
