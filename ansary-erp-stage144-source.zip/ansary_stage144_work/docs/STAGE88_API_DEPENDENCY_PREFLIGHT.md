# Stage 88 — API dependency preflight

The API build now inspects every package declared in the server workspace's `dependencies` and `devDependencies` before starting TypeScript. Missing packages are reported together with the `SERVER_DEPENDENCIES_MISSING` prefix and an actionable instruction to install from the project root or use the prepared offline npm cache.

This check improves diagnosis; it does not install packages, bypass registry connectivity, or prove that the API can run. A successful build still requires the complete dependency tree, including native modules built for the target platform.
