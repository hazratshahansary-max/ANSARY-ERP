# Stage 14 — Purchase posting and stock receipt

## Implemented

- `POST /purchases/invoices/:id/post` requires `purchase.post` permission and a user-to-branch assignment.
- Refuses missing/empty drafts, expired batches, missing open financial year, and missing required system accounts.
- Creates a purchase journal using the seeded `INVENTORY`, `AP`, and (when tax is present) `TAX_INPUT` accounts.
- Posts the journal first, then posts the purchase invoice in one database transaction.
- Existing SQLite posting triggers create or update the batch and append immutable purchase stock movements. Free quantities are included in received stock.
- Returns posted invoice/journal identifiers and resulting received batches.

## Accounting treatment

The inventory debit is purchase total less input tax; input tax is debited separately when present; supplier payable is credited for the full invoice total. Values are translated to base currency using the invoice exchange rate. Supplier identity is attached to the AP journal line.

## Important limits

- This stage implements purchase posting only. Purchase returns, supplier payments/allocations, reversal workflow, and tax-policy configuration are separate work.
- PostgreSQL posting has not been integration-tested. The SQLite schema and posting-trigger behavior have been tested.
- The TypeScript server build has not been run because dependencies are not installed in this workspace.
