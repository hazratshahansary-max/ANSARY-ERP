# Stage 17 — Customer & supplier sub-ledger reports

## Delivered

- Added `scripts/party_ledger.py`, a read-only SQLite reporting utility for customer and supplier sub-ledgers.
- Party summary uses the database's authoritative `v_customer_balance` and `v_supplier_balance` views.
- Individual party ledger lists posted journal lines in date / entry / line order, including journal number, source, account, debit, credit, currency, exchange rate, and a running balance.
- Customer running balance is debit minus credit (amount owed by customer); supplier running balance is credit minus debit (amount owed to supplier).
- Supports inclusive date filters and optional branch filter for journal rows; rejects malformed/reversed date ranges and unknown parties.
- Supports JSON output and optional CSV export (UTF-8 with BOM for spreadsheet compatibility).
- Opening balance is displayed separately and is deliberately not added to the journal running balance. This avoids silently assuming the sign/ledger treatment of legacy opening balances; a later opening-balance posting workflow should reconcile it explicitly.

## Usage

Party summary:

```bash
python scripts/party_ledger.py ansary.db --type customer
python scripts/party_ledger.py ansary.db --type supplier
```

Individual statement:

```bash
python scripts/party_ledger.py ansary.db --type customer --party-id CUSTOMER_UUID --from-date 2026-01-01 --to-date 2026-12-31 --csv customer-ledger.csv
python scripts/party_ledger.py ansary.db --type supplier --party-id SUPPLIER_UUID
```

## Verification

```bash
python -m unittest discover -s tests/ledger -v
```

Six tests cover customer/supplier summaries against the existing balance views, chronological statements and running balances, invalid date ranges, and unknown parties.

## Limitations

- Read-only report utility; it does not create or modify transactions.
- Opening balance is separate from posted journal movement pending a defined opening-balance migration/posting rule.
- Supplier master data has no branch field in the current schema; branch filter applies to journal rows only.
- No browser UI, printable statement/PDF template, or TypeScript API integration is included.
- PostgreSQL runtime parity and full server build remain unverified.
