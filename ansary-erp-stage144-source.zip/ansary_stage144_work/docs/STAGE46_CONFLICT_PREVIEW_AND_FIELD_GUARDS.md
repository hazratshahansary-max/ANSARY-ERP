# Stage 46 — conflict preview and strict master-data guards

Stage 46 hardens the local conflict-resolution path.

- Conflict resolution allowlists are now restricted to the five supported master-data tables.
- Server and merged payloads may write only the same explicit fields allowed by the master-data sync apply layer. Protected columns such as `origin_device_id`, timestamps, and arbitrary schema columns cannot be overwritten through a conflict payload.
- For `use_server`, the stored `server_version` in the conflict record is authoritative; a client-supplied `version` value in the JSON payload is not trusted.
- For `merge`, the local merged row receives `max(local_version, server_version) + 1`.
- Added `scripts/sync_conflict_preview.py`, which reports differing field names and version metadata without printing business values.

Preview a conflict:

```bash
python scripts/sync_conflict_preview.py data/ansary.db --conflict-id CONFLICT_ID
```

This is a local SQLite utility. It does not contact the server, does not itself upload a selected resolution, and does not establish live two-device synchronization. Financial and inventory tables remain excluded.
