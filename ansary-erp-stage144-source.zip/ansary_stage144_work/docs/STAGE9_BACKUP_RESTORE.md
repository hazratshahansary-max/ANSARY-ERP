# Stage 9 — Backup & Restore (SQLite utility foundation)

This stage adds a working command-line backup/verification/restore utility for the SQLite database used by the offline desktop edition.

## Commands

Create a timestamped backup:
```bash
python scripts/backup_restore.py backup ansary.db
```

Choose an exact output path:
```bash
python scripts/backup_restore.py backup ansary.db --out backups/ansary.backup.db --type manual
```

Verify a backup and its SHA-256 manifest:
```bash
python scripts/backup_restore.py verify backups/ansary.backup.db
```

List and verify backup files in a directory:
```bash
python scripts/backup_restore.py list backups
```

Restore (the app must be fully closed):
```bash
python scripts/backup_restore.py restore backups/ansary.backup.db ansary.db --force
```

## Safety behavior

- Uses Python's SQLite online backup API, so a consistent snapshot is taken even when the source database uses WAL mode.
- Runs `PRAGMA integrity_check` and `PRAGMA foreign_key_check` before accepting a backup.
- Writes a JSON sidecar manifest containing UTC timestamp, size, SQLite user_version, table count, and SHA-256.
- Verify checks the manifest checksum when a manifest is present.
- Restore refuses to overwrite an existing database unless `--force` is provided.
- With `--force`, it first creates a verified `pre_restore` backup of the current target, then copies the verified backup to a temporary file and atomically replaces the target.

## Important limits

This is a local SQLite utility, not yet an in-app backup screen or background scheduler. It does not upload to cloud storage, encrypt backup files, prune old backups, or back up PostgreSQL. The application must be stopped before restore to avoid open-handle/WAL issues. Keep backup files in a separate drive or secure location; a backup on the same failed disk is not sufficient.

## Tests

Run:
```bash
python -m unittest discover -s tests/backup -v
```

The tests cover backup creation, manifest/checksum verification, safe restore, pre-restore backup creation, and missing database handling.
