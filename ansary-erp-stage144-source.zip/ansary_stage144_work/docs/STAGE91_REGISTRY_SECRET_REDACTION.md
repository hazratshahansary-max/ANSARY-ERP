# Stage 91 — Windows npm registry diagnostic redaction

The Windows API preparation script accepts `ANSARY_NPM_REGISTRY` and may use a private registry URL containing credentials or a query token. Earlier diagnostics wrote the full registry URL into the log and JSON report, and npm output could repeat it.

Stage 91 adds a sanitized registry representation for diagnostics. The sanitizer removes URI username, password, query, and fragment components. The original URI is still passed to npm so authenticated registry access is not broken. Captured command output is sanitized before it is displayed or persisted.

This change protects the setup log and report from common URL-embedded secrets. It does not guarantee that arbitrary secrets printed by third-party npm packages in unrelated output are removed; users should still review logs before sharing them.
