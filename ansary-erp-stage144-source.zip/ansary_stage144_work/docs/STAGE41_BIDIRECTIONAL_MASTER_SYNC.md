# Stage 41 — outbound master-data relay

Stage 41 extends `scripts/sync_http_client.py` to send pending local outbox
changes for exactly five master-data tables to the authenticated
`POST /api/sync/push` relay before pulling remote changes:

- `categories`
- `companies`
- `medicines`
- `customers`
- `suppliers`

The client builds a full allowlisted snapshot from the current local row, not
arbitrary caller-provided SQL fields. It maps local schema names to relay names
(`kind` → `company_type`, `code` → `customer_code` / `supplier_code`) and
never sends financial or inventory tables. A stable event UUID and base version
are persisted to the local outbox before network I/O, so a lost HTTP response
can be retried with the same idempotency key. Only event UUIDs returned in the
relay's `acknowledged` list are marked `sent` locally. A relay acknowledgement
means the server accepted the event envelope; it does **not** mean another
device has applied it.

## Run

```powershell
$env:ANSARY_SYNC_SERVER = "https://your-erp-server.example"
$env:ANSARY_SYNC_DEVICE_ID = "registered-device-uuid"
$env:ANSARY_SYNC_TOKEN = "your-access-token"
python scripts/sync_http_client.py data/ansary.db
```

One run now performs: retry previous pending ACK → push pending supported
master events → pull remote master events → apply locally → ACK the applied
cursor. The default push batch is at most 100 events. Use `--limit` to tune the
batch size (1–500); push remains capped at 100 per cycle.

## Important safety limits

- Hard-delete outbox entries are deliberately left pending and counted in
  `pending_master_deletes`. The existing outbox does not preserve the deleted
  row's base version, so the client will not guess one or send an unsafe delete.
- Outbox entries for invoices, stock, accounting, payments, and all other
  non-master tables are ignored and remain untouched.
- Server `/push` stores relay envelopes. Remote devices still need to pull,
  apply, and ACK them. There is no guarantee of immediate delivery or that a
  remote device has applied an event when the source marks it `sent`.
- This is a one-cycle command, not a background scheduler.
- HTTP behavior is tested with mocked transport and SQLite fixtures. No live
  server, production token, PostgreSQL deployment, or two-physical-device
  replication test was available; those are not claimed as passed.
