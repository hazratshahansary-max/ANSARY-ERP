# Stage 108 — FEFO multi-batch sales allocation

## API

`POST /api/sales/invoices/:id/items/auto-allocate`

The route is part of the existing sales router. It requires authentication, `sales.create`, a draft invoice, and permission to access the invoice's branch.

Example JSON body:

```json
{
  "medicineId": "MEDICINE_ID",
  "quantity": 12,
  "freeQuantity": 2,
  "unitPrice": 100,
  "discountPct": 0,
  "taxPct": 0
}
```

The endpoint selects eligible batches for the invoice branch and medicine, ordered by earliest expiry date (FEFO). Blocked, empty, expired-on-invoice-date, and already-used-on-this-invoice batches are excluded. If aggregate eligible stock is insufficient, no lines are created.

Each generated invoice line has a positive paid quantity because the existing `sales_invoice_items` schema enforces `quantity > 0`. Free units are attached only to a batch line that also contains paid quantity. If free units remain after all paid quantity has been allocated, the endpoint returns `FREE_QUANTITY_CANNOT_BE_ALLOCATED_WITHOUT_PAID_QUANTITY` rather than creating an invalid free-only line.

All generated lines are inserted in a single database transaction. Invoice totals are recalculated after commit.

## Limitations

This is a source-level implementation with focused contract tests. It has not yet been verified by a production TypeScript build or authenticated live HTTP acceptance test. Draft lines do not create a separate stock reservation in this feature; final stock validation remains in the existing invoice posting flow. Concurrent draft edits and stock changes require end-to-end race-condition testing before production use.
