# Stage 10 — Online / Offline Synchronisation Foundation

## Included in this stage

`scripts/sync_engine.py` provides device-side SQLite primitives with an injected transport:

- reads pending `sync_outbox` rows in sequence order and serializes current row data;
- strips configured derived columns from outbound payloads;
- marks only explicitly acknowledged outbox sequence numbers as sent;
- preserves pending rows and increments retry attempts when transport fails or an item is not acknowledged;
- applies an incoming pull batch in one SQLite transaction;
- suppresses trigger-generated echo by setting `sync_state.applying_remote=1` while applying;
- advances `last_pulled_seq` only when the complete batch commits;
- refuses unsafe table names, non-allowlisted tables, malformed events, and backwards cursors;
- records conflicts when a row has a pending local change or a newer local version.

## Example integration

```python
import sqlite3
from scripts.sync_engine import SyncEngine

con = sqlite3.connect('ansary.db')
engine = SyncEngine(con, allowed_tables={
    'currencies', 'branches', 'medicines', 'customers', 'suppliers',
    'batches', 'purchase_invoices', 'sales_invoices', 'stock_movements'
}, excluded_columns={'batches': {'qty_on_hand', 'last_movement_at'}})

# Supply a real authenticated HTTPS transport. It must return only sequence IDs
# that the server durably accepted.
result = engine.push(send_batch_to_server)
# Pull response shape: {'events': [...], 'next_cursor': integer}
engine.apply_pull(response['events'], response['next_cursor'])
```

## Not yet included / important limitations

- No HTTP sync endpoints, device registration UI, authentication handshake, or cloud server deployment are delivered in this stage.
- No production PostgreSQL push/pull service is implemented here.
- The caller must supply a secure transport (HTTPS), device authentication, server-side authorization, retries/backoff, and branch filtering.
- Conflict rows are recorded, not automatically resolved. A human-authorized conflict-resolution workflow is still required.
- The allowlist and dependency order must be configured for the actual deployment. Do not expose arbitrary table names from a client.
- Do not use this foundation for live multi-device production until PostgreSQL integration and end-to-end tests pass.

See [SYNC.md](SYNC.md) for the intended hub-and-spoke architecture and conflict policy.
