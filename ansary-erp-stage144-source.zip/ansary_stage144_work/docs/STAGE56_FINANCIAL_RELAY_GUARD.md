# Stage 56 — Financial and stock relay guard

## Purpose

The server currently has a general event relay table containing names for both
master data and financial/stock tables. A general table-name schema is not
permission to synchronize every listed table. Financial and stock records must
remain blocked until their posting atomicity, idempotency, dependency ordering,
and rollback behavior are implemented and verified.

## Changes

- Added `MASTER_SYNC_TABLES`, derived only from the explicit `MASTER_FIELDS`
  allowlist (categories, companies, medicines, customers, suppliers).
- The shared event schema now rejects every table outside that allowlist with
  `TABLE_SYNC_NOT_ENABLED`. This applies to both `/push` and `/apply-master`.
- `/pull` defaults to master scope and always applies the five-table filter.
  The legacy `scope=all` query value cannot bypass the filter.
- Existing user-session, branch-scope, and device-secret checks remain required.

## Safety boundary

This does not implement financial or stock synchronization. It prevents those
records from entering or leaving the current master-data relay. Existing old
financial rows in `sync_events` are not deleted; they are simply not delivered
by `/pull`.

## Validation

The Stage 56 Python tests are source-contract regression checks. They do not
replace a TypeScript build, live HTTP integration test, PostgreSQL test, or
multi-device end-to-end test. Those remain pending because server dependencies
were not available from the local npm cache in this environment.
