# Stage 63 — Server HTTP smoke-test harness

## What was added

- `scripts/server-http-smoke.mjs` starts the **compiled** API as a child Node process.
- It uses a newly-created temporary SQLite database and explicitly clears `DATABASE_URL`, so it cannot point the test at a configured production PostgreSQL database.
- It calls the actual HTTP endpoints `GET /health/live` and `GET /health/ready` and checks their status and JSON response.
- It sends SIGTERM to the child and removes the temporary test directory.
- Root npm script: `npm run smoke:server`.

## How to run when dependencies are available

```bash
npm install
npm run build:server
npm run smoke:server
```

The smoke test requires the compiled output at `server/dist/index.js` and runtime packages including Express and better-sqlite3.

## Validation performed in this environment

- Node.js syntax check of the smoke-test script: passed.
- Existing SQL placeholder adapter tests: 5 passed.
- Stage 63 Python contract tests: 4 passed.
- Full Python and database test suites: see `STAGE63_TEST_RESULTS.txt`.

## Not claimed

The real HTTP smoke test was **not executed** in this environment because npm dependency installation could not reach the npm registry (DNS/network error). Consequently the TypeScript build, Express startup, SQLite driver runtime, PostgreSQL runtime, and multi-device Sync are not certified by this stage. Run the commands above on a machine with npm registry access before deployment.
