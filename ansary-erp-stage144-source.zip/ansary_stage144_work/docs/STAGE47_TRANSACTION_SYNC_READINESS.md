# Stage 47 — Stock and financial sync readiness audit

Stage 47 does **not** enable stock or financial replication. It adds a read-only audit of the existing SQLite schema so the next implementation does not bypass accounting or inventory invariants.

## What is checked

- The master-data sync boundary remains limited to `categories`, `companies`, `medicines`, `customers`, and `suppliers`.
- Core stock/accounting/invoice tables exist but remain outside the master-data apply path.
- `stock_movements` has a unique source-line/movement/batch identity and append-only UPDATE/DELETE guards.
- Journal posting, reversal, frozen-entry and journal-line guards exist.
- Sales and purchase invoices carry branch/lifecycle/idempotency fields and unique `client_uuid` indexes.

## Run

```bash
python scripts/sync_transaction_readiness.py
python scripts/sync_transaction_readiness.py --output reports/transaction-sync-readiness.json
```

Exit code `0` means all schema checks passed; it does **not** mean transaction sync is enabled or production-ready. Exit code `2` means one or more schema checks failed.

## Decision

The current schema passes the seven checks, but the report returns `SCHEMA_GUARDS_PRESENT_PROTOCOL_STILL_REQUIRED`. A server-authoritative immutable transaction event protocol, atomic parent/child application, branch/permission enforcement, balanced journal validation, replay/out-of-order tests, PostgreSQL parity and real two-device verification are still required before enabling financial or stock sync.

No business rows are read or changed by the audit. It only executes the supplied schema in an in-memory SQLite database and inspects table/index/trigger metadata.
