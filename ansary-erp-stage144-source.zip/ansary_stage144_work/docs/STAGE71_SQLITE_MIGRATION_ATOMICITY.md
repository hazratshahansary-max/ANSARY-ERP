# Stage 71 — SQLite migration atomicity

## Problem
The SQLite migration runner previously committed a migration's DDL first and inserted its `schema_migrations` checksum in a separate transaction. A process interruption between those operations could leave schema changes applied but unrecorded, making the next startup attempt to apply the same DDL again.

## Changes
- Added a statement executor that respects SQLite complete-statement boundaries, including trigger bodies containing internal semicolons.
- Applied each migration and inserted its filename/SHA-256 record inside the same transaction.
- Rolled back both DDL and ledger changes when a migration fails.
- Kept checksum verification fail-closed for already-applied migrations.
- Ensured the CLI closes its SQLite connection through `finally`.
- Added regression tests for atomic rollback, repeat-run idempotency, checksum tampering, and multi-statement triggers.

## Validation
Run:

```bash
python -m unittest database.tests.test_migration_runner -v
python -m unittest discover -s database/tests -v
python -m unittest discover -s tests -v
node --test server/tests/*.test.js server/src/auth/*.test.js server/src/db/*.test.js server/src/middleware/*.test.js scripts/package-server.test.mjs
python scripts/verify_desktop_package.py
```

This stage does not claim a successful TypeScript build, live API, PostgreSQL runtime, Windows installer, Android APK, or multi-device sync. Those remain separate deployment/integration gates.
