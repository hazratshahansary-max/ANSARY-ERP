# Stage 88 — API listener startup diagnostics

The API validates `PORT` before opening the database (Stage 86). This stage improves the next failure boundary: binding the HTTP listener.

| OS error | Diagnostic | Suggested action |
|---|---|---|
| `EADDRINUSE` | `API_PORT_IN_USE` | Stop the other process or choose another `PORT`. |
| `EACCES` / `EPERM` | `API_PORT_PERMISSION_DENIED` | Choose an unprivileged port above 1024. |
| `EADDRNOTAVAIL` | `API_ADDRESS_UNAVAILABLE` | Check host/network address configuration. |
| Other | `API_LISTEN_FAILED` | Review the underlying error detail. |

On listener failure the process marks itself unsuccessful and closes the database connection. Tests: `npm run test:api-listen-errors`. These are helper-level tests; they do not replace a live HTTP startup test.
