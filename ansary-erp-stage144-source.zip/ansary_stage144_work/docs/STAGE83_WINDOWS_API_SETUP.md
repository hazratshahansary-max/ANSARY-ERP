# Stage 83 — Windows x64 API setup

The full-project Windows preparation script is `desktop/scripts/prepare-offline-api-windows.ps1`.

## Requirements
- Windows x64
- Node.js 20 or newer
- npm 10 or newer
- Network access to an approved HTTPS npm registry

## Optional registry mirror
Set `ANSARY_NPM_REGISTRY` before running PowerShell if the default npm registry is not reachable:

```powershell
$env:ANSARY_NPM_REGISTRY = 'https://your-approved-npm-mirror/'
```

## Run
From the full project root:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\desktop\scripts\prepare-offline-api-windows.ps1
```

The script checks the Windows x64 runtime, validates the registry URL and DNS, creates an isolated API source bundle, retries dependency installation up to three times, requires a real `package-lock.json`, builds the TypeScript API, prunes development dependencies, verifies the runtime bundle, and writes a SHA-256 checksum.

Reports are written under `release/`:
- `stage83-windows-api-setup.log`
- `stage83-windows-api-setup.json`
- `ansary-erp-api-windows-x64-stage83.zip`
- `ansary-erp-api-windows-x64-stage83.zip.sha256.txt`

This is a preparation workflow, not a completed installer. It has not been run on Windows in this environment. A successful report must say `SUCCESS` before the ZIP is treated as a deployable Windows API bundle.


Stage 83 fixes the command-output capture in the PowerShell runner: the prior script passed `-Append` twice to `Tee-Object`, which can stop execution before npm is invoked. The runner now captures stdout/stderr, logs each line, and checks the native process exit code. The script remains unexecuted on this Linux host.
