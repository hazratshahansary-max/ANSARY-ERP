# Stage 16 — Customer receipts and supplier payments

## Implemented

- Added `scripts/post_voucher.py`, a SQLite posting service for `customer_receipt` and `supplier_payment` vouchers.
- Uses `BEGIN IMMEDIATE` so journal creation, journal posting, voucher posting, and invoice settlement happen atomically.
- Validates draft status, party identity, posted invoice status, invoice ownership, allocation type, outstanding balance, open financial year, and active posting accounts.
- Customer receipt journal: debit selected cash/bank ledger account, credit Accounts Receivable (AR).
- Supplier payment journal: debit Accounts Payable (AP), credit selected cash/bank ledger account.
- Creates a balanced journal with `source_type='vouchers'` and the voucher as source; then posts the voucher so existing database triggers update invoice `paid_amount` and `payment_status`.
- Duplicate posting is rejected. Failures roll back the entire operation.

## Usage

```bash
python scripts/post_voucher.py DATABASE_PATH VOUCHER_ID USER_ID
```

The voucher and its payment allocations must already exist as drafts. This command supports only customer receipts and supplier payments; general cash receipts/payments, contra, expenses, and reversal workflows are not implemented by this script.

## Verification

Run:

```bash
python -m unittest discover -s tests/vouchers -v
```

The tests cover customer receipt settlement, supplier payment settlement, balanced posted journals, and duplicate-post prevention.

## Limitations

- The TypeScript API routes currently create payment records in a separate `payments`-table model; this Stage 16 utility targets the actual SQLite schema's `vouchers` and `payment_allocations` model. The API/database model mismatch must be reconciled before production integration.
- No receipt/payment user interface or printable receipt has been completed.
- No live PostgreSQL test or full application build is claimed.
