# ANSARY ERP Stage 4 — Purchase Management foundation

This stage adds authenticated purchase endpoints under `/api/purchases`.

## Endpoints

- `GET /api/purchases/suppliers?branchId=<id>` — active supplier list (requires `supplier.view`).
- `GET /api/purchases/invoices?branchId=<id>` — latest 200 invoices visible to the user's assigned branches (`purchase.view`).
- `POST /api/purchases/invoices` — create a draft purchase invoice (`purchase.create`).
- `GET /api/purchases/invoices/:id` — invoice header and lines (`purchase.view`).
- `POST /api/purchases/invoices/:id/items` — add a draft line; computes discount, tax, line total and landed unit cost (`purchase.create`).
- `DELETE /api/purchases/invoices/:id/items/:itemId` — remove a line from a draft (`purchase.create`).

## Important accounting and stock safeguards

Creating a draft or adding a line does not change stock or supplier balances. Stock is changed only by the existing database posting triggers after a valid posted journal entry is linked to the invoice. Posting is deliberately not exposed in this stage: the complete journal-entry posting workflow and transactional adapter must be completed and tested before enabling it.

All endpoints require a bearer session and permission checks. Branch ownership is checked against `user_branches`. Draft invoices only can be edited. Supplier invoice number and invoice number uniqueness are enforced by database constraints.

## Request examples

Create a draft:

```json
{
  "branchId": "BRANCH_UUID",
  "supplierId": "SUPPLIER_UUID",
  "invoiceNo": "PUR-2026-0001",
  "supplierInvoiceNo": "SUP-INV-778",
  "invoiceDate": "2026-11-15",
  "dueDate": "2026-12-15",
  "currencyCode": "AFN",
  "exchangeRate": 1,
  "discountAmount": 0,
  "roundOff": 0,
  "notes": "First purchase"
}
```

Add a line:

```json
{
  "medicineId": "MEDICINE_UUID",
  "batchNo": "BATCH-001",
  "mfgDate": "2026-01-01",
  "expiryDate": "2028-01-01",
  "quantity": 100,
  "freeQuantity": 5,
  "unitPrice": 12.5,
  "discountPct": 2,
  "taxPct": 0,
  "additionalCost": 25
}
```

## Known limitations

- This is an API/backend foundation, not a finished purchase UI.
- Purchase order and goods-receipt workflows are not exposed yet.
- Supplier payment allocation and purchase returns are not exposed yet.
- Posting is intentionally disabled until journal creation and database transactions are fully implemented.
- The current `DatabaseAdapter` does not expose transactions; do not use this API for multi-user production accounting until transaction support is added.
- Run the TypeScript build and API integration tests in an environment with the server dependencies installed before deployment.
