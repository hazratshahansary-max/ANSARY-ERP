# Stage 77 — reproducible server dependency transfer

The build environment used to prepare this release cannot resolve `registry.npmjs.org` (`EAI_AGAIN`). No lockfile or resolved package versions have been fabricated. Use this workflow to prepare dependencies on a separate internet-connected computer.

## A. On an internet-connected computer

1. Install Node.js 20 or newer and npm 10 or newer.
2. Open a terminal in the ANSARY ERP project root.
3. Run:

   ```sh
   npm run prepare:server:cache
   ```

4. Wait for npm to finish successfully. This creates/updates `package-lock.json`, installs only the server workspace dependencies, verifies the npm cache structure, and writes `server-dependency-cache-manifest.json`.
5. Copy the **entire project folder** and the **entire npm cache directory** shown by the command to a USB drive. Do not copy only selected `_cacache` files.

To find the cache directory independently, run `npm config get cache`.

## B. On the offline computer

1. Copy the project folder and the complete npm cache folder from USB.
2. Set `ANSARY_NPM_CACHE_DIR` to the copied cache folder.
3. Run the install and build commands from the project root.

   Windows PowerShell:

   ```powershell
   $env:ANSARY_NPM_CACHE_DIR = 'D:\AnsaryNpmCache'
   $env:ANSARY_NPM_OFFLINE = 'true'
   npm run setup:server
   npm run build:server
   npm run smoke:server
   ```

   Linux/macOS:

   ```sh
   export ANSARY_NPM_CACHE_DIR=/media/usb/AnsaryNpmCache
   export ANSARY_NPM_OFFLINE=true
   npm run setup:server
   npm run build:server
   npm run smoke:server
   ```

4. Keep `package-lock.json` with the project. Do not regenerate it on the offline computer.

## C. What the preparation manifest proves

`server-dependency-cache-manifest.json` records the direct server dependencies, engine requirements, lockfile version, and SHA-256 digest of the lockfile. It verifies the lockfile's `server` workspace entry matches the server package manifest. It does **not** prove every tarball is present in the copied cache; the offline `npm ci`/install step is the definitive check.

## Current release limitation

This environment could not reach the npm registry, so the online preparation command was not successfully completed here. The TypeScript build, live HTTP server, and PostgreSQL integration are still unverified. Do not treat this release as a production-ready installer.
