# Stage 65 — Server dependency recovery

## Purpose

Stage 65 makes server dependency installation repeatable and diagnosable. It does not claim that the TypeScript server builds or that HTTP Sync is live; those require a successful dependency install followed by the build and smoke tests.

## Requirements

- Node.js 20 or newer
- npm 10 or newer
- Network access to the configured npm registry, or an organization-approved npm mirror

## Install the server workspace

From the project root:

```bash
npm run setup:server
```

The setup script:

- installs only the `@ansary-erp/server` workspace and its required workspace dependencies;
- uses `npm ci` when a root `package-lock.json` exists;
- otherwise uses `npm install` and asks npm to create a root lockfile;
- retries transient DNS/network failures up to three times by default;
- allows up to five attempts through `ANSARY_NPM_RETRIES`;
- accepts a registry override through `ANSARY_NPM_REGISTRY`;
- bounds each npm attempt to 120 seconds by default (`ANSARY_NPM_TIMEOUT_MS` can be set from 15,000 to 300,000 milliseconds);
- does not open or modify the ERP application database.

Example using a registry mirror approved by your organization:

```bash
# Linux/macOS
ANSARY_NPM_REGISTRY=https://your-approved-registry.example npm run setup:server

# Windows PowerShell
$env:ANSARY_NPM_REGISTRY = 'https://your-approved-registry.example'
npm run setup:server
```

Do not use an unknown public mirror for production dependencies. Use only a registry you trust and whose TLS certificate is valid.

## Build and smoke test

After dependency setup succeeds:

```bash
npm run build:server
npm run smoke:server
```

Or run the combined sequence:

```bash
npm run build:server:ready
```

The combined command installs dependencies, compiles the server, and runs the HTTP smoke test. A successful install alone is not proof of a successful build or live database integration.

## Diagnostics

```bash
node scripts/server-build-preflight.mjs
npm run test:server-setup
```

If npm reports `EAI_AGAIN` or `ENOTFOUND`, fix DNS/network access or configure an approved registry mirror, then rerun setup. If npm reports `ERESOLVE`, review the dependency conflict rather than bypassing it with `--force`.

## Stage 65 limitations

- This environment currently cannot resolve `registry.npmjs.org` (`EAI_AGAIN`), so package installation and lockfile generation may remain blocked here.
- No TypeScript build, live HTTP API test, PostgreSQL runtime test, or two-device Sync test is claimed by this stage.
- No financial or stock synchronization is enabled by this stage.
