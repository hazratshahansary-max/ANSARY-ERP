# Stage 58 — Partial Sync Batch Outcomes

## Purpose
A batch push can contain multiple independent master-data events. Previously, one event UUID collision or persistence error could terminate the HTTP request after earlier events had already been stored. The client then received no structured per-event outcome and had to retry the entire batch without knowing which rows had succeeded.

## Changes
- `POST /api/sync/push` now evaluates each event independently after request-level authentication and schema validation.
- Successful/idempotent events are listed in `acknowledged`.
- Rejected events are listed in `rejected` with `event_uuid`, a stable error `code`, and a `retryable` hint.
- Storage exceptions are converted to the generic `EVENT_STORAGE_ERROR`; SQL details are not returned.
- A rejected event does not prevent later events in the same batch from being processed.
- The Python client validates that acknowledgements and rejections are disjoint and refer only to submitted events.
- Only acknowledged rows become `sent`; rejected/unacknowledged rows remain `pending`, retain their event UUID and payload, and record a bounded `last_error` code.
- Financial and stock event tables remain blocked; this change applies only to the existing five master-data tables.

## Safety notes
- Request-level authentication, device authorization, branch authorization, and event schema validation still reject the whole request before event processing.
- This does not make each batch atomic. It deliberately provides per-event outcomes. Each accepted event is independently durable.
- A retryable storage failure can be retried with the same event UUID and identical payload. Permanent UUID collisions remain pending for operator review and are not silently rewritten.
- No live HTTP server, PostgreSQL, or two-device end-to-end test is claimed by the local Python tests.
