# Stage 3 – Medicines and inventory API foundation

## Implemented endpoints
All endpoints require `Authorization: Bearer <session-token>`.

- `GET /api/inventory/categories` – active medicine categories.
- `GET /api/inventory/companies` – active companies/manufacturers.
- `GET /api/inventory/medicines?page=1&limit=25&search=...&branchId=...` – paginated medicine catalogue and branch-scoped stock/nearest-expiry summary.
- `POST /api/inventory/medicines` – create a medicine (requires `inventory.create`).
- `PATCH /api/inventory/medicines/:id` – update medicine master data (requires `inventory.edit`).
- `GET /api/inventory/stock?branchId=...` – positive stock summary (requires `inventory.view`).
- `GET /api/inventory/expiry-alerts?days=90&branchId=...` – positive-stock batches expiring by the selected cutoff (requires `inventory.view`).

## Security and validation
- All routes require an authenticated session.
- Read operations enforce `inventory.view`; create and edit use their matching permissions.
- Stock and expiry queries are restricted to branch IDs assigned to the authenticated user. Requesting another branch returns 403.
- Medicine input is validated with Zod; numeric prices and quantities cannot be negative, box quantity must be positive, and max stock cannot be below min stock when a maximum is set.
- SQL values are parameterized. Product code/barcode uniqueness conflicts return 409.

## Not yet implemented
- Inventory adjustment documents and posting/reversal screens.
- Purchase receiving workflow and batch creation through posted purchases.
- Barcode scanning/printing UI.
- Low-stock notifications and expiry dashboard UI.
- Frontend, desktop application, Android app, installer, and end-to-end API tests.

## Verification required
Install dependencies from the repository root with `npm install`, then run `npm run build:server`. Start the API against a migrated SQLite database and verify all endpoints with an authenticated user assigned to one branch. Repeat against PostgreSQL before production use.
