# Stage 57 — Sync event UUID content integrity

## Change

The `/api/sync/push` route previously treated an existing `event_uuid` from the
same device as an idempotent duplicate without comparing the stored event body.
A client could therefore reuse a UUID with a different table, row, operation,
base version, or payload and receive an acknowledgement for content the server
had not stored.

The route now reads the existing event and compares:

- device ID;
- table name and row ID;
- operation and base version;
- canonical JSON payload (object key order is ignored; array order is retained).

A UUID used by another device returns `EVENT_UUID_ALREADY_USED`. A UUID reused
with different content returns `EVENT_UUID_CONTENT_MISMATCH`. An acknowledgement
is added only after exact semantic content equality is established.

## Scope and limits

- This change applies to the existing master-data relay route only.
- The five-table master-data allowlist remains unchanged.
- Financial and stock events remain blocked.
- This route still processes a batch event-by-event; an error later in a batch
  can occur after earlier events have been persisted and acknowledged only in
  the response if the request completes. Clients should retry using the same
  UUID and identical content. A future stage should define explicit partial
  batch response semantics or all-or-nothing batch transactions.
- The change is source-level and covered by Python source-contract regression
  tests in this environment. A live TypeScript build, HTTP server run, and
  PostgreSQL runtime test have not been performed here.
