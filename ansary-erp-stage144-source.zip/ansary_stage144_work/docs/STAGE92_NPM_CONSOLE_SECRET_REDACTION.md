# Stage 92 — npm console diagnostic secret redaction

The dependency setup command previously sanitized the registry value persisted in its JSON report, but its console output still displayed the raw registry and raw npm stdout/stderr. A registry URL containing user-info or query credentials could therefore appear in terminal logs.

Stage 92 changes:

- Display the sanitized registry value in the setup summary.
- Display a sanitized copy of the npm command arguments while preserving the original arguments for the actual process invocation.
- Redact credential-bearing URLs and npm auth-token/password assignments from displayed stdout/stderr.
- Keep the raw npm output only in process memory for failure classification; it is not written to the JSON report.
- Add a regression test covering URL credentials, query tokens, and npm `_authToken` output.

Validation is limited to source-level unit tests and project test suites in this environment. It does not establish a successful dependency install or API build.
