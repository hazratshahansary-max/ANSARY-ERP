# Stage 48 — Transaction event envelope contract

## Purpose

Stage 48 defines a strict, side-effect-free draft contract for future financial
and inventory replication. It does **not** send events, write business tables,
post invoices, move stock, or enable transaction sync.

## Envelope v1

The exact top-level fields are: `schema_version`, `event_uuid`, `event_type`,
`aggregate_type`, `aggregate_id`, `branch_id`, `device_id`, `actor_id`,
`occurred_at`, `device_sequence`, `payload`, and `payload_sha256`.

- `event_uuid` is a canonical UUID and is the future idempotency key.
- `event_type` must be in the explicit allowlist in
  `scripts/sync_transaction_envelope.py`.
- Branch, device, actor and aggregate identifiers are mandatory.
- `occurred_at` must include a timezone; `device_sequence` must be positive.
- The payload digest is SHA-256 over UTF-8 JSON serialized with sorted keys,
  compact separators, Unicode preserved, and non-finite numbers forbidden.
- Unknown envelope fields are rejected to avoid silently accepting unreviewed
  authority or metadata fields.

## Example usage

```python
from scripts.sync_transaction_envelope import build_envelope

event = build_envelope(
    event_type="sales_invoice.posted",
    aggregate_type="sales_invoice", aggregate_id="INV-001",
    branch_id="BR-01", device_id="DEV-01", actor_id="USR-01",
    occurred_at="2026-11-15T12:00:00+04:30", device_sequence=1,
    payload={"invoice_id": "INV-001", "items": [{"qty": 2}]},
)
```

This creates and validates a local draft only. A client-supplied envelope is not
proof of identity, permission, branch membership, correct stock, or balanced
accounting. A future server must authenticate the device and actor, authorize
the branch and posting action, independently validate all child rows and
business invariants, and persist the event plus all affected rows atomically.
The server must also own accepted ordering and deduplication.

## Explicit exclusions

No event is applied to invoices, payments, journal entries, batches, or stock
movements. There is no outbox writer, HTTP endpoint, server acceptance, ACK,
replay processor, PostgreSQL adapter, or two-device workflow in this stage.
The event allowlist is a protocol proposal, not permission to activate sync.
