# Stage 25 — Windows desktop packaging foundation

## Implemented
- Electron desktop shell for Windows 10/11 x64.
- Hardened BrowserWindow: `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`.
- Separate Node.js API child process on `127.0.0.1:3177`.
- SQLite data under Electron's per-user application data folder, outside the installation directory.
- First-run SQLite migration runner with SHA-256 migration checks and production seed.
- NSIS installer configuration and a PowerShell preparation script that downloads Node.js 22.16.0 x64 and verifies its official SHA-256 checksum.

## Validation performed in this workspace
- 80 Python database tests passed.
- 52 Python application/feature tests passed.
- 5 Node SQL placeholder adapter tests passed.
- JavaScript syntax checks passed for the client, Electron main process, and database bootstrap script.
- ZIP integrity checked.

## Not validated
- `npm install` on Windows and native module compilation.
- TypeScript production build in a clean Windows environment.
- Electron packaging or actual NSIS Setup.exe generation.
- Installation, upgrade, uninstall, and runtime tests on Windows 10/11.
- Windows 7 or 32-bit compatibility.
- Android APK, live PostgreSQL deployment, and live synchronization server.

## Build on Windows 10/11 x64
Run from repository root in PowerShell:

```powershell
npm install
npm run desktop:prepare:win
npm run desktop:build
```

The preparation script compiles the API and stages production dependencies. Do not distribute the installer until it has been generated and tested on a real Windows 10/11 x64 machine.
