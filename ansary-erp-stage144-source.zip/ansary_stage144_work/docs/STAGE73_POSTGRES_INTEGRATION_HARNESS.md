# Stage 73 — Disposable PostgreSQL integration harness

## What this adds

- A Docker Compose PostgreSQL 16 test service with an isolated database/user and a loopback-only host port (`127.0.0.1:55432`).
- A one-command integration runner that waits for database readiness, runs two migration runners concurrently against the same empty schema, checks the migration ledger count, loads production system seed plus sample fixtures, and executes `database/tests/postgres_integrity_tests.sql`.
- An EXIT/INT/TERM cleanup trap that removes the disposable container and its volume.
- Static contract tests that verify the harness uses a dedicated test database, has cleanup, and exercises concurrent migration and integrity SQL paths.

## Run on a machine with Docker Compose v2

From the project root:

```bash
npm run test:stage73-postgres-harness
npm run test:postgres-integration
```

The integration runner creates a temporary Compose project and deletes its container and volume on exit. It does not use a configured production `DATABASE_URL`; credentials are test-only and defined in `docker-compose.postgres-test.yml`. Do not change the test service to point at a production database.

## What a successful live run proves

- PostgreSQL 16 accepts the migration SQL.
- Two concurrent migration processes complete without duplicate application or migration-ledger mismatch.
- All migration files are recorded.
- The production system seed and sample fixtures load.
- The existing PostgreSQL integrity SQL assertions pass.

## Validation limitation in this build environment

The current build container has neither Docker nor `psql`, so the live PostgreSQL run cannot be executed here. Only shell syntax and static harness contract tests can be run in this environment. The harness is ready for a Docker-enabled machine, but PostgreSQL runtime compatibility remains **unverified until that command passes**.
