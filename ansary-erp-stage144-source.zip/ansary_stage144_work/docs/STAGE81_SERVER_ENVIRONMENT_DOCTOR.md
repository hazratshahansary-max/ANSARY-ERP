# Stage 81 — Server environment doctor

## Purpose

Stage 81 adds an explicit, repeatable diagnostic for the server build prerequisites. It does not claim that a missing dependency, lockfile, registry connection, or native module is repaired merely because a diagnostic command ran.

## Run

From the repository root:

```bash
npm run doctor:server
```

The command prints a concise report and writes `SERVER_ENVIRONMENT_REPORT.json` in the project root. It checks Node.js >=20, npm >=10, root/server lockfile consistency, npm cache structure, resolution of the server runtime and build packages, and (unless `--no-dns` is passed) DNS lookup of the configured npm registry.

For a deployment gate that returns exit code 2 when blockers remain:

```bash
node scripts/server-environment-doctor.mjs --strict
```

To diagnose local files without performing a DNS lookup:

```bash
node scripts/server-environment-doctor.mjs --no-dns
```

The registry is selected from `ANSARY_NPM_REGISTRY`, `npm_config_registry`, or the npmjs default. The cache directory is selected from `ANSARY_NPM_CACHE_DIR` or `npm config get cache`.

## Current environment status

A diagnostic report is generated during Stage 81. Missing `package-lock.json` and uninstalled server packages remain blockers. The environment's npm registry DNS connectivity has not been assumed to work. No synthetic lockfile or fake dependency versions are created.

## Scope limits

This diagnostic is not a substitute for `npm ci`, a successful TypeScript build, live HTTP route tests, PostgreSQL integration, or two-device synchronization tests. Native modules such as `argon2` and `better-sqlite3` must be installed and tested on the target OS/architecture.
