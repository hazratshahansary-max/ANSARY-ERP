# Stage 66 — Server database schema readiness gate

## What changed

- Added a read-only schema contract for 30 core ERP tables.
- SQLite checks enumerate `sqlite_master`; PostgreSQL checks enumerate the current schema in `information_schema.tables`.
- `/health/ready` and the compatibility `/health` endpoint now distinguish a connected database from a complete ERP schema. An incomplete schema returns HTTP 503 and the missing table names only.
- Server startup fails closed before opening the HTTP listener if core tables are missing. It closes the database adapter and prints a migration instruction.
- `/health/live` remains a process liveness endpoint and does not claim that the database is ready.
- No migrations are automatically applied, and no business data is modified by the readiness check.

## Required operator action

Run the canonical migrations before starting the API:

```bash
python scripts/migrate_sqlite.py data/ansary.db --seed
```

For PostgreSQL, apply the canonical PostgreSQL migrations using the project's PostgreSQL migration procedure, then configure `DATABASE_URL` and start the server. Do not point a production instance at an empty database.

## Validation performed

- Applied all 22 canonical SQLite migrations to a fresh temporary database.
- Confirmed all 30 required core tables exist.
- SQLite `integrity_check`: `ok`.
- SQLite `foreign_key_check`: zero violations.
- Added four Node.js unit tests covering complete schema, missing tables, PostgreSQL catalog selection, and empty database.
- Existing server dependency/preflight/placeholder tests: 13 passed.
- Python project tests: 243 passed.
- Database tests: 82 passed.
- Desktop package contract check: passed.
- Client syntax/manifest check: passed.

## Not verified

- TypeScript build and live HTTP listener remain blocked because workspace dependencies and Node type definitions are not installed in this environment; npm registry access was unavailable in the previous dependency recovery attempt.
- PostgreSQL was not available for a live runtime check.
- No two-device sync, installer, or Android APK test was performed.
