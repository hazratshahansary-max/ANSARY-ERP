# Stage 11 — ANSARY ERP browser client foundation

## Delivered
- Responsive Pashto RTL browser interface, with English-safe field rendering.
- Login and first-administrator setup forms wired to `/api/auth/login` and `/api/auth/setup`.
- Bearer-token session storage and logout wired to existing auth endpoints.
- API address can be configured and is saved in browser local storage.
- API health indicator.
- Dashboard wired to `/api/reports/dashboard`.
- Medicine list/search wired to `/api/inventory/medicines`.
- 90-day expiry list wired to `/api/inventory/expiry-alerts?days=90`.
- Sales and stock summary wired to the existing report endpoints.
- Responsive navigation for desktop and mobile screen sizes.

## Run locally
1. Start the API from the repository root after installing server workspace dependencies:
   `npm --workspace @ansary-erp/server run dev`
2. In a second terminal, start the client static server:
   `cd client`
   Windows: `py -m http.server 5173`
   Linux/macOS: `python3 -m http.server 5173`
3. Open `http://localhost:5173`.
4. Set API address to `http://localhost:3000` if it is not already set.
5. Use **لومړنی تنظیم** only once, on a database that has not yet been initialized; then sign in.

## Important limits
- This is a browser client foundation, not a packaged Windows installer or Android APK.
- The interface requires the API and database to be running; it is not an offline-first local database client yet.
- The current API CORS defaults permit localhost:5173. For other origins, configure `CORS_ORIGIN` on the server.
- Dashboard and reports display data returned by the current API. Empty data is normal for an empty database.
- No create/edit medicine form, purchase/sales workflow screens, customer/supplier screens, or sync UI are delivered in this stage.
- Browser session token is stored in localStorage for this foundation. A production deployment should review the authentication/session storage model and use HTTPS.
- The font stack uses local system fonts so the UI does not require an external font download.
