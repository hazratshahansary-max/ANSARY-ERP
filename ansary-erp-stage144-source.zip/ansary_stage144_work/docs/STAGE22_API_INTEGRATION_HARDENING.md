# Stage 22 — API integration hardening

## Implemented

- Replaced the database adapter's broad regular-expression placeholder replacement with a SQL-aware scanner.
- PostgreSQL conversion now replaces only unquoted `?` placeholders with sequential `$1`, `$2`, ... parameters.
- SQLite conversion now replaces only actual numbered `$1`, `$2`, ... placeholders outside strings, quoted identifiers, comments, and dollar-quoted blocks.
- Both adapters reject SQL/parameter-count mismatches before sending a query to the driver.
- Added dependency-free Node.js unit tests for quoted strings, comments, dollar-quoted blocks, repeated SQLite parameters, and mismatch errors.
- Added `/health/live` for process liveness and `/health/ready` for database readiness. `/health` remains as a compatibility alias for readiness and now probes the database.
- Added graceful HTTP server shutdown before closing the database connection.

## Validation performed

- SQLite schema suite: 80 passed.
- Project feature suite: 44 passed.
- SQL placeholder Node.js suite: 5 passed.
- Browser client JavaScript syntax check: passed.
- SQL placeholder module syntax check: passed.
- ZIP archive integrity: checked after packaging.

## Not validated in this environment

- `npm install` did not complete before the environment timeout.
- Therefore the full TypeScript server build could not be completed; `tsc` reports missing installed packages and Node.js type declarations.
- No live Express server/API request test was run.
- No PostgreSQL server is available here, so live PostgreSQL behavior and schema migration remain unverified.
- No browser end-to-end test, Windows installer, or Android APK was produced.

## Safe next test

Use a copy of a test SQLite database, install the root npm workspace dependencies, run `npm run build:server`, start the server, and verify `/health/live`, `/health/ready`, initial setup, login, and a test purchase/sales lifecycle. Do not use production business data for the first integration run.
