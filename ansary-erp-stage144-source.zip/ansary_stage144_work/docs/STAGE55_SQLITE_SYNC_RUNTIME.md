# Stage 55 — Canonical SQLite Sync Runtime Validation

## What changed
- Added a disposable SQLite runtime verifier that applies the canonical `database/sqlite/migrations` in order.
- Added integration tests that use a fresh migrated database and exercise device registration rows, token-audit constraints, sync-event JSON/operation constraints, UUID uniqueness, foreign keys, and migration idempotency.
- Tests never connect to a production database and never start or modify a live server.

## Run

```bash
python scripts/verify_sync_sqlite_runtime.py --output reports/stage55-sqlite-runtime.json
python -m unittest tests.integration.test_stage55_sqlite_sync_runtime -v
```

## Scope and limitations
This is an actual SQLite migration/runtime test. It is not an HTTP API end-to-end test, does not build or start the TypeScript server, and does not validate PostgreSQL. No financial or inventory sync writes are enabled by this stage.
