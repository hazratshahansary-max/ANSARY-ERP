# Stage 13 — Batch-aware sales entry

## Implemented
- Added authenticated `GET /api/inventory/batches?medicineId=...&branchId=...`.
- The endpoint requires `inventory.view`, verifies the requested branch is assigned to the user, and returns only active, positive-stock, unexpired batches for the selected medicine and branch.
- Sales UI now opens an invoice draft, displays its existing lines, and allows adding/removing draft lines.
- Batch selection shows batch number, expiry date, and on-hand quantity. Suggested unit price is populated from the selected batch's medicine wholesale/retail price according to invoice type.
- The existing sales line endpoint continues to validate branch, expiry, and available quantity before saving a draft line.

## Explicit limitations
- Sales invoice posting remains disabled (HTTP 501 by design). This stage does not reduce stock, post cash/receivables, or create accounting journals.
- The selected batch price is a convenience default; server-side price override permission checks remain authoritative.
- Browser UI and JavaScript syntax were checked, but the TypeScript server build and live API/database integration were not run because dependencies are not installed in this environment.
