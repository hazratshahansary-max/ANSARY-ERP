# Mandatory data-integrity rules -> enforcement -> tests

| # | Rule | Enforced by | Test (database/tests/test_sqlite.py) |
|---|---|---|---|
| 1 | Confirmed purchase updates stock | `trg_purchase_invoices_post` creates batches, weighted batch cost, `purchase` movements | `test_purchase_posting_creates_batch_stock_and_weighted_cost` |
| 2 | Confirmed sale reduces stock | `trg_sales_invoices_post` -> `sale` movements (qty + free qty) | `test_confirmed_sale_reduces_batch_stock_and_writes_movement` |
| 3 | Customer payment updates customer balance | journal lines tagged `customer_id`; allocation applied to invoice at voucher posting; `v_customer_balance` | `test_receivables_and_payables_match_subledgers`, `test_allocations_updated_invoice_payment_status` |
| 4 | Supplier payment updates supplier balance | same for `supplier_id`; `v_supplier_balance` | same |
| 5 | Return reverses the correct transaction | return must reference original invoice/line/batch; cumulative quantity cap; stock + cost from original | `test_sales_return_cannot_exceed_quantity_sold_and_is_cumulative`, `test_purchase_return_limits`, `test_same_item_twice_in_one_return_blocked` |
| 6 | Expense updates cash/bank | voucher posting requires a posted journal whose total = amount x rate | `test_voucher_amount_must_match_journal` |
| 7 | Unique reference numbers | UNIQUE on every document number; `number_sequences` per branch/year/device | `test_unique_document_numbers`, `test_duplicate_supplier_invoice_number_rejected` |
| 8 | Everything audited | `*_audit` triggers write `audit_log` on every status change; users audited (never the hash); log is append-only | `test_audit_log_records_status_changes_and_never_password_hash` |
| 9 | No duplicate posting | status-transition guard, one movement per (source line, type, batch), `client_uuid` idempotency key, supplier invoice uniqueness | `test_duplicate_posting_does_not_duplicate_stock` |
| 10 | Financial operations transactional | every posting is one statement/transaction; any trigger failure rolls back everything (protocol in ARCHITECTURE.md) | every negative test asserts nothing changed |
| 11 | Never delete posted transactions | `no_delete` guards, frozen-column guards, line guards, reversal-only workflow | `test_posted_documents_are_immutable_and_undeletable`, `test_journal_lines_of_posted_entry_are_frozen` |
| 12 | Consistent costing | batch-specific cost frozen on sale lines; valuation == inventory account | `test_inventory_account_equals_stock_valuation` |
| 13 | Batch-level stock accuracy | movements are the only way to change stock; `qty_on_hand >= 0`; `v_integrity_issues` re-verifies | `test_batch_quantities_match_independent_simulation`, `test_negative_stock_prevented` |
| 14 | Preserve historical prices/details | item rows snapshot price, cost, tax; `medicine_price_history`; exchange-rate history; per-document rate | `test_price_history_trigger`, `test_usd_receipt_stores_currency_and_rate` |

Additional guarantees: empty documents cannot post; unbalanced / single-line / non-postable-account journals rejected; closed financial years reject postings;
expired or blocked batches cannot be sold; expired goods cannot be received; the last active Super Admin cannot be removed; documents cannot be inserted already `posted`.

## Periodic verification
`SELECT * FROM v_integrity_issues;` must return no rows (unbalanced journals, batch quantity != movements, posted documents without journal/movements, overpaid invoices).
Run it after every sync and as part of backup verification.
