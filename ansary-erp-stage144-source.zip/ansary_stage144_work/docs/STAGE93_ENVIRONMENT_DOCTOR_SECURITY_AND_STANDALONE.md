# Stage 93 — Environment doctor security and standalone bundle support

The environment doctor writes `SERVER_ENVIRONMENT_REPORT.json`. Previously it copied the configured npm registry URL directly into that report. A registry URL may contain user information, passwords, query tokens or fragments.

Stage 93 now sanitizes the registry URL before placing it in the report. DNS checks still use the original URL's hostname, so redaction does not alter the connectivity test.

The doctor now supports two project layouts:

- Workspace repository: root `package.json` plus `server/package.json`.
- Standalone API bundle: one API `package.json` at the bundle root.

The lockfile auditor validates a standalone lockfile against its root package entry and dependency groups. The API bundle now includes the dependency-setup helper imported by the doctor.

Run `npm run doctor` from the standalone bundle to inspect readiness. The report is diagnostic only; a READY report is not a substitute for a successful TypeScript build, live HTTP checks, database integration tests or production security review.
