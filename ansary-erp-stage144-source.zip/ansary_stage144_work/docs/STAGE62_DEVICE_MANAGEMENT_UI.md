# Stage 62 — Device Management UI and Permission Hardening

## Implemented
- Added the dedicated `sync.manage` permission to the generated production seed. It is assigned to `super_admin` and `administrator` through the role definitions; other roles do not receive it.
- Device listing and event listing now require `sync.view`.
- Device registration, token rotation, revocation, and token-audit viewing require `sync.manage` and remain branch-scoped.
- Added a bounded token audit endpoint (`GET /api/sync/devices/:deviceId/audit`) that returns action, timestamp, and actor username only; it never returns token material.
- Added Pashto device-management controls to the Sync monitor: register, view token audit, rotate token, and revoke device.
- Token values are shown once in the UI and are not written to browser local storage. The user must copy and securely configure the token on the corresponding device.
- Destructive actions require browser confirmation. Rotation warns that the old token is immediately invalidated.

## Upgrade note
Existing databases must be re-seeded with the production seed to add the new permission and its role mappings. For SQLite, after taking a backup, run:

```bash
python scripts/migrate_sqlite.py ansary.db --seed
```

For PostgreSQL, use the repository's migration script with its `--seed` option after taking a database backup. Do not load sample data into a live database.

## Validation
- Project Python tests: 239 passed.
- Database tests: 82 passed.
- Client JavaScript syntax checks: passed.
- Schema generator consistency check: 37 generated files current.
- Desktop package contract check: passed (static contract only).

## Not verified
- TypeScript build with installed dependencies.
- Live HTTP API and PostgreSQL runtime.
- Two-device end-to-end sync.
- Windows installer or Android APK build.

This stage manages device credentials; it does not enable financial or stock synchronization.
