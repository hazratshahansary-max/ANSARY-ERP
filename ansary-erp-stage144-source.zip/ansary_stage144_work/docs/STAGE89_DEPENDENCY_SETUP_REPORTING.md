# Stage 89 — API dependency setup diagnostics

The server dependency setup command now writes `SERVER_DEPENDENCY_SETUP_REPORT.json` after a successful install or a terminal failure. The report contains a stable result code, a human-readable message, attempt count, exit status, signal, timestamps, selected install mode, offline state and cache path.

Registry values are sanitized before persistence: URL username/password, query strings and fragments are removed. If the configured registry is not a valid URL, the raw value is not written to the report.

Offline mode runs exactly once because retrying an unchanged offline cache cannot make missing cache entries appear. Online mode retains bounded retries for transient network failures. This improves diagnosis and does not claim to install dependencies or make the API runnable when the npm registry/cache is unavailable.
