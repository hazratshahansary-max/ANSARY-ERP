# Stage 60 — Sync Retry Manager Report

Run a privacy-conscious, read-only report:

```bash
python scripts/sync_retry_manager_report.py data/ansary.db
```

For deterministic review:

```bash
python scripts/sync_retry_manager_report.py data/ansary.db --now 2026-11-15T12:10:00Z
```

The report summarizes pending/failed/sent counts for the five supported master-data tables and classifies pending retry-due items, failed transient candidates requiring explicit confirmation, waiting items, and permanent/unknown errors requiring operator review. It lists sequence IDs and safe classifications only. It does not expose raw errors or payloads, mutate the database, or make network requests.

Stage 60 also corrects the Stage 59 advisor classification: a due transient row already marked `failed` is now clearly labelled `failed_retry_candidate_requires_confirmation`, rather than being ambiguously shown as merely waiting. The existing `scripts/sync_retry_outbox.py` remains the separate explicit-confirmation mutation tool; the report never invokes it.

Only `categories`, `companies`, `medicines`, `customers`, and `suppliers` are included. Financial, invoice, payment, accounting, batch, and stock events remain excluded from sync retry scope.
