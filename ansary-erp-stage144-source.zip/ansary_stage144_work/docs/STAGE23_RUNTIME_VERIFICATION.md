# Stage 23 — Runtime verification harness and integration audit

## What was added

- `scripts/api_smoke.py`: dependency-free HTTP smoke checker for `/health/live` and `/health/ready`; optionally checks authenticated `/api/auth/me` with a bearer token.
- `scripts/verify_local.sh`: one-command local verification for the SQLite schema suite, Python feature suite, SQL placeholder tests, browser JavaScript syntax, and TypeScript build when workspace dependencies are installed.
- `tests/api/test_api_smoke.py`: three tests using a local mock HTTP server, including rejection of an invalid token.

## Validation performed in this environment

- SQLite schema tests: 80 passed.
- Python feature tests: 44 passed.
- SQL placeholder Node tests: 5 passed.
- API smoke-checker tests: 3 passed.
- Browser client JavaScript syntax: passed.
- ZIP archive integrity: checked after packaging.

## Explicitly not validated

- `npm install` did not finish within the available execution window.
- `tsc -p server/tsconfig.json --noEmit` was attempted and failed because dependencies and Node.js type declarations are not installed (`express`, `argon2`, `better-sqlite3`, `pg`, `@types/node`, etc.).
- No real Express server was started; no live `/health/*`, setup, login, purchase, or sales HTTP request was performed.
- No PostgreSQL server or browser end-to-end environment was available.

The 3 API smoke tests validate the checker against a local mock HTTP server, not the ANSARY ERP server itself.

## How to run on a computer with Node.js and network access

From the project root:

```bash
npm install
bash scripts/verify_local.sh
```

In a separate terminal, after configuring `server/.env` and starting the server:

```bash
npm run dev:server
```

Then run:

```bash
python scripts/api_smoke.py --base-url http://127.0.0.1:3000
```

After logging in, pass the returned bearer token:

```bash
python scripts/api_smoke.py --base-url http://127.0.0.1:3000 --token YOUR_BEARER_TOKEN
```

Use a disposable test database for setup and transaction tests. Do not point first-time integration tests at real business data.
