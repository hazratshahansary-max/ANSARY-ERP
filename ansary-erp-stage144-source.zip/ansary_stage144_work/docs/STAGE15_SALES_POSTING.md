# Stage 15 — Sales invoice posting

## Implemented

- Sales invoice header recalculation now uses the actual SQLite schema columns (`subtotal`, `discount_amount`, `tax_amount`, `total`, `payment_status`).
- Sales invoice creation and line insertion were aligned with the generated schema, including `cost_price` and `gross_profit` fields.
- Batch validation uses the actual batch ledger fields (`qty_on_hand`, `is_blocked`) and enforces branch, medicine, expiry, and available quantity checks.
- `POST /sales/invoices/:id/post` is enabled with `sales.post` permission and user-branch validation.
- Posting checks that the invoice has lines, that each batch is valid and has enough stock, and that an open financial year exists.
- A balanced journal is created with sales revenue, customer receivable and/or cash/bank debit, tax payable where applicable, and COGS/inventory entries.
- Journal posting and invoice posting are submitted through the database adapter's transaction operation list. The SQLite invoice-posting trigger writes immutable negative stock movements and freezes line cost/profit values.
- Response includes invoice/journal IDs, COGS, gross profit, and resulting batch quantities.
- Sales listing uses the actual invoice balance fields.

## Tests

`python -m unittest discover -s tests/sales -v` — 2 SQLite integration-contract tests pass. They verify stock reduction, immutable sale movement, balanced journal, and rejection of insufficient stock.

## Limits

- The database adapter transaction implementation is atomic for the supported SQLite and PostgreSQL drivers, but PostgreSQL trigger parity and live PostgreSQL posting have not been exercised.
- No live HTTP/API integration test or TypeScript dependency build has been run in this workspace.
- Sales returns, receipt allocation workflows, bank account selection beyond the cash/bank system account, and invoice reversal UI remain separate tasks.
- This stage does not produce Windows installers or Android APKs.
