# Stage 39 — inbound master-data apply

Stage 39 adds `scripts/sync_pull_apply.py`, a SQLite-side consumer for a previously downloaded `/api/sync/pull` JSON response.

## Usage

1. Download a pull response from the authenticated server. Save the complete JSON object (including `events` and `cursor`) as `pull-response.json`.
2. Back up the local SQLite database.
3. Apply the response:

```bash
python scripts/sync_pull_apply.py data/ansary.db pull-response.json
```

4. Inspect `applied`, `conflicts`, `duplicates`, and `cursor` in the output. The script commits data changes, inbox idempotency records, conflict records, and the local cursor in one SQLite transaction.
5. Only after a successful commit, send the authenticated `POST /api/sync/ack` request with the same device ID and cursor. This script deliberately does not send network requests or ACK automatically.

## Scope and safeguards

- Only `categories`, `companies`, `medicines`, `customers`, and `suppliers` are supported.
- Financial and stock tables are rejected.
- Local pending outbox changes are not overwritten; they are recorded in `sync_inbox_conflicts`.
- Version mismatches are recorded as conflicts.
- Replayed event UUIDs are idempotent.
- A malformed event aborts the entire batch and rolls back the cursor.
- This is a SQLite command-line integration utility, not a live browser/desktop automatic sync client. It has not been verified against a live server or two physical devices.
