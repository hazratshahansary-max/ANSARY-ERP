# Stage 67 — Public authentication endpoint rate limiting

## Changes

- Added a dependency-free fixed-window in-memory rate limiter.
- `/api/auth/login` is limited to 10 requests per client IP per 15-minute window.
- `/api/auth/setup` is limited to 5 requests per client IP per 15-minute window.
- Blocked requests receive HTTP 429, a stable error code, `Retry-After`, and standard `RateLimit-*` headers.
- The limiter uses Express `req.ip` or the socket address. It does not read `X-Forwarded-For` directly; configure Express proxy trust only when the deployment is behind a trusted reverse proxy.
- Expired buckets are periodically cleaned to limit memory growth.
- No new npm dependency is required.

## Limitations

- The limiter is process-local and resets when the API process restarts.
- In a multi-instance deployment, each instance has its own counters. A shared store (for example Redis) is required for cluster-wide enforcement.
- The existing per-account failed-login lockout remains in place; this stage adds a separate IP-level layer.
- This is not a substitute for HTTPS, strong passwords, secure proxy configuration, or monitoring.

## Tests

Run:

```bash
npm run test:auth-rate-limit
```

The tests cover allowed requests, HTTP 429 responses, independent client buckets, window reset, and invalid configuration.

## Not verified

The TypeScript API build and live HTTP login/setup routes remain unverified because workspace dependencies are not installed in this environment. The rate limiter's standalone Node.js tests do not prove the complete API server is running.
