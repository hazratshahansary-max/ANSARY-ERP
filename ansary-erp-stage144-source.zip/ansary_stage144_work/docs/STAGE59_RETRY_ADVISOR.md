# Stage 59 — Sync Retry Advisor

Run:

```bash
python scripts/sync_retry_advisor.py data/ansary.db
```

For deterministic review:

```bash
python scripts/sync_retry_advisor.py data/ansary.db --now 2026-11-15T12:00:00Z
```

The tool opens SQLite in read-only mode. It does not retry, modify outbox rows,
make network requests, or print raw error messages. Only `categories`,
`companies`, `medicines`, `customers`, and `suppliers` are in scope. Financial
and stock rows are excluded. Unknown/permanent errors are held for operator
review. Backoff starts at 30 seconds, doubles per attempt, and caps at 1 hour.
The operator must use the existing explicit retry workflow after reviewing.
