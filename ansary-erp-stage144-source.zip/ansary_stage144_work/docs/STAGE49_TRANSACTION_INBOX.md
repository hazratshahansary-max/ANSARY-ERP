# Stage 49 — Durable idempotent transaction inbox

This stage adds a SQLite reference inbox for events that pass the Stage 48
contract. It stores the envelope and marks it `accepted`; it does not post or
apply invoices, payments, journal entries, stock movements, or any other
business data.

## Guarantees tested

- The envelope is validated before any database write.
- `event_uuid` is the primary key. An identical retry returns `duplicate` and
  does not create a second row.
- Reuse of an event UUID with changed content is rejected.
- `(device_id, device_sequence)` is unique; a sequence collision is rejected.
- Insert is performed under `BEGIN IMMEDIATE`, and failures roll back.
- The inbox status is `accepted`, not `applied`.

## Usage

```python
from scripts.sync_transaction_inbox import TransactionInbox
inbox = TransactionInbox('data/transaction-inbox.db')
result = inbox.accept(validated_envelope)
```

## Security and deployment boundary

This is a local SQLite reference implementation and automated test target, not
a production server endpoint. It does not authenticate device credentials,
authorize actor/branch membership, validate invoice totals or stock availability,
verify accounting balance, assign server-side sequence numbers, or apply
business rows. A production API must perform those checks and persist its inbox
record atomically with the corresponding business transaction before reporting
acceptance. No HTTP route or financial/stock synchronization is enabled here.
