# Stage 40 — HTTP master-data pull/apply/ack

Stage 40 adds `scripts/sync_http_client.py`, a one-cycle authenticated HTTP client.
It reads `ANSARY_SYNC_TOKEN` from the environment, `ANSARY_SYNC_SERVER` and
`ANSARY_SYNC_DEVICE_ID` optionally from the environment, and accepts the local
SQLite database path as its positional argument.

Example (PowerShell):

```powershell
$env:ANSARY_SYNC_SERVER = "https://your-erp-server.example"
$env:ANSARY_SYNC_DEVICE_ID = "registered-device-uuid"
$env:ANSARY_SYNC_TOKEN = "your-access-token"
python scripts/sync_http_client.py data/ansary.db
```

Example (Linux/macOS shell):

```sh
export ANSARY_SYNC_SERVER="https://your-erp-server.example"
export ANSARY_SYNC_DEVICE_ID="registered-device-uuid"
export ANSARY_SYNC_TOKEN="your-access-token"
python scripts/sync_http_client.py data/ansary.db
```

The client first retries a previously committed pending ACK, then requests
`GET /api/sync/pull` with `scope=master`, applies the batch in one local SQLite
transaction, and sends `POST /api/sync/ack` only after the local commit. The
pending ACK cursor is persisted with the local apply transaction. If ACK fails,
the next run retries that ACK before pulling more data. Repeating an ACK is
safe under the server cursor checks.

The server's `scope=master` filter limits this client to `categories`,
`companies`, `medicines`, `customers`, and `suppliers`; financial and stock events
are not delivered to this applier. Known server-only fields that have no safe
local counterpart are intentionally ignored and counted in `ignored_fields`:
company notes, medicine tax_rate/image_path, customer opening_balance, and
supplier opening_balance/payment_terms_days. Aliases include company_type to
kind, customer_code to code, and supplier_code to code. Opening balances remain
excluded because they are financial data.

This is an executable one-cycle HTTP client, not a background scheduler. The
repository tests use mocked HTTP transport and contract checks. A deployed API,
valid user token, registered device, compatible server/local schema versions,
TLS endpoint, and two physical devices are still required for end-to-end
verification. No live server credentials or deployment environment were
available during this build, so live HTTP/PostgreSQL/two-device tests are not
claimed as passed. Push of local outbox events is not included in this stage.
