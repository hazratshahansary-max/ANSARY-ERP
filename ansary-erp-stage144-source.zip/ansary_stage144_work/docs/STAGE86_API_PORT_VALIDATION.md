# Stage 86 — API TCP port validation

The API now validates `PORT` before opening the database or starting Express. An absent value uses port 3000. Valid values are decimal whole numbers from 1 through 65535. Blank strings, signs, fractions, exponent notation, non-numeric text, zero, and values above 65535 are rejected with a clear startup error.

This prevents malformed environment configuration from reaching `app.listen()` and avoids doing database startup work when the port setting is invalid. The parser is isolated in `server/src/runtime/portConfig.js` so it can be tested without installing Express, SQLite, PostgreSQL, or other runtime packages.

Run the focused test with `npm run test:api-port-config`. This is a unit test only; it does not claim that the full API has been built or launched.
