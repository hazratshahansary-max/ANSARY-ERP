# Stage 74 — Server dependency recovery and build diagnostics

## Changes
- Server build preflight now checks the registry host actually configured by `ANSARY_NPM_REGISTRY`, `npm_config_registry`, or the project's `.npmrc`, rather than hard-coding `registry.npmjs.org`.
- DNS lookup has a bounded timeout that is cleaned up after completion.
- Dependency installation now prefers the local npm cache before reaching the network.
- Added an explicit cache-only install mode: `ANSARY_NPM_OFFLINE=true npm run setup:server`.
- Kept dependency installation scoped to `@ansary-erp/server`; it does not open or modify the application database.
- Updated workspace and desktop app package versions to `0.74.0`.
- Regenerated the standalone API source bundle at `release/server-stage74`.

## Build / install result in this environment
- Node.js 22.16.0 and npm 10.9.2 are present.
- The registry preflight reports `registry.npmjs.org` DNS unavailable or timed out.
- A bounded dependency setup attempt (`ANSARY_NPM_RETRIES=1`, timeout 15 seconds) timed out.
- No package lock or `node_modules` were created; no TypeScript build was possible.
- A configured alternate npm registry can now be checked by preflight, and cache-only installation can be attempted on machines with a populated npm cache.

## Commands on a network-enabled machine

```bash
# Optional: use an organization's or mirror registry
# PowerShell:
$env:ANSARY_NPM_REGISTRY = 'https://your-approved-registry/'

npm run preflight:server
npm run setup:server
npm run build:server
npm run smoke:server
```

If all required package tarballs already exist in the local npm cache:

```bash
# PowerShell:
$env:ANSARY_NPM_OFFLINE = 'true'
npm run setup:server
npm run build:server
```

Do not use a random public mirror for production dependency installation. Prefer the npm registry or an organization-approved mirror.

## Not verified
- TypeScript build and live HTTP API.
- Live PostgreSQL integration and two-device Sync.
- Windows installer, Android APK, and Windows 7 32-bit support.
