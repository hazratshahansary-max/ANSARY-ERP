# Testing

```bash
python -m unittest discover -s database/tests -v                       # SQLite + parity (80 tests, ~6 s)
python -m unittest database/tests/test_schema_parity.py -v             # generated files in sync, PG/SQLite parity
psql -v ON_ERROR_STOP=1 -d ansary_test -f database/tests/postgres_integrity_tests.sql   # needs a PostgreSQL server
```
Last recorded run (Stage 1 build): **80 tests OK** (SQLite 3.45, Python 3.12); import of 100,000 medicines 3.8 s, FTS prefix search 0.5 ms,
name-prefix 2 ms, barcode lookup 0.02 ms (index used). The PostgreSQL suite has **not been run** (no server in the build environment).

Test groups: schema & seeds (7) · sample-data reconciliation (13) · integrity rules (42) · sync bookkeeping (8) · search/scale (2) · parity & hygiene (8) · migration runner (checksum tamper detection).

`database/tests/test_sqlite.py` also acts as the executable specification for the posting protocol: see helpers `post_journal()` and `make_sale()`.
