# Stage 103 — npm registry connectivity preflight

The server build preflight now checks more than DNS when server packages are missing:

1. Resolve the configured npm registry hostname.
2. If DNS resolves, issue a bounded (3-second) HTTP request to the registry `/-/ping` endpoint.
3. Report HTTP status separately from DNS so DNS success is not mistaken for a usable registry connection.
4. Treat HTTP 5xx and transport failures as blockers. A 401/403 response confirms transport reachability but warns that registry authentication may be required.
5. Strip URL username, password, query, and fragment before the probe; reports contain only a status/reason, never registry credentials.

The probe is skipped when all declared server dependencies already resolve locally, or when DNS has already failed. It is read-only and does not install packages or change application data.

Run:

```bash
node scripts/server-build-preflight.mjs
node scripts/server-build-preflight.mjs --json
```

This change also fixed a stale release version in `desktop/app/package.json` that caused the full Python desktop-contract test to fail after version bumps. All six workspace manifests and the visible browser version now align at `0.103.0`.

The current environment still cannot resolve `registry.npmjs.org` (`EAI_AGAIN`), so this diagnostic improvement does not claim that dependencies were installed or that the API build succeeded.
