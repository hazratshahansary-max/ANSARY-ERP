# Stage 97 — Portable npm cache validation

## Problem
The dependency setup accepted a configured cache if `_cacache` existed, even when the npm content index (`_cacache/index-v5`) was absent. Such a directory is not a complete portable npm cache and can only fail later during an offline install with a less useful npm error.

## Change
`validateNpmCacheDir()` now requires both:
- `<cache>/_cacache/` as a directory; and
- `<cache>/_cacache/index-v5/` as a directory.

The diagnostic explicitly tells the operator to copy the complete npm cache folder when the index is missing. Tests cover a valid cache, a non-cache path, and an incomplete cache that has content storage but no index.

## Operator note
This check validates the expected cache structure only. It does not prove that every package tarball required by ANSARY ERP is present. A real offline `npm ci` is still the definitive completeness test.
