# Stage 51 — Server-side device authentication

## What changed

- Added `token_sha256` to `sync_devices` in SQLite and PostgreSQL migration 019.
- Device registration (`POST /api/sync/devices`) now creates a high-entropy device token, stores only its SHA-256 digest, and returns the raw token once in the registration response.
- The authenticated user's existing API session remains required by the sync router.
- `POST /api/sync/push` and `POST /api/sync/apply-master` additionally require `X-Device-Token` for the selected registered device.
- Device tokens are compared in constant time. Revoked devices and legacy devices without a token hash cannot perform these write operations.
- Device tokens are not returned by device-list endpoints.

## Client requirement

Keep the `deviceToken` from the successful registration response in the device's protected local secret store. Send it as `X-Device-Token` on sync push/apply-master requests, alongside the normal user session `Authorization: Bearer ...` header. Do not place it in URLs, logs, or ordinary application settings.

## Rotation / legacy devices

Existing registered devices have a null token hash after migration and therefore cannot push or apply master events until re-registered or until a future administrator-controlled rotation workflow is implemented. This is intentional fail-closed behavior.

## Verification boundary

Python contract tests and SQLite migration tests validate the migration and source contract. The TypeScript server build, live HTTP registration, PostgreSQL runtime migration, Windows installer, Android package, and multi-device end-to-end flow were not run in this environment. This stage adds device authentication only to the two write endpoints; read endpoints still rely on the user's API session and branch scoping.
