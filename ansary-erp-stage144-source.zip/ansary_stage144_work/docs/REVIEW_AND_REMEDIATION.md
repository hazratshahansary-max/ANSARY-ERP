# ANSARY ERP — Stage 1 review and remediation record

Review date: 2026-11-15

## Scope actually present in the supplied ZIP

The supplied archive is a Stage 1 database-foundation project. It contains a
Python schema DSL, generated SQLite/PostgreSQL migrations, production/sample
seeds, migration runners, documentation and automated database tests.

It does **not** contain an implemented REST API, graphical client, Windows
desktop application, Android application, invoice/PDF renderer, or running
online/offline synchronization service. The `server/`, `client/`, `desktop/`
and `shared/` directories are reserved for later stages.

## Validation performed on this archive

- `python tools/schema/build.py --check`: passed; 37 generated files current.
- `python -m unittest discover -s database/tests -v`: passed; 80 tests.
- Fresh SQLite database migration + production seed + sample seed: passed.
- SQLite `PRAGMA integrity_check`: `ok`.
- SQLite `PRAGMA foreign_key_check`: zero violations.
- PostgreSQL migrations and PostgreSQL integration tests: not executed; a live
  PostgreSQL server was not available in this validation environment.

## Repository structure issue clarified

The archive contains two SQL trees: `database/` and `server/db/`. The active
migration runner and schema generator use `database/` only. The older
`server/db/` SQL tree is retained for historical reference, and
`server/db/README.md` now explicitly marks it as legacy and non-executable.
This avoids accidentally applying an outdated migration set. No existing SQL
files or user data were deleted.

## Remaining work — not claimed as completed

1. Execute and fix PostgreSQL migrations on PostgreSQL 14+.
2. Implement Stage 2 authentication, sessions, RBAC and API.
3. Implement medicine, inventory, purchasing and sales workflows.
4. Implement accounting workflows and user-facing reports.
5. Implement UI, invoice/PDF printing and backup/restore interface.
6. Implement and test the actual synchronization service.
7. Build and test Windows and Android deliverables.

## Safety note

The sample seed is demonstration data and must never be loaded into a live
production database. Back up any existing database before applying future
migrations. The current changes are documentation/structure clarification only;
they do not claim to deliver the later application stages.
