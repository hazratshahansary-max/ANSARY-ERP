# Stage 44 — local Sync status and conflict report

Stage 44 adds `scripts/sync_status_report.py`, a read-only SQLite diagnostic report for the five supported master-data tables. It summarizes outbox counts by status/table/operation, conflict counts by resolution/table, recent pending conflict identifiers and version metadata, cursor/ACK state, tombstone count, and actionable warnings.

## Privacy and safety

- Opens the database in SQLite read-only mode.
- Never prints raw local/server conflict payloads, business record contents, passwords, or access tokens.
- Does not modify outbox rows, conflicts, tombstones, or cursors.
- Reports only local device state; it does not prove that a server or another device is online or synchronized.
- Does not include financial or inventory tables in its master-data scope.

## Usage

```bash
python scripts/sync_status_report.py data/ansary.db
python scripts/sync_status_report.py data/ansary.db --recent-limit 50
```

The output is JSON suitable for support diagnostics. A pending conflict or ACK warning requires operator review; the report does not resolve conflicts automatically.

## Verification

`python -m unittest tests.sync.test_stage44_status_report -v`
