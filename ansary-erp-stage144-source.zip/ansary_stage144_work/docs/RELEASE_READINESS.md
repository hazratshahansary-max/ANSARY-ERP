# ANSARY ERP — Release-readiness audit

Audit baseline: Stage 100 / version 0.100.0 (2026-11-15)

## Verified in this workspace

| Area | Evidence | Boundary |
|---|---|---|
| SQLite schema and migrations | 93 database tests; generated schema check reports 39 files current | SQLite automated tests pass; still back up any real database before upgrades |
| Core Python workflows | 251 application tests | Automated tests do not replace user acceptance with real business records |
| JavaScript helper/runtime contracts | 118 Node.js tests after Stage 100 | Does not prove the TypeScript API can compile or run |
| Browser client | JavaScript syntax, service-worker syntax, and web-manifest JSON checks pass | Full browser/device acceptance has not been completed |
| Desktop packaging contract | Static package contract check passes | No actual Windows installer was built or installed in this environment |
| Python source | `compileall` passes | Compilation is not an end-to-end workflow test |
| Version metadata | Six package manifests and visible browser label checked by `npm run check:versions` | Does not validate release signing or installer metadata outside these files |

## Implemented foundations, but not release-certified

- TypeScript/Express API routes for authentication, users, inventory, purchases, sales, accounting, reports, and sync are present in source.
- SQLite and PostgreSQL schema/migration sources are present. PostgreSQL migration/integrity execution against a live PostgreSQL 14+ service has not been completed here.
- The browser client is a Pashto RTL web app/PWA shell. Offline behavior is limited to the application shell and selected read-only GET cache; offline transaction entry/posting is not enabled.
- Sync relay, device lifecycle, master-data apply, transaction envelope/inbox and retry/conflict foundations exist in source. A complete multi-device, end-to-end financial/stock synchronization acceptance run is not certified.
- Electron/NSIS x64 packaging scripts and configuration exist. A real Setup.exe has not been produced and installed on a clean Windows 10/11 x64 computer.

## Blocking issues before production use

1. **API dependencies/build:** 13 of 14 declared server dependencies were unavailable in the current build runtime. The root `package-lock.json` is missing and the npm cache is incomplete. npm registry access timed out. TypeScript compilation and live HTTP API tests therefore remain blocked.
2. **PostgreSQL:** run all migrations and `database/tests/postgres_integrity_tests.sql` against a disposable PostgreSQL 14+ database; fix and rerun until clean.
3. **Business acceptance:** test initial setup, role/permission boundaries, medicine and batch management, purchase posting, sales posting, receipts/payments, reversals, financial-year closing, reports, and backup/restore with controlled test data.
4. **Sync acceptance:** test two or more devices with intermittent network, duplicate/reordered events, token rotation/revocation, branch isolation, conflict resolution, and stock/financial consistency. Do not assume relay tests prove full sync.
5. **Windows installer:** on Windows 10/11 x64 with Node.js 22.x and npm, install dependencies, run `npm run desktop:release:win`, install the generated Setup.exe on a clean machine, and test first-run database initialization, login, printing, backup/restore, upgrades, and uninstall behavior.
6. **Android:** test the HTTPS PWA on actual Android devices. No APK/AAB is currently provided; the current PWA is not an offline transaction application.
7. **Security and operations:** perform a deployment-specific security review, TLS/reverse-proxy setup, secret management, database backup/restore drill, log retention, and recovery test before production deployment.

## Explicitly unsupported or unverified

- Windows 7 and 32-bit Windows are not supported by the current packaging workflow.
- No Android APK/AAB or Play Store package has been built.
- No live PostgreSQL service, production hosting, or two-device acceptance environment was available for this audit.
- No claim is made that all application features are production-ready merely because unit tests pass.

## Recommended completion order

1. Restore npm registry access or prepare a complete, platform-matched offline npm cache and a real lockfile.
2. Build the API and run live HTTP tests with SQLite.
3. Run PostgreSQL migrations and integration tests.
4. Complete business-workflow and two-device synchronization acceptance.
5. Build and install the Windows x64 package; then validate Android PWA behavior.
6. Complete security, backup/restore, upgrade, and recovery drills.

## Commands

```bash
npm run check:versions
npm run check:client
node --test $(find server scripts -name '*.test.js' -o -name '*.test.mjs' | sort)
python -m unittest discover -s tests -v
python -m unittest discover -s database/tests -v
python tools/schema/build.py --check
python scripts/verify_desktop_package.py
python -m compileall -q scripts tests database desktop
npm run preflight:server
npm run build:server
```

A skipped or blocked command must be reported as such, never counted as a passing build.
