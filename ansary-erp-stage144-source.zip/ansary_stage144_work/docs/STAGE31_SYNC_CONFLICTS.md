# Stage 31 — Explicit sync conflict resolution

Stage 31 adds a local SQLite conflict-resolution utility. It is deliberately
manual: the operator must choose **keep local**, **use server**, **merge**, or
**dismiss** for each pending conflict. No automatic last-write-wins policy is
applied to stock, invoices, or accounting data.

## What each choice does

- `keep_local`: keeps the current local row and ensures a pending outbox event
  exists so the local value can be pushed again.
- `use_server`: applies the stored server payload with remote-trigger
  suppression semantics and marks any pending local outbox item as failed with
  an explanatory reason. Server deletes are represented only as soft deletes;
  hard deletion is refused when the table has no `deleted_at` column.
- `merge`: applies an operator-supplied JSON object and queues an update for a
  later push.
- `dismiss`: records that the conflict was reviewed without changing data.

Every resolution is written to `sync_conflicts.resolution`, `resolved_at`, and
optionally `resolved_by`. The incoming operation (`insert`, `update`, `delete`)
is now preserved in `server_op` by migration 017.

## Python usage

```python
from scripts.sync_conflict_resolution import ConflictResolver
resolver = ConflictResolver(connection, allowed_tables={"medicines", "batches"})
pending = resolver.list_pending()
resolver.resolve("<conflict-id>", "keep_local")
# or resolver.resolve("<conflict-id>", "merge", merged_payload={...})
```

This is **not** a live server-side conflict workflow. The selected local value
must still be synchronized through the authenticated relay, and the relay
currently stores event envelopes rather than applying business changes to its
authoritative tables. Do not enable unattended financial or stock sync based
on this stage alone.
