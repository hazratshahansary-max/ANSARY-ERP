# Stage 24 — Platform compatibility and deployment audit

## What exists today

- Database/schema and business-logic test suites are Python + SQLite.
- The browser client is plain JavaScript/HTML/CSS and calls the Express API.
- The API source is TypeScript/Node.js and declares Node.js 20+.
- SQLite and PostgreSQL adapters are present, but PostgreSQL live validation is not certified.
- `desktop/` is only a reserved workspace manifest; it is not a desktop application.
- There is no Android native project, APK, service worker, or offline-first browser cache.

## Compatibility decision

| Target | Current status | Reason / next requirement |
|---|---|---|
| Windows 10/11 64-bit | Candidate, not certified | Install Node.js 20+, npm dependencies, run server build and end-to-end tests. |
| Windows 7 32-bit | Not supported by current server stack | Node.js 20+ does not support Windows 7; modern native modules such as `argon2` and `better-sqlite3` also need a separately validated legacy strategy. Do not promise an installer. |
| Android 12 browser | Browser UI may be opened over a reachable server | Not an APK; no offline-first support or Android packaging exists. |
| Android APK | Not implemented | Requires a mobile shell/project, secure API configuration, device testing, signing and release process. |
| PostgreSQL server | Source adapter exists, not certified | Requires real PostgreSQL instance, migrations, seed, and API integration tests. |

## Recommended delivery order

1. Install dependencies in a supported Windows 10/11 64-bit or Linux environment.
2. Run `python scripts/preflight.py` and `npm install`.
3. Run `npm run build:server`, `npm run check:client`, and all Python/Node tests.
4. Start SQLite API locally and execute authenticated setup/login, inventory, purchase, sales, receipt/payment and ledger end-to-end tests.
5. Fix any SQL dialect and transaction defects found; validate PostgreSQL separately.
6. Only after those gates pass, choose a desktop wrapper and Android packaging approach.
7. Treat Windows 7 32-bit as a separate legacy product decision, not a build flag. It may require a different backend/runtime and reduced features.

## Read-only preflight

Run from the project root:

```bash
python scripts/preflight.py
```

The script reports OS, Python, SQLite, Node, npm and dependency-folder availability. It does not install packages, modify data, build the server, or certify runtime compatibility.

## Release gate

No `Setup.exe` or `APK` is claimed in Stage 24. Packaging must wait until build, live API, database migrations, auth, purchase/sales posting, backups, and browser QA pass on actual target devices.
