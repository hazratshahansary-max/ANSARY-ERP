# Stage 50 — Transaction Sync Authentication and Authorization

Adds a SQLite reference registry for device credentials, active actors, and explicit actor+device+branch+event-type grants. Device bearer tokens are stored as SHA-256 digests, never plaintext. `TransactionInbox.accept_authorized()` checks the envelope and permission before calling the existing idempotent inbox writer.

## Provisioning example

```python
from scripts.sync_transaction_auth import TransactionSyncAuthorizer
from scripts.sync_transaction_inbox import TransactionInbox

auth = TransactionSyncAuthorizer('auth.db')
token = auth.provision_device('DEVICE-01')  # securely deliver once; do not log it
auth.provision_actor('USER-01')
auth.grant('USER-01', 'DEVICE-01', 'BRANCH-01', ['sales_invoice.posted'])

inbox = TransactionInbox('inbox.db')
inbox.accept_authorized(envelope, auth, token)
```

## Security boundaries and limitations

- Default deny: no device, actor, branch, or event-type grant means rejection.
- Device and actor can be disabled independently.
- The token digest is SHA-256; production deployment should use TLS, secret rotation, rate limiting, audit logging, and a managed identity/secret service.
- This reference implementation is SQLite/local test code. It is not yet wired to the TypeScript HTTP API, has no production login/password flow, and does not prove multi-tenant isolation under a live server.
- Authorized events are only accepted into the inbox; no invoice, journal, or stock rows are applied.
