# Stage 21 — Transaction UI integration

## Delivered

- Connected purchase invoice detail to the purchase invoice list.
- Added purchase line review and an explicit confirm/post action.
- The purchase action calls the existing `POST /api/purchases/invoices/:id/post` endpoint and refreshes the list after success.
- Connected sales invoice detail to the existing `POST /api/sales/invoices/:id/post` endpoint.
- Added explicit confirmation before posting a sale; the server-side posting endpoint remains responsible for stock movements and journal posting.
- Added protected invoice printing through an authenticated fetch, because the print endpoints require a bearer token and cannot safely be opened as a bare URL.
- Corrected the sales invoice list to display the API's `total` field rather than the nonexistent `total_amount` field.

## Validation

- `node --check client/src/app.js` passes.
- Python/SQLite suites pass as recorded in `STAGE21_TEST_RESULTS.txt`.
- Stage 21 contract tests verify that the UI references the existing posting routes and authenticated print helper.

## Not yet validated

- No live Express API was started because npm dependency installation timed out in this environment.
- No real browser end-to-end test was run.
- No PostgreSQL server test was run.
- Purchase/sales posting should first be tried against a copied test database, not the user's live business database.
- The TypeScript build, Windows installer, Android APK, and offline client mode remain outstanding.

## Safe test procedure

1. Make a backup of the SQLite database.
2. Start the API locally with the configured database and seed/test company.
3. Sign in with a test administrator.
4. Create a purchase draft, add a batch line, verify it, then post it; confirm the stock movement and journal.
5. Create a sales draft, select a batch, add a line, then post it; confirm stock reduction and journal.
6. Verify the printed invoices in the browser.
7. Never use the production database for first-run integration tests.
