# Cloud / offline synchronisation architecture

## Model
Hub-and-spoke. **PostgreSQL = source of truth.** Each desktop/Android device keeps a SQLite copy of its branch and works offline.
The sync service (Stage 10) is the only writer in *remote mode*.

## Row metadata (every synchronised table)
`id` (UUID) · `origin_device_id` · `created_at` · `updated_at` · `version` (+ `deleted_at` for soft-deleted master data).
Triggers bump `version`/`updated_at` on every local edit. Append-only tables (`stock_movements`, `audit_log`, `login_history`, `medicine_price_history`) carry only origin/created.
Device-local tables never sync: `user_sessions`, `backup_history`, `sync_conflicts`, `sync_log`, `schema_migrations`, `sync_state`, `sync_outbox`.

## Device side (SQLite)
* `sync_outbox(table_name,row_id,op,status)` - filled by triggers; repeated edits of one row collapse into one pending entry (`insert+update = insert`).
* `sync_state`: `applying_remote` (0/1), `device_id`, `device_code`, `last_pulled_seq`, `last_synced_at`.
* **Push:** read pending outbox rows in `seq` order -> load current row JSON (excluding derived columns) -> POST batch -> mark `sent`.
* **Pull:** `GET /sync/changes?since=<last_pulled_seq>` -> set `applying_remote='1'` -> apply in dependency order -> set `'0'` -> store new cursor. While `applying_remote=1` the outbox is **not** written (no echo) and version numbers supplied by the server are kept.

## Server side (PostgreSQL)
* `change_log(seq, table_name, row_id, op, version, branch_id, origin_device_id)` written by `ansary_log_change()` on every insert/update/delete; `pg_notify('ansary_changes', ...)` feeds real-time updates to online clients.
* `sync_devices` registers devices, their branch, last acknowledged `seq`, revocation.
* Pull filter: rows with `branch_id` in the device's branches (or no branch: master data) and `origin_device_id <> device`.
* The sync service executes `SET LOCAL ansary.applying_remote = 'on'` inside its apply transaction. **Only the sync service role may do this** (restrict DB credentials accordingly).

## Conflict detection and resolution
Every push carries `base_version`. The server compares with the stored `version`.

| Data | Rule |
|---|---|
| Append-only (movements, audit, history) | Union - never conflicts (ids are unique). |
| Posted/frozen financial documents | Cannot be edited anywhere, therefore cannot conflict; only the reversal documents sync. |
| Drafts / master data, same version | Accept, `version = base+1`. |
| Server version newer than `base_version` | **Never overwrite newer with older.** Different columns changed -> field-level merge; same column -> row recorded in `sync_conflicts` (both payloads kept) and the server value stays until a user with `sync.resolve_conflicts` decides (`local_won` / `server_won` / `merged`). |
| Stock | Quantities are derived from movements, so two devices selling the same batch offline both sync. If the union would make a batch negative the apply fails for that movement and is recorded as a conflict (`reason='negative_stock'`) for manual correction (adjustment/return) - stock is never silently clamped. |
| Document numbers | Device code is part of the number; unique constraint rejects any residual duplicate -> conflict. |
| Unique business keys (barcode, username, supplier invoice no.) | Unique violation -> conflict record, never a silent merge. |

**Before resolving a serious conflict** the service writes a `backup_history` row (`kind='pre_conflict'`) with a verified backup, and records the outcome in `sync_conflicts.backup_ref` and `sync_log`.

## Apply order (FK dependency)
currencies, branches, company_profile, settings, tax_rates -> roles, permissions, users... -> categories, dosage_forms, units, companies, medicines, customers, suppliers -> financial_years, accounts -> journal_entries (+lines) -> batches -> documents + items -> `stock_movements` -> vouchers/allocations -> audit_log.
Posted documents arrive already `posted` (allowed only in remote mode); the sync service verifies `v_integrity_issues` after each pull batch and raises an alert on any row.

## Rules for the sync service implementer
1. Never send `batches.qty_on_hand`/`last_movement_at`; the receiving DB recomputes from movements (a remote-inserted batch starts at 0).
2. Always pull/apply inside a transaction; on any error roll back and keep the cursor.
3. Full re-sync = restore from a verified server snapshot + `last_pulled_seq = snapshot seq`.
4. Clock skew must never decide a winner; `version`, not timestamps, decides.
