# Backup & restore (database level - Stage 1)
The application features (scheduler, UI, cloud upload, pre-upgrade backup) arrive in Stage 11/12; `backup_history` is ready for them. Manual procedures now:

**SQLite (device)** - consistent online backup, then verify:
```bash
sqlite3 ansary.db "VACUUM INTO 'backup-2026-11-14.db'"
sqlite3 backup-2026-11-14.db "PRAGMA integrity_check; PRAGMA foreign_key_check;"
sqlite3 backup-2026-11-14.db "SELECT * FROM v_integrity_issues;"      # must return nothing
sha256sum backup-2026-11-14.db
```
Restore: close the app, keep the damaged file, copy the verified backup over `ansary.db`, run `scripts/migrate_sqlite.py ansary.db` (applies only missing migrations).

**PostgreSQL**:
```bash
pg_dump -Fc -d ansary -f ansary-2026-11-14.dump
createdb ansary_restore && pg_restore -d ansary_restore --no-owner ansary-2026-11-14.dump
psql -d ansary_restore -c "SELECT * FROM v_integrity_issues"
```
Always take a backup **before** running `migrate_*` against a production database.
