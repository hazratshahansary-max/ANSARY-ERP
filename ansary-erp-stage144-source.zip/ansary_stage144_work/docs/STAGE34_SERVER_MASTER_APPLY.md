# Stage 34 — Authenticated server-side master-data apply

Adds `POST /api/sync/apply-master` to the authenticated sync router. A registered, non-revoked device must belong to one of the authenticated user's branches. Only categories, companies, medicines, customers, and suppliers are accepted. Each table has a fixed writable-field allowlist; client values are parameters, and table/column identifiers come only from server constants or validated allowlists.

Updates and soft deletes require an exact `base_version`; successful writes increment the version. Inserts start at version 1. Event UUIDs are checked against `sync_master_apply_log`; applied events and version conflicts are logged. Customer branch changes are rejected when they cross the device branch. Batches, stock movements, invoices, receipts, payments, and journal records remain excluded.

## Endpoint

`POST /api/sync/apply-master` (Bearer-authenticated)

```json
{
  "deviceId": "registered-device-uuid",
  "events": [
    {
      "event_uuid": "event-uuid",
      "table_name": "categories",
      "row_id": "category-id",
      "op": "update",
      "base_version": 1,
      "payload": { "name": "Updated category" }
    }
  ]
}
```

The response contains applied/conflict/duplicate counts and per-event results. Apply one event at a time; send a new event UUID for a deliberate retry after resolving a conflict.

## Important implementation boundary

The route uses the existing database adapter and its conditional version update. The event apply and audit-log write are separate adapter calls, not one cross-database transaction; a process crash between them can leave a successful write without an idempotency log. Production rollout therefore still requires transaction-level atomicity and live SQLite/PostgreSQL integration tests. This stage is an authenticated server apply path, not a claim of completed multi-device replication.
