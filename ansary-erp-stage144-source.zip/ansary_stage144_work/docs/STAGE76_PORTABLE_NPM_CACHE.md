# Stage 76 — Portable npm cache support

## What changed

- The server dependency installer can use a copied npm cache directory through `ANSARY_NPM_CACHE_DIR`.
- The installer validates that the supplied directory contains npm's `_cacache` store before invoking npm.
- The selected cache is passed to npm as `npm_config_cache`; it does not overwrite the user's global npm configuration.
- Build preflight reports whether a configured external cache is present.
- Existing online, cache-first and explicit offline modes remain supported.

## Use on a computer with internet access

1. Open the project root in a terminal.
2. Run `npm run setup:server` to populate the local npm cache and install the server workspace.
3. Copy the npm cache directory reported by `npm config get cache` to a USB drive. Keep its `_cacache` folder intact.
4. Copy the project and cache to the target computer.

A cache is useful only if the required package tarballs and metadata were actually downloaded. A folder containing `_cacache` does not by itself prove the cache is complete.

## Use on the offline target computer

PowerShell:

```powershell
$env:ANSARY_NPM_CACHE_DIR = 'D:\\ansary-npm-cache'
$env:ANSARY_NPM_OFFLINE = 'true'
npm run setup:server
npm run build:server
```

The cache path must point to the directory directly containing `_cacache`.

## Current environment limitation

Stage 76 was developed in an environment whose DNS lookup for `registry.npmjs.org` fails with `EAI_AGAIN`. The available npm cache contains no package content store, so no dependency archive or successful TypeScript build can honestly be reported from this environment. A portable cache must first be populated on a machine that can download the packages.
