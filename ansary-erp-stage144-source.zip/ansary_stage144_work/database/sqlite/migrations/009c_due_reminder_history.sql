-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 009c_due_reminder_history.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- due_reminder_history: Append-only manual customer due-reminder history; records contact attempts but never sends messages.
CREATE TABLE IF NOT EXISTS due_reminder_history (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    sales_invoice_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    channel TEXT NOT NULL,
    outcome TEXT NOT NULL DEFAULT 'recorded',
    notes TEXT,
    reminded_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    created_by TEXT NOT NULL,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    CONSTRAINT pk_due_reminder_history PRIMARY KEY (id),
    CONSTRAINT ck_due_reminder_history_1 CHECK (channel IN ('phone','sms','email','whatsapp','in_person')),
    CONSTRAINT ck_due_reminder_history_2 CHECK (outcome IN ('recorded','sent','failed')),
    CONSTRAINT fk_due_reminder_history_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_1 ON due_reminder_history (branch_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_2 ON due_reminder_history (sales_invoice_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_customer_id ON due_reminder_history (customer_id);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_created_by ON due_reminder_history (created_by);
