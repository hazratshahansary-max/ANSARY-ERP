-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 000_init.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- SQLite requires: PRAGMA foreign_keys = ON; (per connection) and SQLite >= 3.39.
-- Nothing to create here; kept so both dialects share the same migration numbering.
SELECT 1;
