-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 001_core.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- currencies: Supported currencies; exactly one base currency (AFN).
CREATE TABLE currencies (
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    name_ps TEXT,
    symbol TEXT NOT NULL,
    decimals INTEGER NOT NULL DEFAULT 2,
    is_base INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_currencies PRIMARY KEY (code),
    CONSTRAINT ck_currencies_1 CHECK (length(code) = 3),
    CONSTRAINT ck_currencies_2 CHECK (decimals BETWEEN 0 AND 4),
    CONSTRAINT ck_currencies_3 CHECK (is_base IN (0,1)),
    CONSTRAINT ck_currencies_4 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_currencies_5 CHECK (version >= 1)
);
CREATE UNIQUE INDEX ux_currencies_1 ON currencies (is_base) WHERE is_base;

-- exchange_rates: Exchange rate history (1 unit of from_currency = rate units of to_currency).
CREATE TABLE exchange_rates (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    from_currency TEXT NOT NULL,
    to_currency TEXT NOT NULL,
    rate NUMERIC NOT NULL,
    effective_date TEXT NOT NULL,
    source TEXT NOT NULL DEFAULT 'manual',
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_exchange_rates PRIMARY KEY (id),
    CONSTRAINT uq_exchange_rates_1 UNIQUE (from_currency, to_currency, effective_date),
    CONSTRAINT ck_exchange_rates_1 CHECK (rate > 0),
    CONSTRAINT ck_exchange_rates_2 CHECK (effective_date IS NULL OR date(effective_date) = effective_date),
    CONSTRAINT ck_exchange_rates_3 CHECK (version >= 1),
    CONSTRAINT ck_exchange_rates_4 CHECK (from_currency <> to_currency),
    CONSTRAINT fk_exchange_rates_from_currency FOREIGN KEY (from_currency) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_exchange_rates_to_currency FOREIGN KEY (to_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_exchange_rates_to_currency ON exchange_rates (to_currency);

-- branches: Business branches.
CREATE TABLE branches (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    name_ps TEXT,
    address TEXT,
    phone TEXT,
    email TEXT,
    is_head_office INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    deleted_at TEXT,
    CONSTRAINT pk_branches PRIMARY KEY (id),
    CONSTRAINT uq_branches_1 UNIQUE (code),
    CONSTRAINT ck_branches_1 CHECK (is_head_office IN (0,1)),
    CONSTRAINT ck_branches_2 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_branches_3 CHECK (version >= 1)
);

-- company_profile: Single-row company profile used on invoices and reports.
CREATE TABLE company_profile (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    singleton INTEGER NOT NULL DEFAULT 1,
    name TEXT NOT NULL,
    name_ps TEXT,
    tagline TEXT,
    logo_path TEXT,
    address TEXT,
    phone TEXT,
    email TEXT,
    website TEXT,
    tax_number TEXT,
    license_number TEXT,
    base_currency TEXT NOT NULL DEFAULT 'AFN',
    date_format TEXT NOT NULL DEFAULT 'YYYY-MM-DD',
    language TEXT NOT NULL DEFAULT 'en',
    invoice_footer TEXT,
    invoice_save_dir TEXT,
    developer TEXT NOT NULL DEFAULT 'Hazrat Shah Ansary',
    brand TEXT NOT NULL DEFAULT 'ANSARY DATABASES',
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_company_profile PRIMARY KEY (id),
    CONSTRAINT uq_company_profile_1 UNIQUE (singleton),
    CONSTRAINT ck_company_profile_1 CHECK (singleton = 1),
    CONSTRAINT ck_company_profile_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_company_profile_3 CHECK (version >= 1),
    CONSTRAINT fk_company_profile_base_currency FOREIGN KEY (base_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_company_profile_base_currency ON company_profile (base_currency);

-- settings: Key/value configuration (global, per branch or per user).
CREATE TABLE settings (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    scope_type TEXT NOT NULL DEFAULT 'global',
    scope_id TEXT NOT NULL DEFAULT '',
    key TEXT NOT NULL,
    value TEXT,
    value_type TEXT NOT NULL DEFAULT 'string',
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_settings PRIMARY KEY (id),
    CONSTRAINT uq_settings_1 UNIQUE (scope_type, scope_id, key),
    CONSTRAINT ck_settings_1 CHECK (scope_type IN ('global','branch','user')),
    CONSTRAINT ck_settings_2 CHECK (value_type IN ('string','int','decimal','bool','json')),
    CONSTRAINT ck_settings_3 CHECK (version >= 1)
);

-- tax_rates: Tax configuration.
CREATE TABLE tax_rates (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    name TEXT NOT NULL,
    rate_pct NUMERIC NOT NULL,
    is_default INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_tax_rates PRIMARY KEY (id),
    CONSTRAINT uq_tax_rates_1 UNIQUE (name),
    CONSTRAINT ck_tax_rates_1 CHECK (rate_pct >= 0 AND rate_pct <= 100),
    CONSTRAINT ck_tax_rates_2 CHECK (is_default IN (0,1)),
    CONSTRAINT ck_tax_rates_3 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_tax_rates_4 CHECK (version >= 1)
);

-- invoice_templates: Customisable invoice/label templates (A4, thermal).
CREATE TABLE invoice_templates (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    name TEXT NOT NULL,
    doc_type TEXT NOT NULL,
    paper TEXT NOT NULL,
    config TEXT NOT NULL DEFAULT '{}',
    is_default INTEGER NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_invoice_templates PRIMARY KEY (id),
    CONSTRAINT uq_invoice_templates_1 UNIQUE (name),
    CONSTRAINT ck_invoice_templates_1 CHECK (doc_type IN ('sales_invoice','purchase_invoice','receipt','label','statement')),
    CONSTRAINT ck_invoice_templates_2 CHECK (paper IN ('A4','A5','thermal80','thermal58','label')),
    CONSTRAINT ck_invoice_templates_3 CHECK (config IS NULL OR json_valid(config)),
    CONSTRAINT ck_invoice_templates_4 CHECK (is_default IN (0,1)),
    CONSTRAINT ck_invoice_templates_5 CHECK (version >= 1)
);
