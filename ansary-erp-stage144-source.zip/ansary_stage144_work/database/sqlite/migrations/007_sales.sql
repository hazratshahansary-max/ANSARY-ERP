-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 007_sales.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- sales_orders: Sales quotations and sales orders.
CREATE TABLE sales_orders (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    doc_type TEXT NOT NULL,
    doc_no TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    doc_date TEXT NOT NULL,
    valid_until TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    created_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_orders PRIMARY KEY (id),
    CONSTRAINT uq_sales_orders_1 UNIQUE (doc_no),
    CONSTRAINT ck_sales_orders_1 CHECK (doc_type IN ('quotation','order')),
    CONSTRAINT ck_sales_orders_2 CHECK (doc_date IS NULL OR date(doc_date) = doc_date),
    CONSTRAINT ck_sales_orders_3 CHECK (valid_until IS NULL OR date(valid_until) = valid_until),
    CONSTRAINT ck_sales_orders_4 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_orders_5 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_orders_6 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_orders_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_orders_8 CHECK (total >= 0),
    CONSTRAINT ck_sales_orders_9 CHECK (status IN ('draft', 'confirmed', 'converted', 'cancelled', 'expired')),
    CONSTRAINT ck_sales_orders_10 CHECK (version >= 1),
    CONSTRAINT fk_sales_orders_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_orders_branch_id ON sales_orders (branch_id);
CREATE INDEX ix_sales_orders_customer_id ON sales_orders (customer_id);
CREATE INDEX ix_sales_orders_currency_code ON sales_orders (currency_code);
CREATE INDEX ix_sales_orders_created_by ON sales_orders (created_by);

-- sales_order_items: Order/quotation lines.
CREATE TABLE sales_order_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    order_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    medicine_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    free_quantity NUMERIC NOT NULL DEFAULT 0,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    discount_pct NUMERIC NOT NULL DEFAULT 0,
    tax_pct NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_order_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_order_items_1 UNIQUE (order_id, line_no),
    CONSTRAINT ck_sales_order_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_order_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_order_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_order_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_order_items_5 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_order_items_6 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_order_items_7 CHECK (version >= 1),
    CONSTRAINT fk_sales_order_items_order_id FOREIGN KEY (order_id) REFERENCES sales_orders (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_order_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_order_items_medicine_id ON sales_order_items (medicine_id);

-- sales_invoices: Sales invoices (retail/wholesale, cash/credit); posting reduces stock.
CREATE TABLE sales_invoices (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    invoice_no TEXT NOT NULL,
    sale_type TEXT NOT NULL,
    payment_type TEXT NOT NULL,
    customer_id TEXT,
    sales_order_id TEXT,
    invoice_date TEXT NOT NULL,
    due_date TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    round_off NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    previous_balance NUMERIC NOT NULL DEFAULT 0,
    paid_amount NUMERIC NOT NULL DEFAULT 0,
    payment_method TEXT,
    payment_status TEXT NOT NULL DEFAULT 'unpaid',
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    journal_entry_id TEXT,
    reversal_entry_id TEXT,
    client_uuid TEXT,
    balance_due NUMERIC GENERATED ALWAYS AS (total - paid_amount) STORED,
    account_balance_after NUMERIC GENERATED ALWAYS AS (previous_balance + total - paid_amount) STORED,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoices PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoices_1 UNIQUE (invoice_no),
    CONSTRAINT ck_sales_invoices_1 CHECK (sale_type IN ('retail','wholesale')),
    CONSTRAINT ck_sales_invoices_2 CHECK (payment_type IN ('cash','credit')),
    CONSTRAINT ck_sales_invoices_3 CHECK (invoice_date IS NULL OR date(invoice_date) = invoice_date),
    CONSTRAINT ck_sales_invoices_4 CHECK (due_date IS NULL OR date(due_date) = due_date),
    CONSTRAINT ck_sales_invoices_5 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_invoices_6 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_invoices_7 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoices_8 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoices_9 CHECK (total >= 0),
    CONSTRAINT ck_sales_invoices_10 CHECK (paid_amount >= 0),
    CONSTRAINT ck_sales_invoices_11 CHECK (payment_method IS NULL OR payment_method IN ('cash','bank','cheque','transfer','card')),
    CONSTRAINT ck_sales_invoices_12 CHECK (payment_status IN ('unpaid','partial','paid')),
    CONSTRAINT ck_sales_invoices_13 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_invoices_14 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoices_15 CHECK (payment_type = 'cash' OR customer_id IS NOT NULL),
    CONSTRAINT ck_sales_invoices_16 CHECK (paid_amount <= total),
    CONSTRAINT ck_sales_invoices_17 CHECK (discount_amount <= subtotal),
    CONSTRAINT ck_sales_invoices_18 CHECK (round(total,4) = round(subtotal - discount_amount + tax_amount + round_off,4)),
    CONSTRAINT fk_sales_invoices_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoices_1 ON sales_invoices (invoice_date);
CREATE INDEX ix_sales_invoices_2 ON sales_invoices (customer_id, invoice_date);
CREATE UNIQUE INDEX ux_sales_invoices_3 ON sales_invoices (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_invoices_branch_id ON sales_invoices (branch_id);
CREATE INDEX ix_sales_invoices_sales_order_id ON sales_invoices (sales_order_id);
CREATE INDEX ix_sales_invoices_currency_code ON sales_invoices (currency_code);
CREATE INDEX ix_sales_invoices_posted_by ON sales_invoices (posted_by);
CREATE INDEX ix_sales_invoices_reversed_by ON sales_invoices (reversed_by);
CREATE INDEX ix_sales_invoices_journal_entry_id ON sales_invoices (journal_entry_id);
CREATE INDEX ix_sales_invoices_reversal_entry_id ON sales_invoices (reversal_entry_id);

-- sales_invoice_items: Sales lines; cost_price/gross_profit are frozen at posting.
CREATE TABLE sales_invoice_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    invoice_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    medicine_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    free_quantity NUMERIC NOT NULL DEFAULT 0,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    discount_pct NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_pct NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    cost_price NUMERIC NOT NULL DEFAULT 0,
    gross_profit NUMERIC NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoice_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoice_items_1 UNIQUE (invoice_id, line_no),
    CONSTRAINT uq_sales_invoice_items_2 UNIQUE (invoice_id, batch_id),
    CONSTRAINT ck_sales_invoice_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_invoice_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_invoice_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_invoice_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_6 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_8 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_invoice_items_9 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_invoice_items_10 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoice_items_11 CHECK (round(line_total,4) = round(quantity * unit_price - discount_amount + tax_amount,4)),
    CONSTRAINT fk_sales_invoice_items_invoice_id FOREIGN KEY (invoice_id) REFERENCES sales_invoices (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_invoice_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoice_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoice_items_medicine_id ON sales_invoice_items (medicine_id);
CREATE INDEX ix_sales_invoice_items_batch_id ON sales_invoice_items (batch_id);

-- sales_returns: Sales returns / customer credit notes against an original invoice.
CREATE TABLE sales_returns (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    return_no TEXT NOT NULL,
    original_invoice_id TEXT NOT NULL,
    customer_id TEXT,
    return_date TEXT NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    refund_method TEXT NOT NULL DEFAULT 'credit_note',
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    journal_entry_id TEXT,
    reversal_entry_id TEXT,
    client_uuid TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_returns PRIMARY KEY (id),
    CONSTRAINT uq_sales_returns_1 UNIQUE (return_no),
    CONSTRAINT ck_sales_returns_1 CHECK (return_date IS NULL OR date(return_date) = return_date),
    CONSTRAINT ck_sales_returns_2 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_returns_3 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_returns_4 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_returns_5 CHECK (total >= 0),
    CONSTRAINT ck_sales_returns_6 CHECK (refund_method IN ('credit_note','cash','bank')),
    CONSTRAINT ck_sales_returns_7 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_returns_8 CHECK (version >= 1),
    CONSTRAINT ck_sales_returns_9 CHECK (round(total,4) = round(subtotal + tax_amount,4)),
    CONSTRAINT fk_sales_returns_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_original_invoice_id FOREIGN KEY (original_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_sales_returns_1 ON sales_returns (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_returns_branch_id ON sales_returns (branch_id);
CREATE INDEX ix_sales_returns_original_invoice_id ON sales_returns (original_invoice_id);
CREATE INDEX ix_sales_returns_customer_id ON sales_returns (customer_id);
CREATE INDEX ix_sales_returns_currency_code ON sales_returns (currency_code);
CREATE INDEX ix_sales_returns_posted_by ON sales_returns (posted_by);
CREATE INDEX ix_sales_returns_reversed_by ON sales_returns (reversed_by);
CREATE INDEX ix_sales_returns_journal_entry_id ON sales_returns (journal_entry_id);
CREATE INDEX ix_sales_returns_reversal_entry_id ON sales_returns (reversal_entry_id);

-- sales_return_items: Sales return lines.
CREATE TABLE sales_return_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    return_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    original_item_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    cost_price NUMERIC NOT NULL DEFAULT 0,
    reason TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_return_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_return_items_1 UNIQUE (return_id, line_no),
    CONSTRAINT uq_sales_return_items_2 UNIQUE (return_id, original_item_id),
    CONSTRAINT ck_sales_return_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_return_items_2 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_return_items_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_return_items_4 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_return_items_5 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_return_items_6 CHECK (version >= 1),
    CONSTRAINT ck_sales_return_items_7 CHECK (round(line_total,4) = round(quantity * unit_price + tax_amount,4)),
    CONSTRAINT fk_sales_return_items_return_id FOREIGN KEY (return_id) REFERENCES sales_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_return_items_original_item_id FOREIGN KEY (original_item_id) REFERENCES sales_invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_return_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_return_items_original_item_id ON sales_return_items (original_item_id);
CREATE INDEX ix_sales_return_items_batch_id ON sales_return_items (batch_id);
