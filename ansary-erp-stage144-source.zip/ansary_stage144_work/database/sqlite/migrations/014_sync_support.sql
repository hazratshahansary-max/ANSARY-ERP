-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 014_sync_support.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE TRIGGER trg_currencies_touch AFTER UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE currencies SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE code = NEW.code;
END;

CREATE TRIGGER trg_currencies_outbox_insert AFTER INSERT ON currencies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('currencies', NEW.code, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_currencies_outbox_update AFTER UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('currencies', NEW.code, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_currencies_outbox_delete AFTER DELETE ON currencies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('currencies', OLD.code, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_exchange_rates_touch AFTER UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE exchange_rates SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_exchange_rates_outbox_insert AFTER INSERT ON exchange_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('exchange_rates', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_exchange_rates_outbox_update AFTER UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('exchange_rates', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_exchange_rates_outbox_delete AFTER DELETE ON exchange_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('exchange_rates', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_branches_touch AFTER UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE branches SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_branches_outbox_insert AFTER INSERT ON branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('branches', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_branches_outbox_update AFTER UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('branches', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_branches_outbox_delete AFTER DELETE ON branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('branches', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_company_profile_touch AFTER UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE company_profile SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_company_profile_outbox_insert AFTER INSERT ON company_profile FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('company_profile', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_company_profile_outbox_update AFTER UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('company_profile', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_company_profile_outbox_delete AFTER DELETE ON company_profile FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('company_profile', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_settings_touch AFTER UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE settings SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_settings_outbox_insert AFTER INSERT ON settings FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('settings', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_settings_outbox_update AFTER UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('settings', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_settings_outbox_delete AFTER DELETE ON settings FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('settings', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_tax_rates_touch AFTER UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE tax_rates SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_tax_rates_outbox_insert AFTER INSERT ON tax_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('tax_rates', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_tax_rates_outbox_update AFTER UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('tax_rates', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_tax_rates_outbox_delete AFTER DELETE ON tax_rates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('tax_rates', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_invoice_templates_touch AFTER UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE invoice_templates SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_invoice_templates_outbox_insert AFTER INSERT ON invoice_templates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('invoice_templates', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_invoice_templates_outbox_update AFTER UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('invoice_templates', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_invoice_templates_outbox_delete AFTER DELETE ON invoice_templates FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('invoice_templates', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_roles_touch AFTER UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE roles SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_roles_outbox_insert AFTER INSERT ON roles FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('roles', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_roles_outbox_update AFTER UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('roles', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_roles_outbox_delete AFTER DELETE ON roles FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('roles', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_permissions_touch AFTER UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE permissions SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_permissions_outbox_insert AFTER INSERT ON permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('permissions', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_permissions_outbox_update AFTER UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('permissions', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_permissions_outbox_delete AFTER DELETE ON permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('permissions', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_role_permissions_touch AFTER UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE role_permissions SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_role_permissions_outbox_insert AFTER INSERT ON role_permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('role_permissions', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_role_permissions_outbox_update AFTER UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('role_permissions', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_role_permissions_outbox_delete AFTER DELETE ON role_permissions FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('role_permissions', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_users_touch AFTER UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE users SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_users_outbox_insert AFTER INSERT ON users FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('users', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_users_outbox_update AFTER UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('users', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_users_outbox_delete AFTER DELETE ON users FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('users', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_branches_touch AFTER UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE user_branches SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_user_branches_outbox_insert AFTER INSERT ON user_branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_branches', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_branches_outbox_update AFTER UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_branches', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_branches_outbox_delete AFTER DELETE ON user_branches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_branches', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_permission_overrides_touch AFTER UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE user_permission_overrides SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_user_permission_overrides_outbox_insert AFTER INSERT ON user_permission_overrides FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_permission_overrides', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_permission_overrides_outbox_update AFTER UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_permission_overrides', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_user_permission_overrides_outbox_delete AFTER DELETE ON user_permission_overrides FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('user_permission_overrides', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_login_history_outbox_insert AFTER INSERT ON login_history FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('login_history', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_audit_log_outbox_insert AFTER INSERT ON audit_log FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('audit_log', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_attachments_touch AFTER UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE attachments SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_attachments_outbox_insert AFTER INSERT ON attachments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('attachments', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_attachments_outbox_update AFTER UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('attachments', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_attachments_outbox_delete AFTER DELETE ON attachments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('attachments', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_financial_years_touch AFTER UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE financial_years SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_financial_years_outbox_insert AFTER INSERT ON financial_years FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('financial_years', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_financial_years_outbox_update AFTER UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('financial_years', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_financial_years_outbox_delete AFTER DELETE ON financial_years FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('financial_years', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_number_sequences_touch AFTER UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE number_sequences SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_number_sequences_outbox_insert AFTER INSERT ON number_sequences FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('number_sequences', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_number_sequences_outbox_update AFTER UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('number_sequences', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_number_sequences_outbox_delete AFTER DELETE ON number_sequences FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('number_sequences', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_accounts_touch AFTER UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE accounts SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_accounts_outbox_insert AFTER INSERT ON accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('accounts', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_accounts_outbox_update AFTER UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('accounts', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_accounts_outbox_delete AFTER DELETE ON accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('accounts', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_bank_accounts_touch AFTER UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE bank_accounts SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_bank_accounts_outbox_insert AFTER INSERT ON bank_accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('bank_accounts', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_bank_accounts_outbox_update AFTER UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('bank_accounts', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_bank_accounts_outbox_delete AFTER DELETE ON bank_accounts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('bank_accounts', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_expense_categories_touch AFTER UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE expense_categories SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_expense_categories_outbox_insert AFTER INSERT ON expense_categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('expense_categories', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_expense_categories_outbox_update AFTER UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('expense_categories', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_expense_categories_outbox_delete AFTER DELETE ON expense_categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('expense_categories', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_entries_touch AFTER UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE journal_entries SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_journal_entries_outbox_insert AFTER INSERT ON journal_entries FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_entries', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_entries_outbox_update AFTER UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_entries', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_entries_outbox_delete AFTER DELETE ON journal_entries FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_entries', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_lines_touch AFTER UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE journal_lines SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_journal_lines_outbox_insert AFTER INSERT ON journal_lines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_lines', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_lines_outbox_update AFTER UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_lines', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_journal_lines_outbox_delete AFTER DELETE ON journal_lines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('journal_lines', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_categories_touch AFTER UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE categories SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_categories_outbox_insert AFTER INSERT ON categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('categories', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_categories_outbox_update AFTER UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('categories', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_categories_outbox_delete AFTER DELETE ON categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('categories', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_dosage_forms_touch AFTER UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE dosage_forms SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_dosage_forms_outbox_insert AFTER INSERT ON dosage_forms FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('dosage_forms', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_dosage_forms_outbox_update AFTER UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('dosage_forms', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_dosage_forms_outbox_delete AFTER DELETE ON dosage_forms FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('dosage_forms', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_units_touch AFTER UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE units SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_units_outbox_insert AFTER INSERT ON units FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('units', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_units_outbox_update AFTER UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('units', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_units_outbox_delete AFTER DELETE ON units FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('units', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_companies_touch AFTER UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE companies SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_companies_outbox_insert AFTER INSERT ON companies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('companies', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_companies_outbox_update AFTER UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('companies', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_companies_outbox_delete AFTER DELETE ON companies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('companies', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicines_touch AFTER UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE medicines SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_medicines_outbox_insert AFTER INSERT ON medicines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicines', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicines_outbox_update AFTER UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicines', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicines_outbox_delete AFTER DELETE ON medicines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicines', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicine_barcodes_touch AFTER UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE medicine_barcodes SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_medicine_barcodes_outbox_insert AFTER INSERT ON medicine_barcodes FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicine_barcodes', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicine_barcodes_outbox_update AFTER UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicine_barcodes', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicine_barcodes_outbox_delete AFTER DELETE ON medicine_barcodes FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicine_barcodes', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_medicine_price_history_outbox_insert AFTER INSERT ON medicine_price_history FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('medicine_price_history', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_customers_touch AFTER UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE customers SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_customers_outbox_insert AFTER INSERT ON customers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('customers', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_customers_outbox_update AFTER UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('customers', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_customers_outbox_delete AFTER DELETE ON customers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('customers', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_suppliers_touch AFTER UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE suppliers SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_suppliers_outbox_insert AFTER INSERT ON suppliers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('suppliers', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_suppliers_outbox_update AFTER UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('suppliers', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_suppliers_outbox_delete AFTER DELETE ON suppliers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('suppliers', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_batches_touch AFTER UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE batches SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_batches_outbox_insert AFTER INSERT ON batches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('batches', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_batches_outbox_update AFTER UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('batches', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_batches_outbox_delete AFTER DELETE ON batches FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('batches', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_movements_outbox_insert AFTER INSERT ON stock_movements FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_movements', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustments_touch AFTER UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE stock_adjustments SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_stock_adjustments_outbox_insert AFTER INSERT ON stock_adjustments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustments', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustments_outbox_update AFTER UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustments', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustments_outbox_delete AFTER DELETE ON stock_adjustments FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustments', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustment_items_touch AFTER UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE stock_adjustment_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_stock_adjustment_items_outbox_insert AFTER INSERT ON stock_adjustment_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustment_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustment_items_outbox_update AFTER UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustment_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_adjustment_items_outbox_delete AFTER DELETE ON stock_adjustment_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_adjustment_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfers_touch AFTER UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE stock_transfers SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_stock_transfers_outbox_insert AFTER INSERT ON stock_transfers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfers', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfers_outbox_update AFTER UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfers', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfers_outbox_delete AFTER DELETE ON stock_transfers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfers', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfer_items_touch AFTER UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE stock_transfer_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_stock_transfer_items_outbox_insert AFTER INSERT ON stock_transfer_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfer_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfer_items_outbox_update AFTER UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfer_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_stock_transfer_items_outbox_delete AFTER DELETE ON stock_transfer_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('stock_transfer_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_counts_touch AFTER UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE physical_counts SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_physical_counts_outbox_insert AFTER INSERT ON physical_counts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_counts', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_counts_outbox_update AFTER UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_counts', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_counts_outbox_delete AFTER DELETE ON physical_counts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_counts', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_count_items_touch AFTER UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE physical_count_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_physical_count_items_outbox_insert AFTER INSERT ON physical_count_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_count_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_count_items_outbox_update AFTER UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_count_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_physical_count_items_outbox_delete AFTER DELETE ON physical_count_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('physical_count_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_orders_touch AFTER UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_orders SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_orders_outbox_insert AFTER INSERT ON purchase_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_orders', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_orders_outbox_update AFTER UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_orders', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_orders_outbox_delete AFTER DELETE ON purchase_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_orders', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_order_items_touch AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_order_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_order_items_outbox_insert AFTER INSERT ON purchase_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_order_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_order_items_outbox_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_order_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_order_items_outbox_delete AFTER DELETE ON purchase_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_order_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipts_touch AFTER UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE goods_receipts SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_goods_receipts_outbox_insert AFTER INSERT ON goods_receipts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipts', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipts_outbox_update AFTER UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipts', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipts_outbox_delete AFTER DELETE ON goods_receipts FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipts', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipt_items_touch AFTER UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE goods_receipt_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_goods_receipt_items_outbox_insert AFTER INSERT ON goods_receipt_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipt_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipt_items_outbox_update AFTER UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipt_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_goods_receipt_items_outbox_delete AFTER DELETE ON goods_receipt_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('goods_receipt_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoices_touch AFTER UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_invoices SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_invoices_outbox_insert AFTER INSERT ON purchase_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoices', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoices_outbox_update AFTER UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoices', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoices_outbox_delete AFTER DELETE ON purchase_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoices', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoice_items_touch AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_invoice_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_invoice_items_outbox_insert AFTER INSERT ON purchase_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoice_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoice_items_outbox_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoice_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_invoice_items_outbox_delete AFTER DELETE ON purchase_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_invoice_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_returns_touch AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_returns SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_returns_outbox_insert AFTER INSERT ON purchase_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_returns', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_returns_outbox_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_returns', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_returns_outbox_delete AFTER DELETE ON purchase_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_returns', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_return_items_touch AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE purchase_return_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_purchase_return_items_outbox_insert AFTER INSERT ON purchase_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_return_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_return_items_outbox_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_return_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_purchase_return_items_outbox_delete AFTER DELETE ON purchase_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('purchase_return_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_orders_touch AFTER UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_orders SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_orders_outbox_insert AFTER INSERT ON sales_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_orders', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_orders_outbox_update AFTER UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_orders', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_orders_outbox_delete AFTER DELETE ON sales_orders FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_orders', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_order_items_touch AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_order_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_order_items_outbox_insert AFTER INSERT ON sales_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_order_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_order_items_outbox_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_order_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_order_items_outbox_delete AFTER DELETE ON sales_order_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_order_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoices_touch AFTER UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_invoices SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_invoices_outbox_insert AFTER INSERT ON sales_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoices', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoices_outbox_update AFTER UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoices', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoices_outbox_delete AFTER DELETE ON sales_invoices FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoices', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoice_items_touch AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_invoice_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_invoice_items_outbox_insert AFTER INSERT ON sales_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoice_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoice_items_outbox_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoice_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_invoice_items_outbox_delete AFTER DELETE ON sales_invoice_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_invoice_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_returns_touch AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_returns SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_returns_outbox_insert AFTER INSERT ON sales_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_returns', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_returns_outbox_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_returns', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_returns_outbox_delete AFTER DELETE ON sales_returns FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_returns', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_return_items_touch AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE sales_return_items SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_sales_return_items_outbox_insert AFTER INSERT ON sales_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_return_items', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_return_items_outbox_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_return_items', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_sales_return_items_outbox_delete AFTER DELETE ON sales_return_items FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('sales_return_items', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_vouchers_touch AFTER UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE vouchers SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_vouchers_outbox_insert AFTER INSERT ON vouchers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('vouchers', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_vouchers_outbox_update AFTER UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('vouchers', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_vouchers_outbox_delete AFTER DELETE ON vouchers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('vouchers', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_payment_allocations_touch AFTER UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE payment_allocations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_payment_allocations_outbox_insert AFTER INSERT ON payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('payment_allocations', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_payment_allocations_outbox_update AFTER UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('payment_allocations', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_payment_allocations_outbox_delete AFTER DELETE ON payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('payment_allocations', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_plans_touch AFTER UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE installment_plans SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_installment_plans_outbox_insert AFTER INSERT ON installment_plans FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_plans', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_plans_outbox_update AFTER UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_plans', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_plans_outbox_delete AFTER DELETE ON installment_plans FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_plans', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_schedule_touch AFTER UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE installment_schedule SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_installment_schedule_outbox_insert AFTER INSERT ON installment_schedule FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_schedule', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_schedule_outbox_update AFTER UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_schedule', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_schedule_outbox_delete AFTER DELETE ON installment_schedule FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_schedule', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_payment_allocations_touch AFTER UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
WHEN NEW.version = OLD.version AND (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    UPDATE installment_payment_allocations SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now'), version = OLD.version + 1 WHERE id = NEW.id;
END;

CREATE TRIGGER trg_installment_payment_allocations_outbox_insert AFTER INSERT ON installment_payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_payment_allocations', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_payment_allocations_outbox_update AFTER UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_payment_allocations', NEW.id, 'update') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

CREATE TRIGGER trg_installment_payment_allocations_outbox_delete AFTER DELETE ON installment_payment_allocations FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('installment_payment_allocations', OLD.id, 'delete') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;
