-- Stage 31: preserve the incoming operation so explicit conflict resolution can
-- distinguish an update from a server-side delete.
ALTER TABLE sync_conflicts ADD COLUMN server_op TEXT NOT NULL DEFAULT 'update'
    CHECK (server_op IN ('insert','update','delete'));
