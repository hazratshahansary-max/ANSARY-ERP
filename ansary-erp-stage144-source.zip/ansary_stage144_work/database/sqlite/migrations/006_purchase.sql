-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 006_purchase.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- purchase_orders: Purchase orders.
CREATE TABLE purchase_orders (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    po_no TEXT NOT NULL,
    supplier_id TEXT NOT NULL,
    po_date TEXT NOT NULL,
    expected_date TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft',
    subtotal NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    notes TEXT,
    created_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_orders PRIMARY KEY (id),
    CONSTRAINT uq_purchase_orders_1 UNIQUE (po_no),
    CONSTRAINT ck_purchase_orders_1 CHECK (po_date IS NULL OR date(po_date) = po_date),
    CONSTRAINT ck_purchase_orders_2 CHECK (expected_date IS NULL OR date(expected_date) = expected_date),
    CONSTRAINT ck_purchase_orders_3 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_orders_4 CHECK (status IN ('draft', 'confirmed', 'partially_received', 'received', 'cancelled')),
    CONSTRAINT ck_purchase_orders_5 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_orders_6 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_orders_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_orders_8 CHECK (total >= 0),
    CONSTRAINT ck_purchase_orders_9 CHECK (version >= 1),
    CONSTRAINT fk_purchase_orders_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_orders_branch_id ON purchase_orders (branch_id);
CREATE INDEX ix_purchase_orders_supplier_id ON purchase_orders (supplier_id);
CREATE INDEX ix_purchase_orders_currency_code ON purchase_orders (currency_code);
CREATE INDEX ix_purchase_orders_created_by ON purchase_orders (created_by);

-- purchase_order_items: PO lines.
CREATE TABLE purchase_order_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    order_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    medicine_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    free_quantity NUMERIC NOT NULL DEFAULT 0,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    discount_pct NUMERIC NOT NULL DEFAULT 0,
    tax_pct NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    received_quantity NUMERIC NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_order_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_order_items_1 UNIQUE (order_id, line_no),
    CONSTRAINT ck_purchase_order_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_order_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_purchase_order_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_order_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_purchase_order_items_5 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_purchase_order_items_6 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_order_items_7 CHECK (received_quantity >= 0),
    CONSTRAINT ck_purchase_order_items_8 CHECK (version >= 1),
    CONSTRAINT fk_purchase_order_items_order_id FOREIGN KEY (order_id) REFERENCES purchase_orders (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_order_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_order_items_medicine_id ON purchase_order_items (medicine_id);

-- goods_receipts: Goods receiving notes (do not move stock; the invoice does).
CREATE TABLE goods_receipts (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    grn_no TEXT NOT NULL,
    purchase_order_id TEXT,
    supplier_id TEXT NOT NULL,
    receipt_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    received_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_goods_receipts PRIMARY KEY (id),
    CONSTRAINT uq_goods_receipts_1 UNIQUE (grn_no),
    CONSTRAINT ck_goods_receipts_1 CHECK (receipt_date IS NULL OR date(receipt_date) = receipt_date),
    CONSTRAINT ck_goods_receipts_2 CHECK (status IN ('draft', 'confirmed', 'cancelled')),
    CONSTRAINT ck_goods_receipts_3 CHECK (version >= 1),
    CONSTRAINT fk_goods_receipts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_purchase_order_id FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_received_by FOREIGN KEY (received_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_goods_receipts_branch_id ON goods_receipts (branch_id);
CREATE INDEX ix_goods_receipts_purchase_order_id ON goods_receipts (purchase_order_id);
CREATE INDEX ix_goods_receipts_supplier_id ON goods_receipts (supplier_id);
CREATE INDEX ix_goods_receipts_received_by ON goods_receipts (received_by);

-- goods_receipt_items: GRN lines.
CREATE TABLE goods_receipt_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    receipt_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    po_item_id TEXT,
    medicine_id TEXT NOT NULL,
    batch_no TEXT NOT NULL,
    mfg_date TEXT,
    expiry_date TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    free_quantity NUMERIC NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_goods_receipt_items PRIMARY KEY (id),
    CONSTRAINT uq_goods_receipt_items_1 UNIQUE (receipt_id, line_no),
    CONSTRAINT ck_goods_receipt_items_1 CHECK (mfg_date IS NULL OR date(mfg_date) = mfg_date),
    CONSTRAINT ck_goods_receipt_items_2 CHECK (expiry_date IS NULL OR date(expiry_date) = expiry_date),
    CONSTRAINT ck_goods_receipt_items_3 CHECK (quantity > 0),
    CONSTRAINT ck_goods_receipt_items_4 CHECK (free_quantity >= 0),
    CONSTRAINT ck_goods_receipt_items_5 CHECK (version >= 1),
    CONSTRAINT fk_goods_receipt_items_receipt_id FOREIGN KEY (receipt_id) REFERENCES goods_receipts (id) ON DELETE CASCADE,
    CONSTRAINT fk_goods_receipt_items_po_item_id FOREIGN KEY (po_item_id) REFERENCES purchase_order_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipt_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_goods_receipt_items_po_item_id ON goods_receipt_items (po_item_id);
CREATE INDEX ix_goods_receipt_items_medicine_id ON goods_receipt_items (medicine_id);

-- purchase_invoices: Purchase invoices; posting adds stock.
CREATE TABLE purchase_invoices (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    invoice_no TEXT NOT NULL,
    supplier_id TEXT NOT NULL,
    supplier_invoice_no TEXT NOT NULL,
    purchase_order_id TEXT,
    goods_receipt_id TEXT,
    invoice_date TEXT NOT NULL,
    due_date TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    additional_costs NUMERIC NOT NULL DEFAULT 0,
    round_off NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    paid_amount NUMERIC NOT NULL DEFAULT 0,
    payment_status TEXT NOT NULL DEFAULT 'unpaid',
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    journal_entry_id TEXT,
    reversal_entry_id TEXT,
    client_uuid TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_invoices PRIMARY KEY (id),
    CONSTRAINT uq_purchase_invoices_1 UNIQUE (supplier_id, supplier_invoice_no),
    CONSTRAINT uq_purchase_invoices_2 UNIQUE (invoice_no),
    CONSTRAINT ck_purchase_invoices_1 CHECK (invoice_date IS NULL OR date(invoice_date) = invoice_date),
    CONSTRAINT ck_purchase_invoices_2 CHECK (due_date IS NULL OR date(due_date) = due_date),
    CONSTRAINT ck_purchase_invoices_3 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_invoices_4 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_invoices_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_invoices_6 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_invoices_7 CHECK (additional_costs >= 0),
    CONSTRAINT ck_purchase_invoices_8 CHECK (total >= 0),
    CONSTRAINT ck_purchase_invoices_9 CHECK (paid_amount >= 0),
    CONSTRAINT ck_purchase_invoices_10 CHECK (payment_status IN ('unpaid','partial','paid')),
    CONSTRAINT ck_purchase_invoices_11 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_purchase_invoices_12 CHECK (version >= 1),
    CONSTRAINT ck_purchase_invoices_13 CHECK (paid_amount <= total),
    CONSTRAINT ck_purchase_invoices_14 CHECK (round(total,4) = round(subtotal - discount_amount + tax_amount + additional_costs + round_off,4)),
    CONSTRAINT fk_purchase_invoices_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_purchase_order_id FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_goods_receipt_id FOREIGN KEY (goods_receipt_id) REFERENCES goods_receipts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_invoices_1 ON purchase_invoices (invoice_date);
CREATE UNIQUE INDEX ux_purchase_invoices_2 ON purchase_invoices (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_purchase_invoices_branch_id ON purchase_invoices (branch_id);
CREATE INDEX ix_purchase_invoices_purchase_order_id ON purchase_invoices (purchase_order_id);
CREATE INDEX ix_purchase_invoices_goods_receipt_id ON purchase_invoices (goods_receipt_id);
CREATE INDEX ix_purchase_invoices_currency_code ON purchase_invoices (currency_code);
CREATE INDEX ix_purchase_invoices_posted_by ON purchase_invoices (posted_by);
CREATE INDEX ix_purchase_invoices_reversed_by ON purchase_invoices (reversed_by);
CREATE INDEX ix_purchase_invoices_journal_entry_id ON purchase_invoices (journal_entry_id);
CREATE INDEX ix_purchase_invoices_reversal_entry_id ON purchase_invoices (reversal_entry_id);

-- purchase_invoice_items: Purchase lines with batch, expiry and landed cost.
CREATE TABLE purchase_invoice_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    invoice_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    medicine_id TEXT NOT NULL,
    batch_id TEXT,
    batch_no TEXT NOT NULL,
    mfg_date TEXT,
    expiry_date TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    free_quantity NUMERIC NOT NULL DEFAULT 0,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    discount_pct NUMERIC NOT NULL DEFAULT 0,
    discount_amount NUMERIC NOT NULL DEFAULT 0,
    tax_pct NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    additional_cost NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    landed_unit_cost NUMERIC NOT NULL DEFAULT 0,
    po_item_id TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_invoice_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_invoice_items_1 UNIQUE (invoice_id, line_no),
    CONSTRAINT uq_purchase_invoice_items_2 UNIQUE (invoice_id, medicine_id, batch_no, expiry_date),
    CONSTRAINT ck_purchase_invoice_items_1 CHECK (mfg_date IS NULL OR date(mfg_date) = mfg_date),
    CONSTRAINT ck_purchase_invoice_items_2 CHECK (expiry_date IS NULL OR date(expiry_date) = expiry_date),
    CONSTRAINT ck_purchase_invoice_items_3 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_invoice_items_4 CHECK (free_quantity >= 0),
    CONSTRAINT ck_purchase_invoice_items_5 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_invoice_items_6 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_purchase_invoice_items_7 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_invoice_items_8 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_purchase_invoice_items_9 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_invoice_items_10 CHECK (additional_cost >= 0),
    CONSTRAINT ck_purchase_invoice_items_11 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_invoice_items_12 CHECK (landed_unit_cost >= 0),
    CONSTRAINT ck_purchase_invoice_items_13 CHECK (version >= 1),
    CONSTRAINT ck_purchase_invoice_items_14 CHECK (mfg_date IS NULL OR mfg_date < expiry_date),
    CONSTRAINT ck_purchase_invoice_items_15 CHECK (round(line_total,4) = round(quantity * unit_price - discount_amount + tax_amount,4)),
    CONSTRAINT fk_purchase_invoice_items_invoice_id FOREIGN KEY (invoice_id) REFERENCES purchase_invoices (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_invoice_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoice_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoice_items_po_item_id FOREIGN KEY (po_item_id) REFERENCES purchase_order_items (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_invoice_items_medicine_id ON purchase_invoice_items (medicine_id);
CREATE INDEX ix_purchase_invoice_items_batch_id ON purchase_invoice_items (batch_id);
CREATE INDEX ix_purchase_invoice_items_po_item_id ON purchase_invoice_items (po_item_id);

-- purchase_returns: Purchase returns / supplier debit notes against an original invoice.
CREATE TABLE purchase_returns (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    return_no TEXT NOT NULL,
    original_invoice_id TEXT NOT NULL,
    supplier_id TEXT NOT NULL,
    return_date TEXT NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    subtotal NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    total NUMERIC NOT NULL DEFAULT 0,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    journal_entry_id TEXT,
    reversal_entry_id TEXT,
    client_uuid TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_returns PRIMARY KEY (id),
    CONSTRAINT uq_purchase_returns_1 UNIQUE (return_no),
    CONSTRAINT ck_purchase_returns_1 CHECK (return_date IS NULL OR date(return_date) = return_date),
    CONSTRAINT ck_purchase_returns_2 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_returns_3 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_returns_4 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_returns_5 CHECK (total >= 0),
    CONSTRAINT ck_purchase_returns_6 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_purchase_returns_7 CHECK (version >= 1),
    CONSTRAINT ck_purchase_returns_8 CHECK (round(total,4) = round(subtotal + tax_amount,4)),
    CONSTRAINT fk_purchase_returns_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_original_invoice_id FOREIGN KEY (original_invoice_id) REFERENCES purchase_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_purchase_returns_1 ON purchase_returns (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_purchase_returns_branch_id ON purchase_returns (branch_id);
CREATE INDEX ix_purchase_returns_original_invoice_id ON purchase_returns (original_invoice_id);
CREATE INDEX ix_purchase_returns_supplier_id ON purchase_returns (supplier_id);
CREATE INDEX ix_purchase_returns_currency_code ON purchase_returns (currency_code);
CREATE INDEX ix_purchase_returns_posted_by ON purchase_returns (posted_by);
CREATE INDEX ix_purchase_returns_reversed_by ON purchase_returns (reversed_by);
CREATE INDEX ix_purchase_returns_journal_entry_id ON purchase_returns (journal_entry_id);
CREATE INDEX ix_purchase_returns_reversal_entry_id ON purchase_returns (reversal_entry_id);

-- purchase_return_items: Purchase return lines.
CREATE TABLE purchase_return_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    return_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    original_item_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    unit_price NUMERIC NOT NULL DEFAULT 0,
    tax_amount NUMERIC NOT NULL DEFAULT 0,
    line_total NUMERIC NOT NULL DEFAULT 0,
    cost_price NUMERIC NOT NULL DEFAULT 0,
    reason TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_return_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_return_items_1 UNIQUE (return_id, line_no),
    CONSTRAINT uq_purchase_return_items_2 UNIQUE (return_id, original_item_id),
    CONSTRAINT ck_purchase_return_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_return_items_2 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_return_items_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_return_items_4 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_return_items_5 CHECK (cost_price >= 0),
    CONSTRAINT ck_purchase_return_items_6 CHECK (version >= 1),
    CONSTRAINT ck_purchase_return_items_7 CHECK (round(line_total,4) = round(quantity * unit_price + tax_amount,4)),
    CONSTRAINT fk_purchase_return_items_return_id FOREIGN KEY (return_id) REFERENCES purchase_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_return_items_original_item_id FOREIGN KEY (original_item_id) REFERENCES purchase_invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_return_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_return_items_original_item_id ON purchase_return_items (original_item_id);
CREATE INDEX ix_purchase_return_items_batch_id ON purchase_return_items (batch_id);
