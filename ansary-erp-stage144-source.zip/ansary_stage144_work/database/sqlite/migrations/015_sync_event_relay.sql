-- Stage 29: authenticated device registration and branch-scoped sync event relay.
CREATE TABLE sync_devices (
    id TEXT PRIMARY KEY,
    device_code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    platform TEXT CHECK (platform IN ('windows','android','web','server')),
    branch_id TEXT NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    last_seen_at TEXT,
    last_acked_seq INTEGER NOT NULL DEFAULT 0,
    is_revoked INTEGER NOT NULL DEFAULT 0,
    registered_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX ix_sync_devices_branch ON sync_devices(branch_id);
CREATE TABLE sync_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    event_uuid TEXT NOT NULL UNIQUE,
    device_id TEXT NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    branch_id TEXT NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    op TEXT NOT NULL CHECK(op IN ('insert','update','delete')),
    base_version INTEGER,
    payload TEXT NOT NULL CHECK(json_valid(payload)),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX ix_sync_events_branch_seq ON sync_events(branch_id,seq);
CREATE INDEX ix_sync_events_device ON sync_events(device_id,seq);
