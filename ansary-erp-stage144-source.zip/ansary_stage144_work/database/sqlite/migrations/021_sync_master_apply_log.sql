-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 021_sync_master_apply_log.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE TABLE sync_master_apply_log (
    event_uuid TEXT PRIMARY KEY,
    device_id TEXT NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('applied','conflict')),
    reason TEXT,
    applied_version INTEGER,
    processed_at TEXT NOT NULL
);
CREATE INDEX ix_sync_master_apply_log_device ON sync_master_apply_log(device_id, processed_at);
