-- Stage 51: bind sync writes to a separately provisioned device secret.
-- Existing devices remain unable to push/apply until re-registered or securely rotated.
ALTER TABLE sync_devices ADD COLUMN token_sha256 TEXT;
