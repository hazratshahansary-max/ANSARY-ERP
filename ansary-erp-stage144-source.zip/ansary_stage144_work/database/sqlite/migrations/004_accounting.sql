-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 004_accounting.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- financial_years: Financial years; closed years reject postings.
CREATE TABLE financial_years (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    is_closed INTEGER NOT NULL DEFAULT 0,
    closed_at TEXT,
    closed_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_financial_years PRIMARY KEY (id),
    CONSTRAINT uq_financial_years_1 UNIQUE (name),
    CONSTRAINT ck_financial_years_1 CHECK (start_date IS NULL OR date(start_date) = start_date),
    CONSTRAINT ck_financial_years_2 CHECK (end_date IS NULL OR date(end_date) = end_date),
    CONSTRAINT ck_financial_years_3 CHECK (is_closed IN (0,1)),
    CONSTRAINT ck_financial_years_4 CHECK (version >= 1),
    CONSTRAINT ck_financial_years_5 CHECK (end_date > start_date),
    CONSTRAINT fk_financial_years_closed_by FOREIGN KEY (closed_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_financial_years_closed_by ON financial_years (closed_by);

-- number_sequences: Per branch/device/year document numbering (prevents offline number collisions).
CREATE TABLE number_sequences (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    doc_type TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    financial_year_id TEXT NOT NULL,
    device_code TEXT NOT NULL DEFAULT '00',
    prefix TEXT NOT NULL,
    padding INTEGER NOT NULL DEFAULT 6,
    next_number INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_number_sequences PRIMARY KEY (id),
    CONSTRAINT uq_number_sequences_1 UNIQUE (doc_type, branch_id, financial_year_id, device_code),
    CONSTRAINT ck_number_sequences_1 CHECK (padding BETWEEN 1 AND 12),
    CONSTRAINT ck_number_sequences_2 CHECK (next_number >= 1),
    CONSTRAINT ck_number_sequences_3 CHECK (version >= 1),
    CONSTRAINT fk_number_sequences_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_number_sequences_financial_year_id FOREIGN KEY (financial_year_id) REFERENCES financial_years (id) ON DELETE RESTRICT
);
CREATE INDEX ix_number_sequences_branch_id ON number_sequences (branch_id);
CREATE INDEX ix_number_sequences_financial_year_id ON number_sequences (financial_year_id);

-- accounts: Chart of accounts.
CREATE TABLE accounts (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    name_ps TEXT,
    account_type TEXT NOT NULL,
    normal_side TEXT NOT NULL,
    parent_id TEXT,
    system_key TEXT,
    is_postable INTEGER NOT NULL DEFAULT 1,
    is_system INTEGER NOT NULL DEFAULT 0,
    is_active INTEGER NOT NULL DEFAULT 1,
    cash_flow_category TEXT NOT NULL DEFAULT 'none',
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_accounts PRIMARY KEY (id),
    CONSTRAINT uq_accounts_1 UNIQUE (code),
    CONSTRAINT ck_accounts_1 CHECK (account_type IN ('asset','liability','equity','income','expense')),
    CONSTRAINT ck_accounts_2 CHECK (normal_side IN ('debit','credit')),
    CONSTRAINT ck_accounts_3 CHECK (is_postable IN (0,1)),
    CONSTRAINT ck_accounts_4 CHECK (is_system IN (0,1)),
    CONSTRAINT ck_accounts_5 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_accounts_6 CHECK (cash_flow_category IN ('operating','investing','financing','cash','none')),
    CONSTRAINT ck_accounts_7 CHECK (version >= 1),
    CONSTRAINT fk_accounts_parent_id FOREIGN KEY (parent_id) REFERENCES accounts (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_accounts_1 ON accounts (system_key) WHERE system_key IS NOT NULL;
CREATE INDEX ix_accounts_parent_id ON accounts (parent_id);

-- bank_accounts: Bank accounts mapped to ledger accounts (bankbook).
CREATE TABLE bank_accounts (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT,
    account_id TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    account_number TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    is_active INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_bank_accounts PRIMARY KEY (id),
    CONSTRAINT uq_bank_accounts_1 UNIQUE (account_id),
    CONSTRAINT ck_bank_accounts_1 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_bank_accounts_2 CHECK (version >= 1),
    CONSTRAINT fk_bank_accounts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_bank_accounts_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_bank_accounts_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_bank_accounts_branch_id ON bank_accounts (branch_id);
CREATE INDEX ix_bank_accounts_currency_code ON bank_accounts (currency_code);

-- expense_categories: Expense categories mapped to expense accounts.
CREATE TABLE expense_categories (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    name TEXT NOT NULL,
    name_ps TEXT,
    account_id TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_expense_categories PRIMARY KEY (id),
    CONSTRAINT uq_expense_categories_1 UNIQUE (name),
    CONSTRAINT ck_expense_categories_1 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_expense_categories_2 CHECK (version >= 1),
    CONSTRAINT fk_expense_categories_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT
);
CREATE INDEX ix_expense_categories_account_id ON expense_categories (account_id);

-- journal_entries: Double-entry journal headers.
CREATE TABLE journal_entries (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    entry_no TEXT NOT NULL,
    entry_date TEXT NOT NULL,
    financial_year_id TEXT NOT NULL,
    entry_kind TEXT NOT NULL DEFAULT 'manual',
    source_type TEXT,
    source_id TEXT,
    description TEXT,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    status TEXT NOT NULL DEFAULT 'draft',
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    reverses_entry_id TEXT,
    total_debit NUMERIC NOT NULL DEFAULT 0,
    total_credit NUMERIC NOT NULL DEFAULT 0,
    client_uuid TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_journal_entries PRIMARY KEY (id),
    CONSTRAINT uq_journal_entries_1 UNIQUE (entry_no),
    CONSTRAINT ck_journal_entries_1 CHECK (entry_date IS NULL OR date(entry_date) = entry_date),
    CONSTRAINT ck_journal_entries_2 CHECK (entry_kind IN ('manual','sales','purchase','sales_return','purchase_return','receipt','payment','contra','expense','income','adjustment','opening','reversal','fx')),
    CONSTRAINT ck_journal_entries_3 CHECK (exchange_rate > 0),
    CONSTRAINT ck_journal_entries_4 CHECK (status IN ('draft', 'posted', 'reversed')),
    CONSTRAINT ck_journal_entries_5 CHECK (total_debit >= 0),
    CONSTRAINT ck_journal_entries_6 CHECK (total_credit >= 0),
    CONSTRAINT ck_journal_entries_7 CHECK (version >= 1),
    CONSTRAINT fk_journal_entries_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_financial_year_id FOREIGN KEY (financial_year_id) REFERENCES financial_years (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_reverses_entry_id FOREIGN KEY (reverses_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_journal_entries_1 ON journal_entries (source_type, source_id, entry_kind) WHERE source_id IS NOT NULL;
CREATE INDEX ix_journal_entries_2 ON journal_entries (entry_date);
CREATE UNIQUE INDEX ux_journal_entries_3 ON journal_entries (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_journal_entries_branch_id ON journal_entries (branch_id);
CREATE INDEX ix_journal_entries_financial_year_id ON journal_entries (financial_year_id);
CREATE INDEX ix_journal_entries_currency_code ON journal_entries (currency_code);
CREATE INDEX ix_journal_entries_posted_by ON journal_entries (posted_by);
CREATE INDEX ix_journal_entries_reversed_by ON journal_entries (reversed_by);
CREATE INDEX ix_journal_entries_reverses_entry_id ON journal_entries (reverses_entry_id);

-- journal_lines: Journal lines; customer_id/supplier_id give the sub-ledgers.
CREATE TABLE journal_lines (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    entry_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    account_id TEXT NOT NULL,
    debit NUMERIC NOT NULL DEFAULT 0,
    credit NUMERIC NOT NULL DEFAULT 0,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    exchange_rate NUMERIC NOT NULL DEFAULT 1,
    amount_fx NUMERIC,
    customer_id TEXT,
    supplier_id TEXT,
    branch_id TEXT,
    description TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_journal_lines PRIMARY KEY (id),
    CONSTRAINT uq_journal_lines_1 UNIQUE (entry_id, line_no),
    CONSTRAINT ck_journal_lines_1 CHECK (line_no >= 1),
    CONSTRAINT ck_journal_lines_2 CHECK (debit >= 0),
    CONSTRAINT ck_journal_lines_3 CHECK (credit >= 0),
    CONSTRAINT ck_journal_lines_4 CHECK (exchange_rate > 0),
    CONSTRAINT ck_journal_lines_5 CHECK (version >= 1),
    CONSTRAINT ck_journal_lines_6 CHECK ((debit = 0 OR credit = 0) AND (debit + credit) > 0),
    CONSTRAINT fk_journal_lines_entry_id FOREIGN KEY (entry_id) REFERENCES journal_entries (id) ON DELETE CASCADE,
    CONSTRAINT fk_journal_lines_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_journal_lines_1 ON journal_lines (account_id, entry_id);
CREATE INDEX ix_journal_lines_2 ON journal_lines (customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX ix_journal_lines_3 ON journal_lines (supplier_id) WHERE supplier_id IS NOT NULL;
CREATE INDEX ix_journal_lines_currency_code ON journal_lines (currency_code);
CREATE INDEX ix_journal_lines_branch_id ON journal_lines (branch_id);
