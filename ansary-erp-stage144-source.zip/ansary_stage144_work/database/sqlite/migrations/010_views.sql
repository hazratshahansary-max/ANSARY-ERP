-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 010_views.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE VIEW v_batch_stock AS
SELECT x.*,
       CASE WHEN x.days_to_expiry < 0 THEN 'expired'
            WHEN x.days_to_expiry <= 30 THEN 'd30'
            WHEN x.days_to_expiry <= 60 THEN 'd60'
            WHEN x.days_to_expiry <= 90 THEN 'd90'
            WHEN x.days_to_expiry <= 120 THEN 'd120'
            WHEN x.days_to_expiry <= 180 THEN 'd180'
            ELSE 'ok' END AS expiry_bucket
FROM (SELECT b.id AS batch_id, b.branch_id, b.medicine_id, m.name AS medicine_name, b.batch_no, b.expiry_date,
             b.qty_on_hand, b.unit_cost, round(b.qty_on_hand * b.unit_cost, 4) AS stock_value, b.is_blocked,
             CAST(julianday(b.expiry_date) - julianday(date('now')) AS INTEGER) AS days_to_expiry
      FROM batches b JOIN medicines m ON m.id = b.medicine_id) x;

CREATE VIEW v_expiry_alerts AS
SELECT * FROM v_batch_stock WHERE qty_on_hand > 0 AND expiry_bucket <> 'ok';

CREATE VIEW v_stock_by_medicine AS
SELECT m.id AS medicine_id, b.branch_id, m.name AS medicine_name, SUM(b.qty_on_hand) AS qty_on_hand,
       SUM(round(b.qty_on_hand * b.unit_cost, 4)) AS stock_value
FROM medicines m JOIN batches b ON b.medicine_id = m.id
GROUP BY m.id, b.branch_id, m.name;

CREATE VIEW v_low_stock AS
SELECT m.id AS medicine_id, m.name AS medicine_name, m.min_stock, COALESCE(SUM(b.qty_on_hand), 0) AS available_qty
FROM medicines m
LEFT JOIN batches b ON b.medicine_id = m.id AND b.expiry_date >= date('now') AND NOT b.is_blocked
WHERE m.is_active AND m.deleted_at IS NULL AND m.min_stock > 0
GROUP BY m.id, m.name, m.min_stock
HAVING COALESCE(SUM(b.qty_on_hand), 0) <= m.min_stock;

CREATE VIEW v_customer_balance AS
SELECT c.id AS customer_id, c.code, c.name, c.credit_limit,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       COALESCE(t.debit, 0) - COALESCE(t.credit, 0) AS balance
FROM customers c
LEFT JOIN (SELECT l.customer_id AS cid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') AND l.customer_id IS NOT NULL GROUP BY l.customer_id) t ON t.cid = c.id;

CREATE VIEW v_supplier_balance AS
SELECT s.id AS supplier_id, s.code, s.name,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       COALESCE(t.credit, 0) - COALESCE(t.debit, 0) AS balance
FROM suppliers s
LEFT JOIN (SELECT l.supplier_id AS sid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') AND l.supplier_id IS NOT NULL GROUP BY l.supplier_id) t ON t.sid = s.id;

CREATE VIEW v_account_balance AS
SELECT a.id AS account_id, a.code, a.name, a.account_type, a.normal_side,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       CASE WHEN a.normal_side = 'debit' THEN COALESCE(t.debit, 0) - COALESCE(t.credit, 0)
            ELSE COALESCE(t.credit, 0) - COALESCE(t.debit, 0) END AS balance
FROM accounts a
LEFT JOIN (SELECT l.account_id AS aid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') GROUP BY l.account_id) t ON t.aid = a.id;

CREATE VIEW v_trial_balance AS
SELECT code, name, account_type, total_debit, total_credit,
       CASE WHEN total_debit > total_credit THEN total_debit - total_credit ELSE 0 END AS debit_balance,
       CASE WHEN total_credit > total_debit THEN total_credit - total_debit ELSE 0 END AS credit_balance
FROM v_account_balance WHERE total_debit <> 0 OR total_credit <> 0;

CREATE VIEW v_sales_invoice_profit AS
SELECT s.id AS invoice_id, s.invoice_no, s.invoice_date, s.branch_id, s.customer_id,
       SUM(i.quantity * i.unit_price - i.discount_amount) AS net_sales,
       SUM(i.cost_price * (i.quantity + i.free_quantity)) AS cogs,
       SUM(i.gross_profit) AS gross_profit
FROM sales_invoices s JOIN sales_invoice_items i ON i.invoice_id = s.id
WHERE s.status = 'posted'
GROUP BY s.id, s.invoice_no, s.invoice_date, s.branch_id, s.customer_id;

CREATE VIEW v_integrity_issues AS
SELECT 'unbalanced_journal' AS check_name, e.id AS entity_id, e.entry_no AS detail FROM journal_entries e WHERE e.status IN ('posted','reversed') AND round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = e.id),4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = e.id),4)
UNION ALL
SELECT 'batch_qty_mismatch', b.id, b.batch_no FROM batches b WHERE round(b.qty_on_hand,3) <> round((SELECT COALESCE(SUM(quantity_change),0) FROM stock_movements m WHERE m.batch_id = b.id),3)
UNION ALL
SELECT 'posted_without_journal', d.id, d.invoice_no FROM sales_invoices d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', d.id, d.invoice_no FROM purchase_invoices d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', d.id, d.return_no FROM sales_returns d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', d.id, d.return_no FROM purchase_returns d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', d.id, d.voucher_no FROM vouchers d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_stock_movement', d.id, d.invoice_no FROM sales_invoices d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM sales_invoice_items i WHERE i.invoice_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'sales_invoices' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', d.id, d.invoice_no FROM purchase_invoices d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM purchase_invoice_items i WHERE i.invoice_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'purchase_invoices' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', d.id, d.return_no FROM sales_returns d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM sales_return_items i WHERE i.return_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'sales_returns' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', d.id, d.return_no FROM purchase_returns d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM purchase_return_items i WHERE i.return_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'purchase_returns' AND m.source_id = d.id)
UNION ALL
SELECT 'invoice_paid_mismatch', d.id, d.invoice_no FROM sales_invoices d WHERE d.status = 'posted' AND d.paid_amount > d.total;
