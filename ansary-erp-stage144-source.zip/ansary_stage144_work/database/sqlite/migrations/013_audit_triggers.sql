-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 013_audit_triggers.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE TRIGGER trg_sales_invoices_audit AFTER UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_invoices', NEW.id, NEW.invoice_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.total));
END;

CREATE TRIGGER trg_purchase_invoices_audit AFTER UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_invoices', NEW.id, NEW.invoice_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.total));
END;

CREATE TRIGGER trg_sales_returns_audit AFTER UPDATE OF status ON sales_returns FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_returns', NEW.id, NEW.return_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.total));
END;

CREATE TRIGGER trg_purchase_returns_audit AFTER UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_returns', NEW.id, NEW.return_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.total));
END;

CREATE TRIGGER trg_vouchers_audit AFTER UPDATE OF status ON vouchers FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'vouchers', NEW.id, NEW.voucher_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.amount));
END;

CREATE TRIGGER trg_stock_adjustments_audit AFTER UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_adjustments', NEW.id, NEW.adj_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NULL));
END;

CREATE TRIGGER trg_journal_entries_audit AFTER UPDATE OF status ON journal_entries FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'journal_entries', NEW.id, NEW.entry_no, json_object('status', OLD.status), json_object('status', NEW.status, 'amount', NEW.total_debit));
END;

CREATE TRIGGER trg_stock_transfers_audit AFTER UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN OLD.status <> NEW.status
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (NEW.posted_by, NEW.from_branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_transfers', NEW.id, NEW.transfer_no, json_object('status', OLD.status), json_object('status', NEW.status));
END;

CREATE TRIGGER trg_users_audit_insert AFTER INSERT ON users FOR EACH ROW
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, new_values) VALUES ('user:created', 'users', NEW.id, NEW.username, json_object('role_id', NEW.role_id));
END;

CREATE TRIGGER trg_users_audit_update AFTER UPDATE OF is_active, role_id, password_hash ON users FOR EACH ROW
WHEN OLD.is_active IS DISTINCT FROM NEW.is_active OR OLD.role_id <> NEW.role_id OR OLD.password_hash <> NEW.password_hash
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, old_values, new_values) VALUES ('user:updated', 'users', NEW.id, NEW.username, json_object('is_active', OLD.is_active, 'role_id', OLD.role_id), json_object('is_active', NEW.is_active, 'role_id', NEW.role_id, 'password_changed', (NEW.password_hash <> OLD.password_hash)));
END;
