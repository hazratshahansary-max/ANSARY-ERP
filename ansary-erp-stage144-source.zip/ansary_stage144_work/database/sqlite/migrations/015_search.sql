-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 015_search.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- Fast medicine search for 100,000+ rows: FTS5 (prefix, multi-word, Pashto/Unicode aware).
CREATE VIRTUAL TABLE medicines_fts USING fts5(
    name, name_ps, generic_name, brand_name, composition,
    content = 'medicines', content_rowid = 'rowid',
    tokenize = 'unicode61 remove_diacritics 2', prefix = '2 3'
);

CREATE TRIGGER trg_medicines_fts_ai AFTER INSERT ON medicines FOR EACH ROW
BEGIN
    INSERT INTO medicines_fts (rowid, name, name_ps, generic_name, brand_name, composition)
    VALUES (NEW.rowid, NEW.name, NEW.name_ps, NEW.generic_name, NEW.brand_name, NEW.composition);
END;

CREATE TRIGGER trg_medicines_fts_ad AFTER DELETE ON medicines FOR EACH ROW
BEGIN
    INSERT INTO medicines_fts (medicines_fts, rowid, name, name_ps, generic_name, brand_name, composition)
    VALUES ('delete', OLD.rowid, OLD.name, OLD.name_ps, OLD.generic_name, OLD.brand_name, OLD.composition);
END;

CREATE TRIGGER trg_medicines_fts_au AFTER UPDATE OF name, name_ps, generic_name, brand_name, composition ON medicines FOR EACH ROW
BEGIN
    INSERT INTO medicines_fts (medicines_fts, rowid, name, name_ps, generic_name, brand_name, composition)
    VALUES ('delete', OLD.rowid, OLD.name, OLD.name_ps, OLD.generic_name, OLD.brand_name, OLD.composition);
    INSERT INTO medicines_fts (rowid, name, name_ps, generic_name, brand_name, composition)
    VALUES (NEW.rowid, NEW.name, NEW.name_ps, NEW.generic_name, NEW.brand_name, NEW.composition);
END;
