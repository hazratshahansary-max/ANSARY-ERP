-- Stage 30: prevent clients from acknowledging or skipping undelivered sync events.
ALTER TABLE sync_devices ADD COLUMN last_delivered_seq INTEGER NOT NULL DEFAULT 0;
