-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 022_due_reminder_history_triggers.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE TRIGGER IF NOT EXISTS trg_due_reminder_history_append_only_update BEFORE UPDATE ON due_reminder_history FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    SELECT RAISE(ABORT, 'due_reminder_history is append-only') WHERE 1 = 1;
END;

CREATE TRIGGER IF NOT EXISTS trg_due_reminder_history_append_only_delete BEFORE DELETE ON due_reminder_history FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    SELECT RAISE(ABORT, 'due_reminder_history is append-only') WHERE 1 = 1;
END;

CREATE TRIGGER IF NOT EXISTS trg_due_reminder_history_outbox_insert AFTER INSERT ON due_reminder_history FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key = 'applying_remote'),'0') <> '1')
BEGIN
    INSERT INTO sync_outbox (table_name, row_id, op) VALUES ('due_reminder_history', NEW.id, 'insert') ON CONFLICT (table_name, row_id) WHERE status = 'pending' DO UPDATE SET op = CASE WHEN sync_outbox.op = 'insert' AND excluded.op = 'update' THEN 'insert' ELSE excluded.op END, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;
