-- Stage 42: retain the exact master-row version when a hard delete occurs.
-- Legacy pending deletes without a tombstone remain unsent; the client never guesses.
CREATE TABLE sync_master_tombstones (
  table_name TEXT NOT NULL, row_id TEXT NOT NULL, base_version INTEGER NOT NULL CHECK(base_version >= 0),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY(table_name,row_id)
);

DROP TRIGGER IF EXISTS trg_categories_outbox_delete;
CREATE TRIGGER trg_categories_outbox_delete AFTER DELETE ON categories FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key='applying_remote'),'0') <> '1')
BEGIN
  INSERT INTO sync_master_tombstones(table_name,row_id,base_version) VALUES('categories',OLD.id,OLD.version)
  ON CONFLICT(table_name,row_id) DO UPDATE SET base_version=excluded.base_version,created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
  INSERT INTO sync_outbox(table_name,row_id,op) VALUES('categories',OLD.id,'delete')
  ON CONFLICT(table_name,row_id) WHERE status='pending' DO UPDATE SET op='delete',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

DROP TRIGGER IF EXISTS trg_companies_outbox_delete;
CREATE TRIGGER trg_companies_outbox_delete AFTER DELETE ON companies FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key='applying_remote'),'0') <> '1')
BEGIN
  INSERT INTO sync_master_tombstones(table_name,row_id,base_version) VALUES('companies',OLD.id,OLD.version)
  ON CONFLICT(table_name,row_id) DO UPDATE SET base_version=excluded.base_version,created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
  INSERT INTO sync_outbox(table_name,row_id,op) VALUES('companies',OLD.id,'delete')
  ON CONFLICT(table_name,row_id) WHERE status='pending' DO UPDATE SET op='delete',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

DROP TRIGGER IF EXISTS trg_medicines_outbox_delete;
CREATE TRIGGER trg_medicines_outbox_delete AFTER DELETE ON medicines FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key='applying_remote'),'0') <> '1')
BEGIN
  INSERT INTO sync_master_tombstones(table_name,row_id,base_version) VALUES('medicines',OLD.id,OLD.version)
  ON CONFLICT(table_name,row_id) DO UPDATE SET base_version=excluded.base_version,created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
  INSERT INTO sync_outbox(table_name,row_id,op) VALUES('medicines',OLD.id,'delete')
  ON CONFLICT(table_name,row_id) WHERE status='pending' DO UPDATE SET op='delete',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

DROP TRIGGER IF EXISTS trg_customers_outbox_delete;
CREATE TRIGGER trg_customers_outbox_delete AFTER DELETE ON customers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key='applying_remote'),'0') <> '1')
BEGIN
  INSERT INTO sync_master_tombstones(table_name,row_id,base_version) VALUES('customers',OLD.id,OLD.version)
  ON CONFLICT(table_name,row_id) DO UPDATE SET base_version=excluded.base_version,created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
  INSERT INTO sync_outbox(table_name,row_id,op) VALUES('customers',OLD.id,'delete')
  ON CONFLICT(table_name,row_id) WHERE status='pending' DO UPDATE SET op='delete',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;

DROP TRIGGER IF EXISTS trg_suppliers_outbox_delete;
CREATE TRIGGER trg_suppliers_outbox_delete AFTER DELETE ON suppliers FOR EACH ROW
WHEN (COALESCE((SELECT value FROM sync_state WHERE key='applying_remote'),'0') <> '1')
BEGIN
  INSERT INTO sync_master_tombstones(table_name,row_id,base_version) VALUES('suppliers',OLD.id,OLD.version)
  ON CONFLICT(table_name,row_id) DO UPDATE SET base_version=excluded.base_version,created_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
  INSERT INTO sync_outbox(table_name,row_id,op) VALUES('suppliers',OLD.id,'delete')
  ON CONFLICT(table_name,row_id) WHERE status='pending' DO UPDATE SET op='delete',updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now');
END;
