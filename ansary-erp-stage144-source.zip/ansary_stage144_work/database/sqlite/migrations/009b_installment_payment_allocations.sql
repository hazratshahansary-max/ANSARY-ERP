-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 009b_installment_payment_allocations.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- installment_payment_allocations: Draft customer receipt allocations to individual installment schedule rows; applied when voucher posts.
CREATE TABLE IF NOT EXISTS installment_payment_allocations (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    voucher_id TEXT NOT NULL,
    installment_schedule_id TEXT NOT NULL,
    amount NUMERIC NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_payment_allocations PRIMARY KEY (id),
    CONSTRAINT uq_installment_payment_allocations_1 UNIQUE (voucher_id, installment_schedule_id),
    CONSTRAINT ck_installment_payment_allocations_1 CHECK (amount >= 0),
    CONSTRAINT ck_installment_payment_allocations_2 CHECK (version >= 1),
    CONSTRAINT ck_installment_payment_allocations_3 CHECK (amount > 0),
    CONSTRAINT fk_installment_payment_allocations_voucher_id FOREIGN KEY (voucher_id) REFERENCES vouchers (id) ON DELETE CASCADE,
    CONSTRAINT fk_installment_payment_allocations_installment_schedule_id FOREIGN KEY (installment_schedule_id) REFERENCES installment_schedule (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_payment_allocations_1 ON installment_payment_allocations (installment_schedule_id);
