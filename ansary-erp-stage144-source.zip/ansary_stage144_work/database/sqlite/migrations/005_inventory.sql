-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 005_inventory.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- batches: Batch-level stock. qty_on_hand is derived from stock_movements by trigger.
CREATE TABLE batches (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    medicine_id TEXT NOT NULL,
    batch_no TEXT NOT NULL,
    mfg_date TEXT,
    expiry_date TEXT NOT NULL,
    unit_cost NUMERIC NOT NULL DEFAULT 0,
    qty_on_hand NUMERIC NOT NULL DEFAULT 0,
    wholesale_price NUMERIC,
    retail_price NUMERIC,
    supplier_id TEXT,
    is_blocked INTEGER NOT NULL DEFAULT 0,
    block_reason TEXT,
    last_movement_at TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_batches PRIMARY KEY (id),
    CONSTRAINT uq_batches_1 UNIQUE (branch_id, medicine_id, batch_no, expiry_date),
    CONSTRAINT ck_batches_1 CHECK (mfg_date IS NULL OR date(mfg_date) = mfg_date),
    CONSTRAINT ck_batches_2 CHECK (expiry_date IS NULL OR date(expiry_date) = expiry_date),
    CONSTRAINT ck_batches_3 CHECK (unit_cost >= 0),
    CONSTRAINT ck_batches_4 CHECK (qty_on_hand >= 0),
    CONSTRAINT ck_batches_5 CHECK (wholesale_price IS NULL OR wholesale_price >= 0),
    CONSTRAINT ck_batches_6 CHECK (retail_price IS NULL OR retail_price >= 0),
    CONSTRAINT ck_batches_7 CHECK (is_blocked IN (0,1)),
    CONSTRAINT ck_batches_8 CHECK (version >= 1),
    CONSTRAINT ck_batches_9 CHECK (mfg_date IS NULL OR mfg_date < expiry_date),
    CONSTRAINT fk_batches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT
);
CREATE INDEX ix_batches_1 ON batches (expiry_date) WHERE qty_on_hand > 0;
CREATE INDEX ix_batches_2 ON batches (medicine_id, branch_id);
CREATE INDEX ix_batches_supplier_id ON batches (supplier_id);

-- stock_movements: Immutable stock ledger. Every stock change is a row here.
CREATE TABLE stock_movements (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    medicine_id TEXT NOT NULL,
    movement_type TEXT NOT NULL,
    quantity_change NUMERIC NOT NULL,
    unit_cost NUMERIC NOT NULL DEFAULT 0,
    movement_date TEXT NOT NULL,
    source_type TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_line_id TEXT NOT NULL,
    user_id TEXT,
    notes TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    CONSTRAINT pk_stock_movements PRIMARY KEY (id),
    CONSTRAINT uq_stock_movements_1 UNIQUE (source_type, source_line_id, movement_type, batch_id),
    CONSTRAINT ck_stock_movements_1 CHECK (movement_type IN ('purchase','sale','sales_return','purchase_return','adjustment_in','adjustment_out','transfer_in','transfer_out','damaged','expired','opening','count_variance','reversal')),
    CONSTRAINT ck_stock_movements_2 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_movements_3 CHECK (unit_cost >= 0),
    CONSTRAINT ck_stock_movements_4 CHECK (movement_date IS NULL OR date(movement_date) = movement_date),
    CONSTRAINT fk_stock_movements_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_movements_1 ON stock_movements (batch_id, created_at);
CREATE INDEX ix_stock_movements_2 ON stock_movements (source_type, source_id);
CREATE INDEX ix_stock_movements_3 ON stock_movements (medicine_id, branch_id, movement_date);
CREATE INDEX ix_stock_movements_branch_id ON stock_movements (branch_id);
CREATE INDEX ix_stock_movements_user_id ON stock_movements (user_id);

-- stock_adjustments: Stock adjustments, damaged/expired write-offs, opening stock.
CREATE TABLE stock_adjustments (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    adj_no TEXT NOT NULL,
    adj_date TEXT NOT NULL,
    adj_type TEXT NOT NULL,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    reversed_at TEXT,
    reversed_by TEXT,
    reversal_reason TEXT,
    journal_entry_id TEXT,
    reversal_entry_id TEXT,
    client_uuid TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustments PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustments_1 UNIQUE (adj_no),
    CONSTRAINT ck_stock_adjustments_1 CHECK (adj_date IS NULL OR date(adj_date) = adj_date),
    CONSTRAINT ck_stock_adjustments_2 CHECK (adj_type IN ('adjustment','damaged','expired','reconciliation','opening')),
    CONSTRAINT ck_stock_adjustments_3 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_stock_adjustments_4 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustments_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_stock_adjustments_1 ON stock_adjustments (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_stock_adjustments_branch_id ON stock_adjustments (branch_id);
CREATE INDEX ix_stock_adjustments_posted_by ON stock_adjustments (posted_by);
CREATE INDEX ix_stock_adjustments_reversed_by ON stock_adjustments (reversed_by);
CREATE INDEX ix_stock_adjustments_journal_entry_id ON stock_adjustments (journal_entry_id);
CREATE INDEX ix_stock_adjustments_reversal_entry_id ON stock_adjustments (reversal_entry_id);

-- stock_adjustment_items: Adjustment lines.
CREATE TABLE stock_adjustment_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    adjustment_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    batch_id TEXT NOT NULL,
    quantity_change NUMERIC NOT NULL,
    unit_cost NUMERIC NOT NULL DEFAULT 0,
    reason TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustment_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustment_items_1 UNIQUE (adjustment_id, line_no),
    CONSTRAINT uq_stock_adjustment_items_2 UNIQUE (adjustment_id, batch_id),
    CONSTRAINT ck_stock_adjustment_items_1 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_adjustment_items_2 CHECK (unit_cost >= 0),
    CONSTRAINT ck_stock_adjustment_items_3 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustment_items_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_adjustment_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_adjustment_items_batch_id ON stock_adjustment_items (batch_id);

-- stock_transfers: Branch-to-branch stock transfers.
CREATE TABLE stock_transfers (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    transfer_no TEXT NOT NULL,
    from_branch_id TEXT NOT NULL,
    to_branch_id TEXT NOT NULL,
    transfer_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    notes TEXT,
    posted_at TEXT,
    posted_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfers PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfers_1 UNIQUE (transfer_no),
    CONSTRAINT ck_stock_transfers_1 CHECK (transfer_date IS NULL OR date(transfer_date) = transfer_date),
    CONSTRAINT ck_stock_transfers_2 CHECK (status IN ('draft', 'posted', 'cancelled')),
    CONSTRAINT ck_stock_transfers_3 CHECK (version >= 1),
    CONSTRAINT ck_stock_transfers_4 CHECK (from_branch_id <> to_branch_id),
    CONSTRAINT fk_stock_transfers_from_branch_id FOREIGN KEY (from_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_to_branch_id FOREIGN KEY (to_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfers_from_branch_id ON stock_transfers (from_branch_id);
CREATE INDEX ix_stock_transfers_to_branch_id ON stock_transfers (to_branch_id);
CREATE INDEX ix_stock_transfers_posted_by ON stock_transfers (posted_by);

-- stock_transfer_items: Transfer lines (dest_batch_id set at posting).
CREATE TABLE stock_transfer_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    transfer_id TEXT NOT NULL,
    line_no INTEGER NOT NULL,
    batch_id TEXT NOT NULL,
    quantity NUMERIC NOT NULL,
    dest_batch_id TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfer_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfer_items_1 UNIQUE (transfer_id, line_no),
    CONSTRAINT uq_stock_transfer_items_2 UNIQUE (transfer_id, batch_id),
    CONSTRAINT ck_stock_transfer_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_stock_transfer_items_2 CHECK (version >= 1),
    CONSTRAINT fk_stock_transfer_items_transfer_id FOREIGN KEY (transfer_id) REFERENCES stock_transfers (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_transfer_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfer_items_dest_batch_id FOREIGN KEY (dest_batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfer_items_batch_id ON stock_transfer_items (batch_id);
CREATE INDEX ix_stock_transfer_items_dest_batch_id ON stock_transfer_items (dest_batch_id);

-- physical_counts: Physical stock verification sessions.
CREATE TABLE physical_counts (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    count_no TEXT NOT NULL,
    count_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    adjustment_id TEXT,
    notes TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_counts PRIMARY KEY (id),
    CONSTRAINT uq_physical_counts_1 UNIQUE (count_no),
    CONSTRAINT ck_physical_counts_1 CHECK (count_date IS NULL OR date(count_date) = count_date),
    CONSTRAINT ck_physical_counts_2 CHECK (status IN ('draft', 'in_progress', 'completed', 'reconciled', 'cancelled')),
    CONSTRAINT ck_physical_counts_3 CHECK (version >= 1),
    CONSTRAINT fk_physical_counts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_physical_counts_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_counts_branch_id ON physical_counts (branch_id);
CREATE INDEX ix_physical_counts_adjustment_id ON physical_counts (adjustment_id);

-- physical_count_items: Counted vs system quantity per batch.
CREATE TABLE physical_count_items (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    count_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    system_qty NUMERIC NOT NULL DEFAULT 0,
    counted_qty NUMERIC NOT NULL DEFAULT 0,
    variance NUMERIC GENERATED ALWAYS AS (counted_qty - system_qty) STORED,
    notes TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_count_items PRIMARY KEY (id),
    CONSTRAINT uq_physical_count_items_1 UNIQUE (count_id, batch_id),
    CONSTRAINT ck_physical_count_items_1 CHECK (system_qty >= 0),
    CONSTRAINT ck_physical_count_items_2 CHECK (counted_qty >= 0),
    CONSTRAINT ck_physical_count_items_3 CHECK (version >= 1),
    CONSTRAINT fk_physical_count_items_count_id FOREIGN KEY (count_id) REFERENCES physical_counts (id) ON DELETE CASCADE,
    CONSTRAINT fk_physical_count_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_count_items_batch_id ON physical_count_items (batch_id);
