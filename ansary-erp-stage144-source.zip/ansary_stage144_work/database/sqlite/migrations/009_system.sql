-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 009_system.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- backup_history: Backup and restore history (device-local).
CREATE TABLE backup_history (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    kind TEXT NOT NULL,
    location TEXT NOT NULL DEFAULT 'local',
    file_path TEXT NOT NULL,
    size_bytes INTEGER,
    sha256 TEXT,
    status TEXT NOT NULL DEFAULT 'started',
    integrity_result TEXT,
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    finished_at TEXT,
    created_by TEXT,
    note TEXT,
    CONSTRAINT pk_backup_history PRIMARY KEY (id),
    CONSTRAINT ck_backup_history_1 CHECK (kind IN ('manual','automatic','scheduled','pre_upgrade','pre_conflict','restore_point')),
    CONSTRAINT ck_backup_history_2 CHECK (location IN ('local','cloud')),
    CONSTRAINT ck_backup_history_3 CHECK (status IN ('started','completed','failed','verified','restored')),
    CONSTRAINT fk_backup_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_backup_history_created_by ON backup_history (created_by);

-- sync_conflicts: Detected synchronisation conflicts awaiting or recording resolution.
CREATE TABLE sync_conflicts (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    device_id TEXT,
    local_version INTEGER,
    server_version INTEGER,
    local_payload TEXT,
    server_payload TEXT,
    reason TEXT NOT NULL DEFAULT 'version_conflict',
    detected_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    resolution TEXT NOT NULL DEFAULT 'pending',
    resolved_by TEXT,
    resolved_at TEXT,
    backup_ref TEXT,
    CONSTRAINT pk_sync_conflicts PRIMARY KEY (id),
    CONSTRAINT ck_sync_conflicts_1 CHECK (local_payload IS NULL OR json_valid(local_payload)),
    CONSTRAINT ck_sync_conflicts_2 CHECK (server_payload IS NULL OR json_valid(server_payload)),
    CONSTRAINT ck_sync_conflicts_3 CHECK (resolution IN ('pending','local_won','server_won','merged','dismissed')),
    CONSTRAINT fk_sync_conflicts_resolved_by FOREIGN KEY (resolved_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sync_conflicts_1 ON sync_conflicts (resolution, detected_at);
CREATE INDEX ix_sync_conflicts_resolved_by ON sync_conflicts (resolved_by);

-- sync_log: One row per synchronisation run.
CREATE TABLE sync_log (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    device_id TEXT,
    direction TEXT NOT NULL,
    started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    finished_at TEXT,
    pushed INTEGER NOT NULL DEFAULT 0,
    pulled INTEGER NOT NULL DEFAULT 0,
    conflicts INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'started',
    error TEXT,
    CONSTRAINT pk_sync_log PRIMARY KEY (id),
    CONSTRAINT ck_sync_log_1 CHECK (direction IN ('push','pull','full')),
    CONSTRAINT ck_sync_log_2 CHECK (status IN ('started','ok','partial','failed'))
);


CREATE TABLE sync_state (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
INSERT INTO sync_state (key, value) VALUES
    ('applying_remote', '0'),     -- set to '1' by the sync engine while applying server data
    ('device_id', ''),            -- assigned at device registration
    ('device_code', '00'),        -- short code used in document numbers
    ('last_pulled_seq', '0'),     -- server change_log cursor
    ('last_synced_at', '');

CREATE TABLE sync_outbox (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    table_name TEXT NOT NULL,
    row_id TEXT NOT NULL,
    op TEXT NOT NULL CHECK (op IN ('insert','update','delete')),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed')),
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE UNIQUE INDEX ux_sync_outbox_pending ON sync_outbox (table_name, row_id) WHERE status = 'pending';
CREATE INDEX ix_sync_outbox_status ON sync_outbox (status, seq);
