-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 002_security.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- roles: Role definitions (8 built-in roles).
CREATE TABLE roles (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    name_ps TEXT,
    description TEXT,
    is_system INTEGER NOT NULL DEFAULT 0,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_roles PRIMARY KEY (id),
    CONSTRAINT uq_roles_1 UNIQUE (code),
    CONSTRAINT ck_roles_1 CHECK (is_system IN (0,1)),
    CONSTRAINT ck_roles_2 CHECK (version >= 1)
);

-- permissions: Permission catalogue (module.action).
CREATE TABLE permissions (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    code TEXT NOT NULL,
    module TEXT NOT NULL,
    action TEXT NOT NULL,
    description TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_permissions PRIMARY KEY (id),
    CONSTRAINT uq_permissions_1 UNIQUE (module, action),
    CONSTRAINT uq_permissions_2 UNIQUE (code),
    CONSTRAINT ck_permissions_1 CHECK (version >= 1)
);

-- role_permissions: Role to permission grants.
CREATE TABLE role_permissions (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    role_id TEXT NOT NULL,
    permission_id TEXT NOT NULL,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_role_permissions PRIMARY KEY (id),
    CONSTRAINT uq_role_permissions_1 UNIQUE (role_id, permission_id),
    CONSTRAINT ck_role_permissions_1 CHECK (version >= 1),
    CONSTRAINT fk_role_permissions_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_role_permissions_permission_id ON role_permissions (permission_id);

-- users: User accounts (password stored only as a salted hash).
CREATE TABLE users (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    username TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_algo TEXT NOT NULL DEFAULT 'argon2id',
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    role_id TEXT NOT NULL,
    default_branch_id TEXT,
    language TEXT NOT NULL DEFAULT 'en',
    is_active INTEGER NOT NULL DEFAULT 1,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT,
    last_login_at TEXT,
    password_changed_at TEXT,
    session_timeout_minutes INTEGER NOT NULL DEFAULT 30,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    deleted_at TEXT,
    CONSTRAINT pk_users PRIMARY KEY (id),
    CONSTRAINT uq_users_1 UNIQUE (username),
    CONSTRAINT ck_users_1 CHECK (username = lower(username)),
    CONSTRAINT ck_users_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_users_3 CHECK (is_active IN (0,1)),
    CONSTRAINT ck_users_4 CHECK (must_change_password IN (0,1)),
    CONSTRAINT ck_users_5 CHECK (failed_attempts >= 0),
    CONSTRAINT ck_users_6 CHECK (session_timeout_minutes >= 1),
    CONSTRAINT ck_users_7 CHECK (version >= 1),
    CONSTRAINT fk_users_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT fk_users_default_branch_id FOREIGN KEY (default_branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_users_role_id ON users (role_id);
CREATE INDEX ix_users_default_branch_id ON users (default_branch_id);

-- user_branches: Branches a user may access.
CREATE TABLE user_branches (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    user_id TEXT NOT NULL,
    branch_id TEXT NOT NULL,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_branches PRIMARY KEY (id),
    CONSTRAINT uq_user_branches_1 UNIQUE (user_id, branch_id),
    CONSTRAINT ck_user_branches_1 CHECK (version >= 1),
    CONSTRAINT fk_user_branches_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_branches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_branches_branch_id ON user_branches (branch_id);

-- user_permission_overrides: Per-user grant/deny on top of the role.
CREATE TABLE user_permission_overrides (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    user_id TEXT NOT NULL,
    permission_id TEXT NOT NULL,
    granted INTEGER NOT NULL,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_permission_overrides PRIMARY KEY (id),
    CONSTRAINT uq_user_permission_overrides_1 UNIQUE (user_id, permission_id),
    CONSTRAINT ck_user_permission_overrides_1 CHECK (granted IN (0,1)),
    CONSTRAINT ck_user_permission_overrides_2 CHECK (version >= 1),
    CONSTRAINT fk_user_permission_overrides_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_permission_overrides_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_permission_overrides_permission_id ON user_permission_overrides (permission_id);

-- user_sessions: Active sessions (device-local, never synchronised).
CREATE TABLE user_sessions (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    user_id TEXT NOT NULL,
    token_hash TEXT NOT NULL,
    device_id TEXT,
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    expires_at TEXT NOT NULL,
    revoked_at TEXT,
    revoked_reason TEXT,
    CONSTRAINT pk_user_sessions PRIMARY KEY (id),
    CONSTRAINT uq_user_sessions_1 UNIQUE (token_hash),
    CONSTRAINT fk_user_sessions_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_user_sessions_user_id ON user_sessions (user_id);

-- login_history: Every login attempt (append-only).
CREATE TABLE login_history (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    user_id TEXT,
    username_attempted TEXT NOT NULL,
    success INTEGER NOT NULL,
    failure_reason TEXT,
    ip_address TEXT,
    user_agent TEXT,
    device_id TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    CONSTRAINT pk_login_history PRIMARY KEY (id),
    CONSTRAINT ck_login_history_1 CHECK (success IN (0,1)),
    CONSTRAINT fk_login_history_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_login_history_user_id ON login_history (user_id);

-- audit_log: Immutable transaction audit trail.
CREATE TABLE audit_log (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    user_id TEXT,
    branch_id TEXT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    ref_no TEXT,
    old_values TEXT,
    new_values TEXT,
    ip_address TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    CONSTRAINT pk_audit_log PRIMARY KEY (id),
    CONSTRAINT ck_audit_log_1 CHECK (old_values IS NULL OR json_valid(old_values)),
    CONSTRAINT ck_audit_log_2 CHECK (new_values IS NULL OR json_valid(new_values)),
    CONSTRAINT fk_audit_log_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_audit_log_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_audit_log_1 ON audit_log (entity_type, entity_id);
CREATE INDEX ix_audit_log_2 ON audit_log (created_at);
CREATE INDEX ix_audit_log_user_id ON audit_log (user_id);
CREATE INDEX ix_audit_log_branch_id ON audit_log (branch_id);

-- attachments: File attachments metadata (files live on disk/object store).
CREATE TABLE attachments (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    file_name TEXT NOT NULL,
    mime_type TEXT,
    storage_path TEXT NOT NULL,
    sha256 TEXT,
    size_bytes INTEGER,
    uploaded_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_attachments PRIMARY KEY (id),
    CONSTRAINT ck_attachments_1 CHECK (size_bytes IS NULL OR size_bytes >= 0),
    CONSTRAINT ck_attachments_2 CHECK (version >= 1),
    CONSTRAINT fk_attachments_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_attachments_1 ON attachments (entity_type, entity_id);
CREATE INDEX ix_attachments_uploaded_by ON attachments (uploaded_by);
