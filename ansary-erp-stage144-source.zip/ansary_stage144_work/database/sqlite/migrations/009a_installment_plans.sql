-- ANSARY ERP  |  ANSARY DATABASES  |  sqlite migration 009a_installment_plans.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- installment_plans: Customer installment plans for posted credit sales invoices; one active plan record per invoice.
CREATE TABLE IF NOT EXISTS installment_plans (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    branch_id TEXT NOT NULL,
    sales_invoice_id TEXT NOT NULL,
    customer_id TEXT NOT NULL,
    plan_no TEXT NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'AFN',
    principal_amount NUMERIC NOT NULL DEFAULT 0,
    installment_count INTEGER NOT NULL,
    frequency TEXT NOT NULL DEFAULT 'monthly',
    first_due_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    notes TEXT,
    created_by TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_plans PRIMARY KEY (id),
    CONSTRAINT uq_installment_plans_1 UNIQUE (sales_invoice_id),
    CONSTRAINT uq_installment_plans_2 UNIQUE (plan_no),
    CONSTRAINT ck_installment_plans_1 CHECK (principal_amount >= 0),
    CONSTRAINT ck_installment_plans_2 CHECK (installment_count BETWEEN 2 AND 60),
    CONSTRAINT ck_installment_plans_3 CHECK (frequency IN ('weekly','biweekly','monthly')),
    CONSTRAINT ck_installment_plans_4 CHECK (first_due_date IS NULL OR date(first_due_date) = first_due_date),
    CONSTRAINT ck_installment_plans_5 CHECK (status IN ('active', 'completed', 'cancelled')),
    CONSTRAINT ck_installment_plans_6 CHECK (version >= 1),
    CONSTRAINT fk_installment_plans_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_installment_plans_1 ON installment_plans (customer_id, status);
CREATE INDEX IF NOT EXISTS ix_installment_plans_2 ON installment_plans (branch_id, first_due_date);
CREATE INDEX IF NOT EXISTS ix_installment_plans_currency_code ON installment_plans (currency_code);
CREATE INDEX IF NOT EXISTS ix_installment_plans_created_by ON installment_plans (created_by);

-- installment_schedule: Dated customer installment schedule; payment settlement integration is a later stage.
CREATE TABLE IF NOT EXISTS installment_schedule (
    id TEXT NOT NULL DEFAULT (lower(hex(randomblob(4)) || '-' || hex(randomblob(2)) || '-4' || substr(hex(randomblob(2)),2) || '-' || substr('89ab',abs(random()) % 4 + 1,1) || substr(hex(randomblob(2)),2) || '-' || hex(randomblob(6)))),
    plan_id TEXT NOT NULL,
    installment_no INTEGER NOT NULL,
    due_date TEXT NOT NULL,
    amount NUMERIC NOT NULL DEFAULT 0,
    paid_amount NUMERIC NOT NULL DEFAULT 0,
    balance_due NUMERIC GENERATED ALWAYS AS (amount - paid_amount) STORED,
    status TEXT NOT NULL DEFAULT 'scheduled',
    paid_at TEXT,
    notes TEXT,
    origin_device_id TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    version INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_schedule PRIMARY KEY (id),
    CONSTRAINT uq_installment_schedule_1 UNIQUE (plan_id, installment_no),
    CONSTRAINT ck_installment_schedule_1 CHECK (installment_no >= 1),
    CONSTRAINT ck_installment_schedule_2 CHECK (due_date IS NULL OR date(due_date) = due_date),
    CONSTRAINT ck_installment_schedule_3 CHECK (amount >= 0),
    CONSTRAINT ck_installment_schedule_4 CHECK (paid_amount >= 0),
    CONSTRAINT ck_installment_schedule_5 CHECK (status IN ('scheduled', 'partial', 'paid', 'overdue', 'cancelled')),
    CONSTRAINT ck_installment_schedule_6 CHECK (version >= 1),
    CONSTRAINT ck_installment_schedule_7 CHECK (paid_amount <= amount),
    CONSTRAINT fk_installment_schedule_plan_id FOREIGN KEY (plan_id) REFERENCES installment_plans (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_schedule_1 ON installment_schedule (due_date, status);
