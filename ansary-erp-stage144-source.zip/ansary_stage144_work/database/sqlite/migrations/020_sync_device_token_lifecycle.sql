-- Stage 52: audit device-token lifecycle changes without storing raw secrets.
CREATE TABLE IF NOT EXISTS sync_device_token_audit (
 id TEXT PRIMARY KEY,
 device_id TEXT NOT NULL,
 actor_user_id TEXT NOT NULL,
 action TEXT NOT NULL CHECK(action IN ('rotated','revoked')),
 occurred_at TEXT NOT NULL,
 FOREIGN KEY(device_id) REFERENCES sync_devices(id) ON DELETE RESTRICT,
 FOREIGN KEY(actor_user_id) REFERENCES users(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS idx_sync_device_token_audit_device_time
 ON sync_device_token_audit(device_id, occurred_at);
