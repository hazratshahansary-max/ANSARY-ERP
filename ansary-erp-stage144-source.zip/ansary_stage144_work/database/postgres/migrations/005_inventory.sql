-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 005_inventory.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- batches: Batch-level stock. qty_on_hand is derived from stock_movements by trigger.
CREATE TABLE batches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    batch_no text NOT NULL,
    mfg_date date,
    expiry_date date NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    qty_on_hand numeric(14,3) NOT NULL DEFAULT 0,
    wholesale_price numeric(18,4),
    retail_price numeric(18,4),
    supplier_id uuid,
    is_blocked boolean NOT NULL DEFAULT FALSE,
    block_reason text,
    last_movement_at timestamptz,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_batches PRIMARY KEY (id),
    CONSTRAINT uq_batches_1 UNIQUE (branch_id, medicine_id, batch_no, expiry_date),
    CONSTRAINT ck_batches_1 CHECK (unit_cost >= 0),
    CONSTRAINT ck_batches_2 CHECK (qty_on_hand >= 0),
    CONSTRAINT ck_batches_3 CHECK (wholesale_price IS NULL OR wholesale_price >= 0),
    CONSTRAINT ck_batches_4 CHECK (retail_price IS NULL OR retail_price >= 0),
    CONSTRAINT ck_batches_5 CHECK (version >= 1),
    CONSTRAINT ck_batches_6 CHECK (mfg_date IS NULL OR mfg_date < expiry_date),
    CONSTRAINT fk_batches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT
);
CREATE INDEX ix_batches_1 ON batches (expiry_date) WHERE qty_on_hand > 0;
CREATE INDEX ix_batches_2 ON batches (medicine_id, branch_id);
CREATE INDEX ix_batches_supplier_id ON batches (supplier_id);

-- stock_movements: Immutable stock ledger. Every stock change is a row here.
CREATE TABLE stock_movements (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    movement_type text NOT NULL,
    quantity_change numeric(14,3) NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    movement_date date NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    source_line_id uuid NOT NULL,
    user_id uuid,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_stock_movements PRIMARY KEY (id),
    CONSTRAINT uq_stock_movements_1 UNIQUE (source_type, source_line_id, movement_type, batch_id),
    CONSTRAINT ck_stock_movements_1 CHECK (movement_type IN ('purchase','sale','sales_return','purchase_return','adjustment_in','adjustment_out','transfer_in','transfer_out','damaged','expired','opening','count_variance','reversal')),
    CONSTRAINT ck_stock_movements_2 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_movements_3 CHECK (unit_cost >= 0),
    CONSTRAINT fk_stock_movements_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_movements_1 ON stock_movements (batch_id, created_at);
CREATE INDEX ix_stock_movements_2 ON stock_movements (source_type, source_id);
CREATE INDEX ix_stock_movements_3 ON stock_movements (medicine_id, branch_id, movement_date);
CREATE INDEX ix_stock_movements_branch_id ON stock_movements (branch_id);
CREATE INDEX ix_stock_movements_user_id ON stock_movements (user_id);

-- stock_adjustments: Stock adjustments, damaged/expired write-offs, opening stock.
CREATE TABLE stock_adjustments (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    adj_no text NOT NULL,
    adj_date date NOT NULL,
    adj_type text NOT NULL,
    reason text,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustments PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustments_1 UNIQUE (adj_no),
    CONSTRAINT ck_stock_adjustments_1 CHECK (adj_type IN ('adjustment','damaged','expired','reconciliation','opening')),
    CONSTRAINT ck_stock_adjustments_2 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_stock_adjustments_3 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustments_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_stock_adjustments_1 ON stock_adjustments (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_stock_adjustments_branch_id ON stock_adjustments (branch_id);
CREATE INDEX ix_stock_adjustments_posted_by ON stock_adjustments (posted_by);
CREATE INDEX ix_stock_adjustments_reversed_by ON stock_adjustments (reversed_by);
CREATE INDEX ix_stock_adjustments_journal_entry_id ON stock_adjustments (journal_entry_id);
CREATE INDEX ix_stock_adjustments_reversal_entry_id ON stock_adjustments (reversal_entry_id);

-- stock_adjustment_items: Adjustment lines.
CREATE TABLE stock_adjustment_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    adjustment_id uuid NOT NULL,
    line_no integer NOT NULL,
    batch_id uuid NOT NULL,
    quantity_change numeric(14,3) NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustment_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustment_items_1 UNIQUE (adjustment_id, line_no),
    CONSTRAINT uq_stock_adjustment_items_2 UNIQUE (adjustment_id, batch_id),
    CONSTRAINT ck_stock_adjustment_items_1 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_adjustment_items_2 CHECK (unit_cost >= 0),
    CONSTRAINT ck_stock_adjustment_items_3 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustment_items_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_adjustment_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_adjustment_items_batch_id ON stock_adjustment_items (batch_id);

-- stock_transfers: Branch-to-branch stock transfers.
CREATE TABLE stock_transfers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    transfer_no text NOT NULL,
    from_branch_id uuid NOT NULL,
    to_branch_id uuid NOT NULL,
    transfer_date date NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfers PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfers_1 UNIQUE (transfer_no),
    CONSTRAINT ck_stock_transfers_1 CHECK (status IN ('draft', 'posted', 'cancelled')),
    CONSTRAINT ck_stock_transfers_2 CHECK (version >= 1),
    CONSTRAINT ck_stock_transfers_3 CHECK (from_branch_id <> to_branch_id),
    CONSTRAINT fk_stock_transfers_from_branch_id FOREIGN KEY (from_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_to_branch_id FOREIGN KEY (to_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfers_from_branch_id ON stock_transfers (from_branch_id);
CREATE INDEX ix_stock_transfers_to_branch_id ON stock_transfers (to_branch_id);
CREATE INDEX ix_stock_transfers_posted_by ON stock_transfers (posted_by);

-- stock_transfer_items: Transfer lines (dest_batch_id set at posting).
CREATE TABLE stock_transfer_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    transfer_id uuid NOT NULL,
    line_no integer NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    dest_batch_id uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfer_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfer_items_1 UNIQUE (transfer_id, line_no),
    CONSTRAINT uq_stock_transfer_items_2 UNIQUE (transfer_id, batch_id),
    CONSTRAINT ck_stock_transfer_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_stock_transfer_items_2 CHECK (version >= 1),
    CONSTRAINT fk_stock_transfer_items_transfer_id FOREIGN KEY (transfer_id) REFERENCES stock_transfers (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_transfer_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfer_items_dest_batch_id FOREIGN KEY (dest_batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfer_items_batch_id ON stock_transfer_items (batch_id);
CREATE INDEX ix_stock_transfer_items_dest_batch_id ON stock_transfer_items (dest_batch_id);

-- physical_counts: Physical stock verification sessions.
CREATE TABLE physical_counts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    count_no text NOT NULL,
    count_date date NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    adjustment_id uuid,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_counts PRIMARY KEY (id),
    CONSTRAINT uq_physical_counts_1 UNIQUE (count_no),
    CONSTRAINT ck_physical_counts_1 CHECK (status IN ('draft', 'in_progress', 'completed', 'reconciled', 'cancelled')),
    CONSTRAINT ck_physical_counts_2 CHECK (version >= 1),
    CONSTRAINT fk_physical_counts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_physical_counts_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_counts_branch_id ON physical_counts (branch_id);
CREATE INDEX ix_physical_counts_adjustment_id ON physical_counts (adjustment_id);

-- physical_count_items: Counted vs system quantity per batch.
CREATE TABLE physical_count_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    count_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    system_qty numeric(14,3) NOT NULL DEFAULT 0,
    counted_qty numeric(14,3) NOT NULL DEFAULT 0,
    variance numeric(14,3) GENERATED ALWAYS AS (counted_qty - system_qty) STORED,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_count_items PRIMARY KEY (id),
    CONSTRAINT uq_physical_count_items_1 UNIQUE (count_id, batch_id),
    CONSTRAINT ck_physical_count_items_1 CHECK (system_qty >= 0),
    CONSTRAINT ck_physical_count_items_2 CHECK (counted_qty >= 0),
    CONSTRAINT ck_physical_count_items_3 CHECK (version >= 1),
    CONSTRAINT fk_physical_count_items_count_id FOREIGN KEY (count_id) REFERENCES physical_counts (id) ON DELETE CASCADE,
    CONSTRAINT fk_physical_count_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_count_items_batch_id ON physical_count_items (batch_id);
