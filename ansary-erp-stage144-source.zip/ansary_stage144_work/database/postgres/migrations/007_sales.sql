-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 007_sales.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- sales_orders: Sales quotations and sales orders.
CREATE TABLE sales_orders (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    doc_type text NOT NULL,
    doc_no text NOT NULL,
    customer_id uuid NOT NULL,
    doc_date date NOT NULL,
    valid_until date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    created_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_orders PRIMARY KEY (id),
    CONSTRAINT uq_sales_orders_1 UNIQUE (doc_no),
    CONSTRAINT ck_sales_orders_1 CHECK (doc_type IN ('quotation','order')),
    CONSTRAINT ck_sales_orders_2 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_orders_3 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_orders_4 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_orders_5 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_orders_6 CHECK (total >= 0),
    CONSTRAINT ck_sales_orders_7 CHECK (status IN ('draft', 'confirmed', 'converted', 'cancelled', 'expired')),
    CONSTRAINT ck_sales_orders_8 CHECK (version >= 1),
    CONSTRAINT fk_sales_orders_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_orders_branch_id ON sales_orders (branch_id);
CREATE INDEX ix_sales_orders_customer_id ON sales_orders (customer_id);
CREATE INDEX ix_sales_orders_currency_code ON sales_orders (currency_code);
CREATE INDEX ix_sales_orders_created_by ON sales_orders (created_by);

-- sales_order_items: Order/quotation lines.
CREATE TABLE sales_order_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_order_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_order_items_1 UNIQUE (order_id, line_no),
    CONSTRAINT ck_sales_order_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_order_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_order_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_order_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_order_items_5 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_order_items_6 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_order_items_7 CHECK (version >= 1),
    CONSTRAINT fk_sales_order_items_order_id FOREIGN KEY (order_id) REFERENCES sales_orders (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_order_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_order_items_medicine_id ON sales_order_items (medicine_id);

-- sales_invoices: Sales invoices (retail/wholesale, cash/credit); posting reduces stock.
CREATE TABLE sales_invoices (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    invoice_no text NOT NULL,
    sale_type text NOT NULL,
    payment_type text NOT NULL,
    customer_id uuid,
    sales_order_id uuid,
    invoice_date date NOT NULL,
    due_date date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    round_off numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    previous_balance numeric(18,4) NOT NULL DEFAULT 0,
    paid_amount numeric(18,4) NOT NULL DEFAULT 0,
    payment_method text,
    payment_status text NOT NULL DEFAULT 'unpaid',
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    balance_due numeric(18,4) GENERATED ALWAYS AS (total - paid_amount) STORED,
    account_balance_after numeric(18,4) GENERATED ALWAYS AS (previous_balance + total - paid_amount) STORED,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoices PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoices_1 UNIQUE (invoice_no),
    CONSTRAINT ck_sales_invoices_1 CHECK (sale_type IN ('retail','wholesale')),
    CONSTRAINT ck_sales_invoices_2 CHECK (payment_type IN ('cash','credit')),
    CONSTRAINT ck_sales_invoices_3 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_invoices_4 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_invoices_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoices_6 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoices_7 CHECK (total >= 0),
    CONSTRAINT ck_sales_invoices_8 CHECK (paid_amount >= 0),
    CONSTRAINT ck_sales_invoices_9 CHECK (payment_method IS NULL OR payment_method IN ('cash','bank','cheque','transfer','card')),
    CONSTRAINT ck_sales_invoices_10 CHECK (payment_status IN ('unpaid','partial','paid')),
    CONSTRAINT ck_sales_invoices_11 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_invoices_12 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoices_13 CHECK (payment_type = 'cash' OR customer_id IS NOT NULL),
    CONSTRAINT ck_sales_invoices_14 CHECK (paid_amount <= total),
    CONSTRAINT ck_sales_invoices_15 CHECK (discount_amount <= subtotal),
    CONSTRAINT ck_sales_invoices_16 CHECK (round(total,4) = round(subtotal - discount_amount + tax_amount + round_off,4)),
    CONSTRAINT fk_sales_invoices_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoices_1 ON sales_invoices (invoice_date);
CREATE INDEX ix_sales_invoices_2 ON sales_invoices (customer_id, invoice_date);
CREATE UNIQUE INDEX ux_sales_invoices_3 ON sales_invoices (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_invoices_branch_id ON sales_invoices (branch_id);
CREATE INDEX ix_sales_invoices_sales_order_id ON sales_invoices (sales_order_id);
CREATE INDEX ix_sales_invoices_currency_code ON sales_invoices (currency_code);
CREATE INDEX ix_sales_invoices_posted_by ON sales_invoices (posted_by);
CREATE INDEX ix_sales_invoices_reversed_by ON sales_invoices (reversed_by);
CREATE INDEX ix_sales_invoices_journal_entry_id ON sales_invoices (journal_entry_id);
CREATE INDEX ix_sales_invoices_reversal_entry_id ON sales_invoices (reversal_entry_id);

-- sales_invoice_items: Sales lines; cost_price/gross_profit are frozen at posting.
CREATE TABLE sales_invoice_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    invoice_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    cost_price numeric(18,4) NOT NULL DEFAULT 0,
    gross_profit numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoice_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoice_items_1 UNIQUE (invoice_id, line_no),
    CONSTRAINT uq_sales_invoice_items_2 UNIQUE (invoice_id, batch_id),
    CONSTRAINT ck_sales_invoice_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_invoice_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_invoice_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_invoice_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_6 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_8 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_invoice_items_9 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_invoice_items_10 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoice_items_11 CHECK (round(line_total,4) = round(quantity * unit_price - discount_amount + tax_amount,4)),
    CONSTRAINT fk_sales_invoice_items_invoice_id FOREIGN KEY (invoice_id) REFERENCES sales_invoices (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_invoice_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoice_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoice_items_medicine_id ON sales_invoice_items (medicine_id);
CREATE INDEX ix_sales_invoice_items_batch_id ON sales_invoice_items (batch_id);

-- sales_returns: Sales returns / customer credit notes against an original invoice.
CREATE TABLE sales_returns (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    return_no text NOT NULL,
    original_invoice_id uuid NOT NULL,
    customer_id uuid,
    return_date date NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    refund_method text NOT NULL DEFAULT 'credit_note',
    reason text,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_returns PRIMARY KEY (id),
    CONSTRAINT uq_sales_returns_1 UNIQUE (return_no),
    CONSTRAINT ck_sales_returns_1 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_returns_2 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_returns_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_returns_4 CHECK (total >= 0),
    CONSTRAINT ck_sales_returns_5 CHECK (refund_method IN ('credit_note','cash','bank')),
    CONSTRAINT ck_sales_returns_6 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_returns_7 CHECK (version >= 1),
    CONSTRAINT ck_sales_returns_8 CHECK (round(total,4) = round(subtotal + tax_amount,4)),
    CONSTRAINT fk_sales_returns_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_original_invoice_id FOREIGN KEY (original_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_sales_returns_1 ON sales_returns (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_returns_branch_id ON sales_returns (branch_id);
CREATE INDEX ix_sales_returns_original_invoice_id ON sales_returns (original_invoice_id);
CREATE INDEX ix_sales_returns_customer_id ON sales_returns (customer_id);
CREATE INDEX ix_sales_returns_currency_code ON sales_returns (currency_code);
CREATE INDEX ix_sales_returns_posted_by ON sales_returns (posted_by);
CREATE INDEX ix_sales_returns_reversed_by ON sales_returns (reversed_by);
CREATE INDEX ix_sales_returns_journal_entry_id ON sales_returns (journal_entry_id);
CREATE INDEX ix_sales_returns_reversal_entry_id ON sales_returns (reversal_entry_id);

-- sales_return_items: Sales return lines.
CREATE TABLE sales_return_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    return_id uuid NOT NULL,
    line_no integer NOT NULL,
    original_item_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    cost_price numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_return_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_return_items_1 UNIQUE (return_id, line_no),
    CONSTRAINT uq_sales_return_items_2 UNIQUE (return_id, original_item_id),
    CONSTRAINT ck_sales_return_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_return_items_2 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_return_items_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_return_items_4 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_return_items_5 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_return_items_6 CHECK (version >= 1),
    CONSTRAINT ck_sales_return_items_7 CHECK (round(line_total,4) = round(quantity * unit_price + tax_amount,4)),
    CONSTRAINT fk_sales_return_items_return_id FOREIGN KEY (return_id) REFERENCES sales_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_return_items_original_item_id FOREIGN KEY (original_item_id) REFERENCES sales_invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_return_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_return_items_original_item_id ON sales_return_items (original_item_id);
CREATE INDEX ix_sales_return_items_batch_id ON sales_return_items (batch_id);
