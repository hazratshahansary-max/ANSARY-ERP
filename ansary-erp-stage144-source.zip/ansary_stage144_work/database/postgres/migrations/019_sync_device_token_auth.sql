-- Stage 51: bind sync writes to a separately provisioned device secret.
ALTER TABLE sync_devices ADD COLUMN token_sha256 text;
