-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 021_sync_master_apply_log.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE TABLE sync_master_apply_log (
    event_uuid text PRIMARY KEY,
    device_id uuid NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
    table_name text NOT NULL,
    row_id text NOT NULL,
    status text NOT NULL CHECK (status IN ('applied','conflict')),
    reason text,
    applied_version integer,
    processed_at timestamptz NOT NULL
);
CREATE INDEX ix_sync_master_apply_log_device ON sync_master_apply_log(device_id, processed_at);
