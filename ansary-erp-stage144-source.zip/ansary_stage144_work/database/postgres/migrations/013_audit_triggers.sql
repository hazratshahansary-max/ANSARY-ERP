-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 013_audit_triggers.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE FUNCTION fn_trg_sales_invoices_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_invoices', CAST(NEW.id AS text), NEW.invoice_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_audit AFTER UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_sales_invoices_audit();

CREATE FUNCTION fn_trg_purchase_invoices_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_invoices', CAST(NEW.id AS text), NEW.invoice_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_audit AFTER UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_purchase_invoices_audit();

CREATE FUNCTION fn_trg_sales_returns_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_returns', CAST(NEW.id AS text), NEW.return_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_sales_returns_audit AFTER UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_sales_returns_audit();

CREATE FUNCTION fn_trg_purchase_returns_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_returns', CAST(NEW.id AS text), NEW.return_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_audit AFTER UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_purchase_returns_audit();

CREATE FUNCTION fn_trg_vouchers_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'vouchers', CAST(NEW.id AS text), NEW.voucher_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.amount));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_vouchers_audit AFTER UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_vouchers_audit();

CREATE FUNCTION fn_trg_stock_adjustments_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_adjustments', CAST(NEW.id AS text), NEW.adj_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NULL));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_audit AFTER UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_stock_adjustments_audit();

CREATE FUNCTION fn_trg_journal_entries_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'journal_entries', CAST(NEW.id AS text), NEW.entry_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total_debit));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_journal_entries_audit AFTER UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_journal_entries_audit();

CREATE FUNCTION fn_trg_stock_transfers_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (NEW.posted_by, NEW.from_branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_transfers', CAST(NEW.id AS text), NEW.transfer_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_audit AFTER UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_stock_transfers_audit();

CREATE FUNCTION fn_trg_users_audit_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, new_values) VALUES ('user:created', 'users', CAST(NEW.id AS text), NEW.username, jsonb_build_object('role_id', NEW.role_id));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_users_audit_insert AFTER INSERT ON users FOR EACH ROW EXECUTE FUNCTION fn_trg_users_audit_insert();

CREATE FUNCTION fn_trg_users_audit_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, old_values, new_values) VALUES ('user:updated', 'users', CAST(NEW.id AS text), NEW.username, jsonb_build_object('is_active', OLD.is_active, 'role_id', OLD.role_id), jsonb_build_object('is_active', NEW.is_active, 'role_id', NEW.role_id, 'password_changed', (NEW.password_hash <> OLD.password_hash)));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_users_audit_update AFTER UPDATE OF is_active, role_id, password_hash ON users FOR EACH ROW
WHEN (OLD.is_active IS DISTINCT FROM NEW.is_active OR OLD.role_id <> NEW.role_id OR OLD.password_hash <> NEW.password_hash) EXECUTE FUNCTION fn_trg_users_audit_update();
