-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 003_master.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- categories: Medicine categories.
CREATE TABLE categories (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    name_ps text,
    parent_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_categories PRIMARY KEY (id),
    CONSTRAINT uq_categories_1 UNIQUE (name),
    CONSTRAINT ck_categories_1 CHECK (version >= 1),
    CONSTRAINT fk_categories_parent_id FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE RESTRICT
);
CREATE INDEX ix_categories_parent_id ON categories (parent_id);

-- dosage_forms: Tablet, Syrup, Injection...
CREATE TABLE dosage_forms (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    name_ps text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_dosage_forms PRIMARY KEY (id),
    CONSTRAINT uq_dosage_forms_1 UNIQUE (name),
    CONSTRAINT ck_dosage_forms_1 CHECK (version >= 1)
);

-- units: Units of measure.
CREATE TABLE units (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_units PRIMARY KEY (id),
    CONSTRAINT uq_units_1 UNIQUE (code),
    CONSTRAINT ck_units_1 CHECK (version >= 1)
);

-- companies: Manufacturers / companies.
CREATE TABLE companies (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    kind text NOT NULL DEFAULT 'manufacturer',
    country text,
    address text,
    phone text,
    email text,
    contact_person text,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_companies PRIMARY KEY (id),
    CONSTRAINT uq_companies_1 UNIQUE (code),
    CONSTRAINT ck_companies_1 CHECK (kind IN ('manufacturer','distributor','both')),
    CONSTRAINT ck_companies_2 CHECK (version >= 1)
);

-- medicines: Medicine master (designed and tested for 100,000+ rows).
CREATE TABLE medicines (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    product_code text NOT NULL,
    barcode text,
    name text NOT NULL,
    name_ps text,
    generic_name text,
    brand_name text,
    manufacturer_id uuid,
    company_id uuid,
    category_id uuid,
    composition text,
    strength text NOT NULL DEFAULT '',
    dosage_form_id uuid,
    packing text NOT NULL DEFAULT '',
    unit_id uuid,
    box_quantity numeric(14,3) NOT NULL DEFAULT 1,
    purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    retail_price numeric(18,4) NOT NULL DEFAULT 0,
    min_stock numeric(14,3) NOT NULL DEFAULT 0,
    max_stock numeric(14,3) NOT NULL DEFAULT 0,
    rack_number text,
    country_of_origin text,
    registration_number text,
    image_attachment_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_medicines PRIMARY KEY (id),
    CONSTRAINT uq_medicines_1 UNIQUE (product_code),
    CONSTRAINT ck_medicines_1 CHECK (box_quantity > 0),
    CONSTRAINT ck_medicines_2 CHECK (purchase_price >= 0),
    CONSTRAINT ck_medicines_3 CHECK (wholesale_price >= 0),
    CONSTRAINT ck_medicines_4 CHECK (retail_price >= 0),
    CONSTRAINT ck_medicines_5 CHECK (min_stock >= 0),
    CONSTRAINT ck_medicines_6 CHECK (max_stock >= 0),
    CONSTRAINT ck_medicines_7 CHECK (version >= 1),
    CONSTRAINT ck_medicines_8 CHECK (max_stock = 0 OR max_stock >= min_stock),
    CONSTRAINT fk_medicines_manufacturer_id FOREIGN KEY (manufacturer_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_company_id FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_category_id FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_dosage_form_id FOREIGN KEY (dosage_form_id) REFERENCES dosage_forms (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_unit_id FOREIGN KEY (unit_id) REFERENCES units (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_image_attachment_id FOREIGN KEY (image_attachment_id) REFERENCES attachments (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_medicines_1 ON medicines (barcode) WHERE barcode IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX ix_medicines_2 ON medicines (barcode);
CREATE INDEX ix_medicines_3 ON medicines (lower(name));
CREATE INDEX ix_medicines_4 ON medicines (lower(generic_name));
CREATE INDEX ix_medicines_5 ON medicines (lower(brand_name));
CREATE INDEX ix_medicines_6 ON medicines (manufacturer_id, lower(name));
CREATE INDEX ix_medicines_7 ON medicines (category_id);
CREATE INDEX ix_medicines_8 ON medicines (is_active);
CREATE INDEX ix_medicines_company_id ON medicines (company_id);
CREATE INDEX ix_medicines_dosage_form_id ON medicines (dosage_form_id);
CREATE INDEX ix_medicines_unit_id ON medicines (unit_id);
CREATE INDEX ix_medicines_image_attachment_id ON medicines (image_attachment_id);

-- medicine_barcodes: Additional barcodes / formats per medicine.
CREATE TABLE medicine_barcodes (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    medicine_id uuid NOT NULL,
    barcode text NOT NULL,
    barcode_format text NOT NULL DEFAULT 'EAN13',
    is_primary boolean NOT NULL DEFAULT FALSE,
    pack_qty numeric(14,3) NOT NULL DEFAULT 1,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_medicine_barcodes PRIMARY KEY (id),
    CONSTRAINT uq_medicine_barcodes_1 UNIQUE (barcode),
    CONSTRAINT ck_medicine_barcodes_1 CHECK (barcode_format IN ('EAN13','EAN8','UPCA','CODE128','CODE39','QR','DATAMATRIX','OTHER')),
    CONSTRAINT ck_medicine_barcodes_2 CHECK (pack_qty > 0),
    CONSTRAINT ck_medicine_barcodes_3 CHECK (version >= 1),
    CONSTRAINT fk_medicine_barcodes_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE CASCADE
);
CREATE INDEX ix_medicine_barcodes_medicine_id ON medicine_barcodes (medicine_id);

-- medicine_price_history: Price changes (filled by trigger; append-only).
CREATE TABLE medicine_price_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    medicine_id uuid NOT NULL,
    old_purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    new_purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    old_wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    new_wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    old_retail_price numeric(18,4) NOT NULL DEFAULT 0,
    new_retail_price numeric(18,4) NOT NULL DEFAULT 0,
    changed_by uuid,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_medicine_price_history PRIMARY KEY (id),
    CONSTRAINT ck_medicine_price_history_1 CHECK (old_purchase_price >= 0),
    CONSTRAINT ck_medicine_price_history_2 CHECK (new_purchase_price >= 0),
    CONSTRAINT ck_medicine_price_history_3 CHECK (old_wholesale_price >= 0),
    CONSTRAINT ck_medicine_price_history_4 CHECK (new_wholesale_price >= 0),
    CONSTRAINT ck_medicine_price_history_5 CHECK (old_retail_price >= 0),
    CONSTRAINT ck_medicine_price_history_6 CHECK (new_retail_price >= 0),
    CONSTRAINT fk_medicine_price_history_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicine_price_history_changed_by FOREIGN KEY (changed_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_medicine_price_history_1 ON medicine_price_history (medicine_id, created_at);
CREATE INDEX ix_medicine_price_history_changed_by ON medicine_price_history (changed_by);

-- customers: Customers (opening_balance > 0 means the customer owes us).
CREATE TABLE customers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    business_name text,
    phone text,
    address text,
    customer_type text NOT NULL DEFAULT 'retail',
    opening_balance numeric(18,4) NOT NULL DEFAULT 0,
    opening_balance_date date,
    credit_limit numeric(18,4) NOT NULL DEFAULT 0,
    contact_person text,
    notes text,
    currency_code text NOT NULL DEFAULT 'AFN',
    branch_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_customers PRIMARY KEY (id),
    CONSTRAINT uq_customers_1 UNIQUE (code),
    CONSTRAINT ck_customers_1 CHECK (customer_type IN ('retail','wholesale')),
    CONSTRAINT ck_customers_2 CHECK (credit_limit >= 0),
    CONSTRAINT ck_customers_3 CHECK (version >= 1),
    CONSTRAINT fk_customers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_customers_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_customers_1 ON customers (lower(name));
CREATE INDEX ix_customers_2 ON customers (phone);
CREATE INDEX ix_customers_currency_code ON customers (currency_code);
CREATE INDEX ix_customers_branch_id ON customers (branch_id);

-- suppliers: Suppliers (opening_balance > 0 means we owe the supplier).
CREATE TABLE suppliers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    business_name text,
    company_id uuid,
    phone text,
    address text,
    opening_balance numeric(18,4) NOT NULL DEFAULT 0,
    opening_balance_date date,
    contact_person text,
    notes text,
    currency_code text NOT NULL DEFAULT 'AFN',
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_suppliers PRIMARY KEY (id),
    CONSTRAINT uq_suppliers_1 UNIQUE (code),
    CONSTRAINT ck_suppliers_1 CHECK (version >= 1),
    CONSTRAINT fk_suppliers_company_id FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_suppliers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_suppliers_1 ON suppliers (lower(name));
CREATE INDEX ix_suppliers_company_id ON suppliers (company_id);
CREATE INDEX ix_suppliers_currency_code ON suppliers (currency_code);
