-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 022_due_reminder_history_triggers.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE OR REPLACE FUNCTION fn_trg_due_reminder_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'due_reminder_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;

CREATE OR REPLACE FUNCTION fn_trg_due_reminder_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'due_reminder_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;

DROP TRIGGER IF EXISTS trg_due_reminder_history_append_only_update ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_append_only_update BEFORE UPDATE ON due_reminder_history FOR EACH ROW WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_due_reminder_history_append_only_update();

DROP TRIGGER IF EXISTS trg_due_reminder_history_append_only_delete ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_append_only_delete BEFORE DELETE ON due_reminder_history FOR EACH ROW WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_due_reminder_history_append_only_delete();

DROP TRIGGER IF EXISTS trg_due_reminder_history_changelog_insert ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_changelog_insert AFTER INSERT ON due_reminder_history FOR EACH ROW EXECUTE FUNCTION ansary_log_change('id');
