-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 014_sync_support.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE FUNCTION ansary_touch() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    NEW.version := OLD.version + 1;
    NEW.updated_at := now();
    RETURN NEW;
END
$fn$;

CREATE FUNCTION ansary_log_change() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE
    j jsonb;
    rid text;
BEGIN
    IF TG_OP = 'DELETE' THEN j := to_jsonb(OLD); ELSE j := to_jsonb(NEW); END IF;
    rid := j ->> TG_ARGV[0];
    INSERT INTO change_log (table_name, row_id, op, version, branch_id, origin_device_id)
    VALUES (TG_TABLE_NAME, rid, lower(TG_OP), NULLIF(j ->> 'version', '')::integer,
            COALESCE(NULLIF(j ->> 'branch_id', ''), NULLIF(j ->> 'from_branch_id', ''))::uuid,
            j ->> 'origin_device_id');
    PERFORM pg_notify('ansary_changes', json_build_object('t', TG_TABLE_NAME, 'id', rid, 'op', lower(TG_OP))::text);
    RETURN NULL;
END
$fn$;

-- Allocates the next document number, e.g. SI-HO-00-FY2026-000001 (atomic, row-locked).
CREATE FUNCTION next_doc_no(p_doc_type text, p_branch uuid, p_fy uuid, p_device text DEFAULT '00')
RETURNS text LANGUAGE plpgsql AS $fn$
DECLARE
    s number_sequences%ROWTYPE;
    b text;
    fy text;
BEGIN
    UPDATE number_sequences SET next_number = next_number + 1
     WHERE doc_type = p_doc_type AND branch_id = p_branch AND financial_year_id = p_fy AND device_code = p_device
    RETURNING * INTO s;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'No number sequence configured for % / % / %', p_doc_type, p_branch, p_device;
    END IF;
    SELECT code INTO b FROM branches WHERE id = p_branch;
    SELECT name INTO fy FROM financial_years WHERE id = p_fy;
    RETURN s.prefix || '-' || b || '-' || s.device_code || '-' || fy || '-' || lpad((s.next_number - 1)::text, s.padding, '0');
END
$fn$;

CREATE TRIGGER trg_currencies_touch BEFORE UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_currencies_changelog_insert AFTER INSERT ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_currencies_changelog_update AFTER UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_currencies_changelog_delete AFTER DELETE ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_exchange_rates_touch BEFORE UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_exchange_rates_changelog_insert AFTER INSERT ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_exchange_rates_changelog_update AFTER UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_exchange_rates_changelog_delete AFTER DELETE ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_touch BEFORE UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_branches_changelog_insert AFTER INSERT ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_changelog_update AFTER UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_changelog_delete AFTER DELETE ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_touch BEFORE UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_company_profile_changelog_insert AFTER INSERT ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_changelog_update AFTER UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_changelog_delete AFTER DELETE ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_touch BEFORE UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_settings_changelog_insert AFTER INSERT ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_changelog_update AFTER UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_changelog_delete AFTER DELETE ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_touch BEFORE UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_tax_rates_changelog_insert AFTER INSERT ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_changelog_update AFTER UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_changelog_delete AFTER DELETE ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_touch BEFORE UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_invoice_templates_changelog_insert AFTER INSERT ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_changelog_update AFTER UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_changelog_delete AFTER DELETE ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_touch BEFORE UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_roles_changelog_insert AFTER INSERT ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_changelog_update AFTER UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_changelog_delete AFTER DELETE ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_touch BEFORE UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_permissions_changelog_insert AFTER INSERT ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_changelog_update AFTER UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_changelog_delete AFTER DELETE ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_touch BEFORE UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_role_permissions_changelog_insert AFTER INSERT ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_changelog_update AFTER UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_changelog_delete AFTER DELETE ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_touch BEFORE UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_users_changelog_insert AFTER INSERT ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_changelog_update AFTER UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_changelog_delete AFTER DELETE ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_touch BEFORE UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_user_branches_changelog_insert AFTER INSERT ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_changelog_update AFTER UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_changelog_delete AFTER DELETE ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_touch BEFORE UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_user_permission_overrides_changelog_insert AFTER INSERT ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_changelog_update AFTER UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_changelog_delete AFTER DELETE ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_login_history_changelog_insert AFTER INSERT ON login_history FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_audit_log_changelog_insert AFTER INSERT ON audit_log FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_touch BEFORE UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_attachments_changelog_insert AFTER INSERT ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_changelog_update AFTER UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_changelog_delete AFTER DELETE ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_touch BEFORE UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_categories_changelog_insert AFTER INSERT ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_changelog_update AFTER UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_changelog_delete AFTER DELETE ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_touch BEFORE UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_dosage_forms_changelog_insert AFTER INSERT ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_changelog_update AFTER UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_changelog_delete AFTER DELETE ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_touch BEFORE UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_units_changelog_insert AFTER INSERT ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_changelog_update AFTER UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_changelog_delete AFTER DELETE ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_touch BEFORE UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_companies_changelog_insert AFTER INSERT ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_changelog_update AFTER UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_changelog_delete AFTER DELETE ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_touch BEFORE UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_medicines_changelog_insert AFTER INSERT ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_changelog_update AFTER UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_changelog_delete AFTER DELETE ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_touch BEFORE UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_medicine_barcodes_changelog_insert AFTER INSERT ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_changelog_update AFTER UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_changelog_delete AFTER DELETE ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_price_history_changelog_insert AFTER INSERT ON medicine_price_history FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_touch BEFORE UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_customers_changelog_insert AFTER INSERT ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_changelog_update AFTER UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_changelog_delete AFTER DELETE ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_touch BEFORE UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_suppliers_changelog_insert AFTER INSERT ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_changelog_update AFTER UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_changelog_delete AFTER DELETE ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_touch BEFORE UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_financial_years_changelog_insert AFTER INSERT ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_changelog_update AFTER UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_changelog_delete AFTER DELETE ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_touch BEFORE UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_number_sequences_changelog_insert AFTER INSERT ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_changelog_update AFTER UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_changelog_delete AFTER DELETE ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_touch BEFORE UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_accounts_changelog_insert AFTER INSERT ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_changelog_update AFTER UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_changelog_delete AFTER DELETE ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_touch BEFORE UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_bank_accounts_changelog_insert AFTER INSERT ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_changelog_update AFTER UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_changelog_delete AFTER DELETE ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_touch BEFORE UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_expense_categories_changelog_insert AFTER INSERT ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_changelog_update AFTER UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_changelog_delete AFTER DELETE ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_touch BEFORE UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_journal_entries_changelog_insert AFTER INSERT ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_changelog_update AFTER UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_changelog_delete AFTER DELETE ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_touch BEFORE UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_journal_lines_changelog_insert AFTER INSERT ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_changelog_update AFTER UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_changelog_delete AFTER DELETE ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_touch BEFORE UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_batches_changelog_insert AFTER INSERT ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_changelog_update AFTER UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_changelog_delete AFTER DELETE ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_movements_changelog_insert AFTER INSERT ON stock_movements FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_touch BEFORE UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_adjustments_changelog_insert AFTER INSERT ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_changelog_update AFTER UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_changelog_delete AFTER DELETE ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_touch BEFORE UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_adjustment_items_changelog_insert AFTER INSERT ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_changelog_update AFTER UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_changelog_delete AFTER DELETE ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_touch BEFORE UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_transfers_changelog_insert AFTER INSERT ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_changelog_update AFTER UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_changelog_delete AFTER DELETE ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_touch BEFORE UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_transfer_items_changelog_insert AFTER INSERT ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_changelog_update AFTER UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_changelog_delete AFTER DELETE ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_touch BEFORE UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_physical_counts_changelog_insert AFTER INSERT ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_changelog_update AFTER UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_changelog_delete AFTER DELETE ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_touch BEFORE UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_physical_count_items_changelog_insert AFTER INSERT ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_changelog_update AFTER UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_changelog_delete AFTER DELETE ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_touch BEFORE UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_orders_changelog_insert AFTER INSERT ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_changelog_update AFTER UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_changelog_delete AFTER DELETE ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_touch BEFORE UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_order_items_changelog_insert AFTER INSERT ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_changelog_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_changelog_delete AFTER DELETE ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_touch BEFORE UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_goods_receipts_changelog_insert AFTER INSERT ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_changelog_update AFTER UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_changelog_delete AFTER DELETE ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_touch BEFORE UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_goods_receipt_items_changelog_insert AFTER INSERT ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_changelog_update AFTER UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_changelog_delete AFTER DELETE ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_touch BEFORE UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_invoices_changelog_insert AFTER INSERT ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_changelog_update AFTER UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_changelog_delete AFTER DELETE ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_touch BEFORE UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_invoice_items_changelog_insert AFTER INSERT ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_changelog_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_changelog_delete AFTER DELETE ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_touch BEFORE UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_returns_changelog_insert AFTER INSERT ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_changelog_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_changelog_delete AFTER DELETE ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_touch BEFORE UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_return_items_changelog_insert AFTER INSERT ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_changelog_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_changelog_delete AFTER DELETE ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_touch BEFORE UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_orders_changelog_insert AFTER INSERT ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_changelog_update AFTER UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_changelog_delete AFTER DELETE ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_touch BEFORE UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_order_items_changelog_insert AFTER INSERT ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_changelog_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_changelog_delete AFTER DELETE ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_touch BEFORE UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_invoices_changelog_insert AFTER INSERT ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_changelog_update AFTER UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_changelog_delete AFTER DELETE ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_touch BEFORE UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_invoice_items_changelog_insert AFTER INSERT ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_changelog_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_changelog_delete AFTER DELETE ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_touch BEFORE UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_returns_changelog_insert AFTER INSERT ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_changelog_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_changelog_delete AFTER DELETE ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_touch BEFORE UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_return_items_changelog_insert AFTER INSERT ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_changelog_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_changelog_delete AFTER DELETE ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_touch BEFORE UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_vouchers_changelog_insert AFTER INSERT ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_changelog_update AFTER UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_changelog_delete AFTER DELETE ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_touch BEFORE UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_payment_allocations_changelog_insert AFTER INSERT ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_changelog_update AFTER UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_changelog_delete AFTER DELETE ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_touch BEFORE UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_plans_changelog_insert AFTER INSERT ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_changelog_update AFTER UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_changelog_delete AFTER DELETE ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_touch BEFORE UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_schedule_changelog_insert AFTER INSERT ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_changelog_update AFTER UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_changelog_delete AFTER DELETE ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_touch BEFORE UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_payment_allocations_changelog_insert AFTER INSERT ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_changelog_update AFTER UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_changelog_delete AFTER DELETE ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
