-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 009_system.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- backup_history: Backup and restore history (device-local).
CREATE TABLE backup_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    kind text NOT NULL,
    location text NOT NULL DEFAULT 'local',
    file_path text NOT NULL,
    size_bytes bigint,
    sha256 text,
    status text NOT NULL DEFAULT 'started',
    integrity_result text,
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    created_by uuid,
    note text,
    CONSTRAINT pk_backup_history PRIMARY KEY (id),
    CONSTRAINT ck_backup_history_1 CHECK (kind IN ('manual','automatic','scheduled','pre_upgrade','pre_conflict','restore_point')),
    CONSTRAINT ck_backup_history_2 CHECK (location IN ('local','cloud')),
    CONSTRAINT ck_backup_history_3 CHECK (status IN ('started','completed','failed','verified','restored')),
    CONSTRAINT fk_backup_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_backup_history_created_by ON backup_history (created_by);

-- sync_conflicts: Detected synchronisation conflicts awaiting or recording resolution.
CREATE TABLE sync_conflicts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    table_name text NOT NULL,
    row_id text NOT NULL,
    device_id text,
    local_version integer,
    server_version integer,
    local_payload jsonb,
    server_payload jsonb,
    reason text NOT NULL DEFAULT 'version_conflict',
    detected_at timestamptz NOT NULL DEFAULT now(),
    resolution text NOT NULL DEFAULT 'pending',
    resolved_by uuid,
    resolved_at timestamptz,
    backup_ref text,
    CONSTRAINT pk_sync_conflicts PRIMARY KEY (id),
    CONSTRAINT ck_sync_conflicts_1 CHECK (resolution IN ('pending','local_won','server_won','merged','dismissed')),
    CONSTRAINT fk_sync_conflicts_resolved_by FOREIGN KEY (resolved_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sync_conflicts_1 ON sync_conflicts (resolution, detected_at);
CREATE INDEX ix_sync_conflicts_resolved_by ON sync_conflicts (resolved_by);

-- sync_log: One row per synchronisation run.
CREATE TABLE sync_log (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    device_id text,
    direction text NOT NULL,
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    pushed integer NOT NULL DEFAULT 0,
    pulled integer NOT NULL DEFAULT 0,
    conflicts integer NOT NULL DEFAULT 0,
    status text NOT NULL DEFAULT 'started',
    error text,
    CONSTRAINT pk_sync_log PRIMARY KEY (id),
    CONSTRAINT ck_sync_log_1 CHECK (direction IN ('push','pull','full')),
    CONSTRAINT ck_sync_log_2 CHECK (status IN ('started','ok','partial','failed'))
);


CREATE TABLE change_log (
    seq bigserial PRIMARY KEY,
    table_name text NOT NULL,
    row_id text NOT NULL,
    op text NOT NULL CHECK (op IN ('insert','update','delete')),
    version integer,
    branch_id uuid,
    origin_device_id text,
    changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_change_log_row ON change_log (table_name, row_id);
CREATE INDEX ix_change_log_branch_seq ON change_log (branch_id, seq);

CREATE TABLE sync_devices (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    device_code text NOT NULL UNIQUE,
    name text NOT NULL,
    platform text CHECK (platform IN ('windows','android','web','server')),
    branch_id uuid REFERENCES branches (id) ON DELETE RESTRICT,
    last_seen_at timestamptz,
    last_acked_seq bigint NOT NULL DEFAULT 0,
    is_revoked boolean NOT NULL DEFAULT false,
    registered_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_sync_devices_branch ON sync_devices (branch_id);
