-- Stage 52: audit device-token lifecycle changes without storing raw secrets.
CREATE TABLE IF NOT EXISTS sync_device_token_audit (
 id uuid PRIMARY KEY,
 device_id uuid NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
 actor_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
 action text NOT NULL CHECK(action IN ('rotated','revoked')),
 occurred_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sync_device_token_audit_device_time
 ON sync_device_token_audit(device_id, occurred_at);
