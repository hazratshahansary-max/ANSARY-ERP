-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 008_vouchers.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- vouchers: Receipts, payments, contra, expense and income vouchers.
CREATE TABLE vouchers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    voucher_no text NOT NULL,
    voucher_type text NOT NULL,
    voucher_date date NOT NULL,
    customer_id uuid,
    supplier_id uuid,
    expense_category_id uuid,
    cash_bank_account_id uuid NOT NULL,
    counter_account_id uuid,
    payment_method text NOT NULL DEFAULT 'cash',
    amount numeric(18,4) NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    reference text,
    description text,
    attachment_id uuid,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_vouchers PRIMARY KEY (id),
    CONSTRAINT uq_vouchers_1 UNIQUE (voucher_no),
    CONSTRAINT ck_vouchers_1 CHECK (voucher_type IN ('cash_receipt','cash_payment','customer_receipt','supplier_payment','contra','expense','income')),
    CONSTRAINT ck_vouchers_2 CHECK (payment_method IN ('cash','bank','cheque','transfer','card')),
    CONSTRAINT ck_vouchers_3 CHECK (amount > 0),
    CONSTRAINT ck_vouchers_4 CHECK (exchange_rate > 0),
    CONSTRAINT ck_vouchers_5 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_vouchers_6 CHECK (version >= 1),
    CONSTRAINT ck_vouchers_7 CHECK (voucher_type <> 'customer_receipt' OR customer_id IS NOT NULL),
    CONSTRAINT ck_vouchers_8 CHECK (voucher_type <> 'supplier_payment' OR supplier_id IS NOT NULL),
    CONSTRAINT ck_vouchers_9 CHECK (voucher_type <> 'expense' OR expense_category_id IS NOT NULL),
    CONSTRAINT ck_vouchers_10 CHECK (voucher_type NOT IN ('cash_receipt','cash_payment','income','contra') OR counter_account_id IS NOT NULL),
    CONSTRAINT ck_vouchers_11 CHECK (counter_account_id IS NULL OR counter_account_id <> cash_bank_account_id),
    CONSTRAINT fk_vouchers_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_expense_category_id FOREIGN KEY (expense_category_id) REFERENCES expense_categories (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_cash_bank_account_id FOREIGN KEY (cash_bank_account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_counter_account_id FOREIGN KEY (counter_account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_attachment_id FOREIGN KEY (attachment_id) REFERENCES attachments (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_vouchers_1 ON vouchers (voucher_date);
CREATE INDEX ix_vouchers_2 ON vouchers (voucher_type, voucher_date);
CREATE UNIQUE INDEX ux_vouchers_3 ON vouchers (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_vouchers_branch_id ON vouchers (branch_id);
CREATE INDEX ix_vouchers_customer_id ON vouchers (customer_id);
CREATE INDEX ix_vouchers_supplier_id ON vouchers (supplier_id);
CREATE INDEX ix_vouchers_expense_category_id ON vouchers (expense_category_id);
CREATE INDEX ix_vouchers_cash_bank_account_id ON vouchers (cash_bank_account_id);
CREATE INDEX ix_vouchers_counter_account_id ON vouchers (counter_account_id);
CREATE INDEX ix_vouchers_currency_code ON vouchers (currency_code);
CREATE INDEX ix_vouchers_attachment_id ON vouchers (attachment_id);
CREATE INDEX ix_vouchers_posted_by ON vouchers (posted_by);
CREATE INDEX ix_vouchers_reversed_by ON vouchers (reversed_by);
CREATE INDEX ix_vouchers_journal_entry_id ON vouchers (journal_entry_id);
CREATE INDEX ix_vouchers_reversal_entry_id ON vouchers (reversal_entry_id);

-- payment_allocations: Settlement of invoices by receipts/payments.
CREATE TABLE payment_allocations (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    voucher_id uuid NOT NULL,
    sales_invoice_id uuid,
    purchase_invoice_id uuid,
    amount numeric(18,4) NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_payment_allocations PRIMARY KEY (id),
    CONSTRAINT uq_payment_allocations_1 UNIQUE (voucher_id, sales_invoice_id, purchase_invoice_id),
    CONSTRAINT ck_payment_allocations_1 CHECK (amount > 0),
    CONSTRAINT ck_payment_allocations_2 CHECK (version >= 1),
    CONSTRAINT ck_payment_allocations_3 CHECK ((sales_invoice_id IS NULL) <> (purchase_invoice_id IS NULL)),
    CONSTRAINT fk_payment_allocations_voucher_id FOREIGN KEY (voucher_id) REFERENCES vouchers (id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_allocations_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_payment_allocations_purchase_invoice_id FOREIGN KEY (purchase_invoice_id) REFERENCES purchase_invoices (id) ON DELETE RESTRICT
);
CREATE INDEX ix_payment_allocations_sales_invoice_id ON payment_allocations (sales_invoice_id);
CREATE INDEX ix_payment_allocations_purchase_invoice_id ON payment_allocations (purchase_invoice_id);
