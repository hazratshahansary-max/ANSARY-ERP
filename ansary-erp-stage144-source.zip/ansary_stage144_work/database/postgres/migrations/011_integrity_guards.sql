-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 011_integrity_guards.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE FUNCTION fn_trg_sales_invoices_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_no_posted_insert BEFORE INSERT ON sales_invoices FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_no_posted_insert();

CREATE FUNCTION fn_trg_sales_invoices_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_no_delete BEFORE DELETE ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_no_delete();

CREATE FUNCTION fn_trg_sales_invoices_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_transition BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_sales_invoices_transition();

CREATE FUNCTION fn_trg_sales_invoices_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_frozen BEFORE UPDATE ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.invoice_no IS DISTINCT FROM OLD.invoice_no OR NEW.sale_type IS DISTINCT FROM OLD.sale_type OR NEW.payment_type IS DISTINCT FROM OLD.payment_type OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.sales_order_id IS DISTINCT FROM OLD.sales_order_id OR NEW.invoice_date IS DISTINCT FROM OLD.invoice_date OR NEW.due_date IS DISTINCT FROM OLD.due_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.discount_amount IS DISTINCT FROM OLD.discount_amount OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.round_off IS DISTINCT FROM OLD.round_off OR NEW.total IS DISTINCT FROM OLD.total OR NEW.previous_balance IS DISTINCT FROM OLD.previous_balance OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_sales_invoices_frozen();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = NEW.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_insert BEFORE INSERT ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_insert();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_update BEFORE UPDATE ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_update();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_delete BEFORE DELETE ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_delete();

CREATE FUNCTION fn_trg_purchase_invoices_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_no_posted_insert BEFORE INSERT ON purchase_invoices FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_no_posted_insert();

CREATE FUNCTION fn_trg_purchase_invoices_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_no_delete BEFORE DELETE ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_no_delete();

CREATE FUNCTION fn_trg_purchase_invoices_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_transition BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_purchase_invoices_transition();

CREATE FUNCTION fn_trg_purchase_invoices_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_frozen BEFORE UPDATE ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.invoice_no IS DISTINCT FROM OLD.invoice_no OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.supplier_invoice_no IS DISTINCT FROM OLD.supplier_invoice_no OR NEW.purchase_order_id IS DISTINCT FROM OLD.purchase_order_id OR NEW.goods_receipt_id IS DISTINCT FROM OLD.goods_receipt_id OR NEW.invoice_date IS DISTINCT FROM OLD.invoice_date OR NEW.due_date IS DISTINCT FROM OLD.due_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.discount_amount IS DISTINCT FROM OLD.discount_amount OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.additional_costs IS DISTINCT FROM OLD.additional_costs OR NEW.round_off IS DISTINCT FROM OLD.round_off OR NEW.total IS DISTINCT FROM OLD.total OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_purchase_invoices_frozen();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = NEW.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_insert BEFORE INSERT ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_insert();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_update BEFORE UPDATE ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_update();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_delete BEFORE DELETE ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_delete();

CREATE FUNCTION fn_trg_sales_returns_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_no_posted_insert BEFORE INSERT ON sales_returns FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_no_posted_insert();

CREATE FUNCTION fn_trg_sales_returns_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_returns_no_delete BEFORE DELETE ON sales_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_no_delete();

CREATE FUNCTION fn_trg_sales_returns_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_transition BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_sales_returns_transition();

CREATE FUNCTION fn_trg_sales_returns_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_frozen BEFORE UPDATE ON sales_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.return_no IS DISTINCT FROM OLD.return_no OR NEW.original_invoice_id IS DISTINCT FROM OLD.original_invoice_id OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.return_date IS DISTINCT FROM OLD.return_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.total IS DISTINCT FROM OLD.total OR NEW.refund_method IS DISTINCT FROM OLD.refund_method OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_sales_returns_frozen();

CREATE FUNCTION fn_trg_sales_return_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = NEW.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_insert BEFORE INSERT ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_insert();

CREATE FUNCTION fn_trg_sales_return_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_update BEFORE UPDATE ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_update();

CREATE FUNCTION fn_trg_sales_return_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_delete BEFORE DELETE ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_delete();

CREATE FUNCTION fn_trg_purchase_returns_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_no_posted_insert BEFORE INSERT ON purchase_returns FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_no_posted_insert();

CREATE FUNCTION fn_trg_purchase_returns_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_no_delete BEFORE DELETE ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_no_delete();

CREATE FUNCTION fn_trg_purchase_returns_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_transition BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_purchase_returns_transition();

CREATE FUNCTION fn_trg_purchase_returns_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_frozen BEFORE UPDATE ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.return_no IS DISTINCT FROM OLD.return_no OR NEW.original_invoice_id IS DISTINCT FROM OLD.original_invoice_id OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.return_date IS DISTINCT FROM OLD.return_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.total IS DISTINCT FROM OLD.total OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_purchase_returns_frozen();

CREATE FUNCTION fn_trg_purchase_return_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = NEW.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_insert BEFORE INSERT ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_insert();

CREATE FUNCTION fn_trg_purchase_return_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_update BEFORE UPDATE ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_update();

CREATE FUNCTION fn_trg_purchase_return_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_delete BEFORE DELETE ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_delete();

CREATE FUNCTION fn_trg_vouchers_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_no_posted_insert BEFORE INSERT ON vouchers FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_no_posted_insert();

CREATE FUNCTION fn_trg_vouchers_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_vouchers_no_delete BEFORE DELETE ON vouchers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_no_delete();

CREATE FUNCTION fn_trg_vouchers_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_transition BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_vouchers_transition();

CREATE FUNCTION fn_trg_vouchers_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_frozen BEFORE UPDATE ON vouchers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.voucher_no IS DISTINCT FROM OLD.voucher_no OR NEW.voucher_type IS DISTINCT FROM OLD.voucher_type OR NEW.voucher_date IS DISTINCT FROM OLD.voucher_date OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.expense_category_id IS DISTINCT FROM OLD.expense_category_id OR NEW.cash_bank_account_id IS DISTINCT FROM OLD.cash_bank_account_id OR NEW.counter_account_id IS DISTINCT FROM OLD.counter_account_id OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.amount IS DISTINCT FROM OLD.amount OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.reference IS DISTINCT FROM OLD.reference OR NEW.description IS DISTINCT FROM OLD.description OR NEW.attachment_id IS DISTINCT FROM OLD.attachment_id OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_vouchers_frozen();

CREATE FUNCTION fn_trg_payment_allocations_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = NEW.voucher_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_insert BEFORE INSERT ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_insert();

CREATE FUNCTION fn_trg_payment_allocations_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = OLD.voucher_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_update BEFORE UPDATE ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_update();

CREATE FUNCTION fn_trg_payment_allocations_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = OLD.voucher_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_delete BEFORE DELETE ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_delete();

CREATE FUNCTION fn_trg_stock_adjustments_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_no_posted_insert BEFORE INSERT ON stock_adjustments FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_no_posted_insert();

CREATE FUNCTION fn_trg_stock_adjustments_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_no_delete BEFORE DELETE ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_no_delete();

CREATE FUNCTION fn_trg_stock_adjustments_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_transition BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_stock_adjustments_transition();

CREATE FUNCTION fn_trg_stock_adjustments_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_frozen BEFORE UPDATE ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.adj_no IS DISTINCT FROM OLD.adj_no OR NEW.adj_date IS DISTINCT FROM OLD.adj_date OR NEW.adj_type IS DISTINCT FROM OLD.adj_type OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_stock_adjustments_frozen();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = NEW.adjustment_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_insert BEFORE INSERT ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_insert();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = OLD.adjustment_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_update BEFORE UPDATE ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_update();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = OLD.adjustment_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_delete BEFORE DELETE ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_delete();

CREATE FUNCTION fn_trg_stock_transfers_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_no_posted_insert BEFORE INSERT ON stock_transfers FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_no_posted_insert();

CREATE FUNCTION fn_trg_stock_transfers_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_no_delete BEFORE DELETE ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_no_delete();

CREATE FUNCTION fn_trg_stock_transfers_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_transition BEFORE UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_stock_transfers_transition();

CREATE FUNCTION fn_trg_stock_transfers_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_frozen BEFORE UPDATE ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.transfer_no IS DISTINCT FROM OLD.transfer_no OR NEW.from_branch_id IS DISTINCT FROM OLD.from_branch_id OR NEW.to_branch_id IS DISTINCT FROM OLD.to_branch_id OR NEW.transfer_date IS DISTINCT FROM OLD.transfer_date OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by)) EXECUTE FUNCTION fn_trg_stock_transfers_frozen();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = NEW.transfer_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_insert BEFORE INSERT ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_insert();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = OLD.transfer_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_update BEFORE UPDATE ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_update();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = OLD.transfer_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_delete BEFORE DELETE ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_delete();

CREATE FUNCTION fn_trg_journal_entries_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_no_posted_insert BEFORE INSERT ON journal_entries FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_no_posted_insert();

CREATE FUNCTION fn_trg_journal_entries_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_journal_entries_no_delete BEFORE DELETE ON journal_entries FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_no_delete();

CREATE FUNCTION fn_trg_journal_entries_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_transition BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_journal_entries_transition();

CREATE FUNCTION fn_trg_journal_entries_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_frozen BEFORE UPDATE ON journal_entries FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.entry_no IS DISTINCT FROM OLD.entry_no OR NEW.entry_date IS DISTINCT FROM OLD.entry_date OR NEW.financial_year_id IS DISTINCT FROM OLD.financial_year_id OR NEW.entry_kind IS DISTINCT FROM OLD.entry_kind OR NEW.source_type IS DISTINCT FROM OLD.source_type OR NEW.source_id IS DISTINCT FROM OLD.source_id OR NEW.description IS DISTINCT FROM OLD.description OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.reverses_entry_id IS DISTINCT FROM OLD.reverses_entry_id OR NEW.total_debit IS DISTINCT FROM OLD.total_debit OR NEW.total_credit IS DISTINCT FROM OLD.total_credit OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_journal_entries_frozen();

CREATE FUNCTION fn_trg_journal_lines_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = NEW.entry_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_insert BEFORE INSERT ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_insert();

CREATE FUNCTION fn_trg_journal_lines_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = OLD.entry_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_update BEFORE UPDATE ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_update();

CREATE FUNCTION fn_trg_journal_lines_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = OLD.entry_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_delete BEFORE DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_delete();

CREATE FUNCTION fn_trg_stock_movements_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'stock_movements is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_movements_append_only_update BEFORE UPDATE ON stock_movements FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_movements_append_only_update();

CREATE FUNCTION fn_trg_stock_movements_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'stock_movements is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_movements_append_only_delete BEFORE DELETE ON stock_movements FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_movements_append_only_delete();

CREATE FUNCTION fn_trg_audit_log_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'audit_log is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_audit_log_append_only_update BEFORE UPDATE ON audit_log FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_audit_log_append_only_update();

CREATE FUNCTION fn_trg_audit_log_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'audit_log is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_audit_log_append_only_delete BEFORE DELETE ON audit_log FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_audit_log_append_only_delete();

CREATE FUNCTION fn_trg_login_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'login_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_login_history_append_only_update BEFORE UPDATE ON login_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_login_history_append_only_update();

CREATE FUNCTION fn_trg_login_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'login_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_login_history_append_only_delete BEFORE DELETE ON login_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_login_history_append_only_delete();

CREATE FUNCTION fn_trg_medicine_price_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'medicine_price_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_medicine_price_history_append_only_update BEFORE UPDATE ON medicine_price_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_medicine_price_history_append_only_update();

CREATE FUNCTION fn_trg_medicine_price_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'medicine_price_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_medicine_price_history_append_only_delete BEFORE DELETE ON medicine_price_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_medicine_price_history_append_only_delete();

CREATE FUNCTION fn_trg_stock_movements_check() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM batches b WHERE b.id = NEW.batch_id AND b.branch_id = NEW.branch_id AND b.medicine_id = NEW.medicine_id) THEN RAISE EXCEPTION 'Stock movement does not match its batch/branch/medicine' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_movements_check BEFORE INSERT ON stock_movements FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_movements_check();

CREATE FUNCTION fn_trg_stock_movements_apply() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    UPDATE batches SET qty_on_hand = qty_on_hand + NEW.quantity_change, last_movement_at = NEW.created_at WHERE id = NEW.batch_id;
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_movements_apply AFTER INSERT ON stock_movements FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_movements_apply();

CREATE FUNCTION fn_trg_batches_remote_zero() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    UPDATE batches SET qty_on_hand = 0 WHERE id = NEW.id AND qty_on_hand <> 0;
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_batches_remote_zero AFTER INSERT ON batches FOR EACH ROW
WHEN ((ansary_remote())) EXECUTE FUNCTION fn_trg_batches_remote_zero();

CREATE FUNCTION fn_trg_medicines_price_history() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO medicine_price_history (medicine_id, old_purchase_price, new_purchase_price, old_wholesale_price, new_wholesale_price, old_retail_price, new_retail_price) VALUES (NEW.id, OLD.purchase_price, NEW.purchase_price, OLD.wholesale_price, NEW.wholesale_price, OLD.retail_price, NEW.retail_price);
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_medicines_price_history AFTER UPDATE OF purchase_price, wholesale_price, retail_price ON medicines FOR EACH ROW
WHEN (NEW.purchase_price <> OLD.purchase_price OR NEW.wholesale_price <> OLD.wholesale_price OR NEW.retail_price <> OLD.retail_price) EXECUTE FUNCTION fn_trg_medicines_price_history();

CREATE FUNCTION fn_trg_users_keep_super_admin() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF (SELECT code FROM roles WHERE id = OLD.role_id) = 'super_admin' AND (SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'super_admin' AND u.is_active AND u.deleted_at IS NULL AND u.id <> OLD.id) = 0 THEN RAISE EXCEPTION 'At least one active Super Admin must remain' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_users_keep_super_admin BEFORE UPDATE OF is_active, role_id, deleted_at ON users FOR EACH ROW
WHEN (OLD.is_active AND OLD.deleted_at IS NULL AND (NOT NEW.is_active OR NEW.role_id <> OLD.role_id OR NEW.deleted_at IS NOT NULL)) EXECUTE FUNCTION fn_trg_users_keep_super_admin();
