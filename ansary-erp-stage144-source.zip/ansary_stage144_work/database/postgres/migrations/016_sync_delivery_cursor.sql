-- Stage 30: prevent clients from acknowledging or skipping undelivered sync events.
ALTER TABLE sync_devices ADD COLUMN last_delivered_seq bigint NOT NULL DEFAULT 0;
