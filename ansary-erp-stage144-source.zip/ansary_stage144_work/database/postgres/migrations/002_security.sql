-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 002_security.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- roles: Role definitions (8 built-in roles).
CREATE TABLE roles (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    description text,
    is_system boolean NOT NULL DEFAULT FALSE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_roles PRIMARY KEY (id),
    CONSTRAINT uq_roles_1 UNIQUE (code),
    CONSTRAINT ck_roles_1 CHECK (version >= 1)
);

-- permissions: Permission catalogue (module.action).
CREATE TABLE permissions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    description text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_permissions PRIMARY KEY (id),
    CONSTRAINT uq_permissions_1 UNIQUE (module, action),
    CONSTRAINT uq_permissions_2 UNIQUE (code),
    CONSTRAINT ck_permissions_1 CHECK (version >= 1)
);

-- role_permissions: Role to permission grants.
CREATE TABLE role_permissions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_role_permissions PRIMARY KEY (id),
    CONSTRAINT uq_role_permissions_1 UNIQUE (role_id, permission_id),
    CONSTRAINT ck_role_permissions_1 CHECK (version >= 1),
    CONSTRAINT fk_role_permissions_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_role_permissions_permission_id ON role_permissions (permission_id);

-- users: User accounts (password stored only as a salted hash).
CREATE TABLE users (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    username text NOT NULL,
    password_hash text NOT NULL,
    password_algo text NOT NULL DEFAULT 'argon2id',
    full_name text NOT NULL,
    email text,
    phone text,
    role_id uuid NOT NULL,
    default_branch_id uuid,
    language text NOT NULL DEFAULT 'en',
    is_active boolean NOT NULL DEFAULT TRUE,
    must_change_password boolean NOT NULL DEFAULT TRUE,
    failed_attempts integer NOT NULL DEFAULT 0,
    locked_until timestamptz,
    last_login_at timestamptz,
    password_changed_at timestamptz,
    session_timeout_minutes integer NOT NULL DEFAULT 30,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_users PRIMARY KEY (id),
    CONSTRAINT uq_users_1 UNIQUE (username),
    CONSTRAINT ck_users_1 CHECK (username = lower(username)),
    CONSTRAINT ck_users_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_users_3 CHECK (failed_attempts >= 0),
    CONSTRAINT ck_users_4 CHECK (session_timeout_minutes >= 1),
    CONSTRAINT ck_users_5 CHECK (version >= 1),
    CONSTRAINT fk_users_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT fk_users_default_branch_id FOREIGN KEY (default_branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_users_role_id ON users (role_id);
CREATE INDEX ix_users_default_branch_id ON users (default_branch_id);

-- user_branches: Branches a user may access.
CREATE TABLE user_branches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_branches PRIMARY KEY (id),
    CONSTRAINT uq_user_branches_1 UNIQUE (user_id, branch_id),
    CONSTRAINT ck_user_branches_1 CHECK (version >= 1),
    CONSTRAINT fk_user_branches_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_branches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_branches_branch_id ON user_branches (branch_id);

-- user_permission_overrides: Per-user grant/deny on top of the role.
CREATE TABLE user_permission_overrides (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    granted boolean NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_permission_overrides PRIMARY KEY (id),
    CONSTRAINT uq_user_permission_overrides_1 UNIQUE (user_id, permission_id),
    CONSTRAINT ck_user_permission_overrides_1 CHECK (version >= 1),
    CONSTRAINT fk_user_permission_overrides_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_permission_overrides_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_permission_overrides_permission_id ON user_permission_overrides (permission_id);

-- user_sessions: Active sessions (device-local, never synchronised).
CREATE TABLE user_sessions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    device_id text,
    ip_address text,
    user_agent text,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    revoked_reason text,
    CONSTRAINT pk_user_sessions PRIMARY KEY (id),
    CONSTRAINT uq_user_sessions_1 UNIQUE (token_hash),
    CONSTRAINT fk_user_sessions_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_user_sessions_user_id ON user_sessions (user_id);

-- login_history: Every login attempt (append-only).
CREATE TABLE login_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid,
    username_attempted text NOT NULL,
    success boolean NOT NULL,
    failure_reason text,
    ip_address text,
    user_agent text,
    device_id text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_login_history PRIMARY KEY (id),
    CONSTRAINT fk_login_history_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_login_history_user_id ON login_history (user_id);

-- audit_log: Immutable transaction audit trail.
CREATE TABLE audit_log (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid,
    branch_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    ref_no text,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_audit_log PRIMARY KEY (id),
    CONSTRAINT fk_audit_log_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_audit_log_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_audit_log_1 ON audit_log (entity_type, entity_id);
CREATE INDEX ix_audit_log_2 ON audit_log (created_at);
CREATE INDEX ix_audit_log_user_id ON audit_log (user_id);
CREATE INDEX ix_audit_log_branch_id ON audit_log (branch_id);

-- attachments: File attachments metadata (files live on disk/object store).
CREATE TABLE attachments (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    file_name text NOT NULL,
    mime_type text,
    storage_path text NOT NULL,
    sha256 text,
    size_bytes bigint,
    uploaded_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_attachments PRIMARY KEY (id),
    CONSTRAINT ck_attachments_1 CHECK (size_bytes IS NULL OR size_bytes >= 0),
    CONSTRAINT ck_attachments_2 CHECK (version >= 1),
    CONSTRAINT fk_attachments_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_attachments_1 ON attachments (entity_type, entity_id);
CREATE INDEX ix_attachments_uploaded_by ON attachments (uploaded_by);
