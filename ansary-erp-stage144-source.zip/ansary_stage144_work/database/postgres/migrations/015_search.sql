-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 015_search.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- Fast medicine search for 100,000+ rows (prefix + substring + typo tolerant).
CREATE INDEX ix_medicines_name_prefix ON medicines (lower(name) text_pattern_ops);
CREATE INDEX ix_medicines_generic_prefix ON medicines (lower(generic_name) text_pattern_ops);
CREATE INDEX ix_medicines_name_trgm ON medicines USING gin (lower(name) gin_trgm_ops);
CREATE INDEX ix_medicines_generic_trgm ON medicines USING gin (lower(generic_name) gin_trgm_ops);
CREATE INDEX ix_medicines_brand_trgm ON medicines USING gin (lower(brand_name) gin_trgm_ops);
CREATE INDEX ix_medicines_composition_trgm ON medicines USING gin (lower(composition) gin_trgm_ops);
CREATE INDEX ix_companies_name_trgm ON companies USING gin (lower(name) gin_trgm_ops);
CREATE INDEX ix_customers_name_trgm ON customers USING gin (lower(name) gin_trgm_ops);
