-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 012_posting_logic.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

CREATE FUNCTION fn_trg_journal_entries_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (SELECT COUNT(*) FROM journal_lines WHERE entry_id = OLD.id) < 2 THEN RAISE EXCEPTION 'A journal entry needs at least two lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = OLD.id),4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = OLD.id),4) THEN RAISE EXCEPTION 'Unbalanced journal entry: total debit must equal total credit' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.total_debit,4) <> round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = OLD.id),4) OR round(NEW.total_credit,4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = OLD.id),4) THEN RAISE EXCEPTION 'Stored journal totals do not match the lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM financial_years f WHERE f.id = NEW.financial_year_id AND NOT f.is_closed AND NEW.entry_date >= f.start_date AND NEW.entry_date <= f.end_date) THEN RAISE EXCEPTION 'Entry date is outside an open financial year' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE l.entry_id = OLD.id AND (NOT a.is_postable OR NOT a.is_active)) THEN RAISE EXCEPTION 'Journal uses a non-postable or inactive account' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (NEW.entry_kind = 'reversal') <> (NEW.reverses_entry_id IS NOT NULL) THEN RAISE EXCEPTION 'reverses_entry_id is required for (and only for) reversal entries' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_post BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_post();

CREATE FUNCTION fn_trg_journal_entries_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.entry_kind = 'reversal' THEN RAISE EXCEPTION 'A reversal entry cannot itself be reversed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries r WHERE r.reverses_entry_id = OLD.id AND r.status = 'posted' AND r.entry_kind = 'reversal' AND round(r.total_debit,4) = round(OLD.total_debit,4)) THEN RAISE EXCEPTION 'A posted mirror reversal entry is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_reverse BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_reverse();

CREATE FUNCTION fn_trg_sales_invoices_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'sales_invoices' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_invoice_items WHERE invoice_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.discount_amount,4) < round((SELECT COALESCE(SUM(discount_amount),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice discount is less than the sum of line discounts' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id AND (b.branch_id <> NEW.branch_id OR b.medicine_id <> i.medicine_id OR b.is_blocked OR b.expiry_date < NEW.invoice_date)) THEN RAISE EXCEPTION 'A batch is blocked, expired, or belongs to another branch/medicine' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id AND b.qty_on_hand < i.quantity + i.free_quantity) THEN RAISE EXCEPTION 'Insufficient batch stock (negative stock is not allowed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoice_items SET cost_price = (SELECT b.unit_cost FROM batches b WHERE b.id = sales_invoice_items.batch_id), gross_profit = round(quantity * unit_price - discount_amount - (SELECT b.unit_cost FROM batches b WHERE b.id = sales_invoice_items.batch_id) * (quantity + free_quantity), 4) WHERE invoice_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, i.medicine_id, 'sale', -(i.quantity + i.free_quantity), b.unit_cost, NEW.invoice_date, 'sales_invoices', OLD.id, i.id, NEW.posted_by FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_post BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_post();

CREATE FUNCTION fn_trg_purchase_invoices_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'purchase_invoices' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_invoice_items WHERE invoice_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.additional_costs,4) <> round((SELECT COALESCE(SUM(additional_cost),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Additional costs do not match the lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.discount_amount,4) < round((SELECT COALESCE(SUM(discount_amount),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice discount is less than the sum of line discounts' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id AND i.expiry_date < NEW.invoice_date) THEN RAISE EXCEPTION 'Cannot receive already-expired stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO batches (branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, qty_on_hand, supplier_id) SELECT NEW.branch_id, i.medicine_id, i.batch_no, i.mfg_date, i.expiry_date, i.landed_unit_cost, 0, NEW.supplier_id FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id AND NOT EXISTS (SELECT 1 FROM batches b WHERE b.branch_id = NEW.branch_id AND b.medicine_id = i.medicine_id AND b.batch_no = i.batch_no AND b.expiry_date = i.expiry_date);
    UPDATE batches SET unit_cost = round((batches.qty_on_hand * batches.unit_cost + (i.quantity + i.free_quantity) * i.landed_unit_cost) / (batches.qty_on_hand + i.quantity + i.free_quantity), 4) FROM purchase_invoice_items AS i WHERE i.invoice_id = OLD.id AND batches.branch_id = NEW.branch_id AND batches.medicine_id = i.medicine_id AND batches.batch_no = i.batch_no AND batches.expiry_date = i.expiry_date;
    UPDATE purchase_invoice_items SET batch_id = (SELECT b.id FROM batches b WHERE b.branch_id = NEW.branch_id AND b.medicine_id = purchase_invoice_items.medicine_id AND b.batch_no = purchase_invoice_items.batch_no AND b.expiry_date = purchase_invoice_items.expiry_date) WHERE invoice_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, i.medicine_id, 'purchase', i.quantity + i.free_quantity, i.landed_unit_cost, NEW.invoice_date, 'purchase_invoices', OLD.id, i.id, NEW.posted_by FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_post BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_post();

CREATE FUNCTION fn_trg_sales_returns_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'sales_returns' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_return_items WHERE return_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_invoices o WHERE o.id = NEW.original_invoice_id AND o.status = 'posted') THEN RAISE EXCEPTION 'The original sales invoice must be posted' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_return_items r JOIN sales_invoice_items o ON o.id = r.original_item_id WHERE r.return_id = OLD.id AND (o.invoice_id <> NEW.original_invoice_id OR o.batch_id IS DISTINCT FROM r.batch_id OR r.quantity + COALESCE((SELECT SUM(r2.quantity) FROM sales_return_items r2 JOIN sales_returns h ON h.id = r2.return_id WHERE r2.original_item_id = r.original_item_id AND h.status = 'posted' AND h.id <> OLD.id),0) > o.quantity)) THEN RAISE EXCEPTION 'Return quantity exceeds the quantity sold (or wrong invoice/batch)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM sales_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM sales_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_return_items SET cost_price = (SELECT o.cost_price FROM sales_invoice_items o WHERE o.id = sales_return_items.original_item_id) WHERE return_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, o.medicine_id, 'sales_return', i.quantity, i.cost_price, NEW.return_date, 'sales_returns', OLD.id, i.id, NEW.posted_by FROM sales_return_items i JOIN sales_invoice_items o ON o.id = i.original_item_id WHERE i.return_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_post BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_post();

CREATE FUNCTION fn_trg_purchase_returns_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'purchase_returns' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_return_items WHERE return_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_invoices o WHERE o.id = NEW.original_invoice_id AND o.status = 'posted') THEN RAISE EXCEPTION 'The original purchase invoice must be posted' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_return_items r JOIN purchase_invoice_items o ON o.id = r.original_item_id WHERE r.return_id = OLD.id AND (o.invoice_id <> NEW.original_invoice_id OR o.batch_id IS DISTINCT FROM r.batch_id OR r.quantity + COALESCE((SELECT SUM(r2.quantity) FROM purchase_return_items r2 JOIN purchase_returns h ON h.id = r2.return_id WHERE r2.original_item_id = r.original_item_id AND h.status = 'posted' AND h.id <> OLD.id),0) > o.quantity)) THEN RAISE EXCEPTION 'Return quantity exceeds the quantity purchased (or wrong invoice/batch)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_return_items r JOIN batches b ON b.id = r.batch_id WHERE r.return_id = OLD.id AND b.qty_on_hand < r.quantity) THEN RAISE EXCEPTION 'Insufficient batch stock to return to the supplier' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM purchase_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM purchase_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE purchase_return_items SET cost_price = (SELECT o.landed_unit_cost FROM purchase_invoice_items o WHERE o.id = purchase_return_items.original_item_id) WHERE return_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, o.medicine_id, 'purchase_return', -i.quantity, i.cost_price, NEW.return_date, 'purchase_returns', OLD.id, i.id, NEW.posted_by FROM purchase_return_items i JOIN purchase_invoice_items o ON o.id = i.original_item_id WHERE i.return_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_post BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_post();

CREATE FUNCTION fn_trg_stock_adjustments_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_adjustment_items i JOIN batches b ON b.id = i.batch_id WHERE i.adjustment_id = OLD.id AND (b.branch_id <> NEW.branch_id OR b.qty_on_hand + i.quantity_change < 0)) THEN RAISE EXCEPTION 'Adjustment would make batch stock negative or uses another branch''s batch' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NEW.adj_type IN ('damaged','expired') AND EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id AND quantity_change > 0) THEN RAISE EXCEPTION 'Damaged/expired adjustments must reduce stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id AND round(quantity_change * unit_cost,4) <> 0) AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'stock_adjustments' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry is required for adjustments with a monetary value' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, b.medicine_id, CASE WHEN NEW.adj_type = 'damaged' THEN 'damaged' WHEN NEW.adj_type = 'expired' THEN 'expired' WHEN NEW.adj_type = 'opening' THEN 'opening' WHEN NEW.adj_type = 'reconciliation' THEN 'count_variance' WHEN i.quantity_change > 0 THEN 'adjustment_in' ELSE 'adjustment_out' END, i.quantity_change, i.unit_cost, NEW.adj_date, 'stock_adjustments', OLD.id, i.id, NEW.posted_by FROM stock_adjustment_items i JOIN batches b ON b.id = i.batch_id WHERE i.adjustment_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_post BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_post();

CREATE FUNCTION fn_trg_stock_transfers_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM stock_transfer_items WHERE transfer_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_transfer_items i JOIN batches b ON b.id = i.batch_id WHERE i.transfer_id = OLD.id AND (b.branch_id <> NEW.from_branch_id OR b.is_blocked OR b.qty_on_hand < i.quantity)) THEN RAISE EXCEPTION 'Transfer batch is blocked, in another branch, or has insufficient stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO batches (branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, qty_on_hand, supplier_id, wholesale_price, retail_price) SELECT NEW.to_branch_id, s.medicine_id, s.batch_no, s.mfg_date, s.expiry_date, s.unit_cost, 0, s.supplier_id, s.wholesale_price, s.retail_price FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id AND NOT EXISTS (SELECT 1 FROM batches d WHERE d.branch_id = NEW.to_branch_id AND d.medicine_id = s.medicine_id AND d.batch_no = s.batch_no AND d.expiry_date = s.expiry_date);
    UPDATE batches SET unit_cost = round((batches.qty_on_hand * batches.unit_cost + i.quantity * s.unit_cost) / (batches.qty_on_hand + i.quantity), 4) FROM stock_transfer_items AS i JOIN batches AS s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id AND batches.branch_id = NEW.to_branch_id AND batches.medicine_id = s.medicine_id AND batches.batch_no = s.batch_no AND batches.expiry_date = s.expiry_date;
    UPDATE stock_transfer_items SET dest_batch_id = (SELECT d.id FROM batches d JOIN batches s ON s.id = stock_transfer_items.batch_id WHERE d.branch_id = NEW.to_branch_id AND d.medicine_id = s.medicine_id AND d.batch_no = s.batch_no AND d.expiry_date = s.expiry_date) WHERE transfer_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.from_branch_id, i.batch_id, s.medicine_id, 'transfer_out', -i.quantity, s.unit_cost, NEW.transfer_date, 'stock_transfers', OLD.id, i.id, NEW.posted_by FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.to_branch_id, i.dest_batch_id, s.medicine_id, 'transfer_in', i.quantity, s.unit_cost, NEW.transfer_date, 'stock_transfers', OLD.id, i.id, NEW.posted_by FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_post BEFORE UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_post();

CREATE FUNCTION fn_trg_vouchers_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'vouchers' AND j.source_id = OLD.id AND round(j.total_debit,4) = round(NEW.amount * NEW.exchange_rate,4)) THEN RAISE EXCEPTION 'A posted journal entry equal to the voucher amount is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (SELECT COALESCE(SUM(amount),0) FROM payment_allocations WHERE voucher_id = OLD.id) > NEW.amount THEN RAISE EXCEPTION 'Allocations exceed the voucher amount' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a LEFT JOIN sales_invoices s ON s.id = a.sales_invoice_id LEFT JOIN purchase_invoices p ON p.id = a.purchase_invoice_id WHERE a.voucher_id = OLD.id AND ((a.sales_invoice_id IS NOT NULL AND (NEW.voucher_type <> 'customer_receipt' OR s.status <> 'posted' OR s.customer_id IS DISTINCT FROM NEW.customer_id OR a.amount > s.total - s.paid_amount)) OR (a.purchase_invoice_id IS NOT NULL AND (NEW.voucher_type <> 'supplier_payment' OR p.status <> 'posted' OR p.supplier_id IS DISTINCT FROM NEW.supplier_id OR a.amount > p.total - p.paid_amount)))) THEN RAISE EXCEPTION 'Invalid allocation (wrong party, unposted invoice, or amount above the outstanding balance)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoices SET paid_amount = sales_invoices.paid_amount + x.amt, payment_status = CASE WHEN sales_invoices.paid_amount + x.amt >= sales_invoices.total THEN 'paid' ELSE 'partial' END FROM (SELECT sales_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND sales_invoice_id IS NOT NULL GROUP BY sales_invoice_id) AS x WHERE sales_invoices.id = x.iid;
    UPDATE purchase_invoices SET paid_amount = purchase_invoices.paid_amount + x.amt, payment_status = CASE WHEN purchase_invoices.paid_amount + x.amt >= purchase_invoices.total THEN 'paid' ELSE 'partial' END FROM (SELECT purchase_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND purchase_invoice_id IS NOT NULL GROUP BY purchase_invoice_id) AS x WHERE purchase_invoices.id = x.iid;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_post BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_post();

CREATE FUNCTION fn_trg_vouchers_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoices SET paid_amount = sales_invoices.paid_amount - x.amt, payment_status = CASE WHEN sales_invoices.paid_amount - x.amt <= 0 THEN 'unpaid' ELSE 'partial' END FROM (SELECT sales_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND sales_invoice_id IS NOT NULL GROUP BY sales_invoice_id) AS x WHERE sales_invoices.id = x.iid;
    UPDATE purchase_invoices SET paid_amount = purchase_invoices.paid_amount - x.amt, payment_status = CASE WHEN purchase_invoices.paid_amount - x.amt <= 0 THEN 'unpaid' ELSE 'partial' END FROM (SELECT purchase_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND purchase_invoice_id IS NOT NULL GROUP BY purchase_invoice_id) AS x WHERE purchase_invoices.id = x.iid;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_reverse BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_reverse();

CREATE FUNCTION fn_trg_sales_invoices_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_returns r WHERE r.original_invoice_id = OLD.id AND r.status = 'posted') THEN RAISE EXCEPTION 'Reverse the posted returns of this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a JOIN vouchers v ON v.id = a.voucher_id WHERE a.sales_invoice_id = OLD.id AND v.status = 'posted') THEN RAISE EXCEPTION 'Reverse the receipts allocated to this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'sales_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'sales_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_reverse BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_reverse();

CREATE FUNCTION fn_trg_purchase_invoices_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_returns r WHERE r.original_invoice_id = OLD.id AND r.status = 'posted') THEN RAISE EXCEPTION 'Reverse the posted returns of this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a JOIN vouchers v ON v.id = a.voucher_id WHERE a.purchase_invoice_id = OLD.id AND v.status = 'posted') THEN RAISE EXCEPTION 'Reverse the payments allocated to this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'purchase_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'purchase_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_reverse BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_reverse();

CREATE FUNCTION fn_trg_sales_returns_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'sales_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'sales_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_reverse BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_reverse();

CREATE FUNCTION fn_trg_purchase_returns_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'purchase_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'purchase_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_reverse BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_reverse();

CREATE FUNCTION fn_trg_stock_adjustments_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'stock_adjustments' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'stock_adjustments' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_reverse BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_reverse();
