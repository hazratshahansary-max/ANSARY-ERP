-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 001_core.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- currencies: Supported currencies; exactly one base currency (AFN).
CREATE TABLE currencies (
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    symbol text NOT NULL,
    decimals integer NOT NULL DEFAULT 2,
    is_base boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_currencies PRIMARY KEY (code),
    CONSTRAINT ck_currencies_1 CHECK (length(code) = 3),
    CONSTRAINT ck_currencies_2 CHECK (decimals BETWEEN 0 AND 4),
    CONSTRAINT ck_currencies_3 CHECK (version >= 1)
);
CREATE UNIQUE INDEX ux_currencies_1 ON currencies (is_base) WHERE is_base;

-- exchange_rates: Exchange rate history (1 unit of from_currency = rate units of to_currency).
CREATE TABLE exchange_rates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    from_currency text NOT NULL,
    to_currency text NOT NULL,
    rate numeric(18,8) NOT NULL,
    effective_date date NOT NULL,
    source text NOT NULL DEFAULT 'manual',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_exchange_rates PRIMARY KEY (id),
    CONSTRAINT uq_exchange_rates_1 UNIQUE (from_currency, to_currency, effective_date),
    CONSTRAINT ck_exchange_rates_1 CHECK (rate > 0),
    CONSTRAINT ck_exchange_rates_2 CHECK (version >= 1),
    CONSTRAINT ck_exchange_rates_3 CHECK (from_currency <> to_currency),
    CONSTRAINT fk_exchange_rates_from_currency FOREIGN KEY (from_currency) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_exchange_rates_to_currency FOREIGN KEY (to_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_exchange_rates_to_currency ON exchange_rates (to_currency);

-- branches: Business branches.
CREATE TABLE branches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    address text,
    phone text,
    email text,
    is_head_office boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_branches PRIMARY KEY (id),
    CONSTRAINT uq_branches_1 UNIQUE (code),
    CONSTRAINT ck_branches_1 CHECK (version >= 1)
);

-- company_profile: Single-row company profile used on invoices and reports.
CREATE TABLE company_profile (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    singleton integer NOT NULL DEFAULT 1,
    name text NOT NULL,
    name_ps text,
    tagline text,
    logo_path text,
    address text,
    phone text,
    email text,
    website text,
    tax_number text,
    license_number text,
    base_currency text NOT NULL DEFAULT 'AFN',
    date_format text NOT NULL DEFAULT 'YYYY-MM-DD',
    language text NOT NULL DEFAULT 'en',
    invoice_footer text,
    invoice_save_dir text,
    developer text NOT NULL DEFAULT 'Hazrat Shah Ansary',
    brand text NOT NULL DEFAULT 'ANSARY DATABASES',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_company_profile PRIMARY KEY (id),
    CONSTRAINT uq_company_profile_1 UNIQUE (singleton),
    CONSTRAINT ck_company_profile_1 CHECK (singleton = 1),
    CONSTRAINT ck_company_profile_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_company_profile_3 CHECK (version >= 1),
    CONSTRAINT fk_company_profile_base_currency FOREIGN KEY (base_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_company_profile_base_currency ON company_profile (base_currency);

-- settings: Key/value configuration (global, per branch or per user).
CREATE TABLE settings (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    scope_type text NOT NULL DEFAULT 'global',
    scope_id text NOT NULL DEFAULT '',
    key text NOT NULL,
    value text,
    value_type text NOT NULL DEFAULT 'string',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_settings PRIMARY KEY (id),
    CONSTRAINT uq_settings_1 UNIQUE (scope_type, scope_id, key),
    CONSTRAINT ck_settings_1 CHECK (scope_type IN ('global','branch','user')),
    CONSTRAINT ck_settings_2 CHECK (value_type IN ('string','int','decimal','bool','json')),
    CONSTRAINT ck_settings_3 CHECK (version >= 1)
);

-- tax_rates: Tax configuration.
CREATE TABLE tax_rates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    rate_pct numeric(7,4) NOT NULL,
    is_default boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_tax_rates PRIMARY KEY (id),
    CONSTRAINT uq_tax_rates_1 UNIQUE (name),
    CONSTRAINT ck_tax_rates_1 CHECK (rate_pct >= 0 AND rate_pct <= 100),
    CONSTRAINT ck_tax_rates_2 CHECK (version >= 1)
);

-- invoice_templates: Customisable invoice/label templates (A4, thermal).
CREATE TABLE invoice_templates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    doc_type text NOT NULL,
    paper text NOT NULL,
    config jsonb NOT NULL DEFAULT '{}',
    is_default boolean NOT NULL DEFAULT FALSE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_invoice_templates PRIMARY KEY (id),
    CONSTRAINT uq_invoice_templates_1 UNIQUE (name),
    CONSTRAINT ck_invoice_templates_1 CHECK (doc_type IN ('sales_invoice','purchase_invoice','receipt','label','statement')),
    CONSTRAINT ck_invoice_templates_2 CHECK (paper IN ('A4','A5','thermal80','thermal58','label')),
    CONSTRAINT ck_invoice_templates_3 CHECK (version >= 1)
);
