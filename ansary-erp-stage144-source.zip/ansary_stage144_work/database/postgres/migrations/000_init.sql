-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 000_init.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- Extensions and helpers required by every later migration.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- TRUE only while the sync service is applying data received from another device/server.
-- Set per transaction by the sync service:  SET LOCAL ansary.applying_remote = 'on';
CREATE FUNCTION ansary_remote() RETURNS boolean LANGUAGE sql STABLE AS
$$ SELECT COALESCE(current_setting('ansary.applying_remote', true), 'off') = 'on' $$;
