-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 009c_due_reminder_history.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- due_reminder_history: Append-only manual customer due-reminder history; records contact attempts but never sends messages.
CREATE TABLE IF NOT EXISTS due_reminder_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    sales_invoice_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    channel text NOT NULL,
    outcome text NOT NULL DEFAULT 'recorded',
    notes text,
    reminded_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_due_reminder_history PRIMARY KEY (id),
    CONSTRAINT ck_due_reminder_history_1 CHECK (channel IN ('phone','sms','email','whatsapp','in_person')),
    CONSTRAINT ck_due_reminder_history_2 CHECK (outcome IN ('recorded','sent','failed')),
    CONSTRAINT fk_due_reminder_history_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_1 ON due_reminder_history (branch_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_2 ON due_reminder_history (sales_invoice_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_customer_id ON due_reminder_history (customer_id);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_created_by ON due_reminder_history (created_by);
