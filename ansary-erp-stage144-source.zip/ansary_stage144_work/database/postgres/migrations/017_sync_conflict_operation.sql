-- Stage 31: preserve the incoming operation for explicit conflict resolution.
ALTER TABLE sync_conflicts ADD COLUMN server_op text NOT NULL DEFAULT 'update'
    CHECK (server_op IN ('insert','update','delete'));
