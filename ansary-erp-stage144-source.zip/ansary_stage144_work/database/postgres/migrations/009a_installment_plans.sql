-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 009a_installment_plans.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- installment_plans: Customer installment plans for posted credit sales invoices; one active plan record per invoice.
CREATE TABLE IF NOT EXISTS installment_plans (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    sales_invoice_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    plan_no text NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    principal_amount numeric(18,4) NOT NULL DEFAULT 0,
    installment_count integer NOT NULL,
    frequency text NOT NULL DEFAULT 'monthly',
    first_due_date date NOT NULL,
    status text NOT NULL DEFAULT 'active',
    notes text,
    created_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_plans PRIMARY KEY (id),
    CONSTRAINT uq_installment_plans_1 UNIQUE (sales_invoice_id),
    CONSTRAINT uq_installment_plans_2 UNIQUE (plan_no),
    CONSTRAINT ck_installment_plans_1 CHECK (principal_amount >= 0),
    CONSTRAINT ck_installment_plans_2 CHECK (installment_count BETWEEN 2 AND 60),
    CONSTRAINT ck_installment_plans_3 CHECK (frequency IN ('weekly','biweekly','monthly')),
    CONSTRAINT ck_installment_plans_4 CHECK (status IN ('active', 'completed', 'cancelled')),
    CONSTRAINT ck_installment_plans_5 CHECK (version >= 1),
    CONSTRAINT fk_installment_plans_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_installment_plans_1 ON installment_plans (customer_id, status);
CREATE INDEX IF NOT EXISTS ix_installment_plans_2 ON installment_plans (branch_id, first_due_date);
CREATE INDEX IF NOT EXISTS ix_installment_plans_currency_code ON installment_plans (currency_code);
CREATE INDEX IF NOT EXISTS ix_installment_plans_created_by ON installment_plans (created_by);

-- installment_schedule: Dated customer installment schedule; payment settlement integration is a later stage.
CREATE TABLE IF NOT EXISTS installment_schedule (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    plan_id uuid NOT NULL,
    installment_no integer NOT NULL,
    due_date date NOT NULL,
    amount numeric(18,4) NOT NULL DEFAULT 0,
    paid_amount numeric(18,4) NOT NULL DEFAULT 0,
    balance_due numeric(18,4) GENERATED ALWAYS AS (amount - paid_amount) STORED,
    status text NOT NULL DEFAULT 'scheduled',
    paid_at timestamptz,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_schedule PRIMARY KEY (id),
    CONSTRAINT uq_installment_schedule_1 UNIQUE (plan_id, installment_no),
    CONSTRAINT ck_installment_schedule_1 CHECK (installment_no >= 1),
    CONSTRAINT ck_installment_schedule_2 CHECK (amount >= 0),
    CONSTRAINT ck_installment_schedule_3 CHECK (paid_amount >= 0),
    CONSTRAINT ck_installment_schedule_4 CHECK (status IN ('scheduled', 'partial', 'paid', 'overdue', 'cancelled')),
    CONSTRAINT ck_installment_schedule_5 CHECK (version >= 1),
    CONSTRAINT ck_installment_schedule_6 CHECK (paid_amount <= amount),
    CONSTRAINT fk_installment_schedule_plan_id FOREIGN KEY (plan_id) REFERENCES installment_plans (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_schedule_1 ON installment_schedule (due_date, status);
