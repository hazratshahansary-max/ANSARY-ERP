-- Stage 29: authenticated device registration and branch-scoped sync event relay.
CREATE TABLE sync_events (
    seq bigserial PRIMARY KEY,
    event_uuid text NOT NULL UNIQUE,
    device_id uuid NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
    user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    branch_id uuid NOT NULL REFERENCES branches(id) ON DELETE RESTRICT,
    table_name text NOT NULL,
    row_id text NOT NULL,
    op text NOT NULL CHECK(op IN ('insert','update','delete')),
    base_version integer,
    payload jsonb NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_sync_events_branch_seq ON sync_events(branch_id,seq);
CREATE INDEX ix_sync_events_device ON sync_events(device_id,seq);
