-- ANSARY ERP  |  ANSARY DATABASES  |  postgres migration 009b_installment_payment_allocations.sql
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- installment_payment_allocations: Draft customer receipt allocations to individual installment schedule rows; applied when voucher posts.
CREATE TABLE IF NOT EXISTS installment_payment_allocations (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    voucher_id uuid NOT NULL,
    installment_schedule_id uuid NOT NULL,
    amount numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_payment_allocations PRIMARY KEY (id),
    CONSTRAINT uq_installment_payment_allocations_1 UNIQUE (voucher_id, installment_schedule_id),
    CONSTRAINT ck_installment_payment_allocations_1 CHECK (amount >= 0),
    CONSTRAINT ck_installment_payment_allocations_2 CHECK (version >= 1),
    CONSTRAINT ck_installment_payment_allocations_3 CHECK (amount > 0),
    CONSTRAINT fk_installment_payment_allocations_voucher_id FOREIGN KEY (voucher_id) REFERENCES vouchers (id) ON DELETE CASCADE,
    CONSTRAINT fk_installment_payment_allocations_installment_schedule_id FOREIGN KEY (installment_schedule_id) REFERENCES installment_schedule (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_payment_allocations_1 ON installment_payment_allocations (installment_schedule_id);
