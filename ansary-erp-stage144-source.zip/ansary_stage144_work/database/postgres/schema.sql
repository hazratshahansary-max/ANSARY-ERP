-- ANSARY ERP  |  ANSARY DATABASES  |  postgres full schema (all migrations concatenated)
-- GENERATED FILE - do not edit by hand. Edit tools/schema/*.py and run: python tools/schema/build.py

-- Extensions and helpers required by every later migration.
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- TRUE only while the sync service is applying data received from another device/server.
-- Set per transaction by the sync service:  SET LOCAL ansary.applying_remote = 'on';
CREATE FUNCTION ansary_remote() RETURNS boolean LANGUAGE sql STABLE AS
$$ SELECT COALESCE(current_setting('ansary.applying_remote', true), 'off') = 'on' $$;

-- currencies: Supported currencies; exactly one base currency (AFN).
CREATE TABLE currencies (
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    symbol text NOT NULL,
    decimals integer NOT NULL DEFAULT 2,
    is_base boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_currencies PRIMARY KEY (code),
    CONSTRAINT ck_currencies_1 CHECK (length(code) = 3),
    CONSTRAINT ck_currencies_2 CHECK (decimals BETWEEN 0 AND 4),
    CONSTRAINT ck_currencies_3 CHECK (version >= 1)
);
CREATE UNIQUE INDEX ux_currencies_1 ON currencies (is_base) WHERE is_base;

-- exchange_rates: Exchange rate history (1 unit of from_currency = rate units of to_currency).
CREATE TABLE exchange_rates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    from_currency text NOT NULL,
    to_currency text NOT NULL,
    rate numeric(18,8) NOT NULL,
    effective_date date NOT NULL,
    source text NOT NULL DEFAULT 'manual',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_exchange_rates PRIMARY KEY (id),
    CONSTRAINT uq_exchange_rates_1 UNIQUE (from_currency, to_currency, effective_date),
    CONSTRAINT ck_exchange_rates_1 CHECK (rate > 0),
    CONSTRAINT ck_exchange_rates_2 CHECK (version >= 1),
    CONSTRAINT ck_exchange_rates_3 CHECK (from_currency <> to_currency),
    CONSTRAINT fk_exchange_rates_from_currency FOREIGN KEY (from_currency) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_exchange_rates_to_currency FOREIGN KEY (to_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_exchange_rates_to_currency ON exchange_rates (to_currency);

-- branches: Business branches.
CREATE TABLE branches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    address text,
    phone text,
    email text,
    is_head_office boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_branches PRIMARY KEY (id),
    CONSTRAINT uq_branches_1 UNIQUE (code),
    CONSTRAINT ck_branches_1 CHECK (version >= 1)
);

-- company_profile: Single-row company profile used on invoices and reports.
CREATE TABLE company_profile (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    singleton integer NOT NULL DEFAULT 1,
    name text NOT NULL,
    name_ps text,
    tagline text,
    logo_path text,
    address text,
    phone text,
    email text,
    website text,
    tax_number text,
    license_number text,
    base_currency text NOT NULL DEFAULT 'AFN',
    date_format text NOT NULL DEFAULT 'YYYY-MM-DD',
    language text NOT NULL DEFAULT 'en',
    invoice_footer text,
    invoice_save_dir text,
    developer text NOT NULL DEFAULT 'Hazrat Shah Ansary',
    brand text NOT NULL DEFAULT 'ANSARY DATABASES',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_company_profile PRIMARY KEY (id),
    CONSTRAINT uq_company_profile_1 UNIQUE (singleton),
    CONSTRAINT ck_company_profile_1 CHECK (singleton = 1),
    CONSTRAINT ck_company_profile_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_company_profile_3 CHECK (version >= 1),
    CONSTRAINT fk_company_profile_base_currency FOREIGN KEY (base_currency) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_company_profile_base_currency ON company_profile (base_currency);

-- settings: Key/value configuration (global, per branch or per user).
CREATE TABLE settings (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    scope_type text NOT NULL DEFAULT 'global',
    scope_id text NOT NULL DEFAULT '',
    key text NOT NULL,
    value text,
    value_type text NOT NULL DEFAULT 'string',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_settings PRIMARY KEY (id),
    CONSTRAINT uq_settings_1 UNIQUE (scope_type, scope_id, key),
    CONSTRAINT ck_settings_1 CHECK (scope_type IN ('global','branch','user')),
    CONSTRAINT ck_settings_2 CHECK (value_type IN ('string','int','decimal','bool','json')),
    CONSTRAINT ck_settings_3 CHECK (version >= 1)
);

-- tax_rates: Tax configuration.
CREATE TABLE tax_rates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    rate_pct numeric(7,4) NOT NULL,
    is_default boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_tax_rates PRIMARY KEY (id),
    CONSTRAINT uq_tax_rates_1 UNIQUE (name),
    CONSTRAINT ck_tax_rates_1 CHECK (rate_pct >= 0 AND rate_pct <= 100),
    CONSTRAINT ck_tax_rates_2 CHECK (version >= 1)
);

-- invoice_templates: Customisable invoice/label templates (A4, thermal).
CREATE TABLE invoice_templates (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    doc_type text NOT NULL,
    paper text NOT NULL,
    config jsonb NOT NULL DEFAULT '{}',
    is_default boolean NOT NULL DEFAULT FALSE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_invoice_templates PRIMARY KEY (id),
    CONSTRAINT uq_invoice_templates_1 UNIQUE (name),
    CONSTRAINT ck_invoice_templates_1 CHECK (doc_type IN ('sales_invoice','purchase_invoice','receipt','label','statement')),
    CONSTRAINT ck_invoice_templates_2 CHECK (paper IN ('A4','A5','thermal80','thermal58','label')),
    CONSTRAINT ck_invoice_templates_3 CHECK (version >= 1)
);

-- roles: Role definitions (8 built-in roles).
CREATE TABLE roles (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    description text,
    is_system boolean NOT NULL DEFAULT FALSE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_roles PRIMARY KEY (id),
    CONSTRAINT uq_roles_1 UNIQUE (code),
    CONSTRAINT ck_roles_1 CHECK (version >= 1)
);

-- permissions: Permission catalogue (module.action).
CREATE TABLE permissions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    module text NOT NULL,
    action text NOT NULL,
    description text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_permissions PRIMARY KEY (id),
    CONSTRAINT uq_permissions_1 UNIQUE (module, action),
    CONSTRAINT uq_permissions_2 UNIQUE (code),
    CONSTRAINT ck_permissions_1 CHECK (version >= 1)
);

-- role_permissions: Role to permission grants.
CREATE TABLE role_permissions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_role_permissions PRIMARY KEY (id),
    CONSTRAINT uq_role_permissions_1 UNIQUE (role_id, permission_id),
    CONSTRAINT ck_role_permissions_1 CHECK (version >= 1),
    CONSTRAINT fk_role_permissions_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_role_permissions_permission_id ON role_permissions (permission_id);

-- users: User accounts (password stored only as a salted hash).
CREATE TABLE users (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    username text NOT NULL,
    password_hash text NOT NULL,
    password_algo text NOT NULL DEFAULT 'argon2id',
    full_name text NOT NULL,
    email text,
    phone text,
    role_id uuid NOT NULL,
    default_branch_id uuid,
    language text NOT NULL DEFAULT 'en',
    is_active boolean NOT NULL DEFAULT TRUE,
    must_change_password boolean NOT NULL DEFAULT TRUE,
    failed_attempts integer NOT NULL DEFAULT 0,
    locked_until timestamptz,
    last_login_at timestamptz,
    password_changed_at timestamptz,
    session_timeout_minutes integer NOT NULL DEFAULT 30,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_users PRIMARY KEY (id),
    CONSTRAINT uq_users_1 UNIQUE (username),
    CONSTRAINT ck_users_1 CHECK (username = lower(username)),
    CONSTRAINT ck_users_2 CHECK (language IN ('en','ps')),
    CONSTRAINT ck_users_3 CHECK (failed_attempts >= 0),
    CONSTRAINT ck_users_4 CHECK (session_timeout_minutes >= 1),
    CONSTRAINT ck_users_5 CHECK (version >= 1),
    CONSTRAINT fk_users_role_id FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT fk_users_default_branch_id FOREIGN KEY (default_branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_users_role_id ON users (role_id);
CREATE INDEX ix_users_default_branch_id ON users (default_branch_id);

-- user_branches: Branches a user may access.
CREATE TABLE user_branches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_branches PRIMARY KEY (id),
    CONSTRAINT uq_user_branches_1 UNIQUE (user_id, branch_id),
    CONSTRAINT ck_user_branches_1 CHECK (version >= 1),
    CONSTRAINT fk_user_branches_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_branches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_branches_branch_id ON user_branches (branch_id);

-- user_permission_overrides: Per-user grant/deny on top of the role.
CREATE TABLE user_permission_overrides (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    granted boolean NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_user_permission_overrides PRIMARY KEY (id),
    CONSTRAINT uq_user_permission_overrides_1 UNIQUE (user_id, permission_id),
    CONSTRAINT ck_user_permission_overrides_1 CHECK (version >= 1),
    CONSTRAINT fk_user_permission_overrides_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_user_permission_overrides_permission_id FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);
CREATE INDEX ix_user_permission_overrides_permission_id ON user_permission_overrides (permission_id);

-- user_sessions: Active sessions (device-local, never synchronised).
CREATE TABLE user_sessions (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    device_id text,
    ip_address text,
    user_agent text,
    created_at timestamptz NOT NULL DEFAULT now(),
    last_seen_at timestamptz NOT NULL DEFAULT now(),
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    revoked_reason text,
    CONSTRAINT pk_user_sessions PRIMARY KEY (id),
    CONSTRAINT uq_user_sessions_1 UNIQUE (token_hash),
    CONSTRAINT fk_user_sessions_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_user_sessions_user_id ON user_sessions (user_id);

-- login_history: Every login attempt (append-only).
CREATE TABLE login_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid,
    username_attempted text NOT NULL,
    success boolean NOT NULL,
    failure_reason text,
    ip_address text,
    user_agent text,
    device_id text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_login_history PRIMARY KEY (id),
    CONSTRAINT fk_login_history_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_login_history_user_id ON login_history (user_id);

-- audit_log: Immutable transaction audit trail.
CREATE TABLE audit_log (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid,
    branch_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    ref_no text,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_audit_log PRIMARY KEY (id),
    CONSTRAINT fk_audit_log_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_audit_log_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_audit_log_1 ON audit_log (entity_type, entity_id);
CREATE INDEX ix_audit_log_2 ON audit_log (created_at);
CREATE INDEX ix_audit_log_user_id ON audit_log (user_id);
CREATE INDEX ix_audit_log_branch_id ON audit_log (branch_id);

-- attachments: File attachments metadata (files live on disk/object store).
CREATE TABLE attachments (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    file_name text NOT NULL,
    mime_type text,
    storage_path text NOT NULL,
    sha256 text,
    size_bytes bigint,
    uploaded_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_attachments PRIMARY KEY (id),
    CONSTRAINT ck_attachments_1 CHECK (size_bytes IS NULL OR size_bytes >= 0),
    CONSTRAINT ck_attachments_2 CHECK (version >= 1),
    CONSTRAINT fk_attachments_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_attachments_1 ON attachments (entity_type, entity_id);
CREATE INDEX ix_attachments_uploaded_by ON attachments (uploaded_by);

-- categories: Medicine categories.
CREATE TABLE categories (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    name_ps text,
    parent_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_categories PRIMARY KEY (id),
    CONSTRAINT uq_categories_1 UNIQUE (name),
    CONSTRAINT ck_categories_1 CHECK (version >= 1),
    CONSTRAINT fk_categories_parent_id FOREIGN KEY (parent_id) REFERENCES categories (id) ON DELETE RESTRICT
);
CREATE INDEX ix_categories_parent_id ON categories (parent_id);

-- dosage_forms: Tablet, Syrup, Injection...
CREATE TABLE dosage_forms (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    name_ps text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_dosage_forms PRIMARY KEY (id),
    CONSTRAINT uq_dosage_forms_1 UNIQUE (name),
    CONSTRAINT ck_dosage_forms_1 CHECK (version >= 1)
);

-- units: Units of measure.
CREATE TABLE units (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_units PRIMARY KEY (id),
    CONSTRAINT uq_units_1 UNIQUE (code),
    CONSTRAINT ck_units_1 CHECK (version >= 1)
);

-- companies: Manufacturers / companies.
CREATE TABLE companies (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    kind text NOT NULL DEFAULT 'manufacturer',
    country text,
    address text,
    phone text,
    email text,
    contact_person text,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_companies PRIMARY KEY (id),
    CONSTRAINT uq_companies_1 UNIQUE (code),
    CONSTRAINT ck_companies_1 CHECK (kind IN ('manufacturer','distributor','both')),
    CONSTRAINT ck_companies_2 CHECK (version >= 1)
);

-- medicines: Medicine master (designed and tested for 100,000+ rows).
CREATE TABLE medicines (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    product_code text NOT NULL,
    barcode text,
    name text NOT NULL,
    name_ps text,
    generic_name text,
    brand_name text,
    manufacturer_id uuid,
    company_id uuid,
    category_id uuid,
    composition text,
    strength text NOT NULL DEFAULT '',
    dosage_form_id uuid,
    packing text NOT NULL DEFAULT '',
    unit_id uuid,
    box_quantity numeric(14,3) NOT NULL DEFAULT 1,
    purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    retail_price numeric(18,4) NOT NULL DEFAULT 0,
    min_stock numeric(14,3) NOT NULL DEFAULT 0,
    max_stock numeric(14,3) NOT NULL DEFAULT 0,
    rack_number text,
    country_of_origin text,
    registration_number text,
    image_attachment_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_medicines PRIMARY KEY (id),
    CONSTRAINT uq_medicines_1 UNIQUE (product_code),
    CONSTRAINT ck_medicines_1 CHECK (box_quantity > 0),
    CONSTRAINT ck_medicines_2 CHECK (purchase_price >= 0),
    CONSTRAINT ck_medicines_3 CHECK (wholesale_price >= 0),
    CONSTRAINT ck_medicines_4 CHECK (retail_price >= 0),
    CONSTRAINT ck_medicines_5 CHECK (min_stock >= 0),
    CONSTRAINT ck_medicines_6 CHECK (max_stock >= 0),
    CONSTRAINT ck_medicines_7 CHECK (version >= 1),
    CONSTRAINT ck_medicines_8 CHECK (max_stock = 0 OR max_stock >= min_stock),
    CONSTRAINT fk_medicines_manufacturer_id FOREIGN KEY (manufacturer_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_company_id FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_category_id FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_dosage_form_id FOREIGN KEY (dosage_form_id) REFERENCES dosage_forms (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_unit_id FOREIGN KEY (unit_id) REFERENCES units (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicines_image_attachment_id FOREIGN KEY (image_attachment_id) REFERENCES attachments (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_medicines_1 ON medicines (barcode) WHERE barcode IS NOT NULL AND deleted_at IS NULL;
CREATE INDEX ix_medicines_2 ON medicines (barcode);
CREATE INDEX ix_medicines_3 ON medicines (lower(name));
CREATE INDEX ix_medicines_4 ON medicines (lower(generic_name));
CREATE INDEX ix_medicines_5 ON medicines (lower(brand_name));
CREATE INDEX ix_medicines_6 ON medicines (manufacturer_id, lower(name));
CREATE INDEX ix_medicines_7 ON medicines (category_id);
CREATE INDEX ix_medicines_8 ON medicines (is_active);
CREATE INDEX ix_medicines_company_id ON medicines (company_id);
CREATE INDEX ix_medicines_dosage_form_id ON medicines (dosage_form_id);
CREATE INDEX ix_medicines_unit_id ON medicines (unit_id);
CREATE INDEX ix_medicines_image_attachment_id ON medicines (image_attachment_id);

-- medicine_barcodes: Additional barcodes / formats per medicine.
CREATE TABLE medicine_barcodes (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    medicine_id uuid NOT NULL,
    barcode text NOT NULL,
    barcode_format text NOT NULL DEFAULT 'EAN13',
    is_primary boolean NOT NULL DEFAULT FALSE,
    pack_qty numeric(14,3) NOT NULL DEFAULT 1,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_medicine_barcodes PRIMARY KEY (id),
    CONSTRAINT uq_medicine_barcodes_1 UNIQUE (barcode),
    CONSTRAINT ck_medicine_barcodes_1 CHECK (barcode_format IN ('EAN13','EAN8','UPCA','CODE128','CODE39','QR','DATAMATRIX','OTHER')),
    CONSTRAINT ck_medicine_barcodes_2 CHECK (pack_qty > 0),
    CONSTRAINT ck_medicine_barcodes_3 CHECK (version >= 1),
    CONSTRAINT fk_medicine_barcodes_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE CASCADE
);
CREATE INDEX ix_medicine_barcodes_medicine_id ON medicine_barcodes (medicine_id);

-- medicine_price_history: Price changes (filled by trigger; append-only).
CREATE TABLE medicine_price_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    medicine_id uuid NOT NULL,
    old_purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    new_purchase_price numeric(18,4) NOT NULL DEFAULT 0,
    old_wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    new_wholesale_price numeric(18,4) NOT NULL DEFAULT 0,
    old_retail_price numeric(18,4) NOT NULL DEFAULT 0,
    new_retail_price numeric(18,4) NOT NULL DEFAULT 0,
    changed_by uuid,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_medicine_price_history PRIMARY KEY (id),
    CONSTRAINT ck_medicine_price_history_1 CHECK (old_purchase_price >= 0),
    CONSTRAINT ck_medicine_price_history_2 CHECK (new_purchase_price >= 0),
    CONSTRAINT ck_medicine_price_history_3 CHECK (old_wholesale_price >= 0),
    CONSTRAINT ck_medicine_price_history_4 CHECK (new_wholesale_price >= 0),
    CONSTRAINT ck_medicine_price_history_5 CHECK (old_retail_price >= 0),
    CONSTRAINT ck_medicine_price_history_6 CHECK (new_retail_price >= 0),
    CONSTRAINT fk_medicine_price_history_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_medicine_price_history_changed_by FOREIGN KEY (changed_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_medicine_price_history_1 ON medicine_price_history (medicine_id, created_at);
CREATE INDEX ix_medicine_price_history_changed_by ON medicine_price_history (changed_by);

-- customers: Customers (opening_balance > 0 means the customer owes us).
CREATE TABLE customers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    business_name text,
    phone text,
    address text,
    customer_type text NOT NULL DEFAULT 'retail',
    opening_balance numeric(18,4) NOT NULL DEFAULT 0,
    opening_balance_date date,
    credit_limit numeric(18,4) NOT NULL DEFAULT 0,
    contact_person text,
    notes text,
    currency_code text NOT NULL DEFAULT 'AFN',
    branch_id uuid,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_customers PRIMARY KEY (id),
    CONSTRAINT uq_customers_1 UNIQUE (code),
    CONSTRAINT ck_customers_1 CHECK (customer_type IN ('retail','wholesale')),
    CONSTRAINT ck_customers_2 CHECK (credit_limit >= 0),
    CONSTRAINT ck_customers_3 CHECK (version >= 1),
    CONSTRAINT fk_customers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_customers_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_customers_1 ON customers (lower(name));
CREATE INDEX ix_customers_2 ON customers (phone);
CREATE INDEX ix_customers_currency_code ON customers (currency_code);
CREATE INDEX ix_customers_branch_id ON customers (branch_id);

-- suppliers: Suppliers (opening_balance > 0 means we owe the supplier).
CREATE TABLE suppliers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    business_name text,
    company_id uuid,
    phone text,
    address text,
    opening_balance numeric(18,4) NOT NULL DEFAULT 0,
    opening_balance_date date,
    contact_person text,
    notes text,
    currency_code text NOT NULL DEFAULT 'AFN',
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    deleted_at timestamptz,
    CONSTRAINT pk_suppliers PRIMARY KEY (id),
    CONSTRAINT uq_suppliers_1 UNIQUE (code),
    CONSTRAINT ck_suppliers_1 CHECK (version >= 1),
    CONSTRAINT fk_suppliers_company_id FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE RESTRICT,
    CONSTRAINT fk_suppliers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_suppliers_1 ON suppliers (lower(name));
CREATE INDEX ix_suppliers_company_id ON suppliers (company_id);
CREATE INDEX ix_suppliers_currency_code ON suppliers (currency_code);

-- financial_years: Financial years; closed years reject postings.
CREATE TABLE financial_years (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    is_closed boolean NOT NULL DEFAULT FALSE,
    closed_at timestamptz,
    closed_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_financial_years PRIMARY KEY (id),
    CONSTRAINT uq_financial_years_1 UNIQUE (name),
    CONSTRAINT ck_financial_years_1 CHECK (version >= 1),
    CONSTRAINT ck_financial_years_2 CHECK (end_date > start_date),
    CONSTRAINT fk_financial_years_closed_by FOREIGN KEY (closed_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_financial_years_closed_by ON financial_years (closed_by);

-- number_sequences: Per branch/device/year document numbering (prevents offline number collisions).
CREATE TABLE number_sequences (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    doc_type text NOT NULL,
    branch_id uuid NOT NULL,
    financial_year_id uuid NOT NULL,
    device_code text NOT NULL DEFAULT '00',
    prefix text NOT NULL,
    padding integer NOT NULL DEFAULT 6,
    next_number bigint NOT NULL DEFAULT 1,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_number_sequences PRIMARY KEY (id),
    CONSTRAINT uq_number_sequences_1 UNIQUE (doc_type, branch_id, financial_year_id, device_code),
    CONSTRAINT ck_number_sequences_1 CHECK (padding BETWEEN 1 AND 12),
    CONSTRAINT ck_number_sequences_2 CHECK (next_number >= 1),
    CONSTRAINT ck_number_sequences_3 CHECK (version >= 1),
    CONSTRAINT fk_number_sequences_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_number_sequences_financial_year_id FOREIGN KEY (financial_year_id) REFERENCES financial_years (id) ON DELETE RESTRICT
);
CREATE INDEX ix_number_sequences_branch_id ON number_sequences (branch_id);
CREATE INDEX ix_number_sequences_financial_year_id ON number_sequences (financial_year_id);

-- accounts: Chart of accounts.
CREATE TABLE accounts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    name_ps text,
    account_type text NOT NULL,
    normal_side text NOT NULL,
    parent_id uuid,
    system_key text,
    is_postable boolean NOT NULL DEFAULT TRUE,
    is_system boolean NOT NULL DEFAULT FALSE,
    is_active boolean NOT NULL DEFAULT TRUE,
    cash_flow_category text NOT NULL DEFAULT 'none',
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_accounts PRIMARY KEY (id),
    CONSTRAINT uq_accounts_1 UNIQUE (code),
    CONSTRAINT ck_accounts_1 CHECK (account_type IN ('asset','liability','equity','income','expense')),
    CONSTRAINT ck_accounts_2 CHECK (normal_side IN ('debit','credit')),
    CONSTRAINT ck_accounts_3 CHECK (cash_flow_category IN ('operating','investing','financing','cash','none')),
    CONSTRAINT ck_accounts_4 CHECK (version >= 1),
    CONSTRAINT fk_accounts_parent_id FOREIGN KEY (parent_id) REFERENCES accounts (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_accounts_1 ON accounts (system_key) WHERE system_key IS NOT NULL;
CREATE INDEX ix_accounts_parent_id ON accounts (parent_id);

-- bank_accounts: Bank accounts mapped to ledger accounts (bankbook).
CREATE TABLE bank_accounts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid,
    account_id uuid NOT NULL,
    bank_name text NOT NULL,
    account_number text,
    currency_code text NOT NULL DEFAULT 'AFN',
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_bank_accounts PRIMARY KEY (id),
    CONSTRAINT uq_bank_accounts_1 UNIQUE (account_id),
    CONSTRAINT ck_bank_accounts_1 CHECK (version >= 1),
    CONSTRAINT fk_bank_accounts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_bank_accounts_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_bank_accounts_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT
);
CREATE INDEX ix_bank_accounts_branch_id ON bank_accounts (branch_id);
CREATE INDEX ix_bank_accounts_currency_code ON bank_accounts (currency_code);

-- expense_categories: Expense categories mapped to expense accounts.
CREATE TABLE expense_categories (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name text NOT NULL,
    name_ps text,
    account_id uuid NOT NULL,
    is_active boolean NOT NULL DEFAULT TRUE,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_expense_categories PRIMARY KEY (id),
    CONSTRAINT uq_expense_categories_1 UNIQUE (name),
    CONSTRAINT ck_expense_categories_1 CHECK (version >= 1),
    CONSTRAINT fk_expense_categories_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT
);
CREATE INDEX ix_expense_categories_account_id ON expense_categories (account_id);

-- journal_entries: Double-entry journal headers.
CREATE TABLE journal_entries (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    entry_no text NOT NULL,
    entry_date date NOT NULL,
    financial_year_id uuid NOT NULL,
    entry_kind text NOT NULL DEFAULT 'manual',
    source_type text,
    source_id uuid,
    description text,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    status text NOT NULL DEFAULT 'draft',
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    reverses_entry_id uuid,
    total_debit numeric(18,4) NOT NULL DEFAULT 0,
    total_credit numeric(18,4) NOT NULL DEFAULT 0,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_journal_entries PRIMARY KEY (id),
    CONSTRAINT uq_journal_entries_1 UNIQUE (entry_no),
    CONSTRAINT ck_journal_entries_1 CHECK (entry_kind IN ('manual','sales','purchase','sales_return','purchase_return','receipt','payment','contra','expense','income','adjustment','opening','reversal','fx')),
    CONSTRAINT ck_journal_entries_2 CHECK (exchange_rate > 0),
    CONSTRAINT ck_journal_entries_3 CHECK (status IN ('draft', 'posted', 'reversed')),
    CONSTRAINT ck_journal_entries_4 CHECK (total_debit >= 0),
    CONSTRAINT ck_journal_entries_5 CHECK (total_credit >= 0),
    CONSTRAINT ck_journal_entries_6 CHECK (version >= 1),
    CONSTRAINT fk_journal_entries_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_financial_year_id FOREIGN KEY (financial_year_id) REFERENCES financial_years (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_entries_reverses_entry_id FOREIGN KEY (reverses_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_journal_entries_1 ON journal_entries (source_type, source_id, entry_kind) WHERE source_id IS NOT NULL;
CREATE INDEX ix_journal_entries_2 ON journal_entries (entry_date);
CREATE UNIQUE INDEX ux_journal_entries_3 ON journal_entries (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_journal_entries_branch_id ON journal_entries (branch_id);
CREATE INDEX ix_journal_entries_financial_year_id ON journal_entries (financial_year_id);
CREATE INDEX ix_journal_entries_currency_code ON journal_entries (currency_code);
CREATE INDEX ix_journal_entries_posted_by ON journal_entries (posted_by);
CREATE INDEX ix_journal_entries_reversed_by ON journal_entries (reversed_by);
CREATE INDEX ix_journal_entries_reverses_entry_id ON journal_entries (reverses_entry_id);

-- journal_lines: Journal lines; customer_id/supplier_id give the sub-ledgers.
CREATE TABLE journal_lines (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    entry_id uuid NOT NULL,
    line_no integer NOT NULL,
    account_id uuid NOT NULL,
    debit numeric(18,4) NOT NULL DEFAULT 0,
    credit numeric(18,4) NOT NULL DEFAULT 0,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    amount_fx numeric(18,4),
    customer_id uuid,
    supplier_id uuid,
    branch_id uuid,
    description text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_journal_lines PRIMARY KEY (id),
    CONSTRAINT uq_journal_lines_1 UNIQUE (entry_id, line_no),
    CONSTRAINT ck_journal_lines_1 CHECK (line_no >= 1),
    CONSTRAINT ck_journal_lines_2 CHECK (debit >= 0),
    CONSTRAINT ck_journal_lines_3 CHECK (credit >= 0),
    CONSTRAINT ck_journal_lines_4 CHECK (exchange_rate > 0),
    CONSTRAINT ck_journal_lines_5 CHECK (version >= 1),
    CONSTRAINT ck_journal_lines_6 CHECK ((debit = 0 OR credit = 0) AND (debit + credit) > 0),
    CONSTRAINT fk_journal_lines_entry_id FOREIGN KEY (entry_id) REFERENCES journal_entries (id) ON DELETE CASCADE,
    CONSTRAINT fk_journal_lines_account_id FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_journal_lines_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_journal_lines_1 ON journal_lines (account_id, entry_id);
CREATE INDEX ix_journal_lines_2 ON journal_lines (customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX ix_journal_lines_3 ON journal_lines (supplier_id) WHERE supplier_id IS NOT NULL;
CREATE INDEX ix_journal_lines_currency_code ON journal_lines (currency_code);
CREATE INDEX ix_journal_lines_branch_id ON journal_lines (branch_id);

-- batches: Batch-level stock. qty_on_hand is derived from stock_movements by trigger.
CREATE TABLE batches (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    batch_no text NOT NULL,
    mfg_date date,
    expiry_date date NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    qty_on_hand numeric(14,3) NOT NULL DEFAULT 0,
    wholesale_price numeric(18,4),
    retail_price numeric(18,4),
    supplier_id uuid,
    is_blocked boolean NOT NULL DEFAULT FALSE,
    block_reason text,
    last_movement_at timestamptz,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_batches PRIMARY KEY (id),
    CONSTRAINT uq_batches_1 UNIQUE (branch_id, medicine_id, batch_no, expiry_date),
    CONSTRAINT ck_batches_1 CHECK (unit_cost >= 0),
    CONSTRAINT ck_batches_2 CHECK (qty_on_hand >= 0),
    CONSTRAINT ck_batches_3 CHECK (wholesale_price IS NULL OR wholesale_price >= 0),
    CONSTRAINT ck_batches_4 CHECK (retail_price IS NULL OR retail_price >= 0),
    CONSTRAINT ck_batches_5 CHECK (version >= 1),
    CONSTRAINT ck_batches_6 CHECK (mfg_date IS NULL OR mfg_date < expiry_date),
    CONSTRAINT fk_batches_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_batches_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT
);
CREATE INDEX ix_batches_1 ON batches (expiry_date) WHERE qty_on_hand > 0;
CREATE INDEX ix_batches_2 ON batches (medicine_id, branch_id);
CREATE INDEX ix_batches_supplier_id ON batches (supplier_id);

-- stock_movements: Immutable stock ledger. Every stock change is a row here.
CREATE TABLE stock_movements (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    medicine_id uuid NOT NULL,
    movement_type text NOT NULL,
    quantity_change numeric(14,3) NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    movement_date date NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    source_line_id uuid NOT NULL,
    user_id uuid,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_stock_movements PRIMARY KEY (id),
    CONSTRAINT uq_stock_movements_1 UNIQUE (source_type, source_line_id, movement_type, batch_id),
    CONSTRAINT ck_stock_movements_1 CHECK (movement_type IN ('purchase','sale','sales_return','purchase_return','adjustment_in','adjustment_out','transfer_in','transfer_out','damaged','expired','opening','count_variance','reversal')),
    CONSTRAINT ck_stock_movements_2 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_movements_3 CHECK (unit_cost >= 0),
    CONSTRAINT fk_stock_movements_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_movements_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_movements_1 ON stock_movements (batch_id, created_at);
CREATE INDEX ix_stock_movements_2 ON stock_movements (source_type, source_id);
CREATE INDEX ix_stock_movements_3 ON stock_movements (medicine_id, branch_id, movement_date);
CREATE INDEX ix_stock_movements_branch_id ON stock_movements (branch_id);
CREATE INDEX ix_stock_movements_user_id ON stock_movements (user_id);

-- stock_adjustments: Stock adjustments, damaged/expired write-offs, opening stock.
CREATE TABLE stock_adjustments (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    adj_no text NOT NULL,
    adj_date date NOT NULL,
    adj_type text NOT NULL,
    reason text,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustments PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustments_1 UNIQUE (adj_no),
    CONSTRAINT ck_stock_adjustments_1 CHECK (adj_type IN ('adjustment','damaged','expired','reconciliation','opening')),
    CONSTRAINT ck_stock_adjustments_2 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_stock_adjustments_3 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustments_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_adjustments_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_stock_adjustments_1 ON stock_adjustments (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_stock_adjustments_branch_id ON stock_adjustments (branch_id);
CREATE INDEX ix_stock_adjustments_posted_by ON stock_adjustments (posted_by);
CREATE INDEX ix_stock_adjustments_reversed_by ON stock_adjustments (reversed_by);
CREATE INDEX ix_stock_adjustments_journal_entry_id ON stock_adjustments (journal_entry_id);
CREATE INDEX ix_stock_adjustments_reversal_entry_id ON stock_adjustments (reversal_entry_id);

-- stock_adjustment_items: Adjustment lines.
CREATE TABLE stock_adjustment_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    adjustment_id uuid NOT NULL,
    line_no integer NOT NULL,
    batch_id uuid NOT NULL,
    quantity_change numeric(14,3) NOT NULL,
    unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_adjustment_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_adjustment_items_1 UNIQUE (adjustment_id, line_no),
    CONSTRAINT uq_stock_adjustment_items_2 UNIQUE (adjustment_id, batch_id),
    CONSTRAINT ck_stock_adjustment_items_1 CHECK (quantity_change <> 0),
    CONSTRAINT ck_stock_adjustment_items_2 CHECK (unit_cost >= 0),
    CONSTRAINT ck_stock_adjustment_items_3 CHECK (version >= 1),
    CONSTRAINT fk_stock_adjustment_items_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_adjustment_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_adjustment_items_batch_id ON stock_adjustment_items (batch_id);

-- stock_transfers: Branch-to-branch stock transfers.
CREATE TABLE stock_transfers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    transfer_no text NOT NULL,
    from_branch_id uuid NOT NULL,
    to_branch_id uuid NOT NULL,
    transfer_date date NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfers PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfers_1 UNIQUE (transfer_no),
    CONSTRAINT ck_stock_transfers_1 CHECK (status IN ('draft', 'posted', 'cancelled')),
    CONSTRAINT ck_stock_transfers_2 CHECK (version >= 1),
    CONSTRAINT ck_stock_transfers_3 CHECK (from_branch_id <> to_branch_id),
    CONSTRAINT fk_stock_transfers_from_branch_id FOREIGN KEY (from_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_to_branch_id FOREIGN KEY (to_branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfers_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfers_from_branch_id ON stock_transfers (from_branch_id);
CREATE INDEX ix_stock_transfers_to_branch_id ON stock_transfers (to_branch_id);
CREATE INDEX ix_stock_transfers_posted_by ON stock_transfers (posted_by);

-- stock_transfer_items: Transfer lines (dest_batch_id set at posting).
CREATE TABLE stock_transfer_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    transfer_id uuid NOT NULL,
    line_no integer NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    dest_batch_id uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_stock_transfer_items PRIMARY KEY (id),
    CONSTRAINT uq_stock_transfer_items_1 UNIQUE (transfer_id, line_no),
    CONSTRAINT uq_stock_transfer_items_2 UNIQUE (transfer_id, batch_id),
    CONSTRAINT ck_stock_transfer_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_stock_transfer_items_2 CHECK (version >= 1),
    CONSTRAINT fk_stock_transfer_items_transfer_id FOREIGN KEY (transfer_id) REFERENCES stock_transfers (id) ON DELETE CASCADE,
    CONSTRAINT fk_stock_transfer_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_stock_transfer_items_dest_batch_id FOREIGN KEY (dest_batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_stock_transfer_items_batch_id ON stock_transfer_items (batch_id);
CREATE INDEX ix_stock_transfer_items_dest_batch_id ON stock_transfer_items (dest_batch_id);

-- physical_counts: Physical stock verification sessions.
CREATE TABLE physical_counts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    count_no text NOT NULL,
    count_date date NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    adjustment_id uuid,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_counts PRIMARY KEY (id),
    CONSTRAINT uq_physical_counts_1 UNIQUE (count_no),
    CONSTRAINT ck_physical_counts_1 CHECK (status IN ('draft', 'in_progress', 'completed', 'reconciled', 'cancelled')),
    CONSTRAINT ck_physical_counts_2 CHECK (version >= 1),
    CONSTRAINT fk_physical_counts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_physical_counts_adjustment_id FOREIGN KEY (adjustment_id) REFERENCES stock_adjustments (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_counts_branch_id ON physical_counts (branch_id);
CREATE INDEX ix_physical_counts_adjustment_id ON physical_counts (adjustment_id);

-- physical_count_items: Counted vs system quantity per batch.
CREATE TABLE physical_count_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    count_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    system_qty numeric(14,3) NOT NULL DEFAULT 0,
    counted_qty numeric(14,3) NOT NULL DEFAULT 0,
    variance numeric(14,3) GENERATED ALWAYS AS (counted_qty - system_qty) STORED,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_physical_count_items PRIMARY KEY (id),
    CONSTRAINT uq_physical_count_items_1 UNIQUE (count_id, batch_id),
    CONSTRAINT ck_physical_count_items_1 CHECK (system_qty >= 0),
    CONSTRAINT ck_physical_count_items_2 CHECK (counted_qty >= 0),
    CONSTRAINT ck_physical_count_items_3 CHECK (version >= 1),
    CONSTRAINT fk_physical_count_items_count_id FOREIGN KEY (count_id) REFERENCES physical_counts (id) ON DELETE CASCADE,
    CONSTRAINT fk_physical_count_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_physical_count_items_batch_id ON physical_count_items (batch_id);

-- purchase_orders: Purchase orders.
CREATE TABLE purchase_orders (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    po_no text NOT NULL,
    supplier_id uuid NOT NULL,
    po_date date NOT NULL,
    expected_date date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    status text NOT NULL DEFAULT 'draft',
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    notes text,
    created_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_orders PRIMARY KEY (id),
    CONSTRAINT uq_purchase_orders_1 UNIQUE (po_no),
    CONSTRAINT ck_purchase_orders_1 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_orders_2 CHECK (status IN ('draft', 'confirmed', 'partially_received', 'received', 'cancelled')),
    CONSTRAINT ck_purchase_orders_3 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_orders_4 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_orders_5 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_orders_6 CHECK (total >= 0),
    CONSTRAINT ck_purchase_orders_7 CHECK (version >= 1),
    CONSTRAINT fk_purchase_orders_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_orders_branch_id ON purchase_orders (branch_id);
CREATE INDEX ix_purchase_orders_supplier_id ON purchase_orders (supplier_id);
CREATE INDEX ix_purchase_orders_currency_code ON purchase_orders (currency_code);
CREATE INDEX ix_purchase_orders_created_by ON purchase_orders (created_by);

-- purchase_order_items: PO lines.
CREATE TABLE purchase_order_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    received_quantity numeric(14,3) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_order_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_order_items_1 UNIQUE (order_id, line_no),
    CONSTRAINT ck_purchase_order_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_order_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_purchase_order_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_order_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_purchase_order_items_5 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_purchase_order_items_6 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_order_items_7 CHECK (received_quantity >= 0),
    CONSTRAINT ck_purchase_order_items_8 CHECK (version >= 1),
    CONSTRAINT fk_purchase_order_items_order_id FOREIGN KEY (order_id) REFERENCES purchase_orders (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_order_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_order_items_medicine_id ON purchase_order_items (medicine_id);

-- goods_receipts: Goods receiving notes (do not move stock; the invoice does).
CREATE TABLE goods_receipts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    grn_no text NOT NULL,
    purchase_order_id uuid,
    supplier_id uuid NOT NULL,
    receipt_date date NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    received_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_goods_receipts PRIMARY KEY (id),
    CONSTRAINT uq_goods_receipts_1 UNIQUE (grn_no),
    CONSTRAINT ck_goods_receipts_1 CHECK (status IN ('draft', 'confirmed', 'cancelled')),
    CONSTRAINT ck_goods_receipts_2 CHECK (version >= 1),
    CONSTRAINT fk_goods_receipts_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_purchase_order_id FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipts_received_by FOREIGN KEY (received_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_goods_receipts_branch_id ON goods_receipts (branch_id);
CREATE INDEX ix_goods_receipts_purchase_order_id ON goods_receipts (purchase_order_id);
CREATE INDEX ix_goods_receipts_supplier_id ON goods_receipts (supplier_id);
CREATE INDEX ix_goods_receipts_received_by ON goods_receipts (received_by);

-- goods_receipt_items: GRN lines.
CREATE TABLE goods_receipt_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    receipt_id uuid NOT NULL,
    line_no integer NOT NULL,
    po_item_id uuid,
    medicine_id uuid NOT NULL,
    batch_no text NOT NULL,
    mfg_date date,
    expiry_date date NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_goods_receipt_items PRIMARY KEY (id),
    CONSTRAINT uq_goods_receipt_items_1 UNIQUE (receipt_id, line_no),
    CONSTRAINT ck_goods_receipt_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_goods_receipt_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_goods_receipt_items_3 CHECK (version >= 1),
    CONSTRAINT fk_goods_receipt_items_receipt_id FOREIGN KEY (receipt_id) REFERENCES goods_receipts (id) ON DELETE CASCADE,
    CONSTRAINT fk_goods_receipt_items_po_item_id FOREIGN KEY (po_item_id) REFERENCES purchase_order_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_goods_receipt_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_goods_receipt_items_po_item_id ON goods_receipt_items (po_item_id);
CREATE INDEX ix_goods_receipt_items_medicine_id ON goods_receipt_items (medicine_id);

-- purchase_invoices: Purchase invoices; posting adds stock.
CREATE TABLE purchase_invoices (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    invoice_no text NOT NULL,
    supplier_id uuid NOT NULL,
    supplier_invoice_no text NOT NULL,
    purchase_order_id uuid,
    goods_receipt_id uuid,
    invoice_date date NOT NULL,
    due_date date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    additional_costs numeric(18,4) NOT NULL DEFAULT 0,
    round_off numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    paid_amount numeric(18,4) NOT NULL DEFAULT 0,
    payment_status text NOT NULL DEFAULT 'unpaid',
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_invoices PRIMARY KEY (id),
    CONSTRAINT uq_purchase_invoices_1 UNIQUE (supplier_id, supplier_invoice_no),
    CONSTRAINT uq_purchase_invoices_2 UNIQUE (invoice_no),
    CONSTRAINT ck_purchase_invoices_1 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_invoices_2 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_invoices_3 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_invoices_4 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_invoices_5 CHECK (additional_costs >= 0),
    CONSTRAINT ck_purchase_invoices_6 CHECK (total >= 0),
    CONSTRAINT ck_purchase_invoices_7 CHECK (paid_amount >= 0),
    CONSTRAINT ck_purchase_invoices_8 CHECK (payment_status IN ('unpaid','partial','paid')),
    CONSTRAINT ck_purchase_invoices_9 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_purchase_invoices_10 CHECK (version >= 1),
    CONSTRAINT ck_purchase_invoices_11 CHECK (paid_amount <= total),
    CONSTRAINT ck_purchase_invoices_12 CHECK (round(total,4) = round(subtotal - discount_amount + tax_amount + additional_costs + round_off,4)),
    CONSTRAINT fk_purchase_invoices_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_purchase_order_id FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_goods_receipt_id FOREIGN KEY (goods_receipt_id) REFERENCES goods_receipts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoices_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_invoices_1 ON purchase_invoices (invoice_date);
CREATE UNIQUE INDEX ux_purchase_invoices_2 ON purchase_invoices (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_purchase_invoices_branch_id ON purchase_invoices (branch_id);
CREATE INDEX ix_purchase_invoices_purchase_order_id ON purchase_invoices (purchase_order_id);
CREATE INDEX ix_purchase_invoices_goods_receipt_id ON purchase_invoices (goods_receipt_id);
CREATE INDEX ix_purchase_invoices_currency_code ON purchase_invoices (currency_code);
CREATE INDEX ix_purchase_invoices_posted_by ON purchase_invoices (posted_by);
CREATE INDEX ix_purchase_invoices_reversed_by ON purchase_invoices (reversed_by);
CREATE INDEX ix_purchase_invoices_journal_entry_id ON purchase_invoices (journal_entry_id);
CREATE INDEX ix_purchase_invoices_reversal_entry_id ON purchase_invoices (reversal_entry_id);

-- purchase_invoice_items: Purchase lines with batch, expiry and landed cost.
CREATE TABLE purchase_invoice_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    invoice_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    batch_id uuid,
    batch_no text NOT NULL,
    mfg_date date,
    expiry_date date NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    additional_cost numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    landed_unit_cost numeric(18,4) NOT NULL DEFAULT 0,
    po_item_id uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_invoice_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_invoice_items_1 UNIQUE (invoice_id, line_no),
    CONSTRAINT uq_purchase_invoice_items_2 UNIQUE (invoice_id, medicine_id, batch_no, expiry_date),
    CONSTRAINT ck_purchase_invoice_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_invoice_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_purchase_invoice_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_invoice_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_purchase_invoice_items_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_purchase_invoice_items_6 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_purchase_invoice_items_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_invoice_items_8 CHECK (additional_cost >= 0),
    CONSTRAINT ck_purchase_invoice_items_9 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_invoice_items_10 CHECK (landed_unit_cost >= 0),
    CONSTRAINT ck_purchase_invoice_items_11 CHECK (version >= 1),
    CONSTRAINT ck_purchase_invoice_items_12 CHECK (mfg_date IS NULL OR mfg_date < expiry_date),
    CONSTRAINT ck_purchase_invoice_items_13 CHECK (round(line_total,4) = round(quantity * unit_price - discount_amount + tax_amount,4)),
    CONSTRAINT fk_purchase_invoice_items_invoice_id FOREIGN KEY (invoice_id) REFERENCES purchase_invoices (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_invoice_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoice_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_invoice_items_po_item_id FOREIGN KEY (po_item_id) REFERENCES purchase_order_items (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_invoice_items_medicine_id ON purchase_invoice_items (medicine_id);
CREATE INDEX ix_purchase_invoice_items_batch_id ON purchase_invoice_items (batch_id);
CREATE INDEX ix_purchase_invoice_items_po_item_id ON purchase_invoice_items (po_item_id);

-- purchase_returns: Purchase returns / supplier debit notes against an original invoice.
CREATE TABLE purchase_returns (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    return_no text NOT NULL,
    original_invoice_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    return_date date NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_returns PRIMARY KEY (id),
    CONSTRAINT uq_purchase_returns_1 UNIQUE (return_no),
    CONSTRAINT ck_purchase_returns_1 CHECK (exchange_rate > 0),
    CONSTRAINT ck_purchase_returns_2 CHECK (subtotal >= 0),
    CONSTRAINT ck_purchase_returns_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_returns_4 CHECK (total >= 0),
    CONSTRAINT ck_purchase_returns_5 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_purchase_returns_6 CHECK (version >= 1),
    CONSTRAINT ck_purchase_returns_7 CHECK (round(total,4) = round(subtotal + tax_amount,4)),
    CONSTRAINT fk_purchase_returns_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_original_invoice_id FOREIGN KEY (original_invoice_id) REFERENCES purchase_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_returns_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_purchase_returns_1 ON purchase_returns (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_purchase_returns_branch_id ON purchase_returns (branch_id);
CREATE INDEX ix_purchase_returns_original_invoice_id ON purchase_returns (original_invoice_id);
CREATE INDEX ix_purchase_returns_supplier_id ON purchase_returns (supplier_id);
CREATE INDEX ix_purchase_returns_currency_code ON purchase_returns (currency_code);
CREATE INDEX ix_purchase_returns_posted_by ON purchase_returns (posted_by);
CREATE INDEX ix_purchase_returns_reversed_by ON purchase_returns (reversed_by);
CREATE INDEX ix_purchase_returns_journal_entry_id ON purchase_returns (journal_entry_id);
CREATE INDEX ix_purchase_returns_reversal_entry_id ON purchase_returns (reversal_entry_id);

-- purchase_return_items: Purchase return lines.
CREATE TABLE purchase_return_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    return_id uuid NOT NULL,
    line_no integer NOT NULL,
    original_item_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    cost_price numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_purchase_return_items PRIMARY KEY (id),
    CONSTRAINT uq_purchase_return_items_1 UNIQUE (return_id, line_no),
    CONSTRAINT uq_purchase_return_items_2 UNIQUE (return_id, original_item_id),
    CONSTRAINT ck_purchase_return_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_purchase_return_items_2 CHECK (unit_price >= 0),
    CONSTRAINT ck_purchase_return_items_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_purchase_return_items_4 CHECK (line_total >= 0),
    CONSTRAINT ck_purchase_return_items_5 CHECK (cost_price >= 0),
    CONSTRAINT ck_purchase_return_items_6 CHECK (version >= 1),
    CONSTRAINT ck_purchase_return_items_7 CHECK (round(line_total,4) = round(quantity * unit_price + tax_amount,4)),
    CONSTRAINT fk_purchase_return_items_return_id FOREIGN KEY (return_id) REFERENCES purchase_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_purchase_return_items_original_item_id FOREIGN KEY (original_item_id) REFERENCES purchase_invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchase_return_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_purchase_return_items_original_item_id ON purchase_return_items (original_item_id);
CREATE INDEX ix_purchase_return_items_batch_id ON purchase_return_items (batch_id);

-- sales_orders: Sales quotations and sales orders.
CREATE TABLE sales_orders (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    doc_type text NOT NULL,
    doc_no text NOT NULL,
    customer_id uuid NOT NULL,
    doc_date date NOT NULL,
    valid_until date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    created_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_orders PRIMARY KEY (id),
    CONSTRAINT uq_sales_orders_1 UNIQUE (doc_no),
    CONSTRAINT ck_sales_orders_1 CHECK (doc_type IN ('quotation','order')),
    CONSTRAINT ck_sales_orders_2 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_orders_3 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_orders_4 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_orders_5 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_orders_6 CHECK (total >= 0),
    CONSTRAINT ck_sales_orders_7 CHECK (status IN ('draft', 'confirmed', 'converted', 'cancelled', 'expired')),
    CONSTRAINT ck_sales_orders_8 CHECK (version >= 1),
    CONSTRAINT fk_sales_orders_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_orders_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_orders_branch_id ON sales_orders (branch_id);
CREATE INDEX ix_sales_orders_customer_id ON sales_orders (customer_id);
CREATE INDEX ix_sales_orders_currency_code ON sales_orders (currency_code);
CREATE INDEX ix_sales_orders_created_by ON sales_orders (created_by);

-- sales_order_items: Order/quotation lines.
CREATE TABLE sales_order_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_order_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_order_items_1 UNIQUE (order_id, line_no),
    CONSTRAINT ck_sales_order_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_order_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_order_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_order_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_order_items_5 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_order_items_6 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_order_items_7 CHECK (version >= 1),
    CONSTRAINT fk_sales_order_items_order_id FOREIGN KEY (order_id) REFERENCES sales_orders (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_order_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_order_items_medicine_id ON sales_order_items (medicine_id);

-- sales_invoices: Sales invoices (retail/wholesale, cash/credit); posting reduces stock.
CREATE TABLE sales_invoices (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    invoice_no text NOT NULL,
    sale_type text NOT NULL,
    payment_type text NOT NULL,
    customer_id uuid,
    sales_order_id uuid,
    invoice_date date NOT NULL,
    due_date date,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    round_off numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    previous_balance numeric(18,4) NOT NULL DEFAULT 0,
    paid_amount numeric(18,4) NOT NULL DEFAULT 0,
    payment_method text,
    payment_status text NOT NULL DEFAULT 'unpaid',
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    balance_due numeric(18,4) GENERATED ALWAYS AS (total - paid_amount) STORED,
    account_balance_after numeric(18,4) GENERATED ALWAYS AS (previous_balance + total - paid_amount) STORED,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoices PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoices_1 UNIQUE (invoice_no),
    CONSTRAINT ck_sales_invoices_1 CHECK (sale_type IN ('retail','wholesale')),
    CONSTRAINT ck_sales_invoices_2 CHECK (payment_type IN ('cash','credit')),
    CONSTRAINT ck_sales_invoices_3 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_invoices_4 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_invoices_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoices_6 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoices_7 CHECK (total >= 0),
    CONSTRAINT ck_sales_invoices_8 CHECK (paid_amount >= 0),
    CONSTRAINT ck_sales_invoices_9 CHECK (payment_method IS NULL OR payment_method IN ('cash','bank','cheque','transfer','card')),
    CONSTRAINT ck_sales_invoices_10 CHECK (payment_status IN ('unpaid','partial','paid')),
    CONSTRAINT ck_sales_invoices_11 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_invoices_12 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoices_13 CHECK (payment_type = 'cash' OR customer_id IS NOT NULL),
    CONSTRAINT ck_sales_invoices_14 CHECK (paid_amount <= total),
    CONSTRAINT ck_sales_invoices_15 CHECK (discount_amount <= subtotal),
    CONSTRAINT ck_sales_invoices_16 CHECK (round(total,4) = round(subtotal - discount_amount + tax_amount + round_off,4)),
    CONSTRAINT fk_sales_invoices_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_sales_order_id FOREIGN KEY (sales_order_id) REFERENCES sales_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoices_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoices_1 ON sales_invoices (invoice_date);
CREATE INDEX ix_sales_invoices_2 ON sales_invoices (customer_id, invoice_date);
CREATE UNIQUE INDEX ux_sales_invoices_3 ON sales_invoices (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_invoices_branch_id ON sales_invoices (branch_id);
CREATE INDEX ix_sales_invoices_sales_order_id ON sales_invoices (sales_order_id);
CREATE INDEX ix_sales_invoices_currency_code ON sales_invoices (currency_code);
CREATE INDEX ix_sales_invoices_posted_by ON sales_invoices (posted_by);
CREATE INDEX ix_sales_invoices_reversed_by ON sales_invoices (reversed_by);
CREATE INDEX ix_sales_invoices_journal_entry_id ON sales_invoices (journal_entry_id);
CREATE INDEX ix_sales_invoices_reversal_entry_id ON sales_invoices (reversal_entry_id);

-- sales_invoice_items: Sales lines; cost_price/gross_profit are frozen at posting.
CREATE TABLE sales_invoice_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    invoice_id uuid NOT NULL,
    line_no integer NOT NULL,
    medicine_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    free_quantity numeric(14,3) NOT NULL DEFAULT 0,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    discount_pct numeric(7,4) NOT NULL DEFAULT 0,
    discount_amount numeric(18,4) NOT NULL DEFAULT 0,
    tax_pct numeric(7,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    cost_price numeric(18,4) NOT NULL DEFAULT 0,
    gross_profit numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_invoice_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_invoice_items_1 UNIQUE (invoice_id, line_no),
    CONSTRAINT uq_sales_invoice_items_2 UNIQUE (invoice_id, batch_id),
    CONSTRAINT ck_sales_invoice_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_invoice_items_2 CHECK (free_quantity >= 0),
    CONSTRAINT ck_sales_invoice_items_3 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_invoice_items_4 CHECK (discount_pct >= 0 AND discount_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_5 CHECK (discount_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_6 CHECK (tax_pct >= 0 AND tax_pct <= 100),
    CONSTRAINT ck_sales_invoice_items_7 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_invoice_items_8 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_invoice_items_9 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_invoice_items_10 CHECK (version >= 1),
    CONSTRAINT ck_sales_invoice_items_11 CHECK (round(line_total,4) = round(quantity * unit_price - discount_amount + tax_amount,4)),
    CONSTRAINT fk_sales_invoice_items_invoice_id FOREIGN KEY (invoice_id) REFERENCES sales_invoices (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_invoice_items_medicine_id FOREIGN KEY (medicine_id) REFERENCES medicines (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_invoice_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_invoice_items_medicine_id ON sales_invoice_items (medicine_id);
CREATE INDEX ix_sales_invoice_items_batch_id ON sales_invoice_items (batch_id);

-- sales_returns: Sales returns / customer credit notes against an original invoice.
CREATE TABLE sales_returns (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    return_no text NOT NULL,
    original_invoice_id uuid NOT NULL,
    customer_id uuid,
    return_date date NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    subtotal numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    total numeric(18,4) NOT NULL DEFAULT 0,
    refund_method text NOT NULL DEFAULT 'credit_note',
    reason text,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_returns PRIMARY KEY (id),
    CONSTRAINT uq_sales_returns_1 UNIQUE (return_no),
    CONSTRAINT ck_sales_returns_1 CHECK (exchange_rate > 0),
    CONSTRAINT ck_sales_returns_2 CHECK (subtotal >= 0),
    CONSTRAINT ck_sales_returns_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_returns_4 CHECK (total >= 0),
    CONSTRAINT ck_sales_returns_5 CHECK (refund_method IN ('credit_note','cash','bank')),
    CONSTRAINT ck_sales_returns_6 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_sales_returns_7 CHECK (version >= 1),
    CONSTRAINT ck_sales_returns_8 CHECK (round(total,4) = round(subtotal + tax_amount,4)),
    CONSTRAINT fk_sales_returns_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_original_invoice_id FOREIGN KEY (original_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_returns_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE UNIQUE INDEX ux_sales_returns_1 ON sales_returns (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_sales_returns_branch_id ON sales_returns (branch_id);
CREATE INDEX ix_sales_returns_original_invoice_id ON sales_returns (original_invoice_id);
CREATE INDEX ix_sales_returns_customer_id ON sales_returns (customer_id);
CREATE INDEX ix_sales_returns_currency_code ON sales_returns (currency_code);
CREATE INDEX ix_sales_returns_posted_by ON sales_returns (posted_by);
CREATE INDEX ix_sales_returns_reversed_by ON sales_returns (reversed_by);
CREATE INDEX ix_sales_returns_journal_entry_id ON sales_returns (journal_entry_id);
CREATE INDEX ix_sales_returns_reversal_entry_id ON sales_returns (reversal_entry_id);

-- sales_return_items: Sales return lines.
CREATE TABLE sales_return_items (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    return_id uuid NOT NULL,
    line_no integer NOT NULL,
    original_item_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    quantity numeric(14,3) NOT NULL,
    unit_price numeric(18,4) NOT NULL DEFAULT 0,
    tax_amount numeric(18,4) NOT NULL DEFAULT 0,
    line_total numeric(18,4) NOT NULL DEFAULT 0,
    cost_price numeric(18,4) NOT NULL DEFAULT 0,
    reason text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_sales_return_items PRIMARY KEY (id),
    CONSTRAINT uq_sales_return_items_1 UNIQUE (return_id, line_no),
    CONSTRAINT uq_sales_return_items_2 UNIQUE (return_id, original_item_id),
    CONSTRAINT ck_sales_return_items_1 CHECK (quantity > 0),
    CONSTRAINT ck_sales_return_items_2 CHECK (unit_price >= 0),
    CONSTRAINT ck_sales_return_items_3 CHECK (tax_amount >= 0),
    CONSTRAINT ck_sales_return_items_4 CHECK (line_total >= 0),
    CONSTRAINT ck_sales_return_items_5 CHECK (cost_price >= 0),
    CONSTRAINT ck_sales_return_items_6 CHECK (version >= 1),
    CONSTRAINT ck_sales_return_items_7 CHECK (round(line_total,4) = round(quantity * unit_price + tax_amount,4)),
    CONSTRAINT fk_sales_return_items_return_id FOREIGN KEY (return_id) REFERENCES sales_returns (id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_return_items_original_item_id FOREIGN KEY (original_item_id) REFERENCES sales_invoice_items (id) ON DELETE RESTRICT,
    CONSTRAINT fk_sales_return_items_batch_id FOREIGN KEY (batch_id) REFERENCES batches (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sales_return_items_original_item_id ON sales_return_items (original_item_id);
CREATE INDEX ix_sales_return_items_batch_id ON sales_return_items (batch_id);

-- vouchers: Receipts, payments, contra, expense and income vouchers.
CREATE TABLE vouchers (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    voucher_no text NOT NULL,
    voucher_type text NOT NULL,
    voucher_date date NOT NULL,
    customer_id uuid,
    supplier_id uuid,
    expense_category_id uuid,
    cash_bank_account_id uuid NOT NULL,
    counter_account_id uuid,
    payment_method text NOT NULL DEFAULT 'cash',
    amount numeric(18,4) NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    exchange_rate numeric(18,8) NOT NULL DEFAULT 1,
    reference text,
    description text,
    attachment_id uuid,
    status text NOT NULL DEFAULT 'draft',
    notes text,
    posted_at timestamptz,
    posted_by uuid,
    reversed_at timestamptz,
    reversed_by uuid,
    reversal_reason text,
    journal_entry_id uuid,
    reversal_entry_id uuid,
    client_uuid text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_vouchers PRIMARY KEY (id),
    CONSTRAINT uq_vouchers_1 UNIQUE (voucher_no),
    CONSTRAINT ck_vouchers_1 CHECK (voucher_type IN ('cash_receipt','cash_payment','customer_receipt','supplier_payment','contra','expense','income')),
    CONSTRAINT ck_vouchers_2 CHECK (payment_method IN ('cash','bank','cheque','transfer','card')),
    CONSTRAINT ck_vouchers_3 CHECK (amount > 0),
    CONSTRAINT ck_vouchers_4 CHECK (exchange_rate > 0),
    CONSTRAINT ck_vouchers_5 CHECK (status IN ('draft', 'posted', 'reversed', 'cancelled')),
    CONSTRAINT ck_vouchers_6 CHECK (version >= 1),
    CONSTRAINT ck_vouchers_7 CHECK (voucher_type <> 'customer_receipt' OR customer_id IS NOT NULL),
    CONSTRAINT ck_vouchers_8 CHECK (voucher_type <> 'supplier_payment' OR supplier_id IS NOT NULL),
    CONSTRAINT ck_vouchers_9 CHECK (voucher_type <> 'expense' OR expense_category_id IS NOT NULL),
    CONSTRAINT ck_vouchers_10 CHECK (voucher_type NOT IN ('cash_receipt','cash_payment','income','contra') OR counter_account_id IS NOT NULL),
    CONSTRAINT ck_vouchers_11 CHECK (counter_account_id IS NULL OR counter_account_id <> cash_bank_account_id),
    CONSTRAINT fk_vouchers_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_supplier_id FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_expense_category_id FOREIGN KEY (expense_category_id) REFERENCES expense_categories (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_cash_bank_account_id FOREIGN KEY (cash_bank_account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_counter_account_id FOREIGN KEY (counter_account_id) REFERENCES accounts (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_attachment_id FOREIGN KEY (attachment_id) REFERENCES attachments (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_posted_by FOREIGN KEY (posted_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_reversed_by FOREIGN KEY (reversed_by) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_journal_entry_id FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT,
    CONSTRAINT fk_vouchers_reversal_entry_id FOREIGN KEY (reversal_entry_id) REFERENCES journal_entries (id) ON DELETE RESTRICT
);
CREATE INDEX ix_vouchers_1 ON vouchers (voucher_date);
CREATE INDEX ix_vouchers_2 ON vouchers (voucher_type, voucher_date);
CREATE UNIQUE INDEX ux_vouchers_3 ON vouchers (client_uuid) WHERE client_uuid IS NOT NULL;
CREATE INDEX ix_vouchers_branch_id ON vouchers (branch_id);
CREATE INDEX ix_vouchers_customer_id ON vouchers (customer_id);
CREATE INDEX ix_vouchers_supplier_id ON vouchers (supplier_id);
CREATE INDEX ix_vouchers_expense_category_id ON vouchers (expense_category_id);
CREATE INDEX ix_vouchers_cash_bank_account_id ON vouchers (cash_bank_account_id);
CREATE INDEX ix_vouchers_counter_account_id ON vouchers (counter_account_id);
CREATE INDEX ix_vouchers_currency_code ON vouchers (currency_code);
CREATE INDEX ix_vouchers_attachment_id ON vouchers (attachment_id);
CREATE INDEX ix_vouchers_posted_by ON vouchers (posted_by);
CREATE INDEX ix_vouchers_reversed_by ON vouchers (reversed_by);
CREATE INDEX ix_vouchers_journal_entry_id ON vouchers (journal_entry_id);
CREATE INDEX ix_vouchers_reversal_entry_id ON vouchers (reversal_entry_id);

-- payment_allocations: Settlement of invoices by receipts/payments.
CREATE TABLE payment_allocations (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    voucher_id uuid NOT NULL,
    sales_invoice_id uuid,
    purchase_invoice_id uuid,
    amount numeric(18,4) NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_payment_allocations PRIMARY KEY (id),
    CONSTRAINT uq_payment_allocations_1 UNIQUE (voucher_id, sales_invoice_id, purchase_invoice_id),
    CONSTRAINT ck_payment_allocations_1 CHECK (amount > 0),
    CONSTRAINT ck_payment_allocations_2 CHECK (version >= 1),
    CONSTRAINT ck_payment_allocations_3 CHECK ((sales_invoice_id IS NULL) <> (purchase_invoice_id IS NULL)),
    CONSTRAINT fk_payment_allocations_voucher_id FOREIGN KEY (voucher_id) REFERENCES vouchers (id) ON DELETE CASCADE,
    CONSTRAINT fk_payment_allocations_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_payment_allocations_purchase_invoice_id FOREIGN KEY (purchase_invoice_id) REFERENCES purchase_invoices (id) ON DELETE RESTRICT
);
CREATE INDEX ix_payment_allocations_sales_invoice_id ON payment_allocations (sales_invoice_id);
CREATE INDEX ix_payment_allocations_purchase_invoice_id ON payment_allocations (purchase_invoice_id);

-- backup_history: Backup and restore history (device-local).
CREATE TABLE backup_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    kind text NOT NULL,
    location text NOT NULL DEFAULT 'local',
    file_path text NOT NULL,
    size_bytes bigint,
    sha256 text,
    status text NOT NULL DEFAULT 'started',
    integrity_result text,
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    created_by uuid,
    note text,
    CONSTRAINT pk_backup_history PRIMARY KEY (id),
    CONSTRAINT ck_backup_history_1 CHECK (kind IN ('manual','automatic','scheduled','pre_upgrade','pre_conflict','restore_point')),
    CONSTRAINT ck_backup_history_2 CHECK (location IN ('local','cloud')),
    CONSTRAINT ck_backup_history_3 CHECK (status IN ('started','completed','failed','verified','restored')),
    CONSTRAINT fk_backup_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_backup_history_created_by ON backup_history (created_by);

-- sync_conflicts: Detected synchronisation conflicts awaiting or recording resolution.
CREATE TABLE sync_conflicts (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    table_name text NOT NULL,
    row_id text NOT NULL,
    device_id text,
    local_version integer,
    server_version integer,
    local_payload jsonb,
    server_payload jsonb,
    reason text NOT NULL DEFAULT 'version_conflict',
    detected_at timestamptz NOT NULL DEFAULT now(),
    resolution text NOT NULL DEFAULT 'pending',
    resolved_by uuid,
    resolved_at timestamptz,
    backup_ref text,
    CONSTRAINT pk_sync_conflicts PRIMARY KEY (id),
    CONSTRAINT ck_sync_conflicts_1 CHECK (resolution IN ('pending','local_won','server_won','merged','dismissed')),
    CONSTRAINT fk_sync_conflicts_resolved_by FOREIGN KEY (resolved_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX ix_sync_conflicts_1 ON sync_conflicts (resolution, detected_at);
CREATE INDEX ix_sync_conflicts_resolved_by ON sync_conflicts (resolved_by);

-- sync_log: One row per synchronisation run.
CREATE TABLE sync_log (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    device_id text,
    direction text NOT NULL,
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    pushed integer NOT NULL DEFAULT 0,
    pulled integer NOT NULL DEFAULT 0,
    conflicts integer NOT NULL DEFAULT 0,
    status text NOT NULL DEFAULT 'started',
    error text,
    CONSTRAINT pk_sync_log PRIMARY KEY (id),
    CONSTRAINT ck_sync_log_1 CHECK (direction IN ('push','pull','full')),
    CONSTRAINT ck_sync_log_2 CHECK (status IN ('started','ok','partial','failed'))
);


CREATE TABLE change_log (
    seq bigserial PRIMARY KEY,
    table_name text NOT NULL,
    row_id text NOT NULL,
    op text NOT NULL CHECK (op IN ('insert','update','delete')),
    version integer,
    branch_id uuid,
    origin_device_id text,
    changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_change_log_row ON change_log (table_name, row_id);
CREATE INDEX ix_change_log_branch_seq ON change_log (branch_id, seq);

CREATE TABLE sync_devices (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    device_code text NOT NULL UNIQUE,
    name text NOT NULL,
    platform text CHECK (platform IN ('windows','android','web','server')),
    branch_id uuid REFERENCES branches (id) ON DELETE RESTRICT,
    last_seen_at timestamptz,
    last_acked_seq bigint NOT NULL DEFAULT 0,
    is_revoked boolean NOT NULL DEFAULT false,
    registered_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ix_sync_devices_branch ON sync_devices (branch_id);

-- installment_plans: Customer installment plans for posted credit sales invoices; one active plan record per invoice.
CREATE TABLE IF NOT EXISTS installment_plans (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    sales_invoice_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    plan_no text NOT NULL,
    currency_code text NOT NULL DEFAULT 'AFN',
    principal_amount numeric(18,4) NOT NULL DEFAULT 0,
    installment_count integer NOT NULL,
    frequency text NOT NULL DEFAULT 'monthly',
    first_due_date date NOT NULL,
    status text NOT NULL DEFAULT 'active',
    notes text,
    created_by uuid,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_plans PRIMARY KEY (id),
    CONSTRAINT uq_installment_plans_1 UNIQUE (sales_invoice_id),
    CONSTRAINT uq_installment_plans_2 UNIQUE (plan_no),
    CONSTRAINT ck_installment_plans_1 CHECK (principal_amount >= 0),
    CONSTRAINT ck_installment_plans_2 CHECK (installment_count BETWEEN 2 AND 60),
    CONSTRAINT ck_installment_plans_3 CHECK (frequency IN ('weekly','biweekly','monthly')),
    CONSTRAINT ck_installment_plans_4 CHECK (status IN ('active', 'completed', 'cancelled')),
    CONSTRAINT ck_installment_plans_5 CHECK (version >= 1),
    CONSTRAINT fk_installment_plans_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_currency_code FOREIGN KEY (currency_code) REFERENCES currencies (code) ON DELETE RESTRICT,
    CONSTRAINT fk_installment_plans_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_installment_plans_1 ON installment_plans (customer_id, status);
CREATE INDEX IF NOT EXISTS ix_installment_plans_2 ON installment_plans (branch_id, first_due_date);
CREATE INDEX IF NOT EXISTS ix_installment_plans_currency_code ON installment_plans (currency_code);
CREATE INDEX IF NOT EXISTS ix_installment_plans_created_by ON installment_plans (created_by);

-- installment_schedule: Dated customer installment schedule; payment settlement integration is a later stage.
CREATE TABLE IF NOT EXISTS installment_schedule (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    plan_id uuid NOT NULL,
    installment_no integer NOT NULL,
    due_date date NOT NULL,
    amount numeric(18,4) NOT NULL DEFAULT 0,
    paid_amount numeric(18,4) NOT NULL DEFAULT 0,
    balance_due numeric(18,4) GENERATED ALWAYS AS (amount - paid_amount) STORED,
    status text NOT NULL DEFAULT 'scheduled',
    paid_at timestamptz,
    notes text,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_schedule PRIMARY KEY (id),
    CONSTRAINT uq_installment_schedule_1 UNIQUE (plan_id, installment_no),
    CONSTRAINT ck_installment_schedule_1 CHECK (installment_no >= 1),
    CONSTRAINT ck_installment_schedule_2 CHECK (amount >= 0),
    CONSTRAINT ck_installment_schedule_3 CHECK (paid_amount >= 0),
    CONSTRAINT ck_installment_schedule_4 CHECK (status IN ('scheduled', 'partial', 'paid', 'overdue', 'cancelled')),
    CONSTRAINT ck_installment_schedule_5 CHECK (version >= 1),
    CONSTRAINT ck_installment_schedule_6 CHECK (paid_amount <= amount),
    CONSTRAINT fk_installment_schedule_plan_id FOREIGN KEY (plan_id) REFERENCES installment_plans (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_schedule_1 ON installment_schedule (due_date, status);

-- installment_payment_allocations: Draft customer receipt allocations to individual installment schedule rows; applied when voucher posts.
CREATE TABLE IF NOT EXISTS installment_payment_allocations (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    voucher_id uuid NOT NULL,
    installment_schedule_id uuid NOT NULL,
    amount numeric(18,4) NOT NULL DEFAULT 0,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    version integer NOT NULL DEFAULT 1,
    CONSTRAINT pk_installment_payment_allocations PRIMARY KEY (id),
    CONSTRAINT uq_installment_payment_allocations_1 UNIQUE (voucher_id, installment_schedule_id),
    CONSTRAINT ck_installment_payment_allocations_1 CHECK (amount >= 0),
    CONSTRAINT ck_installment_payment_allocations_2 CHECK (version >= 1),
    CONSTRAINT ck_installment_payment_allocations_3 CHECK (amount > 0),
    CONSTRAINT fk_installment_payment_allocations_voucher_id FOREIGN KEY (voucher_id) REFERENCES vouchers (id) ON DELETE CASCADE,
    CONSTRAINT fk_installment_payment_allocations_installment_schedule_id FOREIGN KEY (installment_schedule_id) REFERENCES installment_schedule (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_installment_payment_allocations_1 ON installment_payment_allocations (installment_schedule_id);

-- due_reminder_history: Append-only manual customer due-reminder history; records contact attempts but never sends messages.
CREATE TABLE IF NOT EXISTS due_reminder_history (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    branch_id uuid NOT NULL,
    sales_invoice_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    channel text NOT NULL,
    outcome text NOT NULL DEFAULT 'recorded',
    notes text,
    reminded_at timestamptz NOT NULL DEFAULT now(),
    created_by uuid NOT NULL,
    origin_device_id text,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT pk_due_reminder_history PRIMARY KEY (id),
    CONSTRAINT ck_due_reminder_history_1 CHECK (channel IN ('phone','sms','email','whatsapp','in_person')),
    CONSTRAINT ck_due_reminder_history_2 CHECK (outcome IN ('recorded','sent','failed')),
    CONSTRAINT fk_due_reminder_history_branch_id FOREIGN KEY (branch_id) REFERENCES branches (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_sales_invoice_id FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_customer_id FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_due_reminder_history_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_1 ON due_reminder_history (branch_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_2 ON due_reminder_history (sales_invoice_id, reminded_at);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_customer_id ON due_reminder_history (customer_id);
CREATE INDEX IF NOT EXISTS ix_due_reminder_history_created_by ON due_reminder_history (created_by);

CREATE VIEW v_batch_stock AS
SELECT x.*,
       CASE WHEN x.days_to_expiry < 0 THEN 'expired'
            WHEN x.days_to_expiry <= 30 THEN 'd30'
            WHEN x.days_to_expiry <= 60 THEN 'd60'
            WHEN x.days_to_expiry <= 90 THEN 'd90'
            WHEN x.days_to_expiry <= 120 THEN 'd120'
            WHEN x.days_to_expiry <= 180 THEN 'd180'
            ELSE 'ok' END AS expiry_bucket
FROM (SELECT b.id AS batch_id, b.branch_id, b.medicine_id, m.name AS medicine_name, b.batch_no, b.expiry_date,
             b.qty_on_hand, b.unit_cost, round(b.qty_on_hand * b.unit_cost, 4) AS stock_value, b.is_blocked,
             (b.expiry_date - CURRENT_DATE) AS days_to_expiry
      FROM batches b JOIN medicines m ON m.id = b.medicine_id) x;

CREATE VIEW v_expiry_alerts AS
SELECT * FROM v_batch_stock WHERE qty_on_hand > 0 AND expiry_bucket <> 'ok';

CREATE VIEW v_stock_by_medicine AS
SELECT m.id AS medicine_id, b.branch_id, m.name AS medicine_name, SUM(b.qty_on_hand) AS qty_on_hand,
       SUM(round(b.qty_on_hand * b.unit_cost, 4)) AS stock_value
FROM medicines m JOIN batches b ON b.medicine_id = m.id
GROUP BY m.id, b.branch_id, m.name;

CREATE VIEW v_low_stock AS
SELECT m.id AS medicine_id, m.name AS medicine_name, m.min_stock, COALESCE(SUM(b.qty_on_hand), 0) AS available_qty
FROM medicines m
LEFT JOIN batches b ON b.medicine_id = m.id AND b.expiry_date >= CURRENT_DATE AND NOT b.is_blocked
WHERE m.is_active AND m.deleted_at IS NULL AND m.min_stock > 0
GROUP BY m.id, m.name, m.min_stock
HAVING COALESCE(SUM(b.qty_on_hand), 0) <= m.min_stock;

CREATE VIEW v_customer_balance AS
SELECT c.id AS customer_id, c.code, c.name, c.credit_limit,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       COALESCE(t.debit, 0) - COALESCE(t.credit, 0) AS balance
FROM customers c
LEFT JOIN (SELECT l.customer_id AS cid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') AND l.customer_id IS NOT NULL GROUP BY l.customer_id) t ON t.cid = c.id;

CREATE VIEW v_supplier_balance AS
SELECT s.id AS supplier_id, s.code, s.name,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       COALESCE(t.credit, 0) - COALESCE(t.debit, 0) AS balance
FROM suppliers s
LEFT JOIN (SELECT l.supplier_id AS sid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') AND l.supplier_id IS NOT NULL GROUP BY l.supplier_id) t ON t.sid = s.id;

CREATE VIEW v_account_balance AS
SELECT a.id AS account_id, a.code, a.name, a.account_type, a.normal_side,
       COALESCE(t.debit, 0) AS total_debit, COALESCE(t.credit, 0) AS total_credit,
       CASE WHEN a.normal_side = 'debit' THEN COALESCE(t.debit, 0) - COALESCE(t.credit, 0)
            ELSE COALESCE(t.credit, 0) - COALESCE(t.debit, 0) END AS balance
FROM accounts a
LEFT JOIN (SELECT l.account_id AS aid, SUM(l.debit) AS debit, SUM(l.credit) AS credit
           FROM journal_lines l JOIN journal_entries e ON e.id = l.entry_id
           WHERE e.status IN ('posted','reversed') GROUP BY l.account_id) t ON t.aid = a.id;

CREATE VIEW v_trial_balance AS
SELECT code, name, account_type, total_debit, total_credit,
       CASE WHEN total_debit > total_credit THEN total_debit - total_credit ELSE 0 END AS debit_balance,
       CASE WHEN total_credit > total_debit THEN total_credit - total_debit ELSE 0 END AS credit_balance
FROM v_account_balance WHERE total_debit <> 0 OR total_credit <> 0;

CREATE VIEW v_sales_invoice_profit AS
SELECT s.id AS invoice_id, s.invoice_no, s.invoice_date, s.branch_id, s.customer_id,
       SUM(i.quantity * i.unit_price - i.discount_amount) AS net_sales,
       SUM(i.cost_price * (i.quantity + i.free_quantity)) AS cogs,
       SUM(i.gross_profit) AS gross_profit
FROM sales_invoices s JOIN sales_invoice_items i ON i.invoice_id = s.id
WHERE s.status = 'posted'
GROUP BY s.id, s.invoice_no, s.invoice_date, s.branch_id, s.customer_id;

CREATE VIEW v_integrity_issues AS
SELECT 'unbalanced_journal' AS check_name, CAST(e.id AS text) AS entity_id, e.entry_no AS detail FROM journal_entries e WHERE e.status IN ('posted','reversed') AND round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = e.id),4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = e.id),4)
UNION ALL
SELECT 'batch_qty_mismatch', CAST(b.id AS text), b.batch_no FROM batches b WHERE round(b.qty_on_hand,3) <> round((SELECT COALESCE(SUM(quantity_change),0) FROM stock_movements m WHERE m.batch_id = b.id),3)
UNION ALL
SELECT 'posted_without_journal', CAST(d.id AS text), d.invoice_no FROM sales_invoices d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', CAST(d.id AS text), d.invoice_no FROM purchase_invoices d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', CAST(d.id AS text), d.return_no FROM sales_returns d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', CAST(d.id AS text), d.return_no FROM purchase_returns d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_journal', CAST(d.id AS text), d.voucher_no FROM vouchers d WHERE d.status IN ('posted','reversed') AND d.journal_entry_id IS NULL
UNION ALL
SELECT 'posted_without_stock_movement', CAST(d.id AS text), d.invoice_no FROM sales_invoices d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM sales_invoice_items i WHERE i.invoice_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'sales_invoices' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', CAST(d.id AS text), d.invoice_no FROM purchase_invoices d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM purchase_invoice_items i WHERE i.invoice_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'purchase_invoices' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', CAST(d.id AS text), d.return_no FROM sales_returns d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM sales_return_items i WHERE i.return_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'sales_returns' AND m.source_id = d.id)
UNION ALL
SELECT 'posted_without_stock_movement', CAST(d.id AS text), d.return_no FROM purchase_returns d WHERE d.status IN ('posted','reversed') AND EXISTS (SELECT 1 FROM purchase_return_items i WHERE i.return_id = d.id) AND NOT EXISTS (SELECT 1 FROM stock_movements m WHERE m.source_type = 'purchase_returns' AND m.source_id = d.id)
UNION ALL
SELECT 'invoice_paid_mismatch', CAST(d.id AS text), d.invoice_no FROM sales_invoices d WHERE d.status = 'posted' AND d.paid_amount > d.total;

CREATE FUNCTION fn_trg_sales_invoices_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_no_posted_insert BEFORE INSERT ON sales_invoices FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_no_posted_insert();

CREATE FUNCTION fn_trg_sales_invoices_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_no_delete BEFORE DELETE ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_no_delete();

CREATE FUNCTION fn_trg_sales_invoices_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_transition BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_sales_invoices_transition();

CREATE FUNCTION fn_trg_sales_invoices_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_frozen BEFORE UPDATE ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.invoice_no IS DISTINCT FROM OLD.invoice_no OR NEW.sale_type IS DISTINCT FROM OLD.sale_type OR NEW.payment_type IS DISTINCT FROM OLD.payment_type OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.sales_order_id IS DISTINCT FROM OLD.sales_order_id OR NEW.invoice_date IS DISTINCT FROM OLD.invoice_date OR NEW.due_date IS DISTINCT FROM OLD.due_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.discount_amount IS DISTINCT FROM OLD.discount_amount OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.round_off IS DISTINCT FROM OLD.round_off OR NEW.total IS DISTINCT FROM OLD.total OR NEW.previous_balance IS DISTINCT FROM OLD.previous_balance OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_sales_invoices_frozen();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = NEW.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_insert BEFORE INSERT ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_insert();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_update BEFORE UPDATE ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_update();

CREATE FUNCTION fn_trg_sales_invoice_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_invoice_items_guard_delete BEFORE DELETE ON sales_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_invoice_items_guard_delete();

CREATE FUNCTION fn_trg_purchase_invoices_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_no_posted_insert BEFORE INSERT ON purchase_invoices FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_no_posted_insert();

CREATE FUNCTION fn_trg_purchase_invoices_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_no_delete BEFORE DELETE ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_no_delete();

CREATE FUNCTION fn_trg_purchase_invoices_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_transition BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_purchase_invoices_transition();

CREATE FUNCTION fn_trg_purchase_invoices_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_frozen BEFORE UPDATE ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.invoice_no IS DISTINCT FROM OLD.invoice_no OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.supplier_invoice_no IS DISTINCT FROM OLD.supplier_invoice_no OR NEW.purchase_order_id IS DISTINCT FROM OLD.purchase_order_id OR NEW.goods_receipt_id IS DISTINCT FROM OLD.goods_receipt_id OR NEW.invoice_date IS DISTINCT FROM OLD.invoice_date OR NEW.due_date IS DISTINCT FROM OLD.due_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.discount_amount IS DISTINCT FROM OLD.discount_amount OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.additional_costs IS DISTINCT FROM OLD.additional_costs OR NEW.round_off IS DISTINCT FROM OLD.round_off OR NEW.total IS DISTINCT FROM OLD.total OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_purchase_invoices_frozen();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = NEW.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_insert BEFORE INSERT ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_insert();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_update BEFORE UPDATE ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_update();

CREATE FUNCTION fn_trg_purchase_invoice_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_invoices p WHERE p.id = OLD.invoice_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_invoice_items_guard_delete BEFORE DELETE ON purchase_invoice_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_invoice_items_guard_delete();

CREATE FUNCTION fn_trg_sales_returns_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_no_posted_insert BEFORE INSERT ON sales_returns FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_no_posted_insert();

CREATE FUNCTION fn_trg_sales_returns_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_returns_no_delete BEFORE DELETE ON sales_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_no_delete();

CREATE FUNCTION fn_trg_sales_returns_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_transition BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_sales_returns_transition();

CREATE FUNCTION fn_trg_sales_returns_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_frozen BEFORE UPDATE ON sales_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.return_no IS DISTINCT FROM OLD.return_no OR NEW.original_invoice_id IS DISTINCT FROM OLD.original_invoice_id OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.return_date IS DISTINCT FROM OLD.return_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.total IS DISTINCT FROM OLD.total OR NEW.refund_method IS DISTINCT FROM OLD.refund_method OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_sales_returns_frozen();

CREATE FUNCTION fn_trg_sales_return_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = NEW.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_insert BEFORE INSERT ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_insert();

CREATE FUNCTION fn_trg_sales_return_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_update BEFORE UPDATE ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_update();

CREATE FUNCTION fn_trg_sales_return_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM sales_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_sales_return_items_guard_delete BEFORE DELETE ON sales_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_sales_return_items_guard_delete();

CREATE FUNCTION fn_trg_purchase_returns_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_no_posted_insert BEFORE INSERT ON purchase_returns FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_no_posted_insert();

CREATE FUNCTION fn_trg_purchase_returns_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_no_delete BEFORE DELETE ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_no_delete();

CREATE FUNCTION fn_trg_purchase_returns_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_transition BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_purchase_returns_transition();

CREATE FUNCTION fn_trg_purchase_returns_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_frozen BEFORE UPDATE ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.return_no IS DISTINCT FROM OLD.return_no OR NEW.original_invoice_id IS DISTINCT FROM OLD.original_invoice_id OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.return_date IS DISTINCT FROM OLD.return_date OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.subtotal IS DISTINCT FROM OLD.subtotal OR NEW.tax_amount IS DISTINCT FROM OLD.tax_amount OR NEW.total IS DISTINCT FROM OLD.total OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_purchase_returns_frozen();

CREATE FUNCTION fn_trg_purchase_return_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = NEW.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_insert BEFORE INSERT ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_insert();

CREATE FUNCTION fn_trg_purchase_return_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_update BEFORE UPDATE ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_update();

CREATE FUNCTION fn_trg_purchase_return_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM purchase_returns p WHERE p.id = OLD.return_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_purchase_return_items_guard_delete BEFORE DELETE ON purchase_return_items FOR EACH ROW EXECUTE FUNCTION fn_trg_purchase_return_items_guard_delete();

CREATE FUNCTION fn_trg_vouchers_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_no_posted_insert BEFORE INSERT ON vouchers FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_no_posted_insert();

CREATE FUNCTION fn_trg_vouchers_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_vouchers_no_delete BEFORE DELETE ON vouchers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_no_delete();

CREATE FUNCTION fn_trg_vouchers_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_transition BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_vouchers_transition();

CREATE FUNCTION fn_trg_vouchers_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_frozen BEFORE UPDATE ON vouchers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.voucher_no IS DISTINCT FROM OLD.voucher_no OR NEW.voucher_type IS DISTINCT FROM OLD.voucher_type OR NEW.voucher_date IS DISTINCT FROM OLD.voucher_date OR NEW.customer_id IS DISTINCT FROM OLD.customer_id OR NEW.supplier_id IS DISTINCT FROM OLD.supplier_id OR NEW.expense_category_id IS DISTINCT FROM OLD.expense_category_id OR NEW.cash_bank_account_id IS DISTINCT FROM OLD.cash_bank_account_id OR NEW.counter_account_id IS DISTINCT FROM OLD.counter_account_id OR NEW.payment_method IS DISTINCT FROM OLD.payment_method OR NEW.amount IS DISTINCT FROM OLD.amount OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.reference IS DISTINCT FROM OLD.reference OR NEW.description IS DISTINCT FROM OLD.description OR NEW.attachment_id IS DISTINCT FROM OLD.attachment_id OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_vouchers_frozen();

CREATE FUNCTION fn_trg_payment_allocations_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = NEW.voucher_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_insert BEFORE INSERT ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_insert();

CREATE FUNCTION fn_trg_payment_allocations_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = OLD.voucher_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_update BEFORE UPDATE ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_update();

CREATE FUNCTION fn_trg_payment_allocations_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM vouchers p WHERE p.id = OLD.voucher_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_payment_allocations_guard_delete BEFORE DELETE ON payment_allocations FOR EACH ROW EXECUTE FUNCTION fn_trg_payment_allocations_guard_delete();

CREATE FUNCTION fn_trg_stock_adjustments_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_no_posted_insert BEFORE INSERT ON stock_adjustments FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_no_posted_insert();

CREATE FUNCTION fn_trg_stock_adjustments_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_no_delete BEFORE DELETE ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_no_delete();

CREATE FUNCTION fn_trg_stock_adjustments_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_transition BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_stock_adjustments_transition();

CREATE FUNCTION fn_trg_stock_adjustments_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_frozen BEFORE UPDATE ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.adj_no IS DISTINCT FROM OLD.adj_no OR NEW.adj_date IS DISTINCT FROM OLD.adj_date OR NEW.adj_type IS DISTINCT FROM OLD.adj_type OR NEW.reason IS DISTINCT FROM OLD.reason OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.journal_entry_id IS DISTINCT FROM OLD.journal_entry_id OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_stock_adjustments_frozen();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = NEW.adjustment_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_insert BEFORE INSERT ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_insert();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = OLD.adjustment_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_update BEFORE UPDATE ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_update();

CREATE FUNCTION fn_trg_stock_adjustment_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_adjustments p WHERE p.id = OLD.adjustment_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_adjustment_items_guard_delete BEFORE DELETE ON stock_adjustment_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_adjustment_items_guard_delete();

CREATE FUNCTION fn_trg_stock_transfers_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_no_posted_insert BEFORE INSERT ON stock_transfers FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_no_posted_insert();

CREATE FUNCTION fn_trg_stock_transfers_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_no_delete BEFORE DELETE ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_no_delete();

CREATE FUNCTION fn_trg_stock_transfers_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_transition BEFORE UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_stock_transfers_transition();

CREATE FUNCTION fn_trg_stock_transfers_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_frozen BEFORE UPDATE ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.transfer_no IS DISTINCT FROM OLD.transfer_no OR NEW.from_branch_id IS DISTINCT FROM OLD.from_branch_id OR NEW.to_branch_id IS DISTINCT FROM OLD.to_branch_id OR NEW.transfer_date IS DISTINCT FROM OLD.transfer_date OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by)) EXECUTE FUNCTION fn_trg_stock_transfers_frozen();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = NEW.transfer_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_insert BEFORE INSERT ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_insert();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = OLD.transfer_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_update BEFORE UPDATE ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_update();

CREATE FUNCTION fn_trg_stock_transfer_items_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM stock_transfers p WHERE p.id = OLD.transfer_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_transfer_items_guard_delete BEFORE DELETE ON stock_transfer_items FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_transfer_items_guard_delete();

CREATE FUNCTION fn_trg_journal_entries_no_posted_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Documents must be created as draft and posted by a status change' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_no_posted_insert BEFORE INSERT ON journal_entries FOR EACH ROW
WHEN (NEW.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_no_posted_insert();

CREATE FUNCTION fn_trg_journal_entries_no_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted financial documents cannot be deleted; use an authorised reversal' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_journal_entries_no_delete BEFORE DELETE ON journal_entries FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_no_delete();

CREATE FUNCTION fn_trg_journal_entries_transition() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Invalid status transition (allowed: draft>posted, draft>cancelled, posted>reversed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_transition BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status <> NEW.status AND (NOT ansary_remote()) AND NOT ((OLD.status = 'draft' AND NEW.status IN ('posted','cancelled')) OR (OLD.status = 'posted' AND NEW.status = 'reversed'))) EXECUTE FUNCTION fn_trg_journal_entries_transition();

CREATE FUNCTION fn_trg_journal_entries_frozen() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'Posted documents are immutable; reverse the document instead' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_frozen BEFORE UPDATE ON journal_entries FOR EACH ROW
WHEN (OLD.status <> 'draft' AND (NOT ansary_remote()) AND (NEW.id IS DISTINCT FROM OLD.id OR NEW.branch_id IS DISTINCT FROM OLD.branch_id OR NEW.entry_no IS DISTINCT FROM OLD.entry_no OR NEW.entry_date IS DISTINCT FROM OLD.entry_date OR NEW.financial_year_id IS DISTINCT FROM OLD.financial_year_id OR NEW.entry_kind IS DISTINCT FROM OLD.entry_kind OR NEW.source_type IS DISTINCT FROM OLD.source_type OR NEW.source_id IS DISTINCT FROM OLD.source_id OR NEW.description IS DISTINCT FROM OLD.description OR NEW.currency_code IS DISTINCT FROM OLD.currency_code OR NEW.exchange_rate IS DISTINCT FROM OLD.exchange_rate OR NEW.posted_at IS DISTINCT FROM OLD.posted_at OR NEW.posted_by IS DISTINCT FROM OLD.posted_by OR NEW.reverses_entry_id IS DISTINCT FROM OLD.reverses_entry_id OR NEW.total_debit IS DISTINCT FROM OLD.total_debit OR NEW.total_credit IS DISTINCT FROM OLD.total_credit OR NEW.client_uuid IS DISTINCT FROM OLD.client_uuid)) EXECUTE FUNCTION fn_trg_journal_entries_frozen();

CREATE FUNCTION fn_trg_journal_lines_guard_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = NEW.entry_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_insert BEFORE INSERT ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_insert();

CREATE FUNCTION fn_trg_journal_lines_guard_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = OLD.entry_id AND p.status <> 'draft')) THEN RETURN NEW; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_update BEFORE UPDATE ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_update();

CREATE FUNCTION fn_trg_journal_lines_guard_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT ((NOT ansary_remote()) AND EXISTS (SELECT 1 FROM journal_entries p WHERE p.id = OLD.entry_id AND p.status <> 'draft')) THEN RETURN OLD; END IF;
    IF 1 = 1 THEN RAISE EXCEPTION 'Lines of a posted document cannot be changed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_journal_lines_guard_delete BEFORE DELETE ON journal_lines FOR EACH ROW EXECUTE FUNCTION fn_trg_journal_lines_guard_delete();

CREATE FUNCTION fn_trg_stock_movements_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'stock_movements is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_movements_append_only_update BEFORE UPDATE ON stock_movements FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_movements_append_only_update();

CREATE FUNCTION fn_trg_stock_movements_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'stock_movements is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_stock_movements_append_only_delete BEFORE DELETE ON stock_movements FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_movements_append_only_delete();

CREATE FUNCTION fn_trg_audit_log_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'audit_log is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_audit_log_append_only_update BEFORE UPDATE ON audit_log FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_audit_log_append_only_update();

CREATE FUNCTION fn_trg_audit_log_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'audit_log is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_audit_log_append_only_delete BEFORE DELETE ON audit_log FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_audit_log_append_only_delete();

CREATE FUNCTION fn_trg_login_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'login_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_login_history_append_only_update BEFORE UPDATE ON login_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_login_history_append_only_update();

CREATE FUNCTION fn_trg_login_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'login_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_login_history_append_only_delete BEFORE DELETE ON login_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_login_history_append_only_delete();

CREATE FUNCTION fn_trg_medicine_price_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'medicine_price_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_medicine_price_history_append_only_update BEFORE UPDATE ON medicine_price_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_medicine_price_history_append_only_update();

CREATE FUNCTION fn_trg_medicine_price_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'medicine_price_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;
CREATE TRIGGER trg_medicine_price_history_append_only_delete BEFORE DELETE ON medicine_price_history FOR EACH ROW
WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_medicine_price_history_append_only_delete();

CREATE FUNCTION fn_trg_stock_movements_check() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM batches b WHERE b.id = NEW.batch_id AND b.branch_id = NEW.branch_id AND b.medicine_id = NEW.medicine_id) THEN RAISE EXCEPTION 'Stock movement does not match its batch/branch/medicine' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_movements_check BEFORE INSERT ON stock_movements FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_movements_check();

CREATE FUNCTION fn_trg_stock_movements_apply() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    UPDATE batches SET qty_on_hand = qty_on_hand + NEW.quantity_change, last_movement_at = NEW.created_at WHERE id = NEW.batch_id;
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_movements_apply AFTER INSERT ON stock_movements FOR EACH ROW EXECUTE FUNCTION fn_trg_stock_movements_apply();

CREATE FUNCTION fn_trg_batches_remote_zero() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    UPDATE batches SET qty_on_hand = 0 WHERE id = NEW.id AND qty_on_hand <> 0;
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_batches_remote_zero AFTER INSERT ON batches FOR EACH ROW
WHEN ((ansary_remote())) EXECUTE FUNCTION fn_trg_batches_remote_zero();

CREATE FUNCTION fn_trg_medicines_price_history() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO medicine_price_history (medicine_id, old_purchase_price, new_purchase_price, old_wholesale_price, new_wholesale_price, old_retail_price, new_retail_price) VALUES (NEW.id, OLD.purchase_price, NEW.purchase_price, OLD.wholesale_price, NEW.wholesale_price, OLD.retail_price, NEW.retail_price);
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_medicines_price_history AFTER UPDATE OF purchase_price, wholesale_price, retail_price ON medicines FOR EACH ROW
WHEN (NEW.purchase_price <> OLD.purchase_price OR NEW.wholesale_price <> OLD.wholesale_price OR NEW.retail_price <> OLD.retail_price) EXECUTE FUNCTION fn_trg_medicines_price_history();

CREATE FUNCTION fn_trg_users_keep_super_admin() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF (SELECT code FROM roles WHERE id = OLD.role_id) = 'super_admin' AND (SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.code = 'super_admin' AND u.is_active AND u.deleted_at IS NULL AND u.id <> OLD.id) = 0 THEN RAISE EXCEPTION 'At least one active Super Admin must remain' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_users_keep_super_admin BEFORE UPDATE OF is_active, role_id, deleted_at ON users FOR EACH ROW
WHEN (OLD.is_active AND OLD.deleted_at IS NULL AND (NOT NEW.is_active OR NEW.role_id <> OLD.role_id OR NEW.deleted_at IS NOT NULL)) EXECUTE FUNCTION fn_trg_users_keep_super_admin();

CREATE FUNCTION fn_trg_journal_entries_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (SELECT COUNT(*) FROM journal_lines WHERE entry_id = OLD.id) < 2 THEN RAISE EXCEPTION 'A journal entry needs at least two lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = OLD.id),4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = OLD.id),4) THEN RAISE EXCEPTION 'Unbalanced journal entry: total debit must equal total credit' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.total_debit,4) <> round((SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entry_id = OLD.id),4) OR round(NEW.total_credit,4) <> round((SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entry_id = OLD.id),4) THEN RAISE EXCEPTION 'Stored journal totals do not match the lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM financial_years f WHERE f.id = NEW.financial_year_id AND NOT f.is_closed AND NEW.entry_date >= f.start_date AND NEW.entry_date <= f.end_date) THEN RAISE EXCEPTION 'Entry date is outside an open financial year' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM journal_lines l JOIN accounts a ON a.id = l.account_id WHERE l.entry_id = OLD.id AND (NOT a.is_postable OR NOT a.is_active)) THEN RAISE EXCEPTION 'Journal uses a non-postable or inactive account' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (NEW.entry_kind = 'reversal') <> (NEW.reverses_entry_id IS NOT NULL) THEN RAISE EXCEPTION 'reverses_entry_id is required for (and only for) reversal entries' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_post BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_post();

CREATE FUNCTION fn_trg_journal_entries_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.entry_kind = 'reversal' THEN RAISE EXCEPTION 'A reversal entry cannot itself be reversed' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries r WHERE r.reverses_entry_id = OLD.id AND r.status = 'posted' AND r.entry_kind = 'reversal' AND round(r.total_debit,4) = round(OLD.total_debit,4)) THEN RAISE EXCEPTION 'A posted mirror reversal entry is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_journal_entries_reverse BEFORE UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_journal_entries_reverse();

CREATE FUNCTION fn_trg_sales_invoices_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'sales_invoices' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_invoice_items WHERE invoice_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.discount_amount,4) < round((SELECT COALESCE(SUM(discount_amount),0) FROM sales_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice discount is less than the sum of line discounts' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id AND (b.branch_id <> NEW.branch_id OR b.medicine_id <> i.medicine_id OR b.is_blocked OR b.expiry_date < NEW.invoice_date)) THEN RAISE EXCEPTION 'A batch is blocked, expired, or belongs to another branch/medicine' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id AND b.qty_on_hand < i.quantity + i.free_quantity) THEN RAISE EXCEPTION 'Insufficient batch stock (negative stock is not allowed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoice_items SET cost_price = (SELECT b.unit_cost FROM batches b WHERE b.id = sales_invoice_items.batch_id), gross_profit = round(quantity * unit_price - discount_amount - (SELECT b.unit_cost FROM batches b WHERE b.id = sales_invoice_items.batch_id) * (quantity + free_quantity), 4) WHERE invoice_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, i.medicine_id, 'sale', -(i.quantity + i.free_quantity), b.unit_cost, NEW.invoice_date, 'sales_invoices', OLD.id, i.id, NEW.posted_by FROM sales_invoice_items i JOIN batches b ON b.id = i.batch_id WHERE i.invoice_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_post BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_post();

CREATE FUNCTION fn_trg_purchase_invoices_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'purchase_invoices' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_invoice_items WHERE invoice_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.additional_costs,4) <> round((SELECT COALESCE(SUM(additional_cost),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Additional costs do not match the lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.discount_amount,4) < round((SELECT COALESCE(SUM(discount_amount),0) FROM purchase_invoice_items WHERE invoice_id = OLD.id),4) THEN RAISE EXCEPTION 'Invoice discount is less than the sum of line discounts' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id AND i.expiry_date < NEW.invoice_date) THEN RAISE EXCEPTION 'Cannot receive already-expired stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO batches (branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, qty_on_hand, supplier_id) SELECT NEW.branch_id, i.medicine_id, i.batch_no, i.mfg_date, i.expiry_date, i.landed_unit_cost, 0, NEW.supplier_id FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id AND NOT EXISTS (SELECT 1 FROM batches b WHERE b.branch_id = NEW.branch_id AND b.medicine_id = i.medicine_id AND b.batch_no = i.batch_no AND b.expiry_date = i.expiry_date);
    UPDATE batches SET unit_cost = round((batches.qty_on_hand * batches.unit_cost + (i.quantity + i.free_quantity) * i.landed_unit_cost) / (batches.qty_on_hand + i.quantity + i.free_quantity), 4) FROM purchase_invoice_items AS i WHERE i.invoice_id = OLD.id AND batches.branch_id = NEW.branch_id AND batches.medicine_id = i.medicine_id AND batches.batch_no = i.batch_no AND batches.expiry_date = i.expiry_date;
    UPDATE purchase_invoice_items SET batch_id = (SELECT b.id FROM batches b WHERE b.branch_id = NEW.branch_id AND b.medicine_id = purchase_invoice_items.medicine_id AND b.batch_no = purchase_invoice_items.batch_no AND b.expiry_date = purchase_invoice_items.expiry_date) WHERE invoice_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, i.medicine_id, 'purchase', i.quantity + i.free_quantity, i.landed_unit_cost, NEW.invoice_date, 'purchase_invoices', OLD.id, i.id, NEW.posted_by FROM purchase_invoice_items i WHERE i.invoice_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_post BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_post();

CREATE FUNCTION fn_trg_sales_returns_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'sales_returns' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_return_items WHERE return_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM sales_invoices o WHERE o.id = NEW.original_invoice_id AND o.status = 'posted') THEN RAISE EXCEPTION 'The original sales invoice must be posted' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_return_items r JOIN sales_invoice_items o ON o.id = r.original_item_id WHERE r.return_id = OLD.id AND (o.invoice_id <> NEW.original_invoice_id OR o.batch_id IS DISTINCT FROM r.batch_id OR r.quantity + COALESCE((SELECT SUM(r2.quantity) FROM sales_return_items r2 JOIN sales_returns h ON h.id = r2.return_id WHERE r2.original_item_id = r.original_item_id AND h.status = 'posted' AND h.id <> OLD.id),0) > o.quantity)) THEN RAISE EXCEPTION 'Return quantity exceeds the quantity sold (or wrong invoice/batch)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM sales_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM sales_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_return_items SET cost_price = (SELECT o.cost_price FROM sales_invoice_items o WHERE o.id = sales_return_items.original_item_id) WHERE return_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, o.medicine_id, 'sales_return', i.quantity, i.cost_price, NEW.return_date, 'sales_returns', OLD.id, i.id, NEW.posted_by FROM sales_return_items i JOIN sales_invoice_items o ON o.id = i.original_item_id WHERE i.return_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_post BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_post();

CREATE FUNCTION fn_trg_purchase_returns_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'purchase_returns' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry linked to this document is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_return_items WHERE return_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM purchase_invoices o WHERE o.id = NEW.original_invoice_id AND o.status = 'posted') THEN RAISE EXCEPTION 'The original purchase invoice must be posted' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_return_items r JOIN purchase_invoice_items o ON o.id = r.original_item_id WHERE r.return_id = OLD.id AND (o.invoice_id <> NEW.original_invoice_id OR o.batch_id IS DISTINCT FROM r.batch_id OR r.quantity + COALESCE((SELECT SUM(r2.quantity) FROM purchase_return_items r2 JOIN purchase_returns h ON h.id = r2.return_id WHERE r2.original_item_id = r.original_item_id AND h.status = 'posted' AND h.id <> OLD.id),0) > o.quantity)) THEN RAISE EXCEPTION 'Return quantity exceeds the quantity purchased (or wrong invoice/batch)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_return_items r JOIN batches b ON b.id = r.batch_id WHERE r.return_id = OLD.id AND b.qty_on_hand < r.quantity) THEN RAISE EXCEPTION 'Insufficient batch stock to return to the supplier' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.subtotal,4) <> round((SELECT COALESCE(SUM(round(quantity * unit_price,4)),0) FROM purchase_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return subtotal does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF round(NEW.tax_amount,4) <> round((SELECT COALESCE(SUM(tax_amount),0) FROM purchase_return_items WHERE return_id = OLD.id),4) THEN RAISE EXCEPTION 'Return tax does not match its lines' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE purchase_return_items SET cost_price = (SELECT o.landed_unit_cost FROM purchase_invoice_items o WHERE o.id = purchase_return_items.original_item_id) WHERE return_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, o.medicine_id, 'purchase_return', -i.quantity, i.cost_price, NEW.return_date, 'purchase_returns', OLD.id, i.id, NEW.posted_by FROM purchase_return_items i JOIN purchase_invoice_items o ON o.id = i.original_item_id WHERE i.return_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_post BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_post();

CREATE FUNCTION fn_trg_stock_adjustments_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_adjustment_items i JOIN batches b ON b.id = i.batch_id WHERE i.adjustment_id = OLD.id AND (b.branch_id <> NEW.branch_id OR b.qty_on_hand + i.quantity_change < 0)) THEN RAISE EXCEPTION 'Adjustment would make batch stock negative or uses another branch''s batch' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NEW.adj_type IN ('damaged','expired') AND EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id AND quantity_change > 0) THEN RAISE EXCEPTION 'Damaged/expired adjustments must reduce stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_adjustment_items WHERE adjustment_id = OLD.id AND round(quantity_change * unit_cost,4) <> 0) AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'stock_adjustments' AND j.source_id = OLD.id) THEN RAISE EXCEPTION 'A posted journal entry is required for adjustments with a monetary value' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.branch_id, i.batch_id, b.medicine_id, CASE WHEN NEW.adj_type = 'damaged' THEN 'damaged' WHEN NEW.adj_type = 'expired' THEN 'expired' WHEN NEW.adj_type = 'opening' THEN 'opening' WHEN NEW.adj_type = 'reconciliation' THEN 'count_variance' WHEN i.quantity_change > 0 THEN 'adjustment_in' ELSE 'adjustment_out' END, i.quantity_change, i.unit_cost, NEW.adj_date, 'stock_adjustments', OLD.id, i.id, NEW.posted_by FROM stock_adjustment_items i JOIN batches b ON b.id = i.batch_id WHERE i.adjustment_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_post BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_post();

CREATE FUNCTION fn_trg_stock_transfers_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM stock_transfer_items WHERE transfer_id = OLD.id) THEN RAISE EXCEPTION 'Cannot post an empty document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_transfer_items i JOIN batches b ON b.id = i.batch_id WHERE i.transfer_id = OLD.id AND (b.branch_id <> NEW.from_branch_id OR b.is_blocked OR b.qty_on_hand < i.quantity)) THEN RAISE EXCEPTION 'Transfer batch is blocked, in another branch, or has insufficient stock' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO batches (branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, qty_on_hand, supplier_id, wholesale_price, retail_price) SELECT NEW.to_branch_id, s.medicine_id, s.batch_no, s.mfg_date, s.expiry_date, s.unit_cost, 0, s.supplier_id, s.wholesale_price, s.retail_price FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id AND NOT EXISTS (SELECT 1 FROM batches d WHERE d.branch_id = NEW.to_branch_id AND d.medicine_id = s.medicine_id AND d.batch_no = s.batch_no AND d.expiry_date = s.expiry_date);
    UPDATE batches SET unit_cost = round((batches.qty_on_hand * batches.unit_cost + i.quantity * s.unit_cost) / (batches.qty_on_hand + i.quantity), 4) FROM stock_transfer_items AS i JOIN batches AS s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id AND batches.branch_id = NEW.to_branch_id AND batches.medicine_id = s.medicine_id AND batches.batch_no = s.batch_no AND batches.expiry_date = s.expiry_date;
    UPDATE stock_transfer_items SET dest_batch_id = (SELECT d.id FROM batches d JOIN batches s ON s.id = stock_transfer_items.batch_id WHERE d.branch_id = NEW.to_branch_id AND d.medicine_id = s.medicine_id AND d.batch_no = s.batch_no AND d.expiry_date = s.expiry_date) WHERE transfer_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.from_branch_id, i.batch_id, s.medicine_id, 'transfer_out', -i.quantity, s.unit_cost, NEW.transfer_date, 'stock_transfers', OLD.id, i.id, NEW.posted_by FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT NEW.to_branch_id, i.dest_batch_id, s.medicine_id, 'transfer_in', i.quantity, s.unit_cost, NEW.transfer_date, 'stock_transfers', OLD.id, i.id, NEW.posted_by FROM stock_transfer_items i JOIN batches s ON s.id = i.batch_id WHERE i.transfer_id = OLD.id;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_post BEFORE UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_transfers_post();

CREATE FUNCTION fn_trg_vouchers_post() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.posted_by IS NULL OR NEW.posted_at IS NULL THEN RAISE EXCEPTION 'posted_by and posted_at are required when posting' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.journal_entry_id AND j.status = 'posted' AND j.source_type = 'vouchers' AND j.source_id = OLD.id AND round(j.total_debit,4) = round(NEW.amount * NEW.exchange_rate,4)) THEN RAISE EXCEPTION 'A posted journal entry equal to the voucher amount is required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF (SELECT COALESCE(SUM(amount),0) FROM payment_allocations WHERE voucher_id = OLD.id) > NEW.amount THEN RAISE EXCEPTION 'Allocations exceed the voucher amount' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a LEFT JOIN sales_invoices s ON s.id = a.sales_invoice_id LEFT JOIN purchase_invoices p ON p.id = a.purchase_invoice_id WHERE a.voucher_id = OLD.id AND ((a.sales_invoice_id IS NOT NULL AND (NEW.voucher_type <> 'customer_receipt' OR s.status <> 'posted' OR s.customer_id IS DISTINCT FROM NEW.customer_id OR a.amount > s.total - s.paid_amount)) OR (a.purchase_invoice_id IS NOT NULL AND (NEW.voucher_type <> 'supplier_payment' OR p.status <> 'posted' OR p.supplier_id IS DISTINCT FROM NEW.supplier_id OR a.amount > p.total - p.paid_amount)))) THEN RAISE EXCEPTION 'Invalid allocation (wrong party, unposted invoice, or amount above the outstanding balance)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoices SET paid_amount = sales_invoices.paid_amount + x.amt, payment_status = CASE WHEN sales_invoices.paid_amount + x.amt >= sales_invoices.total THEN 'paid' ELSE 'partial' END FROM (SELECT sales_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND sales_invoice_id IS NOT NULL GROUP BY sales_invoice_id) AS x WHERE sales_invoices.id = x.iid;
    UPDATE purchase_invoices SET paid_amount = purchase_invoices.paid_amount + x.amt, payment_status = CASE WHEN purchase_invoices.paid_amount + x.amt >= purchase_invoices.total THEN 'paid' ELSE 'partial' END FROM (SELECT purchase_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND purchase_invoice_id IS NOT NULL GROUP BY purchase_invoice_id) AS x WHERE purchase_invoices.id = x.iid;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_post BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status = 'draft' AND NEW.status = 'posted' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_post();

CREATE FUNCTION fn_trg_vouchers_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    UPDATE sales_invoices SET paid_amount = sales_invoices.paid_amount - x.amt, payment_status = CASE WHEN sales_invoices.paid_amount - x.amt <= 0 THEN 'unpaid' ELSE 'partial' END FROM (SELECT sales_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND sales_invoice_id IS NOT NULL GROUP BY sales_invoice_id) AS x WHERE sales_invoices.id = x.iid;
    UPDATE purchase_invoices SET paid_amount = purchase_invoices.paid_amount - x.amt, payment_status = CASE WHEN purchase_invoices.paid_amount - x.amt <= 0 THEN 'unpaid' ELSE 'partial' END FROM (SELECT purchase_invoice_id AS iid, SUM(amount) AS amt FROM payment_allocations WHERE voucher_id = OLD.id AND purchase_invoice_id IS NOT NULL GROUP BY purchase_invoice_id) AS x WHERE purchase_invoices.id = x.iid;
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_vouchers_reverse BEFORE UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_vouchers_reverse();

CREATE FUNCTION fn_trg_sales_invoices_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM sales_returns r WHERE r.original_invoice_id = OLD.id AND r.status = 'posted') THEN RAISE EXCEPTION 'Reverse the posted returns of this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a JOIN vouchers v ON v.id = a.voucher_id WHERE a.sales_invoice_id = OLD.id AND v.status = 'posted') THEN RAISE EXCEPTION 'Reverse the receipts allocated to this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'sales_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'sales_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_reverse BEFORE UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_invoices_reverse();

CREATE FUNCTION fn_trg_purchase_invoices_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM purchase_returns r WHERE r.original_invoice_id = OLD.id AND r.status = 'posted') THEN RAISE EXCEPTION 'Reverse the posted returns of this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM payment_allocations a JOIN vouchers v ON v.id = a.voucher_id WHERE a.purchase_invoice_id = OLD.id AND v.status = 'posted') THEN RAISE EXCEPTION 'Reverse the payments allocated to this invoice first' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'purchase_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'purchase_invoices' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_reverse BEFORE UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_invoices_reverse();

CREATE FUNCTION fn_trg_sales_returns_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'sales_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'sales_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_sales_returns_reverse BEFORE UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_sales_returns_reverse();

CREATE FUNCTION fn_trg_purchase_returns_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'purchase_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'purchase_returns' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_reverse BEFORE UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_purchase_returns_reverse();

CREATE FUNCTION fn_trg_stock_adjustments_reverse() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF NEW.reversed_by IS NULL OR NEW.reversed_at IS NULL OR NEW.reversal_reason IS NULL THEN RAISE EXCEPTION 'reversed_by, reversed_at and reversal_reason are required' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF OLD.journal_entry_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM journal_entries j WHERE j.id = NEW.reversal_entry_id AND j.status = 'posted' AND j.entry_kind = 'reversal' AND j.reverses_entry_id = OLD.journal_entry_id) THEN RAISE EXCEPTION 'A posted reversal journal entry is required to reverse this document' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    IF EXISTS (SELECT 1 FROM stock_movements m JOIN batches b ON b.id = m.batch_id WHERE m.source_type = 'stock_adjustments' AND m.source_id = OLD.id AND m.movement_type <> 'reversal' AND b.qty_on_hand - m.quantity_change < 0) THEN RAISE EXCEPTION 'Reversal would make batch stock negative (stock already consumed)' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    INSERT INTO stock_movements (branch_id, batch_id, medicine_id, movement_type, quantity_change, unit_cost, movement_date, source_type, source_id, source_line_id, user_id) SELECT m.branch_id, m.batch_id, m.medicine_id, 'reversal', -m.quantity_change, m.unit_cost, (NEW.reversed_at)::date, m.source_type, m.source_id, m.source_line_id, NEW.reversed_by FROM stock_movements m WHERE m.source_type = 'stock_adjustments' AND m.source_id = OLD.id AND m.movement_type <> 'reversal';
    RETURN NEW;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_reverse BEFORE UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status = 'posted' AND NEW.status = 'reversed' AND (NOT ansary_remote())) EXECUTE FUNCTION fn_trg_stock_adjustments_reverse();

CREATE FUNCTION fn_trg_sales_invoices_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_invoices', CAST(NEW.id AS text), NEW.invoice_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_sales_invoices_audit AFTER UPDATE OF status ON sales_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_sales_invoices_audit();

CREATE FUNCTION fn_trg_purchase_invoices_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_invoices', CAST(NEW.id AS text), NEW.invoice_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_purchase_invoices_audit AFTER UPDATE OF status ON purchase_invoices FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_purchase_invoices_audit();

CREATE FUNCTION fn_trg_sales_returns_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'sales_returns', CAST(NEW.id AS text), NEW.return_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_sales_returns_audit AFTER UPDATE OF status ON sales_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_sales_returns_audit();

CREATE FUNCTION fn_trg_purchase_returns_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'purchase_returns', CAST(NEW.id AS text), NEW.return_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_purchase_returns_audit AFTER UPDATE OF status ON purchase_returns FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_purchase_returns_audit();

CREATE FUNCTION fn_trg_vouchers_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'vouchers', CAST(NEW.id AS text), NEW.voucher_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.amount));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_vouchers_audit AFTER UPDATE OF status ON vouchers FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_vouchers_audit();

CREATE FUNCTION fn_trg_stock_adjustments_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_adjustments', CAST(NEW.id AS text), NEW.adj_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NULL));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_adjustments_audit AFTER UPDATE OF status ON stock_adjustments FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_stock_adjustments_audit();

CREATE FUNCTION fn_trg_journal_entries_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (COALESCE(NEW.reversed_by, NEW.posted_by), NEW.branch_id, 'status:' || OLD.status || '->' || NEW.status, 'journal_entries', CAST(NEW.id AS text), NEW.entry_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status, 'amount', NEW.total_debit));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_journal_entries_audit AFTER UPDATE OF status ON journal_entries FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_journal_entries_audit();

CREATE FUNCTION fn_trg_stock_transfers_audit() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (user_id, branch_id, action, entity_type, entity_id, ref_no, old_values, new_values) VALUES (NEW.posted_by, NEW.from_branch_id, 'status:' || OLD.status || '->' || NEW.status, 'stock_transfers', CAST(NEW.id AS text), NEW.transfer_no, jsonb_build_object('status', OLD.status), jsonb_build_object('status', NEW.status));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_stock_transfers_audit AFTER UPDATE OF status ON stock_transfers FOR EACH ROW
WHEN (OLD.status <> NEW.status) EXECUTE FUNCTION fn_trg_stock_transfers_audit();

CREATE FUNCTION fn_trg_users_audit_insert() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, new_values) VALUES ('user:created', 'users', CAST(NEW.id AS text), NEW.username, jsonb_build_object('role_id', NEW.role_id));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_users_audit_insert AFTER INSERT ON users FOR EACH ROW EXECUTE FUNCTION fn_trg_users_audit_insert();

CREATE FUNCTION fn_trg_users_audit_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    INSERT INTO audit_log (action, entity_type, entity_id, ref_no, old_values, new_values) VALUES ('user:updated', 'users', CAST(NEW.id AS text), NEW.username, jsonb_build_object('is_active', OLD.is_active, 'role_id', OLD.role_id), jsonb_build_object('is_active', NEW.is_active, 'role_id', NEW.role_id, 'password_changed', (NEW.password_hash <> OLD.password_hash)));
    RETURN NULL;
END
$fn$;
CREATE TRIGGER trg_users_audit_update AFTER UPDATE OF is_active, role_id, password_hash ON users FOR EACH ROW
WHEN (OLD.is_active IS DISTINCT FROM NEW.is_active OR OLD.role_id <> NEW.role_id OR OLD.password_hash <> NEW.password_hash) EXECUTE FUNCTION fn_trg_users_audit_update();

CREATE FUNCTION ansary_touch() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    NEW.version := OLD.version + 1;
    NEW.updated_at := now();
    RETURN NEW;
END
$fn$;

CREATE FUNCTION ansary_log_change() RETURNS trigger LANGUAGE plpgsql AS $fn$
DECLARE
    j jsonb;
    rid text;
BEGIN
    IF TG_OP = 'DELETE' THEN j := to_jsonb(OLD); ELSE j := to_jsonb(NEW); END IF;
    rid := j ->> TG_ARGV[0];
    INSERT INTO change_log (table_name, row_id, op, version, branch_id, origin_device_id)
    VALUES (TG_TABLE_NAME, rid, lower(TG_OP), NULLIF(j ->> 'version', '')::integer,
            COALESCE(NULLIF(j ->> 'branch_id', ''), NULLIF(j ->> 'from_branch_id', ''))::uuid,
            j ->> 'origin_device_id');
    PERFORM pg_notify('ansary_changes', json_build_object('t', TG_TABLE_NAME, 'id', rid, 'op', lower(TG_OP))::text);
    RETURN NULL;
END
$fn$;

-- Allocates the next document number, e.g. SI-HO-00-FY2026-000001 (atomic, row-locked).
CREATE FUNCTION next_doc_no(p_doc_type text, p_branch uuid, p_fy uuid, p_device text DEFAULT '00')
RETURNS text LANGUAGE plpgsql AS $fn$
DECLARE
    s number_sequences%ROWTYPE;
    b text;
    fy text;
BEGIN
    UPDATE number_sequences SET next_number = next_number + 1
     WHERE doc_type = p_doc_type AND branch_id = p_branch AND financial_year_id = p_fy AND device_code = p_device
    RETURNING * INTO s;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'No number sequence configured for % / % / %', p_doc_type, p_branch, p_device;
    END IF;
    SELECT code INTO b FROM branches WHERE id = p_branch;
    SELECT name INTO fy FROM financial_years WHERE id = p_fy;
    RETURN s.prefix || '-' || b || '-' || s.device_code || '-' || fy || '-' || lpad((s.next_number - 1)::text, s.padding, '0');
END
$fn$;

CREATE TRIGGER trg_currencies_touch BEFORE UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_currencies_changelog_insert AFTER INSERT ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_currencies_changelog_update AFTER UPDATE OF code, name, name_ps, symbol, decimals, is_base, is_active ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_currencies_changelog_delete AFTER DELETE ON currencies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('code');
CREATE TRIGGER trg_exchange_rates_touch BEFORE UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_exchange_rates_changelog_insert AFTER INSERT ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_exchange_rates_changelog_update AFTER UPDATE OF id, from_currency, to_currency, rate, effective_date, source ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_exchange_rates_changelog_delete AFTER DELETE ON exchange_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_touch BEFORE UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_branches_changelog_insert AFTER INSERT ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_changelog_update AFTER UPDATE OF id, code, name, name_ps, address, phone, email, is_head_office, is_active, deleted_at ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_branches_changelog_delete AFTER DELETE ON branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_touch BEFORE UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_company_profile_changelog_insert AFTER INSERT ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_changelog_update AFTER UPDATE OF id, singleton, name, name_ps, tagline, logo_path, address, phone, email, website, tax_number, license_number, base_currency, date_format, language, invoice_footer, invoice_save_dir, developer, brand ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_company_profile_changelog_delete AFTER DELETE ON company_profile FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_touch BEFORE UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_settings_changelog_insert AFTER INSERT ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_changelog_update AFTER UPDATE OF id, scope_type, scope_id, key, value, value_type ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_settings_changelog_delete AFTER DELETE ON settings FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_touch BEFORE UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_tax_rates_changelog_insert AFTER INSERT ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_changelog_update AFTER UPDATE OF id, name, rate_pct, is_default, is_active ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_tax_rates_changelog_delete AFTER DELETE ON tax_rates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_touch BEFORE UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_invoice_templates_changelog_insert AFTER INSERT ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_changelog_update AFTER UPDATE OF id, name, doc_type, paper, config, is_default ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_invoice_templates_changelog_delete AFTER DELETE ON invoice_templates FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_touch BEFORE UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_roles_changelog_insert AFTER INSERT ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_changelog_update AFTER UPDATE OF id, code, name, name_ps, description, is_system ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_roles_changelog_delete AFTER DELETE ON roles FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_touch BEFORE UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_permissions_changelog_insert AFTER INSERT ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_changelog_update AFTER UPDATE OF id, code, module, action, description ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_permissions_changelog_delete AFTER DELETE ON permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_touch BEFORE UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_role_permissions_changelog_insert AFTER INSERT ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_changelog_update AFTER UPDATE OF id, role_id, permission_id ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_role_permissions_changelog_delete AFTER DELETE ON role_permissions FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_touch BEFORE UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_users_changelog_insert AFTER INSERT ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_changelog_update AFTER UPDATE OF id, username, password_hash, password_algo, full_name, email, phone, role_id, default_branch_id, language, is_active, must_change_password, password_changed_at, session_timeout_minutes, deleted_at ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_users_changelog_delete AFTER DELETE ON users FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_touch BEFORE UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_user_branches_changelog_insert AFTER INSERT ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_changelog_update AFTER UPDATE OF id, user_id, branch_id ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_branches_changelog_delete AFTER DELETE ON user_branches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_touch BEFORE UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_user_permission_overrides_changelog_insert AFTER INSERT ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_changelog_update AFTER UPDATE OF id, user_id, permission_id, granted ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_user_permission_overrides_changelog_delete AFTER DELETE ON user_permission_overrides FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_login_history_changelog_insert AFTER INSERT ON login_history FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_audit_log_changelog_insert AFTER INSERT ON audit_log FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_touch BEFORE UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_attachments_changelog_insert AFTER INSERT ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_changelog_update AFTER UPDATE OF id, entity_type, entity_id, file_name, mime_type, storage_path, sha256, size_bytes, uploaded_by ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_attachments_changelog_delete AFTER DELETE ON attachments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_touch BEFORE UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_categories_changelog_insert AFTER INSERT ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_changelog_update AFTER UPDATE OF id, name, name_ps, parent_id, is_active, deleted_at ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_categories_changelog_delete AFTER DELETE ON categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_touch BEFORE UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_dosage_forms_changelog_insert AFTER INSERT ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_changelog_update AFTER UPDATE OF id, name, name_ps ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_dosage_forms_changelog_delete AFTER DELETE ON dosage_forms FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_touch BEFORE UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_units_changelog_insert AFTER INSERT ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_changelog_update AFTER UPDATE OF id, code, name, name_ps ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_units_changelog_delete AFTER DELETE ON units FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_touch BEFORE UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_companies_changelog_insert AFTER INSERT ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_changelog_update AFTER UPDATE OF id, code, name, name_ps, kind, country, address, phone, email, contact_person, is_active, deleted_at ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_companies_changelog_delete AFTER DELETE ON companies FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_touch BEFORE UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_medicines_changelog_insert AFTER INSERT ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_changelog_update AFTER UPDATE OF id, product_code, barcode, name, name_ps, generic_name, brand_name, manufacturer_id, company_id, category_id, composition, strength, dosage_form_id, packing, unit_id, box_quantity, purchase_price, wholesale_price, retail_price, min_stock, max_stock, rack_number, country_of_origin, registration_number, image_attachment_id, is_active, notes, deleted_at ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicines_changelog_delete AFTER DELETE ON medicines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_touch BEFORE UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_medicine_barcodes_changelog_insert AFTER INSERT ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_changelog_update AFTER UPDATE OF id, medicine_id, barcode, barcode_format, is_primary, pack_qty ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_barcodes_changelog_delete AFTER DELETE ON medicine_barcodes FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_medicine_price_history_changelog_insert AFTER INSERT ON medicine_price_history FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_touch BEFORE UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_customers_changelog_insert AFTER INSERT ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_changelog_update AFTER UPDATE OF id, code, name, name_ps, business_name, phone, address, customer_type, opening_balance, opening_balance_date, credit_limit, contact_person, notes, currency_code, branch_id, is_active, deleted_at ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_customers_changelog_delete AFTER DELETE ON customers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_touch BEFORE UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_suppliers_changelog_insert AFTER INSERT ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_changelog_update AFTER UPDATE OF id, code, name, name_ps, business_name, company_id, phone, address, opening_balance, opening_balance_date, contact_person, notes, currency_code, is_active, deleted_at ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_suppliers_changelog_delete AFTER DELETE ON suppliers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_touch BEFORE UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_financial_years_changelog_insert AFTER INSERT ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_changelog_update AFTER UPDATE OF id, name, start_date, end_date, is_closed, closed_at, closed_by ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_financial_years_changelog_delete AFTER DELETE ON financial_years FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_touch BEFORE UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_number_sequences_changelog_insert AFTER INSERT ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_changelog_update AFTER UPDATE OF id, doc_type, branch_id, financial_year_id, device_code, prefix, padding, next_number ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_number_sequences_changelog_delete AFTER DELETE ON number_sequences FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_touch BEFORE UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_accounts_changelog_insert AFTER INSERT ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_changelog_update AFTER UPDATE OF id, code, name, name_ps, account_type, normal_side, parent_id, system_key, is_postable, is_system, is_active, cash_flow_category ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_accounts_changelog_delete AFTER DELETE ON accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_touch BEFORE UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_bank_accounts_changelog_insert AFTER INSERT ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_changelog_update AFTER UPDATE OF id, branch_id, account_id, bank_name, account_number, currency_code, is_active ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_bank_accounts_changelog_delete AFTER DELETE ON bank_accounts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_touch BEFORE UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_expense_categories_changelog_insert AFTER INSERT ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_changelog_update AFTER UPDATE OF id, name, name_ps, account_id, is_active ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_expense_categories_changelog_delete AFTER DELETE ON expense_categories FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_touch BEFORE UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_journal_entries_changelog_insert AFTER INSERT ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_changelog_update AFTER UPDATE OF id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, description, currency_code, exchange_rate, status, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, reverses_entry_id, total_debit, total_credit, client_uuid ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_entries_changelog_delete AFTER DELETE ON journal_entries FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_touch BEFORE UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_journal_lines_changelog_insert AFTER INSERT ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_changelog_update AFTER UPDATE OF id, entry_id, line_no, account_id, debit, credit, currency_code, exchange_rate, amount_fx, customer_id, supplier_id, branch_id, description ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_journal_lines_changelog_delete AFTER DELETE ON journal_lines FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_touch BEFORE UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_batches_changelog_insert AFTER INSERT ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_changelog_update AFTER UPDATE OF id, branch_id, medicine_id, batch_no, mfg_date, expiry_date, unit_cost, wholesale_price, retail_price, supplier_id, is_blocked, block_reason ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_batches_changelog_delete AFTER DELETE ON batches FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_movements_changelog_insert AFTER INSERT ON stock_movements FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_touch BEFORE UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_adjustments_changelog_insert AFTER INSERT ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_changelog_update AFTER UPDATE OF id, branch_id, adj_no, adj_date, adj_type, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustments_changelog_delete AFTER DELETE ON stock_adjustments FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_touch BEFORE UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_adjustment_items_changelog_insert AFTER INSERT ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_changelog_update AFTER UPDATE OF id, adjustment_id, line_no, batch_id, quantity_change, unit_cost, reason ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_adjustment_items_changelog_delete AFTER DELETE ON stock_adjustment_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_touch BEFORE UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_transfers_changelog_insert AFTER INSERT ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_changelog_update AFTER UPDATE OF id, transfer_no, from_branch_id, to_branch_id, transfer_date, status, notes, posted_at, posted_by ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfers_changelog_delete AFTER DELETE ON stock_transfers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_touch BEFORE UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_stock_transfer_items_changelog_insert AFTER INSERT ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_changelog_update AFTER UPDATE OF id, transfer_id, line_no, batch_id, quantity, dest_batch_id ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_stock_transfer_items_changelog_delete AFTER DELETE ON stock_transfer_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_touch BEFORE UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_physical_counts_changelog_insert AFTER INSERT ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_changelog_update AFTER UPDATE OF id, branch_id, count_no, count_date, status, adjustment_id, notes ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_counts_changelog_delete AFTER DELETE ON physical_counts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_touch BEFORE UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_physical_count_items_changelog_insert AFTER INSERT ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_changelog_update AFTER UPDATE OF id, count_id, batch_id, system_qty, counted_qty, notes ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_physical_count_items_changelog_delete AFTER DELETE ON physical_count_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_touch BEFORE UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_orders_changelog_insert AFTER INSERT ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_changelog_update AFTER UPDATE OF id, branch_id, po_no, supplier_id, po_date, expected_date, currency_code, exchange_rate, status, subtotal, discount_amount, tax_amount, total, notes, created_by ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_orders_changelog_delete AFTER DELETE ON purchase_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_touch BEFORE UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_order_items_changelog_insert AFTER INSERT ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_changelog_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total, received_quantity ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_order_items_changelog_delete AFTER DELETE ON purchase_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_touch BEFORE UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_goods_receipts_changelog_insert AFTER INSERT ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_changelog_update AFTER UPDATE OF id, branch_id, grn_no, purchase_order_id, supplier_id, receipt_date, status, notes, received_by ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipts_changelog_delete AFTER DELETE ON goods_receipts FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_touch BEFORE UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_goods_receipt_items_changelog_insert AFTER INSERT ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_changelog_update AFTER UPDATE OF id, receipt_id, line_no, po_item_id, medicine_id, batch_no, mfg_date, expiry_date, quantity, free_quantity ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_goods_receipt_items_changelog_delete AFTER DELETE ON goods_receipt_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_touch BEFORE UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_invoices_changelog_insert AFTER INSERT ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_changelog_update AFTER UPDATE OF id, branch_id, invoice_no, supplier_id, supplier_invoice_no, purchase_order_id, goods_receipt_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, additional_costs, round_off, total, paid_amount, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoices_changelog_delete AFTER DELETE ON purchase_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_touch BEFORE UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_invoice_items_changelog_insert AFTER INSERT ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_changelog_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, batch_no, mfg_date, expiry_date, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, additional_cost, line_total, landed_unit_cost, po_item_id ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_invoice_items_changelog_delete AFTER DELETE ON purchase_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_touch BEFORE UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_returns_changelog_insert AFTER INSERT ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_changelog_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, supplier_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_returns_changelog_delete AFTER DELETE ON purchase_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_touch BEFORE UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_purchase_return_items_changelog_insert AFTER INSERT ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_changelog_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_purchase_return_items_changelog_delete AFTER DELETE ON purchase_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_touch BEFORE UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_orders_changelog_insert AFTER INSERT ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_changelog_update AFTER UPDATE OF id, branch_id, doc_type, doc_no, customer_id, doc_date, valid_until, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, total, status, notes, created_by ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_orders_changelog_delete AFTER DELETE ON sales_orders FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_touch BEFORE UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_order_items_changelog_insert AFTER INSERT ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_changelog_update AFTER UPDATE OF id, order_id, line_no, medicine_id, quantity, free_quantity, unit_price, discount_pct, tax_pct, line_total ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_order_items_changelog_delete AFTER DELETE ON sales_order_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_touch BEFORE UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_invoices_changelog_insert AFTER INSERT ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_changelog_update AFTER UPDATE OF id, branch_id, invoice_no, sale_type, payment_type, customer_id, sales_order_id, invoice_date, due_date, currency_code, exchange_rate, subtotal, discount_amount, tax_amount, round_off, total, previous_balance, paid_amount, payment_method, payment_status, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoices_changelog_delete AFTER DELETE ON sales_invoices FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_touch BEFORE UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_invoice_items_changelog_insert AFTER INSERT ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_changelog_update AFTER UPDATE OF id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, discount_pct, discount_amount, tax_pct, tax_amount, line_total, cost_price, gross_profit ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_invoice_items_changelog_delete AFTER DELETE ON sales_invoice_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_touch BEFORE UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_returns_changelog_insert AFTER INSERT ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_changelog_update AFTER UPDATE OF id, branch_id, return_no, original_invoice_id, customer_id, return_date, currency_code, exchange_rate, subtotal, tax_amount, total, refund_method, reason, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_returns_changelog_delete AFTER DELETE ON sales_returns FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_touch BEFORE UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_sales_return_items_changelog_insert AFTER INSERT ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_changelog_update AFTER UPDATE OF id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, tax_amount, line_total, cost_price, reason ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_sales_return_items_changelog_delete AFTER DELETE ON sales_return_items FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_touch BEFORE UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_vouchers_changelog_insert AFTER INSERT ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_changelog_update AFTER UPDATE OF id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, supplier_id, expense_category_id, cash_bank_account_id, counter_account_id, payment_method, amount, currency_code, exchange_rate, reference, description, attachment_id, status, notes, posted_at, posted_by, reversed_at, reversed_by, reversal_reason, journal_entry_id, reversal_entry_id, client_uuid ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_vouchers_changelog_delete AFTER DELETE ON vouchers FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_touch BEFORE UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_payment_allocations_changelog_insert AFTER INSERT ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_changelog_update AFTER UPDATE OF id, voucher_id, sales_invoice_id, purchase_invoice_id, amount ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_payment_allocations_changelog_delete AFTER DELETE ON payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_touch BEFORE UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_plans_changelog_insert AFTER INSERT ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_changelog_update AFTER UPDATE OF id, branch_id, sales_invoice_id, customer_id, plan_no, currency_code, principal_amount, installment_count, frequency, first_due_date, status, notes, created_by ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_plans_changelog_delete AFTER DELETE ON installment_plans FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_touch BEFORE UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_schedule_changelog_insert AFTER INSERT ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_changelog_update AFTER UPDATE OF id, plan_id, installment_no, due_date, amount, paid_amount, status, paid_at, notes ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_schedule_changelog_delete AFTER DELETE ON installment_schedule FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_touch BEFORE UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
WHEN (NEW.version = OLD.version AND NOT ansary_remote())
EXECUTE FUNCTION ansary_touch();
CREATE TRIGGER trg_installment_payment_allocations_changelog_insert AFTER INSERT ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_changelog_update AFTER UPDATE OF id, voucher_id, installment_schedule_id, amount ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');
CREATE TRIGGER trg_installment_payment_allocations_changelog_delete AFTER DELETE ON installment_payment_allocations FOR EACH ROW
EXECUTE FUNCTION ansary_log_change('id');

-- Fast medicine search for 100,000+ rows (prefix + substring + typo tolerant).
CREATE INDEX ix_medicines_name_prefix ON medicines (lower(name) text_pattern_ops);
CREATE INDEX ix_medicines_generic_prefix ON medicines (lower(generic_name) text_pattern_ops);
CREATE INDEX ix_medicines_name_trgm ON medicines USING gin (lower(name) gin_trgm_ops);
CREATE INDEX ix_medicines_generic_trgm ON medicines USING gin (lower(generic_name) gin_trgm_ops);
CREATE INDEX ix_medicines_brand_trgm ON medicines USING gin (lower(brand_name) gin_trgm_ops);
CREATE INDEX ix_medicines_composition_trgm ON medicines USING gin (lower(composition) gin_trgm_ops);
CREATE INDEX ix_companies_name_trgm ON companies USING gin (lower(name) gin_trgm_ops);
CREATE INDEX ix_customers_name_trgm ON customers USING gin (lower(name) gin_trgm_ops);

CREATE TABLE sync_master_apply_log (
    event_uuid text PRIMARY KEY,
    device_id uuid NOT NULL REFERENCES sync_devices(id) ON DELETE RESTRICT,
    table_name text NOT NULL,
    row_id text NOT NULL,
    status text NOT NULL CHECK (status IN ('applied','conflict')),
    reason text,
    applied_version integer,
    processed_at timestamptz NOT NULL
);
CREATE INDEX ix_sync_master_apply_log_device ON sync_master_apply_log(device_id, processed_at);

CREATE OR REPLACE FUNCTION fn_trg_due_reminder_history_append_only_update() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'due_reminder_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN NEW;
END
$fn$;

CREATE OR REPLACE FUNCTION fn_trg_due_reminder_history_append_only_delete() RETURNS trigger LANGUAGE plpgsql AS $fn$
BEGIN
    IF 1 = 1 THEN RAISE EXCEPTION 'due_reminder_history is append-only' USING ERRCODE = 'integrity_constraint_violation'; END IF;
    RETURN OLD;
END
$fn$;

DROP TRIGGER IF EXISTS trg_due_reminder_history_append_only_update ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_append_only_update BEFORE UPDATE ON due_reminder_history FOR EACH ROW WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_due_reminder_history_append_only_update();

DROP TRIGGER IF EXISTS trg_due_reminder_history_append_only_delete ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_append_only_delete BEFORE DELETE ON due_reminder_history FOR EACH ROW WHEN ((NOT ansary_remote())) EXECUTE FUNCTION fn_trg_due_reminder_history_append_only_delete();

DROP TRIGGER IF EXISTS trg_due_reminder_history_changelog_insert ON due_reminder_history;
CREATE TRIGGER trg_due_reminder_history_changelog_insert AFTER INSERT ON due_reminder_history FOR EACH ROW EXECUTE FUNCTION ansary_log_change('id');
