"""ANSARY ERP - SQLite schema/trigger test suite.

Run:  python -m unittest discover -s database/tests -v
Covers: migrations, seeds, sample-data reconciliation, every mandatory data-integrity rule,
sync bookkeeping, search and 100,000-medicine performance.
"""
import hashlib
import os
import shutil
import sqlite3
import sys
import tempfile
import time
import unittest
import uuid
from datetime import date, datetime
from decimal import Decimal as D

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "tools", "schema"))
import migrate_sqlite as mig  # noqa: E402
import sample  # noqa: E402
import seeds  # noqa: E402

TEMPLATE = None
TMPDIR = None
ADMIN = seeds.ADMIN_ID
HO = seeds.BRANCH_ID


def setUpModule():
    global TEMPLATE, TMPDIR
    TMPDIR = tempfile.mkdtemp()
    path = os.path.join(TMPDIR, "template.db")
    con = mig.connect(path)
    mig.migrate(con)
    mig.load_seed(con, "production")
    mig.load_seed(con, "sample")
    con.close()
    sample.generate()          # populates sample.BATCH/CUST/SUPP expectations
    TEMPLATE = path


def tearDownModule():
    shutil.rmtree(TMPDIR, ignore_errors=True)


def fresh():
    src = sqlite3.connect(TEMPLATE)
    con = sqlite3.connect(":memory:", isolation_level=None)
    src.backup(con)
    src.close()
    con.execute("PRAGMA foreign_keys = ON")
    return con


def one(con, sql, *a):
    r = con.execute(sql, a).fetchone()
    return r[0] if r else None


def gid():
    return str(uuid.uuid4())


def acc(con, code):
    return one(con, "SELECT id FROM accounts WHERE code = ?", code)


def batch(con, bno, branch=HO):
    return one(con, "SELECT id FROM batches WHERE batch_no = ? AND branch_id = ?", bno, branch)


def qty(con, bno, branch=HO):
    return D(str(one(con, "SELECT qty_on_hand FROM batches WHERE batch_no = ? AND branch_id = ?", bno, branch)))


def post_journal(con, no, jdate, lines, source_type=None, source_id=None, kind="manual", fy=None, reverses=None):
    jid = gid()
    td = sum(D(str(l[1])) for l in lines)
    tc = sum(D(str(l[2])) for l in lines)
    fy = fy or one(con, "SELECT id FROM financial_years WHERE ? BETWEEN start_date AND end_date", jdate)
    con.execute("INSERT INTO journal_entries (id, branch_id, entry_no, entry_date, financial_year_id, entry_kind, source_type, source_id, "
                "total_debit, total_credit, reverses_entry_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (jid, HO, no, jdate, fy, kind, source_type, source_id, str(td), str(tc), reverses))
    for i, (code, dr, cr) in enumerate(lines, 1):
        con.execute("INSERT INTO journal_lines (id, entry_id, line_no, account_id, debit, credit) VALUES (?,?,?,?,?,?)",
                    (gid(), jid, i, acc(con, code), str(dr), str(cr)))
    con.execute("UPDATE journal_entries SET status='posted', posted_at='2026-11-14T10:00:00Z', posted_by=? WHERE id=?", (ADMIN, jid))
    return jid


def make_sale(con, no, jdate, items, ptype="cash", cust=None, paid=None, post=True, journal=True, sale_id=None):
    """items: (batch_no, qty, free, unit_price)"""
    sid = sale_id or gid()
    sub = sum(D(str(q)) * D(str(p)) for _, q, _, p in items)
    paid = sub if paid is None else D(str(paid))
    con.execute("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, customer_id, invoice_date, subtotal, total, "
                "paid_amount, payment_status) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (sid, HO, no, "retail", ptype, cust, jdate, str(sub), str(sub), str(paid), "paid" if paid >= sub else "unpaid"))
    for i, (bno, q, f, p) in enumerate(items, 1):
        bid = batch(con, bno)
        med = one(con, "SELECT medicine_id FROM batches WHERE id=?", bid)
        con.execute("INSERT INTO sales_invoice_items (id, invoice_id, line_no, medicine_id, batch_id, quantity, free_quantity, unit_price, line_total) "
                    "VALUES (?,?,?,?,?,?,?,?,?)", (gid(), sid, i, med, bid, q, f, str(p), str(D(str(q)) * D(str(p)))))
    jid = None
    if journal:
        jid = post_journal(con, "JV-" + no, jdate, [("1010", sub, 0), ("4100", 0, sub)], "sales_invoices", sid, "sales")
    if post:
        con.execute("UPDATE sales_invoices SET status='posted', posted_at='2026-11-14T10:00:00Z', posted_by=?, journal_entry_id=? WHERE id=?",
                    (ADMIN, jid, sid))
    return sid


class DB(unittest.TestCase):
    def setUp(self):
        self.con = fresh()

    def tearDown(self):
        self.con.close()

    def fails(self, sql, params=(), contains=None):
        with self.assertRaises(sqlite3.DatabaseError) as cm:
            self.con.execute(sql, params)
        if contains:
            self.assertIn(contains.lower(), str(cm.exception).lower())
        return cm.exception


# ---------------------------------------------------------------- schema & seeds
class TestSchemaAndSeeds(DB):
    def test_integrity_and_foreign_keys(self):
        self.assertEqual(one(self.con, "PRAGMA integrity_check"), "ok")
        self.assertEqual(self.con.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_migration_runner_is_idempotent_and_detects_tampering(self):
        path = os.path.join(TMPDIR, "m.db")
        con = mig.connect(path)
        first = mig.migrate(con)
        self.assertEqual(len(first), 27)
        self.assertEqual(one(con, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='sync_device_token_audit'"), 1)
        self.assertEqual(one(con, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='sync_master_apply_log'"), 1)
        self.assertEqual(one(con, "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='due_reminder_history'"), 1)
        self.assertEqual(one(con, "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'trg_due_reminder_history_append_only_%'"), 2)
        self.assertEqual(one(con, "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' AND name='trg_due_reminder_history_outbox_insert'"), 1)
        self.assertEqual(mig.migrate(con), [])
        con.execute("UPDATE schema_migrations SET checksum='bad' WHERE version='001_core.sql'")
        with self.assertRaises(SystemExit):
            mig.migrate(con)
        con.close()

    def test_stage52_device_token_lifecycle_audit_migration(self):
        from pathlib import Path
        sql = Path(ROOT, "database/sqlite/migrations/020_sync_device_token_lifecycle.sql").read_text(encoding="utf-8")
        self.assertIn("sync_device_token_audit", sql)
        self.assertIn("actor_user_id", sql)
        self.assertIn("'rotated','revoked'", sql)

    def test_stage51_device_token_hash_migration(self):
        columns = {row[1] for row in self.con.execute("PRAGMA table_info(sync_devices)")}
        self.assertIn("token_sha256", columns)
        self.assertIsNone(one(self.con, "SELECT token_sha256 FROM sync_devices LIMIT 1") if one(self.con, "SELECT COUNT(*) FROM sync_devices") else None)

    def test_roles_and_permissions(self):
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM roles"), 8)
        total = one(self.con, "SELECT COUNT(*) FROM permissions")
        sa = one(self.con, "SELECT COUNT(*) FROM role_permissions rp JOIN roles r ON r.id=rp.role_id WHERE r.code='super_admin'")
        self.assertEqual(sa, total)
        has = lambda role, perm: one(self.con, "SELECT COUNT(*) FROM role_permissions rp JOIN roles r ON r.id=rp.role_id "  # noqa
                                     "JOIN permissions p ON p.id=rp.permission_id WHERE r.code=? AND p.code=?", role, perm)
        self.assertEqual(has("viewer", "sales.create"), 0)
        self.assertEqual(has("sales_operator", "sales.post"), 1)
        self.assertEqual(has("sales_operator", "sales.reverse"), 0)
        self.assertEqual(has("administrator", "backup.restore"), 0)
        self.assertEqual(has("accountant", "accounts.post"), 1)

    def test_currencies_exactly_one_base(self):
        self.assertEqual(set(r[0] for r in self.con.execute("SELECT code FROM currencies")), {"AFN", "USD", "PKR", "INR"})
        self.assertEqual(one(self.con, "SELECT code FROM currencies WHERE is_base"), "AFN")
        self.fails("UPDATE currencies SET is_base = 1 WHERE code = 'USD'")

    def test_chart_of_accounts_and_system_keys(self):
        for key in ("CASH", "BANK", "INVENTORY", "AR", "AP", "SALES", "SALES_RETURNS", "COGS", "CAPITAL", "FX_GAIN", "FX_LOSS"):
            self.assertEqual(one(self.con, "SELECT COUNT(*) FROM accounts WHERE system_key=?", key), 1, key)
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM accounts WHERE parent_id IS NULL AND is_postable"), 0)
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM expense_categories"), 8)

    def test_bootstrap_admin_has_no_usable_password(self):
        self.assertEqual(one(self.con, "SELECT password_hash FROM users WHERE username='admin'"), "!")
        self.assertEqual(one(self.con, "SELECT must_change_password FROM users WHERE username='admin'"), 1)

    def test_username_must_be_lowercase(self):
        self.fails("INSERT INTO users (id, username, password_hash, full_name, role_id) VALUES (?,?,?,?,?)",
                   (gid(), "BadName", "x", "x", seeds.role_id("viewer")))


# ---------------------------------------------------------- sample reconciliation
class TestSampleReconciliation(DB):
    def test_no_integrity_issues(self):
        self.assertEqual(self.con.execute("SELECT * FROM v_integrity_issues").fetchall(), [])

    def test_trial_balance_balanced(self):
        d, c = self.con.execute("SELECT round(sum(debit_balance),4), round(sum(credit_balance),4) FROM v_trial_balance").fetchone()
        self.assertEqual(d, c)
        self.assertGreater(d, 0)

    def test_inventory_account_equals_stock_valuation(self):
        inv = one(self.con, "SELECT balance FROM v_account_balance WHERE code='1100'")
        val = one(self.con, "SELECT round(sum(stock_value),4) FROM v_batch_stock")
        self.assertEqual(inv, val)

    def test_receivables_and_payables_match_subledgers(self):
        self.assertEqual(one(self.con, "SELECT balance FROM v_account_balance WHERE code='1200'"), one(self.con, "SELECT sum(balance) FROM v_customer_balance"))
        self.assertEqual(one(self.con, "SELECT balance FROM v_account_balance WHERE code='2100'"), one(self.con, "SELECT sum(balance) FROM v_supplier_balance"))

    def test_batch_quantities_match_independent_simulation(self):
        for (med, bno, exp), b in sample.BATCH.items():
            got = one(self.con, "SELECT qty_on_hand FROM batches WHERE batch_no=? AND branch_id=?", bno, HO)
            self.assertEqual(D(str(got)), b["qty"], bno)
            cost = one(self.con, "SELECT unit_cost FROM batches WHERE batch_no=? AND branch_id=?", bno, HO)
            self.assertEqual(D(str(cost)), b["cost"], bno)

    def test_customer_and_supplier_balances_match_simulation(self):
        for code, bal in sample.CUST.items():
            self.assertEqual(D(str(one(self.con, "SELECT balance FROM v_customer_balance WHERE code=?", code))), bal, code)
        for code, bal in sample.SUPP.items():
            self.assertEqual(D(str(one(self.con, "SELECT balance FROM v_supplier_balance WHERE code=?", code))), bal, code)

    def test_previous_balance_snapshot_on_invoice(self):
        row = self.con.execute("SELECT previous_balance, total, paid_amount, balance_due, account_balance_after FROM sales_invoices "
                               "WHERE invoice_no='SI-HO-00-FY2026-000005'").fetchone()
        prev, total, paid, due, after = (D(str(x)) for x in row)
        self.assertEqual(after, prev + total - paid)
        self.assertEqual(due, total - paid)
        self.assertGreater(prev, 0)

    def test_sales_previous_balance_includes_prior_customer_ledger_movements_by_currency_and_date(self):
        customer = one(self.con, "SELECT id FROM customers WHERE code='C001'")
        fy = one(self.con, "SELECT id FROM financial_years WHERE '2026-11-15' BETWEEN start_date AND end_date")
        ar = one(self.con, "SELECT id FROM accounts WHERE system_key='AR'")
        cash = one(self.con, "SELECT id FROM accounts WHERE system_key='CASH'")
        baseline = self.con.execute("""SELECT COALESCE(SUM(CASE
            WHEN l.debit > 0 THEN COALESCE(l.amount_fx,l.debit/NULLIF(l.exchange_rate,0))
            WHEN l.credit > 0 THEN -COALESCE(l.amount_fx,l.credit/NULLIF(l.exchange_rate,0))
            ELSE 0 END),0)
            FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id
            WHERE l.customer_id=? AND l.currency_code='AFN'
              AND e.status IN ('posted','reversed') AND e.entry_date<='2026-11-15'""", (customer,)).fetchone()[0]

        def movement(no, entry_date, currency, debit, credit, fx_amount, rate=1):
            jid = gid()
            base_debit, base_credit = D(str(debit)), D(str(credit))
            self.con.execute(
                "INSERT INTO journal_entries (id,branch_id,entry_no,entry_date,financial_year_id,entry_kind,currency_code,exchange_rate,total_debit,total_credit) "
                "VALUES (?,?,?,?,?,'manual',?,?,?,?)",
                (jid, HO, no, entry_date, fy, currency, str(rate), str(max(base_debit,base_credit)), str(max(base_debit,base_credit))))
            # The customer sub-ledger line is the AR side; the balancing line has no party id.
            if base_debit > 0:
                self.con.execute("INSERT INTO journal_lines (id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,customer_id,branch_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (gid(),jid,1,ar,str(base_debit),'0',currency,str(rate),fx_amount,customer,HO))
                self.con.execute("INSERT INTO journal_lines (id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,branch_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (gid(),jid,2,cash,'0',str(base_credit),currency,str(rate),None,HO))
            else:
                self.con.execute("INSERT INTO journal_lines (id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,branch_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (gid(),jid,1,cash,str(base_credit),'0',currency,str(rate),None,HO))
                self.con.execute("INSERT INTO journal_lines (id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,customer_id,branch_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (gid(),jid,2,ar,'0',str(base_credit),currency,str(rate),fx_amount,customer,HO))
            self.con.execute("UPDATE journal_entries SET status='posted',posted_at='2026-11-15T10:00:00Z',posted_by=? WHERE id=?", (ADMIN,jid))

        movement('JV-CUST-LEDGER-DEBIT','2026-11-10','AFN',1000,1000,'1000')
        movement('JV-CUST-LEDGER-CREDIT','2026-11-12','AFN',0,250,'250')
        movement('JV-CUST-LEDGER-USD','2026-11-13','USD',500,500,'500')
        movement('JV-CUST-LEDGER-FUTURE','2026-11-20','AFN',900,900,'900')
        movement('JV-CUST-LEDGER-FX-FALLBACK','2026-11-14','AFN',200,200,None,2)

        row = self.con.execute("""SELECT COALESCE(SUM(CASE
            WHEN l.debit > 0 THEN COALESCE(l.amount_fx,l.debit/NULLIF(l.exchange_rate,0))
            WHEN l.credit > 0 THEN -COALESCE(l.amount_fx,l.credit/NULLIF(l.exchange_rate,0))
            ELSE 0 END),0)
            FROM journal_lines l JOIN journal_entries e ON e.id=l.entry_id
            WHERE l.customer_id=? AND l.currency_code='AFN'
              AND e.status IN ('posted','reversed') AND e.entry_date<='2026-11-15'""", (customer,)).fetchone()
        opening = D(str(one(self.con, "SELECT opening_balance FROM customers WHERE id=?", customer)))
        self.assertEqual(D(str(row[0])) + opening, D(str(baseline)) + opening + D('850.0000'))

    def test_expiry_buckets_use_real_batch_dates(self):
        today = date.today()
        for bno, exp, bucket in self.con.execute("SELECT batch_no, expiry_date, expiry_bucket FROM v_batch_stock"):
            days = (datetime.strptime(exp, "%Y-%m-%d").date() - today).days
            want = ("expired" if days < 0 else "d30" if days <= 30 else "d60" if days <= 60 else "d90" if days <= 90
                    else "d120" if days <= 120 else "d180" if days <= 180 else "ok")
            self.assertEqual(bucket, want, bno)
        # registered medicines without stock must never show up as expiring
        n_alert = one(self.con, "SELECT COUNT(DISTINCT medicine_id) FROM v_expiry_alerts")
        self.assertLess(n_alert, one(self.con, "SELECT COUNT(*) FROM medicines"))

    def test_low_stock_view(self):
        rows = {r[0] for r in self.con.execute("SELECT medicine_name FROM v_low_stock")}
        self.assertIn("Cough Syrup 100ml", rows)       # never purchased -> zero stock below minimum

    def test_profit_view(self):
        gp = one(self.con, "SELECT sum(gross_profit) FROM v_sales_invoice_profit")
        self.assertGreater(gp, 0)

    def test_branch_transfer_created_destination_batches(self):
        self.assertEqual(qty(self.con, "ATV-W1", sample.BR2), 30)
        self.assertEqual(qty(self.con, "ORS-V3", sample.BR2), 50)
        self.assertEqual(one(self.con, "SELECT unit_cost FROM batches WHERE batch_no='ATV-W1' AND branch_id=?", sample.BR2),
                         one(self.con, "SELECT unit_cost FROM batches WHERE batch_no='ATV-W1' AND branch_id=?", HO))

    def test_usd_receipt_stores_currency_and_rate(self):
        r = self.con.execute("SELECT currency_code, exchange_rate, amount FROM vouchers WHERE voucher_no='CRT-HO-00-FY2026-000001'").fetchone()
        self.assertEqual((r[0], D(str(r[1])), D(str(r[2]))), ("USD", D("70"), D("100")))
        self.assertEqual(one(self.con, "SELECT debit FROM journal_lines WHERE currency_code='USD' AND debit>0"), 7000)

    def test_allocations_updated_invoice_payment_status(self):
        self.assertEqual(one(self.con, "SELECT payment_status FROM purchase_invoices WHERE invoice_no='PI-HO-00-FY2026-000002'"), "partial")
        self.assertEqual(D(str(one(self.con, "SELECT paid_amount FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000001'"))), D("4000"))


# ------------------------------------------------------ mandatory integrity rules
class TestIntegrityRules(DB):
    def test_empty_invoice_cannot_be_saved_as_posted(self):
        sid = gid()
        self.con.execute("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date) VALUES (?,?,?,?,?,?)",
                         (sid, HO, "SI-T-EMPTY", "retail", "cash", "2026-11-14"))
        jid = post_journal(self.con, "JV-EMPTY", "2026-11-14", [("1010", 0.01, 0), ("4100", 0, 0.01)], "sales_invoices", sid, "sales")
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?",
                   (ADMIN, jid, sid), "empty")

    def test_unbalanced_journal_rejected(self):
        jid = gid()
        fy = one(self.con, "SELECT id FROM financial_years WHERE name='FY2026'")
        self.con.execute("INSERT INTO journal_entries (id, branch_id, entry_no, entry_date, financial_year_id, total_debit, total_credit) VALUES (?,?,?,?,?,100,90)",
                         (jid, HO, "JV-BAD", "2026-11-14", fy))
        for i, (code, dr, cr) in enumerate((("1010", 100, 0), ("4100", 0, 90)), 1):
            self.con.execute("INSERT INTO journal_lines (id, entry_id, line_no, account_id, debit, credit) VALUES (?,?,?,?,?,?)", (gid(), jid, i, acc(self.con, code), dr, cr))
        self.fails("UPDATE journal_entries SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, jid), "unbalanced")

    def test_single_line_and_group_account_journal_rejected(self):
        with self.assertRaises(sqlite3.DatabaseError):
            post_journal(self.con, "JV-ONE", "2026-11-14", [("1010", 5, 0)])
        with self.assertRaises(sqlite3.DatabaseError):
            post_journal(self.con, "JV-GRP", "2026-11-14", [("1000", 5, 0), ("4100", 0, 5)])     # 1000 is a non-postable group

    def test_line_cannot_have_both_debit_and_credit(self):
        jid = gid()
        fy = one(self.con, "SELECT id FROM financial_years WHERE name='FY2026'")
        self.con.execute("INSERT INTO journal_entries (id, branch_id, entry_no, entry_date, financial_year_id) VALUES (?,?,?,?,?)", (jid, HO, "JV-X", "2026-11-14", fy))
        self.fails("INSERT INTO journal_lines (id, entry_id, line_no, account_id, debit, credit) VALUES (?,?,1,?,5,5)", (gid(), jid, acc(self.con, "1010")))

    def test_posting_requires_posted_journal(self):
        sid = make_sale(self.con, "SI-T-NOJ", "2026-11-14", [("MET-M4", 1, 0, 5)], post=False, journal=False)
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, sid), "journal")

    def test_confirmed_sale_reduces_batch_stock_and_writes_movement(self):
        before = qty(self.con, "MET-M4")
        sid = make_sale(self.con, "SI-T-1", "2026-11-14", [("MET-M4", 7, 1, 5)])
        self.assertEqual(qty(self.con, "MET-M4"), before - 8)           # quantity + free quantity
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM stock_movements WHERE source_id=?", sid), 1)
        row = self.con.execute("SELECT cost_price, gross_profit FROM sales_invoice_items WHERE invoice_id=?", (sid,)).fetchone()
        self.assertEqual(D(str(row[0])), D(str(one(self.con, "SELECT unit_cost FROM batches WHERE batch_no='MET-M4'"))))
        self.assertEqual(D(str(row[1])), (D("7") * D("5")) - D(str(row[0])) * 8)

    def test_negative_stock_prevented(self):
        have = qty(self.con, "MET-M4")
        sid = make_sale(self.con, "SI-T-NEG", "2026-11-14", [("MET-M4", int(have) + 1, 0, 5)], post=False)
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=(SELECT id FROM journal_entries WHERE entry_no='JV-SI-T-NEG') WHERE id=?",
                   (ADMIN, sid), "negative stock")
        self.assertEqual(qty(self.con, "MET-M4"), have)
        self.fails("UPDATE batches SET qty_on_hand = -1 WHERE batch_no='MET-M4'")

    def test_expired_batch_cannot_be_sold(self):
        sid = make_sale(self.con, "SI-T-EXP", "2026-11-14", [("PCM-A1", 1, 0, 10)], post=False)
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=(SELECT id FROM journal_entries WHERE entry_no='JV-SI-T-EXP') WHERE id=?",
                   (ADMIN, sid), "expired")

    def test_blocked_batch_cannot_be_sold(self):
        self.con.execute("UPDATE batches SET is_blocked=1, block_reason='recall' WHERE batch_no='MET-M4'")
        sid = make_sale(self.con, "SI-T-BLK", "2026-11-14", [("MET-M4", 1, 0, 5)], post=False)
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=(SELECT id FROM journal_entries WHERE entry_no='JV-SI-T-BLK') WHERE id=?",
                   (ADMIN, sid), "blocked")

    def test_posted_documents_are_immutable_and_undeletable(self):
        inv = one(self.con, "SELECT id FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000003'")
        self.fails("UPDATE sales_invoices SET total = 1 WHERE id=?", (inv,), "immutable")
        self.fails("UPDATE sales_invoices SET customer_id = NULL WHERE id=?", (inv,))
        self.fails("DELETE FROM sales_invoices WHERE id=?", (inv,), "cannot be deleted")
        self.fails("UPDATE sales_invoice_items SET quantity = 1 WHERE invoice_id=?", (inv,), "posted document")
        self.fails("DELETE FROM sales_invoice_items WHERE invoice_id=?", (inv,), "posted document")
        self.fails("INSERT INTO sales_invoice_items (id, invoice_id, line_no, medicine_id, batch_id, quantity, unit_price, line_total) "
                   "SELECT ?, ?, 99, medicine_id, id, 1, 1, 1 FROM batches LIMIT 1", (gid(), inv), "posted document")
        for tbl in ("purchase_invoices", "sales_returns", "purchase_returns", "vouchers", "stock_adjustments", "stock_transfers", "journal_entries"):
            self.fails("DELETE FROM %s WHERE status <> 'draft'" % tbl, contains="cannot be deleted")

    def test_journal_lines_of_posted_entry_are_frozen(self):
        self.fails("UPDATE journal_lines SET debit = debit + 1 WHERE rowid = (SELECT MIN(rowid) FROM journal_lines)", contains="posted")
        self.fails("DELETE FROM journal_lines WHERE rowid = (SELECT MIN(rowid) FROM journal_lines)", contains="posted")

    def test_documents_cannot_be_inserted_directly_as_posted(self):
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date, status) VALUES (?,?,?,?,?,?,?)",
                   (gid(), HO, "SI-T-DIRECT", "retail", "cash", "2026-11-14", "posted"), "draft")

    def test_invalid_status_transitions_blocked(self):
        inv = one(self.con, "SELECT id FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000003'")
        self.fails("UPDATE sales_invoices SET status='draft' WHERE id=?", (inv,), "transition")
        self.fails("UPDATE sales_invoices SET status='cancelled' WHERE id=?", (inv,), "transition")

    def test_duplicate_posting_does_not_duplicate_stock(self):
        sid = make_sale(self.con, "SI-T-DUP", "2026-11-14", [("MET-M4", 2, 0, 5)])
        n = one(self.con, "SELECT COUNT(*) FROM stock_movements")
        q0 = qty(self.con, "MET-M4")
        self.con.execute("UPDATE sales_invoices SET status='posted' WHERE id=?", (sid,))       # no-op re-post
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM stock_movements"), n)
        self.assertEqual(qty(self.con, "MET-M4"), q0)
        # the idempotency key / document number also block a second copy
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date) VALUES (?,?,?,?,?,?)",
                   (gid(), HO, "SI-T-DUP", "retail", "cash", "2026-11-14"), "unique")
        a = gid()
        self.con.execute("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date, client_uuid) VALUES (?,?,?,?,?,?,?)",
                         (a, HO, "SI-T-C1", "retail", "cash", "2026-11-14", "abc"))
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date, client_uuid) VALUES (?,?,?,?,?,?,?)",
                   (gid(), HO, "SI-T-C2", "retail", "cash", "2026-11-14", "abc"), "unique")

    def test_duplicate_supplier_invoice_number_rejected(self):
        self.fails("INSERT INTO purchase_invoices (id, branch_id, invoice_no, supplier_id, supplier_invoice_no, invoice_date) "
                   "SELECT ?, branch_id, 'PI-T-NEW', supplier_id, supplier_invoice_no, invoice_date FROM purchase_invoices LIMIT 1", (gid(),), "unique")

    def test_unique_document_numbers(self):
        self.fails("INSERT INTO journal_entries (id, branch_id, entry_no, entry_date, financial_year_id) SELECT ?, branch_id, entry_no, entry_date, financial_year_id FROM journal_entries LIMIT 1", (gid(),), "unique")

    def test_purchase_posting_creates_batch_stock_and_weighted_cost(self):
        pid, sup = gid(), one(self.con, "SELECT id FROM suppliers WHERE code='S002'")
        med = one(self.con, "SELECT id FROM medicines WHERE product_code='M007'")           # MET-M4 exists: qty 300 @ 4.25
        before_q, before_c = qty(self.con, "MET-M4"), D(str(one(self.con, "SELECT unit_cost FROM batches WHERE batch_no='MET-M4'")))
        self.con.execute("INSERT INTO purchase_invoices (id, branch_id, invoice_no, supplier_id, supplier_invoice_no, invoice_date, subtotal, total, payment_status) "
                         "VALUES (?,?,?,?,?,?,?,?, 'unpaid')", (pid, HO, "PI-T-1", sup, "SUP-T-1", "2026-11-14", "1500", "1500"))
        self.con.execute("INSERT INTO purchase_invoice_items (id, invoice_id, line_no, medicine_id, batch_no, expiry_date, quantity, unit_price, line_total, landed_unit_cost) "
                         "VALUES (?,?,1,?,?,?,300,5,1500,5)", (gid(), pid, med, "MET-M4", "2028-02-29"))
        self.con.execute("INSERT INTO purchase_invoice_items (id, invoice_id, line_no, medicine_id, batch_no, expiry_date, quantity, unit_price, line_total, landed_unit_cost) "
                         "VALUES (?,?,2,?,?,?,0.001,0,0,0)", (gid(), pid, med, "NEW-BATCH", "2029-01-31")) if False else None
        jid = post_journal(self.con, "JV-PI-T-1", "2026-11-14", [("1100", 1500, 0), ("2100", 0, 1500)], "purchase_invoices", pid, "purchase")
        self.con.execute("UPDATE purchase_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, pid))
        self.assertEqual(qty(self.con, "MET-M4"), before_q + 300)
        want = ((before_q * before_c + 300 * 5) / (before_q + 300)).quantize(D("0.0001"))
        self.assertEqual(D(str(one(self.con, "SELECT unit_cost FROM batches WHERE batch_no='MET-M4'"))), want)

    def test_cannot_receive_expired_goods(self):
        pid, sup = gid(), one(self.con, "SELECT id FROM suppliers WHERE code='S002'")
        med = one(self.con, "SELECT id FROM medicines WHERE product_code='M012'")
        self.con.execute("INSERT INTO purchase_invoices (id, branch_id, invoice_no, supplier_id, supplier_invoice_no, invoice_date, subtotal, total) VALUES (?,?,?,?,?,?,100,100)",
                         (pid, HO, "PI-T-EXP", sup, "S-EXP", "2026-11-14"))
        self.con.execute("INSERT INTO purchase_invoice_items (id, invoice_id, line_no, medicine_id, batch_no, expiry_date, quantity, unit_price, line_total, landed_unit_cost) VALUES (?,?,1,?,?,?,10,10,100,10)",
                         (gid(), pid, med, "OLD-1", "2026-01-01"))
        jid = post_journal(self.con, "JV-PI-T-EXP", "2026-11-14", [("1100", 100, 0), ("2100", 0, 100)], "purchase_invoices", pid, "purchase")
        self.fails("UPDATE purchase_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, pid), "expired")

    def test_invoice_total_must_equal_components(self):
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date, subtotal, total) VALUES (?,?,?,?,?,?,100,99)",
                   (gid(), HO, "SI-T-TOT", "retail", "cash", "2026-11-14"))

    def test_invoice_subtotal_must_match_lines_at_posting(self):
        sid = make_sale(self.con, "SI-T-SUB", "2026-11-14", [("MET-M4", 2, 0, 5)], post=False)
        self.con.execute("UPDATE sales_invoices SET subtotal=11, total=11, paid_amount=11 WHERE id=?", (sid,))
        self.fails("UPDATE sales_invoices SET status='posted', posted_at='x', posted_by=?, journal_entry_id=(SELECT id FROM journal_entries WHERE entry_no='JV-SI-T-SUB') WHERE id=?",
                   (ADMIN, sid), "subtotal")

    def test_credit_sale_requires_customer_and_overpayment_blocked(self):
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date) VALUES (?,?,?,?,?,?)",
                   (gid(), HO, "SI-T-CR", "retail", "credit", "2026-11-14"))
        self.fails("INSERT INTO sales_invoices (id, branch_id, invoice_no, sale_type, payment_type, invoice_date, subtotal, total, paid_amount) VALUES (?,?,?,?,?,?,10,10,11)",
                   (gid(), HO, "SI-T-OP", "retail", "cash", "2026-11-14"))

    # ---- returns
    def _sales_return(self, qty_, no):
        orig = one(self.con, "SELECT id FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000001'")
        item = self.con.execute("SELECT id, batch_id, unit_price FROM sales_invoice_items WHERE invoice_id=? AND line_no=1", (orig,)).fetchone()
        rid, total = gid(), D(str(item[2])) * qty_
        self.con.execute("INSERT INTO sales_returns (id, branch_id, return_no, original_invoice_id, customer_id, return_date, subtotal, total) "
                         "SELECT ?,?,?,?,customer_id,'2026-11-14',?,? FROM sales_invoices WHERE id=?", (rid, HO, no, orig, str(total), str(total), orig))
        self.con.execute("INSERT INTO sales_return_items (id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, line_total) VALUES (?,?,1,?,?,?,?,?)",
                         (gid(), rid, item[0], item[1], qty_, item[2], str(total)))
        jid = post_journal(self.con, "JV-" + no, "2026-11-14", [("4200", total, 0), ("1200", 0, total)], "sales_returns", rid, "sales_return")
        return rid, jid

    def test_sales_return_cannot_exceed_quantity_sold_and_is_cumulative(self):
        rid, jid = self._sales_return(181, "SR-T-1")                  # sold 200, 20 already returned -> max 180
        self.fails("UPDATE sales_returns SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, rid), "exceeds")
        rid, jid = self._sales_return(180, "SR-T-2")
        before = qty(self.con, "PCM-A1")
        self.con.execute("UPDATE sales_returns SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, rid))
        self.assertEqual(qty(self.con, "PCM-A1"), before + 180)
        rid, jid = self._sales_return(1, "SR-T-3")                    # nothing left to return
        self.fails("UPDATE sales_returns SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, rid), "exceeds")

    def test_same_item_twice_in_one_return_blocked(self):
        rid, _ = self._sales_return(1, "SR-T-4")
        item = one(self.con, "SELECT original_item_id FROM sales_return_items WHERE return_id=?", rid)
        self.fails("INSERT INTO sales_return_items (id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, line_total) "
                   "SELECT ?, ?, 2, original_item_id, batch_id, 1, 1, 1 FROM sales_return_items WHERE return_id=?", (gid(), rid, rid))

    def test_purchase_return_limits(self):
        orig = one(self.con, "SELECT id FROM purchase_invoices WHERE invoice_no='PI-HO-00-FY2026-000003'")
        item = self.con.execute("SELECT id, batch_id FROM purchase_invoice_items WHERE invoice_id=? AND line_no=3", (orig,)).fetchone()   # DCL-T6 250, 10 returned

        def pr(q, no):
            rid = gid()
            self.con.execute("INSERT INTO purchase_returns (id, branch_id, return_no, original_invoice_id, supplier_id, return_date, subtotal, total) "
                             "SELECT ?,?,?,?,supplier_id,'2026-11-14',?,? FROM purchase_invoices WHERE id=?", (rid, HO, no, orig, str(D('7.2') * q), str(D('7.2') * q), orig))
            self.con.execute("INSERT INTO purchase_return_items (id, return_id, line_no, original_item_id, batch_id, quantity, unit_price, line_total) VALUES (?,?,1,?,?,?,7.2,?)",
                             (gid(), rid, item[0], item[1], q, str(D('7.2') * q)))
            jid = post_journal(self.con, "JV-" + no, "2026-11-14", [("2100", D('7.2') * q, 0), ("1100", 0, D('7.2') * q)], "purchase_returns", rid, "purchase_return")
            return rid, jid
        rid, jid = pr(241, "PR-T-1")
        self.fails("UPDATE purchase_returns SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, rid), "exceeds")
        rid, jid = pr(240, "PR-T-2")
        # stock was reduced by an earlier return/sale? DCL-T6 qty = 250-10 = 240 so exactly enough
        self.con.execute("UPDATE purchase_returns SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, rid))
        self.assertEqual(qty(self.con, "DCL-T6"), 0)

    # ---- reversals
    def test_reversal_restores_stock_and_cannot_repeat(self):
        sid = make_sale(self.con, "SI-T-REV", "2026-11-14", [("MET-M4", 5, 0, 5)])
        after_sale = qty(self.con, "MET-M4")
        orig_j = one(self.con, "SELECT journal_entry_id FROM sales_invoices WHERE id=?", sid)
        self.fails("UPDATE sales_invoices SET status='reversed', reversed_at='2026-11-14T11:00:00Z', reversed_by=?, reversal_reason='x' WHERE id=?",
                   (ADMIN, sid), "reversal journal")
        rj = post_journal(self.con, "JV-REV-T", "2026-11-14", [("4100", 25, 0), ("1010", 0, 25)], "sales_invoices", sid, "reversal", reverses=orig_j)
        self.con.execute("UPDATE journal_entries SET status='reversed', reversed_at='x', reversed_by=?, reversal_reason='x' WHERE id=?", (ADMIN, orig_j))
        self.con.execute("UPDATE sales_invoices SET status='reversed', reversed_at='2026-11-14T11:00:00Z', reversed_by=?, reversal_reason='wrong customer', reversal_entry_id=? WHERE id=?",
                         (ADMIN, rj, sid))
        self.assertEqual(qty(self.con, "MET-M4"), after_sale + 5)
        self.assertEqual(self.con.execute("SELECT * FROM v_integrity_issues").fetchall(), [])
        self.fails("UPDATE sales_invoices SET status='posted' WHERE id=?", (sid,), "transition")      # reversed is final

    def test_invoice_with_posted_return_cannot_be_reversed(self):
        orig = one(self.con, "SELECT id FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000001'")
        oj = one(self.con, "SELECT journal_entry_id FROM sales_invoices WHERE id=?", orig)
        rj = post_journal(self.con, "JV-REV-T2", "2026-11-14", [("4100", 1, 0), ("1010", 0, 1)], "sales_invoices", orig, "reversal", reverses=oj)
        self.fails("UPDATE sales_invoices SET status='reversed', reversed_at='x', reversed_by=?, reversal_reason='x', reversal_entry_id=? WHERE id=?", (ADMIN, rj, orig), "returns")

    def test_reversed_purchase_blocked_if_stock_already_sold(self):
        pid = one(self.con, "SELECT id FROM purchase_invoices WHERE invoice_no='PI-HO-00-FY2026-000002'")
        oj = one(self.con, "SELECT journal_entry_id FROM purchase_invoices WHERE id=?", pid)
        self.con.execute("UPDATE purchase_invoices SET paid_amount = paid_amount WHERE id=?", (pid,))
        rj = post_journal(self.con, "JV-REV-T3", "2026-11-14", [("2100", 1, 0), ("1100", 0, 1)], "purchase_invoices", pid, "reversal", reverses=oj)
        self.fails("UPDATE purchase_invoices SET status='reversed', reversed_at='2026-11-14T10:00:00Z', reversed_by=?, reversal_reason='x', reversal_entry_id=? WHERE id=?", (ADMIN, rj, pid))

    # ---- vouchers & allocations
    def test_receipt_allocation_cannot_exceed_outstanding(self):
        inv = one(self.con, "SELECT id FROM sales_invoices WHERE invoice_no='SI-HO-00-FY2026-000003'")     # C002, due 3,?
        due = D(str(one(self.con, "SELECT balance_due FROM sales_invoices WHERE id=?", inv)))
        cust = one(self.con, "SELECT customer_id FROM sales_invoices WHERE id=?", inv)
        vid = gid()
        amt = due + 1
        self.con.execute("INSERT INTO vouchers (id, branch_id, voucher_no, voucher_type, voucher_date, customer_id, cash_bank_account_id, amount) VALUES (?,?,?,?,?,?,?,?)",
                         (vid, HO, "RCV-T-1", "customer_receipt", "2026-11-14", cust, acc(self.con, "1010"), str(amt)))
        self.con.execute("INSERT INTO payment_allocations (id, voucher_id, sales_invoice_id, amount) VALUES (?,?,?,?)", (gid(), vid, inv, str(amt)))
        jid = post_journal(self.con, "JV-RCV-T-1", "2026-11-14", [("1010", amt, 0), ("1200", 0, amt)], "vouchers", vid, "receipt")
        self.fails("UPDATE vouchers SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, vid), "allocation")

    def test_voucher_amount_must_match_journal(self):
        vid = gid()
        self.con.execute("INSERT INTO vouchers (id, branch_id, voucher_no, voucher_type, voucher_date, expense_category_id, cash_bank_account_id, counter_account_id, amount) "
                         "SELECT ?,?,?,?,?,id,?,?,500 FROM expense_categories WHERE name='Fuel'", (vid, HO, "EXP-T-1", "expense", "2026-11-14", acc(self.con, "1010"), acc(self.con, "6600")))
        jid = post_journal(self.con, "JV-EXP-T-1", "2026-11-14", [("6600", 400, 0), ("1010", 0, 400)], "vouchers", vid, "expense")
        self.fails("UPDATE vouchers SET status='posted', posted_at='x', posted_by=?, journal_entry_id=? WHERE id=?", (ADMIN, jid, vid), "journal entry equal")

    def test_customer_receipt_posting_updates_invoice_paid_amount_atomically(self):
        inv = one(self.con, "SELECT id FROM sales_invoices WHERE status='posted' AND balance_due >= 1 ORDER BY invoice_no LIMIT 1")
        cust = one(self.con, "SELECT customer_id FROM sales_invoices WHERE id=?", inv)
        before = D(str(one(self.con, "SELECT paid_amount FROM sales_invoices WHERE id=?", inv)))
        vid = gid()
        self.con.execute("INSERT INTO vouchers (id,branch_id,voucher_no,voucher_type,voucher_date,customer_id,cash_bank_account_id,amount) VALUES (?,?,?,?,?,?,?,1)",
                         (vid, HO, "RCV-POST-T", "customer_receipt", "2026-11-14", cust, acc(self.con, "1010")))
        self.con.execute("INSERT INTO payment_allocations (id,voucher_id,sales_invoice_id,amount) VALUES (?,?,?,1)", (gid(), vid, inv))
        jid = post_journal(self.con, "JV-RCV-POST-T", "2026-11-14", [("1010", 1, 0), ("1200", 0, 1)], "vouchers", vid, "receipt")
        self.con.execute("UPDATE vouchers SET status='posted',posted_at='2026-11-14T10:00:00Z',posted_by=?,journal_entry_id=? WHERE id=?", (ADMIN, jid, vid))
        after = D(str(one(self.con, "SELECT paid_amount FROM sales_invoices WHERE id=?", inv)))
        self.assertEqual(after, before + D('1'))
        self.assertEqual(one(self.con, "SELECT status FROM vouchers WHERE id=?", vid), "posted")

    def test_installment_receipt_posting_updates_invoice_schedule_and_plan_atomically(self):
        inv = one(self.con, "SELECT id FROM sales_invoices WHERE status='posted' AND payment_type='credit' AND balance_due >= 2 ORDER BY invoice_no LIMIT 1")
        self.assertIsNotNone(inv)
        invoice = self.con.execute("SELECT customer_id,currency_code,balance_due FROM sales_invoices WHERE id=?", (inv,)).fetchone()
        plan_id, voucher_id = gid(), gid()
        self.con.execute(
            "INSERT INTO installment_plans (id,branch_id,sales_invoice_id,customer_id,plan_no,currency_code,principal_amount,installment_count,frequency,first_due_date,status) VALUES (?,?,?,?,?,?,2,2,'monthly','2026-11-15','active')",
            (plan_id, HO, inv, invoice[0], "PLAN-TEST-" + plan_id[:8], invoice[1]),
        )
        schedule_ids = [gid(), gid()]
        for number, sid in enumerate(schedule_ids, 1):
            self.con.execute("INSERT INTO installment_schedule (id,plan_id,installment_no,due_date,amount,paid_amount,status) VALUES (?,?,?,?,1,0,'scheduled')",
                             (sid, plan_id, number, f"2026-12-{number:02d}"))
        self.con.execute("INSERT INTO vouchers (id,branch_id,voucher_no,voucher_type,voucher_date,customer_id,cash_bank_account_id,amount,currency_code) VALUES (?,?,?,?,?,?,?,?,?)",
                         (voucher_id, HO, "RCV-INST-" + voucher_id[:8], "customer_receipt", "2026-11-15", invoice[0], acc(self.con, "1010"), 2, invoice[1]))
        self.con.execute("INSERT INTO payment_allocations (id,voucher_id,sales_invoice_id,amount) VALUES (?,?,?,2)", (gid(), voucher_id, inv))
        for sid in schedule_ids:
            self.con.execute("INSERT INTO installment_payment_allocations (id,voucher_id,installment_schedule_id,amount) VALUES (?,?,?,1)", (gid(), voucher_id, sid))
        jid = post_journal(self.con, "JV-INST-" + voucher_id[:8], "2026-11-15", [("1010", 2, 0), ("1200", 0, 2)], "vouchers", voucher_id, "receipt")
        self.con.execute("UPDATE vouchers SET status='posted',posted_at='2026-11-15T10:00:00Z',posted_by=?,journal_entry_id=? WHERE id=?", (ADMIN, jid, voucher_id))
        for sid in schedule_ids:
            self.con.execute("UPDATE installment_schedule SET paid_amount=paid_amount+1,status='paid',paid_at='2026-11-15T10:00:00Z' WHERE id=?", (sid,))
        self.con.execute("UPDATE installment_plans SET status='completed' WHERE id=? AND NOT EXISTS (SELECT 1 FROM installment_schedule s WHERE s.plan_id=installment_plans.id AND s.status<>'cancelled' AND s.paid_amount<s.amount-0.0001)", (plan_id,))
        self.assertEqual(one(self.con, "SELECT status FROM installment_plans WHERE id=?", plan_id), "completed")
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM installment_schedule WHERE plan_id=? AND status='paid'", plan_id), 2)
        self.assertEqual(D(str(one(self.con, "SELECT balance_due FROM sales_invoices WHERE id=?", inv))), D(str(invoice[2])) - D("2"))

    def test_supplier_payment_posting_updates_purchase_invoice_paid_amount(self):
        inv = one(self.con, "SELECT id FROM purchase_invoices WHERE status='posted' AND total-paid_amount >= 1 ORDER BY invoice_no LIMIT 1")
        supplier = one(self.con, "SELECT supplier_id FROM purchase_invoices WHERE id=?", inv)
        before = D(str(one(self.con, "SELECT paid_amount FROM purchase_invoices WHERE id=?", inv)))
        vid = gid()
        self.con.execute("INSERT INTO vouchers (id,branch_id,voucher_no,voucher_type,voucher_date,supplier_id,cash_bank_account_id,amount) VALUES (?,?,?,?,?,?,?,1)",
                         (vid, HO, "PAY-POST-T", "supplier_payment", "2026-11-14", supplier, acc(self.con, "1010")))
        self.con.execute("INSERT INTO payment_allocations (id,voucher_id,purchase_invoice_id,amount) VALUES (?,?,?,1)", (gid(), vid, inv))
        jid = post_journal(self.con, "JV-PAY-POST-T", "2026-11-14", [("2100", 1, 0), ("1010", 0, 1)], "vouchers", vid, "payment")
        self.con.execute("UPDATE vouchers SET status='posted',posted_at='2026-11-14T10:00:00Z',posted_by=?,journal_entry_id=? WHERE id=?", (ADMIN, jid, vid))
        after = D(str(one(self.con, "SELECT paid_amount FROM purchase_invoices WHERE id=?", inv)))
        self.assertEqual(after, before + D('1'))
        self.assertEqual(one(self.con, "SELECT status FROM vouchers WHERE id=?", vid), "posted")

    def test_voucher_type_rules(self):
        self.fails("INSERT INTO vouchers (id, branch_id, voucher_no, voucher_type, voucher_date, cash_bank_account_id, amount) VALUES (?,?,?,?,?,?,5)",
                   (gid(), HO, "RCV-T-X", "customer_receipt", "2026-11-14", acc(self.con, "1010")))
        self.fails("INSERT INTO vouchers (id, branch_id, voucher_no, voucher_type, voucher_date, cash_bank_account_id, counter_account_id, amount) VALUES (?,?,?,?,?,?,?,5)",
                   (gid(), HO, "CNT-T-X", "contra", "2026-11-14", acc(self.con, "1010"), acc(self.con, "1010")))

    # ---- stock adjustment / transfer
    def test_adjustment_cannot_drive_stock_negative(self):
        have = qty(self.con, "MET-M4")
        aid = gid()
        self.con.execute("INSERT INTO stock_adjustments (id, branch_id, adj_no, adj_date, adj_type) VALUES (?,?,?,?,?)", (aid, HO, "ADJ-T-1", "2026-11-14", "adjustment"))
        self.con.execute("INSERT INTO stock_adjustment_items (id, adjustment_id, line_no, batch_id, quantity_change, unit_cost) VALUES (?,?,1,?,?,0)", (gid(), aid, batch(self.con, "MET-M4"), str(-(have + 1))))
        self.fails("UPDATE stock_adjustments SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, aid), "negative")

    def test_expired_adjustment_must_reduce_stock(self):
        aid = gid()
        self.con.execute("INSERT INTO stock_adjustments (id, branch_id, adj_no, adj_date, adj_type) VALUES (?,?,?,?,?)", (aid, HO, "ADJ-T-2", "2026-11-14", "expired"))
        self.con.execute("INSERT INTO stock_adjustment_items (id, adjustment_id, line_no, batch_id, quantity_change, unit_cost) VALUES (?,?,1,?,5,0)", (gid(), aid, batch(self.con, "PCM-A1")))
        self.fails("UPDATE stock_adjustments SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, aid), "reduce")

    def test_valued_adjustment_requires_journal(self):
        aid = gid()
        self.con.execute("INSERT INTO stock_adjustments (id, branch_id, adj_no, adj_date, adj_type) VALUES (?,?,?,?,?)", (aid, HO, "ADJ-T-3", "2026-11-14", "expired"))
        self.con.execute("INSERT INTO stock_adjustment_items (id, adjustment_id, line_no, batch_id, quantity_change, unit_cost) VALUES (?,?,1,?,-10,6.2)", (gid(), aid, batch(self.con, "PCM-A1")))
        self.fails("UPDATE stock_adjustments SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, aid), "journal")

    def test_transfer_to_same_branch_and_overdraw_blocked(self):
        self.fails("INSERT INTO stock_transfers (id, transfer_no, from_branch_id, to_branch_id, transfer_date) VALUES (?,?,?,?,?)", (gid(), "TRF-T-1", HO, HO, "2026-11-14"))
        tid = gid()
        self.con.execute("INSERT INTO stock_transfers (id, transfer_no, from_branch_id, to_branch_id, transfer_date) VALUES (?,?,?,?,?)", (tid, "TRF-T-2", HO, sample.BR2, "2026-11-14"))
        self.con.execute("INSERT INTO stock_transfer_items (id, transfer_id, line_no, batch_id, quantity) VALUES (?,?,1,?,100000)", (gid(), tid, batch(self.con, "MET-M4")))
        self.fails("UPDATE stock_transfers SET status='posted', posted_at='x', posted_by=? WHERE id=?", (ADMIN, tid), "insufficient")

    # ---- ledger immutability, FY, users, audit
    def test_stock_movements_and_audit_log_are_append_only(self):
        self.fails("UPDATE stock_movements SET quantity_change = 99", contains="append-only")
        self.fails("DELETE FROM stock_movements", contains="append-only")
        self.fails("UPDATE audit_log SET action='x'", contains="append-only")
        self.fails("DELETE FROM audit_log", contains="append-only")
        self.con.execute("UPDATE medicines SET retail_price = retail_price + 1 WHERE product_code='M001'")
        self.fails("DELETE FROM medicine_price_history", contains="append-only")
        self.fails("UPDATE medicine_price_history SET new_retail_price = 0", contains="append-only")

    def test_movement_must_match_batch(self):
        self.fails("INSERT INTO stock_movements (id, branch_id, batch_id, medicine_id, movement_type, quantity_change, movement_date, source_type, source_id, source_line_id) "
                   "SELECT ?, ?, id, medicine_id, 'adjustment_in', 1, '2026-11-14', 'x', ?, ? FROM batches WHERE branch_id <> ? LIMIT 1", (gid(), HO, gid(), gid(), HO), "does not match")

    def test_closed_financial_year_rejects_postings(self):
        self.con.execute("UPDATE financial_years SET is_closed=1, closed_at='x', closed_by=? WHERE name='FY2027'", (ADMIN,))
        with self.assertRaises(sqlite3.DatabaseError) as cm:
            post_journal(self.con, "JV-CLOSED", "2027-01-05", [("1010", 5, 0), ("4100", 0, 5)])
        self.assertIn("open financial year", str(cm.exception))
        with self.assertRaises(sqlite3.DatabaseError):
            post_journal(self.con, "JV-OUT", "2028-01-05", [("1010", 5, 0), ("4100", 0, 5)], fy=one(self.con, "SELECT id FROM financial_years WHERE name='FY2027'"))

    def test_last_super_admin_protected(self):
        self.fails("UPDATE users SET is_active=0 WHERE username='admin'", contains="super admin")
        self.fails("UPDATE users SET role_id=? WHERE username='admin'", (seeds.role_id("viewer"),), "super admin")

    def test_audit_log_records_status_changes_and_never_password_hash(self):
        n = one(self.con, "SELECT COUNT(*) FROM audit_log WHERE entity_type='sales_invoices' AND action='status:draft->posted'")
        self.assertEqual(n, 5)
        row = self.con.execute("SELECT user_id, ref_no, new_values FROM audit_log WHERE entity_type='sales_invoices' LIMIT 1").fetchone()
        self.assertEqual(row[0], ADMIN)
        self.assertIn('"status":"posted"', row[2])
        self.con.execute("UPDATE users SET password_hash='$argon2id$secret', password_changed_at='x' WHERE username='demo_viewer'")
        txt = " ".join(r[0] or "" for r in self.con.execute("SELECT new_values FROM audit_log WHERE entity_type='users'"))
        self.assertIn("password_changed", txt)
        self.assertNotIn("secret", txt)

    def test_price_history_trigger(self):
        self.con.execute("UPDATE medicines SET retail_price = retail_price + 1 WHERE product_code='M001'")
        r = self.con.execute("SELECT old_retail_price, new_retail_price FROM medicine_price_history").fetchall()
        self.assertEqual(len(r), 1)
        self.assertEqual(D(str(r[0][1])) - D(str(r[0][0])), 1)
        self.con.execute("UPDATE medicines SET notes='x' WHERE product_code='M001'")
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM medicine_price_history"), 1)

    def test_medicine_duplicate_barcode_and_value_checks(self):
        self.fails("UPDATE medicines SET barcode = (SELECT barcode FROM medicines WHERE product_code='M001') WHERE product_code='M002'")
        self.fails("UPDATE medicines SET retail_price = -1 WHERE product_code='M001'")
        self.fails("UPDATE medicines SET min_stock = 50, max_stock = 10 WHERE product_code='M001'")

    def test_batch_expiry_must_follow_manufacturing_date(self):
        self.fails("UPDATE batches SET mfg_date = '2030-01-01' WHERE batch_no='MET-M4'")


# ------------------------------------------------------------------------- sync
class TestSyncBookkeeping(DB):
    def test_changes_enter_outbox_and_coalesce(self):
        self.con.execute("DELETE FROM sync_outbox")
        mid_ = gid()
        self.con.execute("INSERT INTO medicines (id, product_code, name) VALUES (?,?,?)", (mid_, "T-001", "Test Med"))
        self.con.execute("UPDATE medicines SET name='Test Med 2' WHERE id=?", (mid_,))
        self.con.execute("UPDATE medicines SET name='Test Med 3' WHERE id=?", (mid_,))
        rows = self.con.execute("SELECT op, status FROM sync_outbox WHERE table_name='medicines' AND row_id=?", (mid_,)).fetchall()
        self.assertEqual(rows, [("insert", "pending")])         # insert + updates collapse into one insert

    def test_version_bumps_on_local_edit(self):
        v0 = one(self.con, "SELECT version FROM medicines WHERE product_code='M001'")
        self.con.execute("UPDATE medicines SET notes='n' WHERE product_code='M001'")
        self.assertEqual(one(self.con, "SELECT version FROM medicines WHERE product_code='M001'"), v0 + 1)

    def test_remote_apply_suppresses_outbox_and_keeps_server_version(self):
        self.con.execute("DELETE FROM sync_outbox")
        self.con.execute("UPDATE sync_state SET value='1' WHERE key='applying_remote'")
        self.con.execute("UPDATE medicines SET notes='from server', version=41 WHERE product_code='M001'")
        self.con.execute("UPDATE sync_state SET value='0' WHERE key='applying_remote'")
        self.assertEqual(one(self.con, "SELECT version FROM medicines WHERE product_code='M001'"), 41)
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM sync_outbox"), 0)

    def test_stock_quantity_changes_do_not_bump_batch_version(self):
        v0 = one(self.con, "SELECT version FROM batches WHERE batch_no='MET-M4'")
        make_sale(self.con, "SI-T-SYNC", "2026-11-14", [("MET-M4", 1, 0, 5)])
        self.assertEqual(one(self.con, "SELECT version FROM batches WHERE batch_no='MET-M4'"), v0)

    def test_soft_delete_bumps_version_and_is_outboxed(self):
        self.con.execute("DELETE FROM sync_outbox")
        self.con.execute("UPDATE customers SET deleted_at='2026-11-14T00:00:00Z' WHERE code='C003'")
        self.assertEqual(one(self.con, "SELECT op FROM sync_outbox WHERE table_name='customers'"), "update")

    def test_local_only_tables_not_synced(self):
        self.con.execute("DELETE FROM sync_outbox")
        self.con.execute("INSERT INTO sync_log (direction) VALUES ('push')")
        self.con.execute("INSERT INTO backup_history (kind, file_path) VALUES ('manual','/tmp/x')")
        self.assertEqual(one(self.con, "SELECT COUNT(*) FROM sync_outbox"), 0)

    def test_remote_batch_insert_does_not_double_count_quantity(self):
        self.con.execute("UPDATE sync_state SET value='1' WHERE key='applying_remote'")
        bid = gid()
        self.con.execute("INSERT INTO batches (id, branch_id, medicine_id, batch_no, expiry_date, unit_cost, qty_on_hand) SELECT ?,?,id,'REM-1','2029-01-01',1,500 FROM medicines LIMIT 1", (bid, HO))
        self.assertEqual(one(self.con, "SELECT qty_on_hand FROM batches WHERE id=?", bid), 0)      # movements will arrive separately

    def test_conflict_and_log_tables_usable(self):
        self.con.execute("INSERT INTO sync_conflicts (table_name, row_id, local_version, server_version, local_payload, server_payload) VALUES ('medicines','x',3,4,'{}','{}')")
        self.fails("UPDATE sync_conflicts SET resolution='bogus'")


# ------------------------------------------------------------- search & scale
class TestSearchAndScale(DB):
    def test_full_text_search_and_rename(self):
        names = lambda q: {r[0] for r in self.con.execute("SELECT m.name FROM medicines m JOIN medicines_fts f ON f.rowid=m.rowid WHERE medicines_fts MATCH ?", (q,))}  # noqa
        self.assertIn("Amoxicillin 500mg Capsule", names("amox*"))
        self.assertIn("Amoxicillin 500mg Capsule", names("generic_name:amoxicillin"))
        self.con.execute("UPDATE medicines SET name='Renamed Zyx Capsule' WHERE product_code='M002'")
        self.assertNotIn("Renamed Zyx Capsule", names("name:amox*"))
        self.assertIn("Renamed Zyx Capsule", names("zyx*"))

    def test_100k_medicines_import_and_search_speed(self):
        con = self.con
        con.execute("UPDATE sync_state SET value='1' WHERE key='applying_remote'")      # bulk import path: no outbox noise
        rows = []
        stems = ["Para", "Amoxi", "Cef", "Ibu", "Metfor", "Omepra", "Atorva", "Cetiri", "Loratad", "Azithro"]
        for i in range(100000):
            rows.append((gid(), "BULK-%06d" % i, "%s%dmg Tablet %d" % (stems[i % 10], (i % 50) * 10 + 10, i),
                         "Generic%d" % (i % 700), "Brand%d" % (i % 3000), "%dmg" % (i % 50 * 10 + 10), "10x10"))
        t0 = time.time()
        con.execute("BEGIN")
        con.executemany("INSERT INTO medicines (id, product_code, name, generic_name, brand_name, strength, packing) VALUES (?,?,?,?,?,?,?)", rows)
        con.execute("COMMIT")
        t_import = time.time() - t0
        self.assertGreaterEqual(one(con, "SELECT COUNT(*) FROM medicines"), 100000)
        t0 = time.time()
        n1 = one(con, "SELECT COUNT(*) FROM (SELECT m.id FROM medicines m JOIN medicines_fts f ON f.rowid=m.rowid WHERE medicines_fts MATCH 'omepra*' LIMIT 50)")
        t_fts = time.time() - t0
        t0 = time.time()
        n2 = one(con, "SELECT COUNT(*) FROM (SELECT id FROM medicines WHERE lower(name) LIKE 'cefa%' OR lower(name) >= 'cef' AND lower(name) < 'ceg' LIMIT 50)")
        t_pre = time.time() - t0
        t0 = time.time()
        n3 = one(con, "SELECT COUNT(*) FROM medicines WHERE barcode = '6291000000007'")
        t_bar = time.time() - t0
        plan = " ".join(str(r) for r in con.execute("EXPLAIN QUERY PLAN SELECT id FROM medicines WHERE barcode='6291000000007'"))
        print("\n    100k import %.1fs | FTS prefix %.1f ms (%d rows) | name-prefix %.1f ms (%d) | barcode %.2f ms (%d row)" % (t_import, t_fts * 1000, n1, t_pre * 1000, n2, t_bar * 1000, n3))
        self.assertEqual(n1, 50)
        self.assertLess(t_fts, 0.25)
        self.assertLess(t_pre, 0.25)
        self.assertLess(t_bar, 0.05)
        self.assertIn("INDEX", plan.upper())
        self.assertEqual(one(con, "PRAGMA integrity_check"), "ok")


if __name__ == "__main__":
    unittest.main(verbosity=2)
