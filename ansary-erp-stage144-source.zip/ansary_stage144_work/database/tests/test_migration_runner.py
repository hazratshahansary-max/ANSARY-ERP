"""Regression tests for the offline SQLite migration runner."""
import importlib.util
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MODULE_PATH = ROOT / "scripts" / "migrate_sqlite.py"
_spec = importlib.util.spec_from_file_location("ansary_migrate_sqlite", MODULE_PATH)
migrate_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(migrate_module)


class SQLiteMigrationRunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "database" / "sqlite" / "migrations").mkdir(parents=True)
        self.original_root = migrate_module.ROOT
        migrate_module.ROOT = str(self.root)
        self.db_path = self.root / "test.db"
        self.con = sqlite3.connect(self.db_path, isolation_level=None)
        self.con.execute("PRAGMA foreign_keys = ON")

    def tearDown(self):
        self.con.close()
        migrate_module.ROOT = self.original_root
        self.tmp.cleanup()

    def write_migration(self, name, sql):
        path = self.root / "database" / "sqlite" / "migrations" / name
        path.write_text(sql, encoding="utf-8")
        return path

    def test_migration_and_checksum_record_are_atomic_on_failure(self):
        self.write_migration(
            "001_atomic.sql",
            "CREATE TABLE should_rollback (id INTEGER PRIMARY KEY);\n"
            "THIS IS NOT VALID SQL;\n",
        )
        with self.assertRaises(sqlite3.OperationalError):
            migrate_module.migrate(self.con)
        tables = {r[0] for r in self.con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertNotIn("should_rollback", tables)
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0], 0)

    def test_migrate_is_idempotent_and_records_checksum(self):
        self.write_migration("001_first.sql", "CREATE TABLE first_table (id INTEGER PRIMARY KEY);\n")
        first = migrate_module.migrate(self.con)
        second = migrate_module.migrate(self.con)
        self.assertEqual(first, ["001_first.sql"])
        self.assertEqual(second, [])
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0], 1)

    def test_modified_applied_migration_fails_closed(self):
        path = self.write_migration("001_first.sql", "CREATE TABLE first_table (id INTEGER PRIMARY KEY);\n")
        migrate_module.migrate(self.con)
        path.write_text("CREATE TABLE first_table (id INTEGER PRIMARY KEY, label TEXT);\n", encoding="utf-8")
        with self.assertRaisesRegex(SystemExit, "modified after being applied"):
            migrate_module.migrate(self.con)

    def test_stage120_released_voucher_migration_checksum_is_accepted(self):
        self.write_migration("008_vouchers.sql", "SELECT 1;\n")
        migrate_module.migrate(self.con)
        self.con.execute(
            "UPDATE schema_migrations SET checksum=? WHERE version=?",
            ("cff37277f5e40a1a02bc051a6f8b5a25941644630fcc2b2083fab954c8f5445c", "008_vouchers.sql"),
        )
        self.assertEqual(migrate_module.migrate(self.con), [])

    def test_stage120_database_upgrades_without_rewriting_008(self):
        self.write_migration(
            "008_vouchers.sql",
            "CREATE TABLE vouchers (id TEXT PRIMARY KEY);\n"
            "CREATE TABLE installment_plans (id TEXT PRIMARY KEY);\n"
            "CREATE TABLE installment_schedule (id TEXT PRIMARY KEY);\n",
        )
        migrate_module.migrate(self.con)
        self.con.execute(
            "UPDATE schema_migrations SET checksum=? WHERE version=?",
            ("cff37277f5e40a1a02bc051a6f8b5a25941644630fcc2b2083fab954c8f5445c", "008_vouchers.sql"),
        )
        self.write_migration("009a_installment_plans.sql", "CREATE TABLE IF NOT EXISTS installment_plans (id TEXT PRIMARY KEY);\nCREATE TABLE IF NOT EXISTS installment_schedule (id TEXT PRIMARY KEY);\n")
        self.write_migration("009b_installment_payment_allocations.sql", "CREATE TABLE IF NOT EXISTS installment_payment_allocations (id TEXT PRIMARY KEY, voucher_id TEXT REFERENCES vouchers(id), installment_schedule_id TEXT REFERENCES installment_schedule(id), amount NUMERIC NOT NULL CHECK(amount > 0));\n")
        done = migrate_module.migrate(self.con)
        self.assertEqual(done, ["009a_installment_plans.sql", "009b_installment_payment_allocations.sql"])
        names = {row[0] for row in self.con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertIn("installment_payment_allocations", names)

    def test_trigger_body_with_internal_semicolons_executes_atomically(self):
        self.write_migration(
            "001_trigger.sql",
            "CREATE TABLE source (id INTEGER PRIMARY KEY, value TEXT);\n"
            "CREATE TABLE audit (value TEXT);\n"
            "CREATE TRIGGER source_audit AFTER INSERT ON source BEGIN\n"
            " INSERT INTO audit(value) VALUES (NEW.value);\n"
            " INSERT INTO audit(value) VALUES ('second');\n"
            "END;\n",
        )
        self.assertEqual(migrate_module.migrate(self.con), ["001_trigger.sql"])
        self.con.execute("INSERT INTO source(value) VALUES ('first')")
        self.assertEqual(self.con.execute("SELECT value FROM audit ORDER BY rowid").fetchall(), [("first",), ("second",)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
