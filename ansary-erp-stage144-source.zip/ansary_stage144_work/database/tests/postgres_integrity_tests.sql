-- ANSARY ERP - PostgreSQL integrity tests (plain SQL, no extensions needed).
--
-- STATUS: written to mirror the SQLite suite, but NOT executed in the environment where Stage 1 was
-- built (no PostgreSQL server was available there). Run them first thing on a real PostgreSQL >= 14:
--
--   createdb ansary_test
--   scripts/migrate_pg.sh ansary_test --seed --sample
--   psql -v ON_ERROR_STOP=1 -d ansary_test -f database/tests/postgres_integrity_tests.sql
--
-- Everything runs inside one transaction that is rolled back. Any failed assertion aborts with a message.
BEGIN;

CREATE FUNCTION pg_temp.expect_error(stmt text, needle text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
    BEGIN
        EXECUTE stmt;
    EXCEPTION WHEN OTHERS THEN
        IF position(lower(needle) IN lower(SQLERRM)) = 0 THEN
            RAISE EXCEPTION 'wrong error for [%]: got "%", expected to contain "%"', stmt, SQLERRM, needle;
        END IF;
        RETURN;
    END;
    RAISE EXCEPTION 'expected failure but statement succeeded: %', stmt;
END $$;

CREATE FUNCTION pg_temp.assert_true(cond boolean, msg text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF cond IS NOT TRUE THEN RAISE EXCEPTION 'ASSERTION FAILED: %', msg; END IF; END $$;

-- 1. reconciliation of the sample data
SELECT pg_temp.assert_true((SELECT count(*) FROM v_integrity_issues) = 0, 'v_integrity_issues must be empty');
SELECT pg_temp.assert_true((SELECT round(sum(debit_balance),4) = round(sum(credit_balance),4) FROM v_trial_balance), 'trial balance balances');
SELECT pg_temp.assert_true((SELECT balance FROM v_account_balance WHERE code = '1100') = (SELECT round(sum(stock_value),4) FROM v_batch_stock), 'inventory account = stock valuation');
SELECT pg_temp.assert_true((SELECT balance FROM v_account_balance WHERE code = '1200') = (SELECT sum(balance) FROM v_customer_balance), 'AR = customer sub-ledger');
SELECT pg_temp.assert_true((SELECT balance FROM v_account_balance WHERE code = '2100') = (SELECT sum(balance) FROM v_supplier_balance), 'AP = supplier sub-ledger');
SELECT pg_temp.assert_true((SELECT count(*) FROM roles) = 8, '8 roles');
SELECT pg_temp.assert_true((SELECT count(*) FROM currencies WHERE is_base) = 1, 'one base currency');

-- 2. posted documents are immutable / undeletable / cannot be inserted posted
SELECT pg_temp.expect_error($q$DELETE FROM sales_invoices WHERE status = 'posted'$q$, 'cannot be deleted');
SELECT pg_temp.expect_error($q$UPDATE sales_invoices SET total = 1 WHERE invoice_no = 'SI-HO-00-FY2026-000003'$q$, 'immutable');
SELECT pg_temp.expect_error($q$UPDATE sales_invoices SET status = 'draft' WHERE invoice_no = 'SI-HO-00-FY2026-000003'$q$, 'transition');
SELECT pg_temp.expect_error($q$UPDATE sales_invoice_items SET quantity = 1 WHERE invoice_id IN (SELECT id FROM sales_invoices WHERE status = 'posted')$q$, 'posted document');
SELECT pg_temp.expect_error($q$INSERT INTO sales_invoices (branch_id, invoice_no, sale_type, payment_type, invoice_date, status)
    SELECT id, 'SI-PG-DIRECT', 'retail', 'cash', CURRENT_DATE, 'posted' FROM branches LIMIT 1$q$, 'draft');

-- 3. append-only ledgers
SELECT pg_temp.expect_error($q$UPDATE stock_movements SET quantity_change = 99$q$, 'append-only');
SELECT pg_temp.expect_error($q$DELETE FROM audit_log$q$, 'append-only');

-- 4. negative stock / CHECK constraints
SELECT pg_temp.expect_error($q$UPDATE batches SET qty_on_hand = -1$q$, 'ck_batches');
SELECT pg_temp.expect_error($q$UPDATE medicines SET retail_price = -1$q$, 'ck_medicines');

-- 5. unbalanced journal, closed year, last super admin
DO $$
DECLARE j uuid := gen_random_uuid(); fy uuid; br uuid; a1 uuid; a2 uuid; adm uuid;
BEGIN
    SELECT id INTO fy FROM financial_years WHERE name = 'FY2026';
    SELECT id INTO br FROM branches WHERE code = 'HO';
    SELECT id INTO a1 FROM accounts WHERE code = '1010';
    SELECT id INTO a2 FROM accounts WHERE code = '4100';
    SELECT id INTO adm FROM users WHERE username = 'admin';
    INSERT INTO journal_entries (id, branch_id, entry_no, entry_date, financial_year_id, total_debit, total_credit)
        VALUES (j, br, 'JV-PG-BAD', '2026-11-14', fy, 100, 90);
    INSERT INTO journal_lines (entry_id, line_no, account_id, debit, credit) VALUES (j, 1, a1, 100, 0), (j, 2, a2, 0, 90);
    PERFORM pg_temp.expect_error(format($q$UPDATE journal_entries SET status='posted', posted_at=now(), posted_by=%L WHERE id=%L$q$, adm, j), 'unbalanced');
    -- fix the line and post: must succeed
    UPDATE journal_lines SET credit = 100 WHERE entry_id = j AND line_no = 2;
    UPDATE journal_entries SET total_credit = 100, status = 'posted', posted_at = now(), posted_by = adm WHERE id = j;
    PERFORM pg_temp.assert_true((SELECT status FROM journal_entries WHERE id = j) = 'posted', 'balanced journal posts');
    PERFORM pg_temp.expect_error(format($q$DELETE FROM journal_entries WHERE id=%L$q$, j), 'cannot be deleted');
    PERFORM pg_temp.expect_error(format($q$UPDATE journal_lines SET debit = 1 WHERE entry_id=%L$q$, j), 'posted');
END $$;
SELECT pg_temp.expect_error($q$UPDATE users SET is_active = false WHERE username = 'admin'$q$, 'super admin');

-- 6. sync bookkeeping: version bump, change_log, remote mode
DO $$
DECLARE v0 int; s0 bigint; v1 int;
BEGIN
    SELECT version INTO v0 FROM medicines WHERE product_code = 'M001';
    SELECT COALESCE(max(seq), 0) INTO s0 FROM change_log;
    UPDATE medicines SET notes = 'pg-test' WHERE product_code = 'M001';
    SELECT version INTO v1 FROM medicines WHERE product_code = 'M001';
    PERFORM pg_temp.assert_true(v1 = v0 + 1, 'version bumps on local edit');
    PERFORM pg_temp.assert_true((SELECT count(*) FROM change_log WHERE seq > s0 AND table_name = 'medicines' AND op = 'update') = 1, 'change_log row written');
    PERFORM set_config('ansary.applying_remote', 'on', true);
    UPDATE medicines SET notes = 'from-server', version = 99 WHERE product_code = 'M001';
    PERFORM pg_temp.assert_true((SELECT version FROM medicines WHERE product_code = 'M001') = 99, 'remote apply keeps server version');
    PERFORM set_config('ansary.applying_remote', 'off', true);
    PERFORM pg_temp.assert_true(next_doc_no('sales_invoice', (SELECT id FROM branches WHERE code='HO'), (SELECT id FROM financial_years WHERE name='FY2026')) = 'SI-HO-00-FY2026-000001', 'next_doc_no format');
END $$;

ROLLBACK;
\echo 'ALL POSTGRESQL INTEGRITY TESTS PASSED'
