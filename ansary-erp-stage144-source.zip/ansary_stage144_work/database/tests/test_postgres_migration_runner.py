"""Contract tests for the PostgreSQL psql migration runner (no live DB needed)."""
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "scripts" / "migrate_pg.sh"


class PostgresMigrationRunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.project = self.root / "project"
        (self.project / "scripts").mkdir(parents=True)
        (self.project / "database" / "postgres" / "migrations").mkdir(parents=True)
        (self.project / "database" / "seed" / "production").mkdir(parents=True)
        (self.project / "database" / "seed" / "sample").mkdir(parents=True)
        self.script = self.project / "scripts" / "migrate_pg.sh"
        self.script.write_bytes(SCRIPT.read_bytes())
        self.script.chmod(0o755)
        self.bin = self.root / "bin"
        self.bin.mkdir()
        self.log = self.root / "psql.log"
        self.fake_psql = self.bin / "psql"
        self.fake_psql.write_text(
            "#!/usr/bin/env python3\n"
            "import os, pathlib, sys\n"
            "args=sys.argv[1:]\n"
            "with open(os.environ['FAKE_PSQL_LOG'], 'a', encoding='utf-8') as log: log.write(repr(args)+'\\n')\n"
            "if '-f' in args:\n"
            " p=pathlib.Path(args[args.index('-f')+1]); data=p.read_text(encoding='utf-8')\n"
            " pathlib.Path(os.environ['FAKE_PSQL_CAPTURE']).write_text(data, encoding='utf-8')\n"
            " if 'FAIL_MIGRATION_FOR_TEST' in data: sys.exit(23)\n"
            "sys.exit(0)\n",
            encoding="utf-8",
        )
        self.fake_psql.chmod(0o755)
        self.env = os.environ.copy()
        self.env.update({
            "PATH": str(self.bin) + os.pathsep + self.env.get("PATH", ""),
            "FAKE_PSQL_LOG": str(self.log),
            "FAKE_PSQL_CAPTURE": str(self.root / "captured.sql"),
        })

    def tearDown(self):
        self.tmp.cleanup()

    def add_migration(self, name, sql):
        path = self.project / "database" / "postgres" / "migrations" / name
        path.write_text(sql, encoding="utf-8")
        return path

    def run_script(self, *args):
        return subprocess.run(
            ["/bin/bash", str(self.script), "ansary_test", *args],
            env=self.env, text=True, capture_output=True, check=False,
        )

    def test_each_migration_and_checksum_are_in_same_locked_transaction(self):
        self.add_migration("001_first.sql", "CREATE TABLE first_table(id integer);\n")
        self.add_migration("002_second.sql", "CREATE TABLE second_table(id integer);\n")
        result = self.run_script()
        self.assertEqual(result.returncode, 0, result.stderr)
        captured = (self.root / "captured.sql").read_text(encoding="utf-8")
        self.assertIn("pg_advisory_xact_lock", captured)
        self.assertIn("\\if :migration_applied", captured)
        self.assertIn("RAISE EXCEPTION 'Migration 002_second.sql was modified after being applied'", captured)
        self.assertIn("CREATE TABLE second_table", captured)
        self.assertIn("INSERT INTO schema_migrations (version, checksum)", captured)
        self.assertIn("BEGIN;", captured)
        self.assertIn("COMMIT;", captured)
        calls = self.log.read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(calls), 3)  # ledger table creation + two migration sessions

    def test_stage120_voucher_checksum_compatibility_is_limited_to_known_hash(self):
        self.add_migration("008_vouchers.sql", "SELECT 1;\n")
        result = self.run_script()
        self.assertEqual(result.returncode, 0, result.stderr)
        captured = (self.root / "captured.sql").read_text(encoding="utf-8")
        self.assertIn("34553e0997381ccd9167530714d059524f1bb3f9c18257116c27ac429ae29d72", captured)
        self.assertIn("applied_sum <> '", captured)

    def test_failed_migration_stops_runner(self):
        self.add_migration("001_fail.sql", "-- FAIL_MIGRATION_FOR_TEST\nSELECT 1;\n")
        self.add_migration("002_never.sql", "CREATE TABLE never_run(id integer);\n")
        result = self.run_script()
        self.assertEqual(result.returncode, 23)
        calls = self.log.read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(calls), 2)  # table creation + failed first migration

    def test_unknown_option_is_rejected_before_database_changes(self):
        result = self.run_script("--unknown")
        self.assertEqual(result.returncode, 2)
        self.assertFalse(self.log.exists())

    def test_missing_psql_is_reported(self):
        env = self.env.copy()
        env["PATH"] = "/nonexistent"
        result = subprocess.run(["/bin/bash", str(self.script), "ansary_test"], env=env, text=True, capture_output=True)
        self.assertEqual(result.returncode, 127)
        self.assertIn("psql not found", result.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
