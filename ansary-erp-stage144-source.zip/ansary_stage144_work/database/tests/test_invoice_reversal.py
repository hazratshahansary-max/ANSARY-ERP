"""SQLite integration checks for atomic sales/purchase invoice reversal guards."""
import os, sqlite3, subprocess, tempfile, unittest, uuid
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__), '../..'))
BRANCH='901dd16e-7e24-5f59-bf92-795122c62d2c'
USER='d4fc8bff-27a0-5c3f-8b70-763e3e4319d8'
SUPPLIER='2c75cc56-ef84-53e8-aa18-8c673977e1b1'
MEDICINE='081bdb1e-65aa-54b5-aab9-86ce348b02f5'

class InvoiceReversalTests(unittest.TestCase):
 def setUp(self):
  fd,self.path=tempfile.mkstemp(suffix='.db');os.close(fd)
  subprocess.run(['python','scripts/migrate_sqlite.py',self.path,'--seed','--sample'],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
  self.db=sqlite3.connect(self.path);self.db.execute('PRAGMA foreign_keys=ON')
 def tearDown(self):
  self.db.close()
  for x in ('','-wal','-shm'):
   try:os.unlink(self.path+x)
   except FileNotFoundError:pass
 def fy(self,date):
  return self.db.execute('SELECT id FROM financial_years WHERE is_closed=0 AND start_date<=? AND end_date>=? LIMIT 1',(date,date)).fetchone()[0]
 def create_sales(self):
  c=self.db; invoice,journal=str(uuid.uuid4()),str(uuid.uuid4()); customer=c.execute('SELECT id FROM customers LIMIT 1').fetchone()[0]
  batch,medicine,qty,cost=c.execute("SELECT id,medicine_id,qty_on_hand,unit_cost FROM batches WHERE branch_id=? AND expiry_date>'2026-11-15' AND qty_on_hand>=2 AND is_blocked=0 LIMIT 1",(BRANCH,)).fetchone()
  date='2026-11-15'; fy=self.fy(date); accounts=dict(c.execute("SELECT system_key,id FROM accounts WHERE system_key IN ('SALES','COGS','INVENTORY','AR')"))
  c.execute("INSERT INTO sales_invoices(id,branch_id,invoice_no,sale_type,payment_type,customer_id,invoice_date,currency_code,exchange_rate,subtotal,total,previous_balance,paid_amount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(invoice,BRANCH,'REV-SALE-'+invoice[:8],'wholesale','credit',customer,date,'AFN',1,100,100,0,0))
  c.execute("INSERT INTO sales_invoice_items(id,invoice_id,line_no,medicine_id,batch_id,quantity,free_quantity,unit_price,discount_pct,discount_amount,tax_pct,tax_amount,line_total,cost_price,gross_profit) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(str(uuid.uuid4()),invoice,1,medicine,batch,1,0,100,0,0,0,0,100,cost,100-cost))
  total=100+cost
  c.execute("INSERT INTO journal_entries(id,branch_id,entry_no,entry_date,financial_year_id,entry_kind,source_type,source_id,description,currency_code,exchange_rate,status,total_debit,total_credit) VALUES(?,?,?,?,?,'sales','sales_invoices',?,?,?,1,'draft',?,?)",(journal,BRANCH,'REV-SALE-JRN-'+invoice[:8],date,fy,invoice,'sale test','AFN',total,total))
  lines=[('AR',100,0,customer),('COGS',cost,0,None),('SALES',0,100,None),('INVENTORY',0,cost,None)]
  for n,(key,d,cr,cust) in enumerate(lines,1):
   if d+cr==0: continue
   c.execute('INSERT INTO journal_lines(id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,customer_id,branch_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),journal,n,accounts[key],d,cr,'AFN',1,d+cr,cust,BRANCH))
  c.execute("UPDATE journal_entries SET status='posted',posted_at=?,posted_by=? WHERE id=?",(date+'T10:00:00Z',USER,journal))
  c.execute("UPDATE sales_invoices SET status='posted',posted_at=?,posted_by=?,journal_entry_id=? WHERE id=?",(date+'T10:00:00Z',USER,journal,invoice))
  return invoice,journal,batch,qty
 def create_purchase(self):
  c=self.db; invoice,journal=str(uuid.uuid4()),str(uuid.uuid4());date='2026-11-15';fy=self.fy(date)
  c.execute('INSERT INTO purchase_invoices(id,branch_id,invoice_no,supplier_id,supplier_invoice_no,invoice_date,currency_code,exchange_rate,total) VALUES(?,?,?,?,?,?,?,?,?)',(invoice,BRANCH,'REV-PI-'+invoice[:8],SUPPLIER,'REV-SUP-'+invoice[:8],date,'AFN',1,0))
  c.execute('INSERT INTO purchase_invoice_items(id,invoice_id,line_no,medicine_id,batch_no,mfg_date,expiry_date,quantity,free_quantity,unit_price,discount_pct,discount_amount,tax_pct,tax_amount,additional_cost,line_total,landed_unit_cost) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),invoice,1,MEDICINE,'REV-BATCH-'+invoice[:8],'2026-01-01','2027-12-31',10,1,10,0,0,0,0,5,100,9.5455))
  c.execute('UPDATE purchase_invoices SET subtotal=100,additional_costs=5,total=105 WHERE id=?',(invoice,))
  accounts=dict(c.execute("SELECT system_key,id FROM accounts WHERE system_key IN ('INVENTORY','AP')"))
  c.execute("INSERT INTO journal_entries(id,branch_id,entry_no,entry_date,financial_year_id,entry_kind,source_type,source_id,description,currency_code,exchange_rate,status,total_debit,total_credit) VALUES(?,?,?,?,?,'purchase','purchase_invoices',?,?,?,1,'draft',105,105)",(journal,BRANCH,'REV-PI-JRN-'+invoice[:8],date,fy,invoice,'purchase test','AFN'))
  for n,(key,d,cr,supplier) in enumerate([('INVENTORY',105,0,None),('AP',0,105,SUPPLIER)],1):
   c.execute('INSERT INTO journal_lines(id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,supplier_id,branch_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),journal,n,accounts[key],d,cr,'AFN',1,105,supplier,BRANCH))
  c.execute("UPDATE journal_entries SET status='posted',posted_at=?,posted_by=? WHERE id=?",(date+'T10:00:00Z',USER,journal))
  c.execute("UPDATE purchase_invoices SET status='posted',posted_at=?,posted_by=?,journal_entry_id=? WHERE id=?",(date+'T10:00:00Z',USER,journal,invoice))
  batch=c.execute('SELECT id,qty_on_hand FROM batches WHERE batch_no=?',('REV-BATCH-'+invoice[:8],)).fetchone()
  return invoice,journal,batch[0],batch[1]
 def reverse_ops(self,table,invoice,journal,kind,date='2026-11-15'):
  c=self.db; reversal=str(uuid.uuid4());fy=self.fy(date)
  original=c.execute('SELECT branch_id,entry_no,currency_code,exchange_rate,total_debit,total_credit FROM journal_entries WHERE id=?',(journal,)).fetchone()
  lines=c.execute('SELECT line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,customer_id,supplier_id,branch_id,description FROM journal_lines WHERE entry_id=? ORDER BY line_no',(journal,)).fetchall()
  c.execute("INSERT INTO journal_entries(id,branch_id,entry_no,entry_date,financial_year_id,entry_kind,source_type,source_id,description,currency_code,exchange_rate,status,reverses_entry_id,total_debit,total_credit) VALUES(?,?,?,?,?,'reversal',?,?,?, ?,?,'draft',?,?,?)",(reversal,original[0],'REV-'+kind+'-'+invoice[:8],date,fy,kind+'_invoice_reversal',invoice,'reversal test',original[2],original[3],journal,original[4],original[5]))
  for line in lines:
   c.execute('INSERT INTO journal_lines(id,entry_id,line_no,account_id,debit,credit,currency_code,exchange_rate,amount_fx,customer_id,supplier_id,branch_id,description) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),reversal,line[0],line[1],line[3],line[2],line[4],line[5],line[6],line[7],line[8],line[9],'reversal'))
  c.execute("UPDATE journal_entries SET status='posted',posted_at=?,posted_by=? WHERE id=?",(date+'T11:00:00Z',USER,reversal))
  c.execute("UPDATE journal_entries SET status='reversed',reversed_at=?,reversed_by=?,reversal_reason=? WHERE id=?",(date+'T11:01:00Z',USER,'test reversal',journal))
  c.execute(f"UPDATE {table} SET status='reversed',reversed_at=?,reversed_by=?,reversal_reason=?,reversal_entry_id=? WHERE id=?",(date+'T11:02:00Z',USER,'test reversal',reversal,invoice))
  return reversal
 def test_sales_invoice_reversal_mirrors_journal_and_restores_batch_stock(self):
  invoice,journal,batch,qty=self.create_sales();self.assertEqual(self.db.execute('SELECT qty_on_hand FROM batches WHERE id=?',(batch,)).fetchone()[0],qty-1)
  with self.db:
   reversal=self.reverse_ops('sales_invoices',invoice,journal,'SI')
  self.assertEqual(self.db.execute('SELECT status,reversal_entry_id FROM sales_invoices WHERE id=?',(invoice,)).fetchone(),('reversed',reversal))
  self.assertEqual(self.db.execute('SELECT status FROM journal_entries WHERE id=?',(journal,)).fetchone()[0],'reversed')
  self.assertEqual(self.db.execute('SELECT qty_on_hand FROM batches WHERE id=?',(batch,)).fetchone()[0],qty)
  self.assertEqual(self.db.execute('SELECT COUNT(*) FROM stock_movements WHERE source_id=? AND movement_type=\'reversal\'',(invoice,)).fetchone()[0],1)
 def test_purchase_invoice_reversal_is_blocked_if_received_stock_has_been_consumed(self):
  invoice,journal,batch,qty=self.create_purchase();self.assertEqual(qty,11)
  self.db.execute('INSERT INTO stock_movements(id,branch_id,batch_id,medicine_id,movement_type,quantity_change,unit_cost,movement_date,source_type,source_id,source_line_id,user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),BRANCH,batch,MEDICINE,'sale',-11,9.5455,'2026-11-15','test_consumption',invoice,str(uuid.uuid4()),USER))
  self.assertEqual(self.db.execute('SELECT qty_on_hand FROM batches WHERE id=?',(batch,)).fetchone()[0],0)
  self.db.commit()
  with self.assertRaises(sqlite3.IntegrityError):
   with self.db:
    self.reverse_ops('purchase_invoices',invoice,journal,'PI')
  self.assertEqual(self.db.execute('SELECT status FROM purchase_invoices WHERE id=?',(invoice,)).fetchone()[0],'posted')
  self.assertEqual(self.db.execute('SELECT status FROM journal_entries WHERE id=?',(journal,)).fetchone()[0],'posted')
  self.assertEqual(self.db.execute('SELECT qty_on_hand FROM batches WHERE id=?',(batch,)).fetchone()[0],0)

if __name__=='__main__':unittest.main()
