"""Static safety/contract tests for the disposable PostgreSQL integration harness."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMPOSE = ROOT / "docker-compose.postgres-test.yml"
RUNNER = ROOT / "scripts" / "test-postgres-integration.sh"


class Stage73PostgresIntegrationHarnessTests(unittest.TestCase):
    def test_compose_uses_isolated_postgres_16_test_database(self):
        text = COMPOSE.read_text(encoding="utf-8")
        self.assertIn("postgres:16-alpine", text)
        self.assertIn("POSTGRES_DB: ansary_erp_test", text)
        self.assertIn("POSTGRES_USER: ansary_test", text)
        self.assertIn('"127.0.0.1:55432:5432"', text)
        self.assertIn("pg_isready", text)

    def test_runner_requires_docker_compose_and_always_cleans_up(self):
        text = RUNNER.read_text(encoding="utf-8")
        self.assertIn("docker compose version", text)
        self.assertIn("trap cleanup EXIT INT TERM", text)
        self.assertIn("down -v --remove-orphans", text)
        self.assertIn("ansary_erp_test", text)
        self.assertIn("POSTGRES_INTEGRATION_OK", text)

    def test_runner_exercises_concurrent_migrations_and_integrity_sql(self):
        text = RUNNER.read_text(encoding="utf-8")
        self.assertIn("migrate-a.log", text)
        self.assertIn("migrate-b.log", text)
        self.assertIn("scripts/migrate_pg.sh ansary_erp_test --seed --sample", text)
        self.assertIn("database/tests/postgres_integrity_tests.sql", text)
        self.assertIn("schema_migrations", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
