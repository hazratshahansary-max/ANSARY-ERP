"""PostgreSQL <-> SQLite parity and generated-file hygiene tests (no database server needed)."""
import glob
import os
import re
import subprocess
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def read(folder, pattern):
    out = ""
    for p in sorted(glob.glob(os.path.join(ROOT, "database", folder, "migrations", pattern))):
        with open(p, encoding="utf-8") as f:
            out += f.read() + "\n"
    return out


def tables(sql):
    res = {}
    for m in re.finditer(r"CREATE TABLE (?:IF NOT EXISTS )?(\w+) \(\n(.*?)\n\);", sql, re.S):
        cols = []
        for line in m.group(2).split(",\n"):
            line = line.strip()
            if line.startswith(("CONSTRAINT", "FOREIGN KEY")):
                continue
            cols.append(line.split()[0])
        res[m.group(1)] = cols
    # Include incremental ALTER TABLE additions so parity compares the final migrated schema.
    for m in re.finditer(r"ALTER TABLE (\w+) ADD COLUMN (\w+)", sql, re.I):
        res.setdefault(m.group(1), []).append(m.group(2))
    return {name: sorted(cols) for name, cols in res.items()}


class Parity(unittest.TestCase):
    def test_generated_files_up_to_date(self):
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "schema", "build.py"), "--check"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)

    def test_same_tables_and_columns(self):
        pg, sq = tables(read("postgres", "*.sql")), tables(read("sqlite", "*.sql"))
        only_pg, only_sq = set(pg) - set(sq), set(sq) - set(pg)
        self.assertEqual(only_pg, {"change_log"})
        self.assertEqual(only_sq, {"sync_state", "sync_outbox", "sync_master_tombstones"})
        for t in set(pg) & set(sq):
            self.assertEqual(pg[t], sq[t], t)
        self.assertEqual(len(set(pg) & set(sq)), 68)

    def test_same_business_triggers_and_indexes(self):
        for pat in ("011_*.sql", "012_*.sql", "013_*.sql"):
            a = set(re.findall(r"CREATE TRIGGER (\w+)", read("postgres", pat)))
            b = set(re.findall(r"CREATE TRIGGER (\w+)", read("sqlite", pat)))
            self.assertEqual(a, b, pat)
            self.assertGreater(len(a), 5)
        for pat in ("00[1-9]_*.sql",):
            a = set(re.findall(r"CREATE (?:UNIQUE )?INDEX (\w+)", read("postgres", pat)))
            b = set(re.findall(r"CREATE (?:UNIQUE )?INDEX (\w+)", read("sqlite", pat)))
            self.assertEqual(a - {"ix_change_log_row", "ix_change_log_branch_seq", "ix_sync_devices_branch"},
                             b - {"ux_sync_outbox_pending", "ix_sync_outbox_status"})

    def test_every_synced_table_has_sync_triggers(self):
        pg = read("postgres", "014_*.sql")
        sq = read("sqlite", "014_*.sql")
        for t in tables(read("sqlite", "00[1-9]_*.sql")):
            if t in ("user_sessions", "backup_history", "sync_conflicts", "sync_log", "sync_state", "sync_outbox"):
                self.assertNotIn("trg_%s_" % t, sq)
                continue
            self.assertIn("trg_%s_outbox_insert" % t, sq, t)
            self.assertIn("trg_%s_changelog_insert" % t, pg, t)

    def test_postgres_function_and_dollar_quote_hygiene(self):
        for pat in ("011_*.sql", "012_*.sql", "013_*.sql", "014_*.sql"):
            sql = read("postgres", pat)
            self.assertEqual(sql.count("$fn$") % 2, 0, pat)
            fns = set(re.findall(r"EXECUTE FUNCTION (\w+)\(", sql))
            defined = set(re.findall(r"CREATE FUNCTION (\w+)\(", read("postgres", "*.sql")))
            self.assertTrue(fns <= defined, fns - defined)

    def test_identifier_length_limit(self):
        for folder in ("postgres",):
            for name in re.findall(r"(?:CREATE (?:UNIQUE )?INDEX|CREATE TRIGGER|CREATE FUNCTION|CONSTRAINT) (\w+)", read(folder, "*.sql")):
                self.assertLessEqual(len(name), 63, name)

    def test_no_marg_branding(self):
        for p in glob.glob(os.path.join(ROOT, "**", "*"), recursive=True):
            if os.path.isfile(p) and p.endswith((".sql", ".py", ".md")) and "test_schema_parity" not in p:
                with open(p, encoding="utf-8") as f:
                    txt = f.read()
                self.assertNotRegex(txt.replace("inspired by MARG", "").replace("MARG ERP-like", ""), r"(?i)\bmarg\b.*logo|marg_", p)

    def test_seed_is_dialect_neutral(self):
        with open(os.path.join(ROOT, "database/seed/production/001_system_data.sql"), encoding="utf-8") as f:
            seed = f.read()
        for bad in ("gen_random_uuid", "strftime", "::", "json_object"):
            self.assertNotIn(bad, seed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
