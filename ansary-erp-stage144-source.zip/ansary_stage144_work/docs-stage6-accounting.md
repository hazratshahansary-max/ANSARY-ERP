# ANSARY ERP — Stage 6 Accounting & Finance

Added accounting API foundation for chart of accounts, draft journals, draft expenses, draft receipts/payments, and posted-only trial balance reporting. All endpoints require authentication and permission checks and restrict branch-scoped operations to assigned branches.

**Posting remains intentionally disabled** until database transactions are supported consistently by SQLite and PostgreSQL. This avoids partially written financial records.

See `docs/STAGE6_ACCOUNTING_GUIDE.md` for endpoint details and validation requirements.
