# ANSARY ERP Browser Client

Responsive, Pashto-first RTL browser interface. It uses the authenticated Express API; it is not an offline-first client and is not yet packaged as a desktop or Android application.

## Run

1. Prepare and migrate a SQLite database using the root project instructions.
2. Install the root npm workspace dependencies (`npm install`).
3. Configure and start the API from the repository root with `npm run dev:server`.
4. In another terminal, run `npm --workspace @ansary-erp/client run start`.
5. Open `http://localhost:5173` and set the API base to `http://localhost:3000` if needed.

The browser client stores its session token in browser local storage. Use HTTPS if accessing it over a network. The UI does not provide full CRUD for customers/suppliers, does not yet post sales/purchase invoices from the browser, and has no service-worker/offline cache.


## Stage 28 — Offline read cache

- Uses IndexedDB to cache selected authenticated GET responses per username.
- Cached routes are limited to medicine catalog, batches, expiry alerts, customers, suppliers, dashboard and summary/party-ledger reports.
- On a network failure, the client may display the last cached response for those routes.
- Cache entries are removed for the active username when the user logs out.
- Authentication endpoints, tokens, print documents, invoice mutations and POST/PUT/PATCH/DELETE requests are never cached or queued.
- On reconnect, the current page is reloaded from the API.

**Important limitation:** This is offline read-only viewing, not offline transaction entry or multi-device synchronization. Do not create or post purchases/sales while disconnected. The Stage 10 SQLite sync engine still has no production HTTP/PostgreSQL transport.


## Stage 123 — Installment creation and receipt workflow

- The installment page can create a plan from a posted credit sales invoice with an outstanding balance. The API remains the authority for invoice eligibility and duplicate-plan validation.
- The page can create a Draft customer receipt, allocate it to the selected installment, and then post it only after a separate confirmation. Posting is performed by the accounting API; this action updates the customer receivable and installment schedule through the existing transactional workflow.
- The payment account selector lists active, postable Asset accounts. Configure the intended cash/bank ledger accounts before entering receipts.
- The receipt workflow uses the first branch assigned to the signed-in user, matching the existing browser client's branch selection behavior.
- A failure between Draft receipt creation and installment allocation can leave an unallocated Draft receipt; inspect the accounting payments list before retrying to avoid duplicate receipts.
