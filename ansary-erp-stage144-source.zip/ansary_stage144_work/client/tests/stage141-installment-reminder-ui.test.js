import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const app = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');

test('Stage 141 renders an accessible in-app overdue installment reminder', () => {
  assert.match(app, /data-installment-reminder/);
  assert.match(app, /role=\\?"alert\\?"/);
  assert.match(app, /aria-live=\\?"polite\\?"/);
  assert.match(app, /د قسطونو د ورکړې یادونه/);
  assert.match(app, /ناورکړل شوی ناوخته مبلغ/);
});

test('Stage 141 keeps overdue totals separated by currency', () => {
  assert.match(app, /overdueByCurrency/);
  assert.match(app, /moneyCurrency\(amount,currency\)/);
  assert.match(app, /SMS، ایمیل یا Push خبرتیا نه لېږي/);
});
