import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const app = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');

test('Stage 142 exposes an accessible filter for overdue installment plans', () => {
  assert.match(app, /id="installmentOverdueFilter"/);
  assert.match(app, /aria-label="د ناوخته قسطونو فلټر"/);
  assert.match(app, /یوازې ناوخته قسطونه/);
  assert.match(app, /بې ناوخته قسطونو پلانونه/);
});

test('Stage 142 filters plans by overdue installment count without changing stored data', () => {
  assert.match(app, /overdueFilter==='overdue'\?Number\(x\.overdue_installment_count\|\|0\)>0/);
  assert.match(app, /overdueFilter==='overdue'\?Number\(x\.overdue_installment_count\|\|0\)>0:Number\(x\.overdue_installment_count\|\|0\)===0/);
  assert.match(app, /\$\('#installmentOverdueFilter'\)\.addEventListener\('change',draw\)/);
});
