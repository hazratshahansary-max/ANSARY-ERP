import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const app = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');
test('Stage 144 renders contact recording controls and reminder history', () => {
  assert.match(app, /dueReminderHistoryTable/);
  assert.match(app, /data-record-reminder/);
  assert.match(app, /data-reminder-channel/);
  assert.match(app, /data-reminder-outcome/);
  assert.match(app, /api\('\/api\/reports\/due-reminder-history'/);
  assert.match(app, /api\('\/api\/reports\/due-reminder-history\?limit=100'/);
});
