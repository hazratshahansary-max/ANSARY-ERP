import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const app = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');

test('purchase posted invoice exposes a reason/date reversal form and correct API route', () => {
  assert.match(app, /id="reversePurchaseForm"/);
  assert.match(app, /\/api\/purchases\/invoices\/\$\{invoiceId\}\/reverse/);
  assert.match(app, /reason\.length<3/);
  assert.match(app, /h\.status==='reversed'\?`<div class="alert-box">دا پېرود فاکتور لغوه شوی دی/);
});

test('sales posted invoice exposes a reason/date reversal form and correct API route', () => {
  assert.match(app, /id="reverseSalesForm"/);
  assert.match(app, /\/api\/sales\/invoices\/\$\{invoiceId\}\/reverse/);
  assert.match(app, /h\.status==='reversed'\?`<div class="alert-box">دا خرڅلاو فاکتور لغوه شوی دی/);
});

test('both reversal forms require a reason and explicit confirmation before POST', () => {
  assert.equal((app.match(/minlength="3" maxlength="500" required/g) || []).length >= 2, true);
  assert.equal((app.match(/if\(!confirm\('ایا ډاډه یاست چې دا (?:پېرود|خرڅلاو) فاکتور لغوه کړئ/g) || []).length, 2);
});
