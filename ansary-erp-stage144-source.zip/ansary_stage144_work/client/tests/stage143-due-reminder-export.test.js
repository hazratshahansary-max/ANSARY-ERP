import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const app = readFileSync(new URL('../src/app.js', import.meta.url), 'utf8');

test('Stage 143 exposes an export action for the due-reminder queue', () => {
  assert.match(app, /id="exportDueReminders"/);
  assert.match(app, /د یادونو Excel صادرول/);
  assert.match(app, /downloadXlsx\(`ansary-due-reminders-/);
});

test('Stage 143 exports the currently loaded reminder rows with customer, invoice, due date and balance', () => {
  assert.match(app, /let dueReminderRows=\[\]/);
  assert.match(app, /dueReminderRows=reminders\.rows\|\|\[\]/);
  for (const field of ['customer_name','invoice_no','due_date','days_past_due','remaining_balance','currency_code']) {
    assert.match(app, new RegExp(`\\['${field}'`));
  }
  assert.match(app, /if\(!dueReminderRows\.length\)\{toast\(/);
});
