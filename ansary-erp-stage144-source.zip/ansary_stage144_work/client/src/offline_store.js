/* Private, user-scoped read cache for the ANSARY ERP PWA.
 * This cache is for offline viewing only; it never stores auth tokens or writes transactions. */
const DB_NAME = 'ansary-erp-offline-v1';
const STORE = 'api_cache';
let dbPromise;

function openDb() {
  if (!('indexedDB' in globalThis)) return Promise.reject(new Error('INDEXEDDB_UNAVAILABLE'));
  if (!dbPromise) dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('INDEXEDDB_OPEN_FAILED'));
  });
  return dbPromise;
}

export function isOfflineCacheable(path) {
  const pathname = String(path).split('?')[0];
  return [
    '/api/inventory/medicines', '/api/inventory/batches', '/api/inventory/expiry-alerts',
    '/api/sales/customers', '/api/purchases/suppliers',
    '/api/reports/dashboard', '/api/reports/sales-summary', '/api/reports/stock-summary',
    '/api/reports/party-ledgers'
  ].some((allowed) => pathname === allowed || pathname.startsWith(`${allowed}/`));
}

export async function putCached(scope, path, data) {
  if (!scope || !isOfflineCacheable(path)) return;
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put({ id: `${scope}::${path}`, scope, path, data, savedAt: new Date().toISOString() });
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error('CACHE_WRITE_FAILED'));
    tx.onabort = () => reject(tx.error || new Error('CACHE_WRITE_ABORTED'));
  });
}

export async function getCached(scope, path) {
  if (!scope || !isOfflineCacheable(path)) return null;
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE, 'readonly').objectStore(STORE).get(`${scope}::${path}`);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error('CACHE_READ_FAILED'));
  });
}

export async function clearScope(scope) {
  if (!scope) return;
  const db = await openDb();
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    const request = store.openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      if (cursor.value.scope === scope) cursor.delete();
      cursor.continue();
    };
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error || new Error('CACHE_CLEAR_FAILED'));
  });
}
