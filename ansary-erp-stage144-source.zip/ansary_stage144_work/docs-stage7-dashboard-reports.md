# Stage 7 — Dashboard & Reports API foundation

This stage adds authenticated, branch-scoped reporting endpoints. It does not yet add the visual desktop/web dashboard or PDF/Excel export.

## Endpoints

All endpoints require a valid authenticated session/token and the listed permission.

- `GET /api/reports/dashboard` — `dashboard.view`; posted sales/purchase totals, collections/payments, live stock valuation, medicine count, customer receivables and supplier payables from posted journals, low-stock count, expiry-within-90-days count, and a daily sales trend for the last 30 days.
- `GET /api/reports/sales-summary?from=YYYY-MM-DD&to=YYYY-MM-DD&branchId=...` — `reports.view`; posted invoice totals grouped by invoice date. Defaults to the last 30 days.
- `GET /api/reports/stock-summary?branchId=...` — `reports.view`; live positive stock grouped by medicine and branch (up to 1,000 rows).
- `GET /api/reports/expiry-alerts?days=90&branchId=...` — `reports.view`; positive-quantity batches expiring on or before the requested horizon (1–365 days, up to 2,000 rows).

## Rules

- Branch IDs are taken from the authenticated user's branch assignments. A requested unassigned branch returns `403 BRANCH_FORBIDDEN`.
- Sales and purchase totals include `posted` invoices only; drafts and cancelled documents are excluded.
- Customer and supplier balances are calculated from posted/reversed journal entries and their subledger references.
- Stock quantities and valuation are read from batch balances, not draft invoices.
- Date range inputs are validated and invalid/reversed ranges return `400 INVALID_DATE_RANGE`.

## Validation

- Schema generation completed successfully (`python tools/schema/build.py`).
- Existing SQLite/schema parity test suite: 80/80 passed.
- Node dependencies are not installed in this environment, so TypeScript compilation and HTTP integration tests have not been run. The visual dashboard and export formats remain future work.
