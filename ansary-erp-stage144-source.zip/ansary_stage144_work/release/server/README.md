# ANSARY ERP API — standalone deployment bundle

This folder is isolated from the root Electron/client workspaces. It contains the API source, exact direct dependency versions, a clean-build verifier, an environment doctor, and canonical SQLite/PostgreSQL migration files.

## Requirements
- Node.js 20 or newer
- npm 10 or newer
- Python 3.10+ only if using the included SQLite migration runner

## Diagnose the environment

```bash
npm run doctor
```

## Install and build online
```bash
npm install --no-audit --no-fund
npm run build
```

## Offline Windows preparation
First run desktop/scripts/prepare-offline-api-windows.ps1 online on a connected Windows x64 computer; this creates release/server-stage103 with a real lockfile and fills npm cache. Transfer the full project (including release/server-stage103) and the entire npm cache directory, including _cacache/index-v5, to the target Windows x64 computer. Set ANSARY_NPM_OFFLINE=true and ANSARY_NPM_CACHE_DIR to the copied cache directory, then rerun the script. Offline mode reuses the prepared bundle and runs npm ci --offline; it never invents a lockfile. Native modules are platform-specific; do not transfer a Linux/macOS/ARM cache to Windows x64.

## Configure and run
- SQLite: set `SQLITE_FILE=./data/ansary.db` (default) and apply migrations before starting.
- PostgreSQL: set `DATABASE_URL` and run `scripts/migrate_pg.sh <database-name> --seed` (requires the PostgreSQL `psql` client and PG* connection variables). PostgreSQL runtime compatibility still requires deployment-side validation.
- Set `PORT` as needed. Configure TLS at a trusted reverse proxy; do not expose the API directly to the public internet without HTTPS and firewall rules.

```bash
# SQLite example
python scripts/migrate_sqlite.py ./data/ansary.db
npm start
```

## Health checks
- `GET /health/live`: process liveness.
- `GET /health/ready`: database connectivity and required schema readiness.

## Important limits
This bundle is source packaging only. It does not include installed node_modules, a generated package-lock, a built dist directory, secrets, or a production database. Run install/build on a machine with registry access, then verify the live API and database before production use.
