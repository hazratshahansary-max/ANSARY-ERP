'use strict';
// First-run SQLite migration runner for the packaged desktop app.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const Database = require('better-sqlite3');

const dbFile = process.argv[2];
const databaseRoot = process.argv[3];
if (!dbFile || !databaseRoot) throw new Error('Usage: bootstrap.cjs <database-file> <database-root>');
const migrationDir = path.join(databaseRoot, 'sqlite', 'migrations');
const seedFile = path.join(databaseRoot, 'seed', 'production', '001_system_data.sql');
const db = new Database(dbFile);
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
try {
  db.exec("CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')))");
  const applied = new Map(db.prepare('SELECT version, checksum FROM schema_migrations').all().map(x => [x.version, x.checksum]));
  const migrations = fs.readdirSync(migrationDir).filter(x => x.endsWith('.sql')).sort();
  for (const name of migrations) {
    const file = path.join(migrationDir, name);
    const sql = fs.readFileSync(file, 'utf8');
    const checksum = crypto.createHash('sha256').update(sql).digest('hex');
    if (applied.has(name)) {
      if (applied.get(name) !== checksum) throw new Error(`Migration checksum mismatch: ${name}`);
      continue;
    }
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(sql);
      db.prepare('INSERT INTO schema_migrations (version, checksum) VALUES (?, ?)').run(name, checksum);
      db.exec('COMMIT');
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
  if (fs.existsSync(seedFile)) {
    const marker = db.prepare("SELECT value FROM settings WHERE scope_type='global' AND scope_id='' AND key='system.production_seed_version' LIMIT 1").get();
    if (!marker) {
      db.exec(fs.readFileSync(seedFile, 'utf8'));
      db.prepare("INSERT INTO settings (scope_type,scope_id,key,value,value_type) VALUES ('global','','system.production_seed_version','1','string')").run();
    }
  }
  const integrity = db.pragma('integrity_check', { simple: true });
  if (integrity !== 'ok') throw new Error(`SQLite integrity check failed: ${integrity}`);
  console.log('SQLite migrations and production seed are ready.');
} finally {
  db.close();
}
