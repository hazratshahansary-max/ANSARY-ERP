$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$RootManifest = Get-Content (Join-Path $ProjectRoot 'package.json') -Raw | ConvertFrom-Json
$ProjectVersion = [string]$RootManifest.version
if ($ProjectVersion -notmatch '^0\.(\d+)\.\d+$') { throw "Unsupported project version format: $ProjectVersion" }
$StageNumber = [int]$Matches[1]
$StageTag = "stage$StageNumber"
$BundleRelative = "release/server-$StageTag"
$BundleDir = Join-Path $ProjectRoot $BundleRelative
$ReleaseDir = Join-Path $ProjectRoot 'release'
$ZipPath = Join-Path $ReleaseDir "ansary-erp-api-windows-x64-$StageTag.zip"
$LogPath = Join-Path $ReleaseDir "$StageTag-windows-api-setup.log"
$ReportPath = Join-Path $ReleaseDir "$StageTag-windows-api-setup.json"
$MaxAttempts = 3
$FetchTimeoutMs = 30000
$Offline = $env:ANSARY_NPM_OFFLINE -match '^(1|true|yes)$'
$AttemptLimit = if ($Offline) { 1 } else { $MaxAttempts }
$CacheDir = $env:ANSARY_NPM_CACHE_DIR

function Write-SetupLog {
    param([string]$Message)
    $Message = Protect-SetupText $Message
    $Line = "[$(Get-Date -Format o)] $Message"
    Write-Host $Line
    Add-Content -Path $LogPath -Value $Line -Encoding UTF8
}

function Invoke-Checked {
    param([string]$Command, [string[]]$Arguments, [string]$WorkingDirectory)
    Push-Location $WorkingDirectory
    try {
        # Capture both output streams without a PowerShell pipeline. The previous
        # duplicate -Append parameter made the setup script fail before npm ran.
        $CommandOutput = @(& $Command @Arguments 2>&1)
        $CommandExitCode = $LASTEXITCODE
        foreach ($OutputLine in $CommandOutput) {
            $TextLine = [string]$OutputLine
            $SafeTextLine = Protect-SetupText $TextLine
            Write-Host $SafeTextLine
            Add-Content -Path $LogPath -Value $SafeTextLine -Encoding UTF8
        }
        if ($CommandExitCode -ne 0) {
            throw "Command failed ($CommandExitCode): $Command $($Arguments -join ' ')"
        }
    }
    finally { Pop-Location }
}

function Get-RegistryUri {
    if ($env:ANSARY_NPM_REGISTRY) { $Value = $env:ANSARY_NPM_REGISTRY }
    else {
        $Value = (& npm.cmd config get registry).Trim()
        if ($LASTEXITCODE -ne 0 -or -not $Value) { $Value = 'https://registry.npmjs.org/' }
    }
    try { $Uri = [System.Uri]$Value }
    catch { throw "Invalid npm registry URL: $Value" }
    if ($Uri.Scheme -ne 'https' -and $Uri.Host -notin @('localhost', '127.0.0.1')) {
        throw "Use an HTTPS npm registry (or localhost for a private mirror): $Value"
    }
    return $Uri
}

New-Item -ItemType Directory -Force -Path $ReleaseDir | Out-Null
Set-Content -Path $LogPath -Value "ANSARY ERP $StageTag Windows API preparation" -Encoding UTF8
$Started = Get-Date
$Status = 'FAILED'
$Failure = $null
$Registry = $null
$SafeRegistry = $null

function Protect-SetupText {
    param([string]$Text)
    if ($Registry -and $SafeRegistry) {
        $Text = $Text.Replace($Registry.AbsoluteUri, $SafeRegistry)
        if ($Registry.UserInfo) { $Text = $Text.Replace($Registry.UserInfo, '[REDACTED]') }
    }
    return $Text
}

function Get-SafeRegistryUri {
    param([System.Uri]$Uri)
    $Builder = [System.UriBuilder]::new($Uri)
    $Builder.UserName = ''
    $Builder.Password = ''
    $Builder.Query = ''
    $Builder.Fragment = ''
    return $Builder.Uri.AbsoluteUri
}

try {
    $Runtime = (& node -p "process.platform + ' ' + process.arch + ' ' + process.version").Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Node.js is required.' }
    if ($Runtime -notmatch '^win32 x64 v(\d+)\.') { throw "Run on Windows x64 with Node.js 20+; detected: $Runtime. Native modules are platform-specific." }
    if ([int]$Matches[1] -lt 20) { throw "Node.js 20+ is required; detected: $Runtime" }

    $NpmVersion = (& npm.cmd --version).Trim()
    if ($LASTEXITCODE -ne 0) { throw 'npm is required.' }
    $NpmMajor = [int]($NpmVersion.Split('.')[0])
    if ($NpmMajor -lt 10) { throw "npm 10+ is required; detected $NpmVersion" }
    $Registry = Get-RegistryUri
    $SafeRegistry = Get-SafeRegistryUri $Registry
    Write-SetupLog "Runtime accepted: $Runtime; npm $NpmVersion"
    Write-SetupLog "Registry selected: $SafeRegistry"

    if ($Offline) {
        if (-not $CacheDir) { throw 'Offline mode requires ANSARY_NPM_CACHE_DIR pointing to a copied npm cache directory.' }
        $CachePath = [System.IO.Path]::GetFullPath($CacheDir)
        $CacheStore = Join-Path $CachePath '_cacache'
        $CacheIndex = Join-Path $CacheStore 'index-v5'
        if (-not (Test-Path $CacheIndex -PathType Container)) { throw "Offline npm cache is incomplete: expected $CacheIndex. Copy the entire npm cache folder, including _cacache/index-v5." }
        $env:npm_config_cache = $CachePath
        Write-SetupLog "Offline mode enabled; using npm cache: $CachePath"
    }
    else {
        try {
            [void][System.Net.Dns]::GetHostAddresses($Registry.Host)
            Write-SetupLog "DNS lookup succeeded for $($Registry.Host)"
        }
        catch {
            throw "DNS lookup failed for npm registry host '$($Registry.Host)': $($_.Exception.Message). Check internet/DNS or set ANSARY_NPM_REGISTRY to an approved reachable HTTPS mirror, or prepare a complete npm cache on an internet-connected computer and use ANSARY_NPM_OFFLINE=true."
        }
    }

    if ($Offline) {
        Write-SetupLog '1/6 Validating the pre-prepared offline API bundle...'
        if (-not (Test-Path $BundleDir -PathType Container)) { throw "Offline bundle not found: $BundleDir. First prepare it on a connected Windows x64 computer by running this script online, then transfer the full project and npm cache." }
        $PreparedLock = Join-Path $BundleDir 'package-lock.json'
        if (-not (Test-Path $PreparedLock -PathType Leaf)) { throw 'Offline bundle has no real package-lock.json. Do not create a synthetic lockfile; prepare the bundle online first.' }
        $PreparedLockData = Get-Content $PreparedLock -Raw | ConvertFrom-Json
        if ($PreparedLockData.lockfileVersion -lt 2) { throw 'Offline bundle package-lock.json must use lockfileVersion 2 or 3.' }
    }
    else {
        Write-SetupLog '1/6 Creating isolated API source bundle...'
        Invoke-Checked 'node' @('scripts/package-server.mjs', $BundleRelative, '--force') $ProjectRoot
    }

    Write-SetupLog '2/6 Installing dependencies and generating/verifying a real package-lock.json...'
    $InstallSucceeded = $false
    for ($Attempt = 1; $Attempt -le $AttemptLimit; $Attempt++) {
        try {
            if ($Offline) {
                $InstallArgs = @('ci', '--no-audit', '--no-fund', '--prefer-offline', '--registry', $Registry.AbsoluteUri, '--offline')
            }
            else {
                $InstallArgs = @('install', '--no-audit', '--no-fund', '--package-lock=true', '--fetch-retries=1', "--fetch-timeout=$FetchTimeoutMs", '--prefer-offline', '--registry', $Registry.AbsoluteUri)
            }
            Invoke-Checked 'npm.cmd' $InstallArgs $BundleDir
            $InstallSucceeded = $true
            break
        }
        catch {
            Write-SetupLog "Install attempt $Attempt/$AttemptLimit failed: $($_.Exception.Message)"
            if ($Attempt -lt $AttemptLimit) {
                $Delay = [Math]::Min(30, 5 * $Attempt)
                Write-SetupLog "Retrying in $Delay seconds..."
                Start-Sleep -Seconds $Delay
            }
        }
    }
    if (-not $InstallSucceeded) { throw "Dependency installation failed in the selected install mode. See $StageTag-windows-api-setup.log." }

    $LockPath = Join-Path $BundleDir 'package-lock.json'
    if (-not (Test-Path $LockPath)) { throw 'npm install returned success but package-lock.json was not created.' }
    $Lock = Get-Content $LockPath -Raw | ConvertFrom-Json
    if ($Lock.lockfileVersion -lt 2) { throw "Unsupported package-lock version: $($Lock.lockfileVersion)" }

    Write-SetupLog '3/6 Building TypeScript API...'
    Invoke-Checked 'npm.cmd' @('run', 'build') $BundleDir
    if (-not (Test-Path (Join-Path $BundleDir 'dist/index.js'))) { throw 'Build returned success but dist/index.js is missing.' }

    Write-SetupLog '4/6 Removing development-only dependencies...'
    $PruneArgs = @('prune', '--omit=dev', '--no-audit', '--no-fund', '--registry', $Registry.AbsoluteUri)
    if ($Offline) { $PruneArgs += '--offline' }
    Invoke-Checked 'npm.cmd' $PruneArgs $BundleDir

    Write-SetupLog '5/6 Verifying runtime bundle and writing deployment manifest...'
    $env:ANSARY_NPM_VERSION = $NpmVersion
    Invoke-Checked 'node' @((Join-Path $ProjectRoot 'scripts/verify-offline-api-bundle.mjs'), $BundleDir, '--write-manifest') $ProjectRoot
    Remove-Item Env:\ANSARY_NPM_VERSION -ErrorAction SilentlyContinue
    Remove-Item Env:\npm_config_cache -ErrorAction SilentlyContinue

    Write-SetupLog '6/6 Creating platform-specific ZIP...'
    if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
    Compress-Archive -Path (Join-Path $BundleDir '*') -DestinationPath $ZipPath -CompressionLevel Optimal
    $Hash = (Get-FileHash $ZipPath -Algorithm SHA256).Hash
    Set-Content -Path "$ZipPath.sha256.txt" -Value "$Hash  $(Split-Path $ZipPath -Leaf)"
    $Status = 'SUCCESS'
    Write-SetupLog "SUCCESS: $ZipPath"
    Write-SetupLog "SHA256: $Hash"
    Write-SetupLog 'This bundle is for Windows x64 only; native modules are not portable to Linux, macOS, ARM, or 32-bit Windows.'
}
catch {
    $Failure = $_.Exception.Message
    Write-SetupLog "FAILED: $Failure"
    throw
}
finally {
    Remove-Item Env:\ANSARY_NPM_VERSION -ErrorAction SilentlyContinue
    Remove-Item Env:\npm_config_cache -ErrorAction SilentlyContinue
    $Report = [ordered]@{
        format = "ansary-$StageTag-windows-api-setup-report"
        version = $ProjectVersion
        stage = $StageNumber
        status = $Status
        startedAt = $Started.ToString('o')
        finishedAt = (Get-Date).ToString('o')
        runtime = if ($Runtime) { $Runtime } else { $null }
        npmVersion = if ($NpmVersion) { $NpmVersion } else { $null }
        registry = if ($SafeRegistry) { $SafeRegistry } else { $null }
        installMode = if ($Offline) { 'offline-cache' } else { 'online-registry' }
        npmCache = if ($Offline) { $CacheDir } else { $null }
        bundle = $BundleDir
        zip = if (Test-Path $ZipPath) { $ZipPath } else { $null }
        sha256 = if ($Hash) { $Hash } else { $null }
        failure = $Failure
        log = $LogPath
    }
    $Report | ConvertTo-Json -Depth 5 | Set-Content -Path $ReportPath -Encoding UTF8
    Write-Host "Setup report: $ReportPath"
}
