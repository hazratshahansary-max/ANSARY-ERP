$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location $root
$nodeVersion = 'v22.16.0'
$runtimeDir = Join-Path $root 'desktop\runtime'
New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
$nodeExe = Join-Path $runtimeDir 'node.exe'
$baseUrl = "https://nodejs.org/dist/$nodeVersion"
$checksums = Join-Path $env:TEMP "node-$nodeVersion-SHASUMS256.txt"
$download = Join-Path $env:TEMP "node-$nodeVersion-win-x64.exe"

Write-Host 'Downloading official Node.js Windows x64 runtime...'
Invoke-WebRequest -Uri "$baseUrl/SHASUMS256.txt" -OutFile $checksums
Invoke-WebRequest -Uri "$baseUrl/win-x64/node.exe" -OutFile $download
$line = Get-Content $checksums | Where-Object { $_ -match '\swin-x64/node\.exe$' } | Select-Object -First 1
if (-not $line) { throw 'Node.js checksum entry was not found.' }
$expected = ($line -split '\s+')[0].ToLowerInvariant()
$actual = (Get-FileHash -Algorithm SHA256 -Path $download).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'Node.js runtime checksum verification failed.' }
Copy-Item -Force $download $nodeExe

Write-Host 'Building the TypeScript API...'
npm run build:server

$stage = Join-Path $root '.desktop-stage\server'
if (Test-Path $stage) { Remove-Item -Recurse -Force $stage }
New-Item -ItemType Directory -Force -Path $stage | Out-Null
Copy-Item -Recurse (Join-Path $root 'server\dist') (Join-Path $stage 'dist')
Copy-Item (Join-Path $root 'server\package.json') (Join-Path $stage 'package.json')
Write-Host 'Installing production API dependencies into the staging folder...'
npm install --prefix $stage --omit=dev --no-audit --no-fund

Write-Host 'Windows packaging prerequisites are staged.'
Write-Host 'Next run: npm run desktop:build'
