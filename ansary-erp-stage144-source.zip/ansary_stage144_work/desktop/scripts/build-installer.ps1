$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location $root

if ($env:OS -ne 'Windows_NT') { throw 'This installer build must run on Windows 10/11 x64.' }
if ([Environment]::Is64BitOperatingSystem -ne $true) { throw 'A 64-bit Windows operating system is required.' }
$nodeMajor = (& node --version 2>$null)
if (-not $nodeMajor -or $nodeMajor -notmatch '^v22\.') { throw 'Install Node.js 22.x x64 and npm before building.' }

Write-Host 'Installing root build dependencies...'
npm install --include=dev --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'Root npm install failed.' }

Write-Host 'Preparing verified runtime and production API staging...'
npm run desktop:prepare:win
if ($LASTEXITCODE -ne 0) { throw 'Windows preparation failed.' }

Write-Host 'Checking desktop package contract...'
npm run desktop:verify -- --prepared
if ($LASTEXITCODE -ne 0) { throw 'Desktop package verification failed.' }

Write-Host 'Building NSIS installer...'
npm run desktop:build
if ($LASTEXITCODE -ne 0) { throw 'electron-builder failed.' }

$installer = Get-ChildItem (Join-Path $root 'release') -Filter 'ANSARY-ERP-Setup-*-x64.exe' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $installer) { throw 'Build finished without producing the expected x64 Setup.exe.' }
Write-Host "Installer created: $($installer.FullName)"
Write-Host 'Install and test on a clean Windows 10/11 x64 machine before distributing.'
