'use strict';

const { app, BrowserWindow, dialog } = require('electron');
const { spawn, spawnSync } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');

let apiProcess = null;
let mainWindow = null;
let shuttingDown = false;
const API_PORT = 3177;
const API_URL = `http://127.0.0.1:${API_PORT}`;

function resourcePath(...parts) {
  const base = app.isPackaged ? process.resourcesPath : path.resolve(__dirname, '..', '..');
  return path.join(base, ...parts);
}

function requestReady() {
  return new Promise((resolve) => {
    const req = http.get(`${API_URL}/health/ready`, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.setTimeout(1000, () => { req.destroy(); resolve(false); });
    req.on('error', () => resolve(false));
  });
}

async function waitForApi(timeoutMs = 25000) {
  const until = Date.now() + timeoutMs;
  while (Date.now() < until) {
    if (await requestReady()) return true;
    await new Promise((r) => setTimeout(r, 350));
    if (apiProcess && apiProcess.exitCode !== null) return false;
  }
  return false;
}

function nodeBinary() {
  return app.isPackaged ? resourcePath('runtime', 'node.exe') : (process.env.ANSARY_NODE_PATH || 'node');
}

function startApi() {
  const serverEntry = resourcePath('server', 'dist', 'index.js');
  const serverModules = resourcePath('server', 'node_modules');
  const bundledNode = nodeBinary();
  const clientEntry = resourcePath('client', 'index.html');
  if (!fs.existsSync(serverEntry) || !fs.existsSync(clientEntry)) {
    throw new Error('د پروګرام اړین فایلونه نیمګړي دي.');
  }
  if (app.isPackaged && !fs.existsSync(bundledNode)) {
    throw new Error('د Node.js runtime فایل نشته؛ د نصب بسته نیمګړې ده.');
  }
  const dataDir = path.join(app.getPath('userData'), 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const databaseFile = path.join(dataDir, 'ansary.db');
  const env = {
      ...process.env,
      PORT: String(API_PORT),
      SQLITE_FILE: databaseFile,
      CORS_ORIGIN: 'null',
      NODE_PATH: serverModules
  };
  const bootstrap = spawnSync(bundledNode, [resourcePath('bootstrap.cjs'), databaseFile, resourcePath('database')], { env, encoding: 'utf8', windowsHide: true });
  if (bootstrap.status !== 0) {
    console.error(bootstrap.stderr || bootstrap.stdout);
    throw new Error('د ډیټابیس لومړنی تنظیم ناکام شو.');
  }
  apiProcess = spawn(bundledNode, [serverEntry], {
    env,
    stdio: 'ignore',
    windowsHide: true
  });
  apiProcess.on('error', (err) => console.error('API process error:', err));
  apiProcess.on('exit', (code) => {
    if (!shuttingDown && code !== 0 && code !== null) {
      console.error(`API process exited: ${code}`);
    }
  });
}

async function createWindow() {
  startApi();
  const ready = await waitForApi();
  if (!ready) {
    await dialog.showMessageBox({ type: 'error', title: 'ANSARY ERP', message: 'د ERP سرور پیل نه شو. د نصب فایلونه او د SQLite ډیټابیس وګورئ.' });
    app.quit();
    return;
  }
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 900,
    minHeight: 620,
    show: false,
    backgroundColor: '#f3f6fa',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  await mainWindow.loadFile(resourcePath('client', 'index.html'));
}

function stopApi() {
  shuttingDown = true;
  if (apiProcess && apiProcess.exitCode === null) {
    if (process.platform === 'win32') {
      spawn('taskkill', ['/pid', String(apiProcess.pid), '/t', '/f'], { windowsHide: true, stdio: 'ignore' });
    } else {
      apiProcess.kill('SIGTERM');
    }
  }
}

app.whenReady().then(createWindow).catch(async (err) => {
  await dialog.showMessageBox({ type: 'error', title: 'ANSARY ERP', message: err.message || 'د پروګرام د پیل تېروتنه' });
  app.quit();
});
app.on('before-quit', stopApi);
app.on('window-all-closed', () => app.quit());
