# ANSARY ERP Windows desktop wrapper — Stage 25 foundation

This stage adds an Electron desktop shell for **Windows 10/11 x64**. It starts the compiled Express API as a child Node process, stores SQLite data under Electron's per-user application data directory, and loads the existing Pashto RTL client in a hardened BrowserWindow.

## Security choices
- `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`.
- The UI only calls the loopback API on `127.0.0.1:3177`.
- The API child process is stopped when the desktop app exits.
- SQLite data is stored outside the installation directory so updates do not overwrite it.

## Build prerequisites
- Windows 10/11 x64 for the target build.
- Node.js 22 x64 and npm. Copy the official Node.js 22 x64 `node.exe` to `desktop/runtime/node.exe` before packaging; it is bundled to run the API separately from Electron and avoid native-module ABI mismatch.
- Build tools required by native dependencies such as `better-sqlite3` and `argon2`.

## Build steps (not executed in this environment)
From the repository root:

```powershell
npm install
npm run build:server
npm run desktop:build
```

The NSIS installer should be written to `release/` as `ANSARY-ERP-Setup-0.25.0-x64.exe`. First launch runs checksum-protected SQLite migrations and the production seed before starting the API.

## Important limitations
- This is a packaging foundation, **not a verified Setup.exe**. The actual Windows installer must be built and tested on Windows 10/11 x64.
- The server TypeScript build and native Windows modules must succeed on Windows before packaging. `desktop/runtime/node.exe` must be supplied; it is intentionally not included in this source ZIP.
- Windows 7 32-bit is not supported by this Electron x64 target. It needs a separate legacy architecture and compatibility validation.
- Android APK, online synchronization server, and PostgreSQL deployment are not included in this stage.

## Prepare the Windows build automatically
On a Windows 10/11 x64 machine with Node.js 22.16.0 and npm installed, run:

```powershell
npm run desktop:prepare:win
npm run desktop:build
```

The preparation script downloads the official Node.js 22.16.0 Windows x64 runtime, verifies its SHA-256 checksum against the official `SHASUMS256.txt`, compiles the API, and installs only production API dependencies into `.desktop-stage/server`. The build command then creates the NSIS installer. These Windows commands have not been run in this Linux workspace.
