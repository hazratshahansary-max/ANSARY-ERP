# ANSARY ERP

**Professional Pharmaceutical Wholesale & Retail ERP** · Developer: Hazrat Shah Ansary · Brand: **ANSARY DATABASES**

> ANSARY ERP is an original product with its own brand. It reproduces the general workflow of traditional
> pharmaceutical ERP software; it does not use any third-party name, logo, source code or protected assets.

## Server dependency setup (Stage 65)

From the project root, install the server workspace with `npm run setup:server`. This uses the existing lockfile when available, otherwise creates one, and supports an approved registry mirror through `ANSARY_NPM_REGISTRY`. After installation succeeds, run `npm run build:server` and `npm run smoke:server`. See `docs/STAGE65_SERVER_DEPENDENCY_RECOVERY.md` for Windows PowerShell instructions and troubleshooting.

## Latest verified status — Stage 100 (2026-11-15)

The current source version is **0.100.0** across the root, server, browser client, desktop, desktop app, and shared workspaces. The latest executed automated suites are **118 Node.js tests, 251 Python application tests, and 93 database tests (462 total)**. The generated schema check (39 files), browser JavaScript/manifest checks, desktop package contract check, and Python compile check also pass. Stage 100 corrects stale release/version metadata, adds an automated workspace-version alignment check, and documents the actual release-readiness boundary.

**Release readiness: NOT production-ready.** The TypeScript API build is blocked because 13 of 14 declared server packages are unavailable in this runtime; the root `package-lock.json` and a complete npm cache are absent, and npm registry access has timed out. The live API, live PostgreSQL migrations/integration, full browser acceptance, real Windows installer, Android APK/AAB, end-to-end multi-device financial synchronization, and Windows 7/32-bit compatibility have not been certified. Automated source tests do not replace live integration or platform acceptance tests. See [docs/RELEASE_READINESS.md](docs/RELEASE_READINESS.md) for the full matrix and next steps.

## Project status: Stages 1–30 foundations and browser client

| Stage | Scope | Status |
|---|---|---|
| 1 | PostgreSQL + SQLite database design, migrations, seeds and integrity tests | SQLite tests pass; PostgreSQL runtime not yet executed |
| 2–8 | Authentication, inventory, purchasing, sales, accounting, reports and invoice-print API foundations | Source included; installed-dependency build/live integration still pending |
| 9 | SQLite backup and restore utility | Implemented and tested |
| 10 | Device-side sync primitives | Implemented and tested; network sync server pending |
| 11 | Responsive Pashto RTL browser client | Implemented; manual browser QA pending |
| 12–13 | Purchase/sales draft entry and batch-aware sales lines | Implemented as entry foundations |
| 14–15 | Purchase and sales posting foundations | SQLite posting tests pass |
| 16 | Receipt/payment voucher posting | SQLite tests pass; integration into every client workflow pending |
| 17 | Customer/supplier ledger reports | Read-only report script and tests included |
| 18 | Printable customer/supplier statements | HTML renderer and tests included; browser prints to PDF |
| 19 | Browser-integrated party ledgers | API routes and Pashto RTL account page added; live HTTP verification pending |
| 20–26 | Integration hardening and Windows packaging foundations | Scripts/configuration included; Windows installer not built in this environment |
| 27–28 | Android PWA and offline cache | Static shell/offline read cache only; offline transaction posting disabled |
| 29 | Authenticated branch-scoped sync event relay | Event envelope relay only; no authoritative business-row replication |
| 30 | Sync delivery cursor protection | Pull/ack cannot jump beyond the cursor delivered by the server; live multi-device QA pending |

**This is still an ERP development foundation, not a fully production-ready application.** It includes a responsive browser client, SQLite database utilities, API source, posting/report foundations, and automated Python tests. The TypeScript API has not passed an installed-dependency build in this environment. PostgreSQL live testing, full browser QA, end-to-end sync, and Windows/Android packaging remain outstanding.

### Honest test status
* **SQLite (offline database): fully executed.** 72 trigger/constraint/reconciliation/sync/search/scale tests + 8 parity tests pass.
* **PostgreSQL (cloud database): NOT executed.** No PostgreSQL server was available in the build environment.
  The PG files are generated from the same definition as the tested SQLite files and pass static parity checks, but
  they must be run on a real server before being trusted:
  ```bash
  createdb ansary_test
  scripts/migrate_pg.sh ansary_test --seed --sample
  psql -v ON_ERROR_STOP=1 -d ansary_test -f database/tests/postgres_integrity_tests.sql
  ```
  Expect to fix a few syntax/semantic details on first run; fix them in `tools/schema/*.py`, then `python tools/schema/build.py`.

## What Stage 1 delivers
* **60 tables** per dialect (+2 dialect-specific sync tables): medicines (100k+ tested), batches, parties, purchase,
  sales, returns, vouchers, double-entry accounting, multi-branch, multi-currency, users/roles/permissions, audit, sync, backup history.
* **~300 triggers** enforcing the 14 mandatory data-integrity rules inside the database (see [docs/DATA_INTEGRITY.md](docs/DATA_INTEGRITY.md)).
* 10 reporting/integrity **views** (stock valuation, expiry buckets, balances, trial balance, `v_integrity_issues`...).
* Seeds: 8 roles, 78 permissions, 4 currencies, 39-account chart of accounts, expense categories, numbering, templates.
  **No default password is shipped.**
* Separate **sample data** that posts a realistic month of business through the real triggers.
* **Sync architecture** (device outbox, server change log, conflict table, remote-apply mode): [docs/SYNC.md](docs/SYNC.md).

## Quick start (Python 3.10+; SQLite >= 3.39)
```bash
python scripts/migrate_sqlite.py demo.db --seed --sample      # build a demo database
python -m unittest discover -s database/tests -v              # run all tests
python tools/schema/build.py                                  # regenerate SQL after editing tools/schema/*.py
```

## Layout
```
tools/schema/     single source of truth (Python DSL) -> generates both SQL dialects
database/postgres|sqlite/migrations/   generated, numbered, checksummed migrations (+ schema.sql)
database/seed/production|sample/       system data | demo data (never mix)
database/tests/   SQLite suite, parity suite, PostgreSQL suite
docs/             architecture, integrity, sync, testing, stage guide, backup, generated catalog
scripts/          migration runners, packaging
server/ client/ desktop/ shared/       API source, responsive browser client, desktop packaging and shared modules
```
**Never edit generated SQL by hand** - edit `tools/schema/` and rebuild (`build.py --check` is a test).


## Historical implementation notes

The stage-by-stage notes below are retained as development history and may describe an earlier boundary. For the current verified state and production blockers, use [docs/RELEASE_READINESS.md](docs/RELEASE_READINESS.md).

## Current progress

Stage 4 purchase-management, Stage 5 sales-management, and Stage 6 accounting API foundations are included. See `docs/STAGE4_PURCHASE_GUIDE.md` for endpoints, safeguards, examples, and known limitations. The purchase workflow is draft-only; posting remains disabled pending transaction-safe journal integration.


Stage 6 details: `docs/STAGE6_ACCOUNTING_GUIDE.md`. Financial posting remains intentionally disabled until the required atomic workflows are implemented and integration-tested.


## Stage 7 — Dashboard & Reports

See `docs-stage7-dashboard-reports.md`. Authenticated, branch-scoped dashboard, sales-summary, stock-summary, and expiry-alert endpoints are available under `/api/reports`. The visual UI and PDF/Excel exports are not included yet.


## Stage 8 — Invoice printing

Printable sales and purchase invoice views are available from the authenticated API:

- `GET /api/sales/invoices/:id/print`
- `GET /api/purchases/invoices/:id/print`

Use `?size=80mm` for thermal receipt styling. The default layout is A4-oriented. Open the print view in a browser and choose **Print → Save as PDF**. Configure the printed company header with `ANSARY_COMPANY_NAME`, `ANSARY_COMPANY_ADDRESS`, and `ANSARY_COMPANY_PHONE`. Print views do not post invoices or change stock/accounting data.

## Stage 9 — Backup & Restore
SQLite backup utility:
```bash
python scripts/backup_restore.py backup ansary.db
python scripts/backup_restore.py verify ansary-YYYYMMDD-HHMMSS.backup.db
python scripts/backup_restore.py list ./backups
# Close the application before restore:
python scripts/backup_restore.py restore ./backups/ansary.backup.db ansary.db --force
```
See `docs/STAGE9_BACKUP_RESTORE.md` for safety details and limitations.


## Stage 10 — Online / Offline Sync foundation
See [docs/STAGE10_SYNC.md](docs/STAGE10_SYNC.md). The SQLite device-side engine supports safe outbox batching, acknowledged push, transactional pull, cursor advancement, and conflict recording. It is not yet a complete network sync product: authenticated HTTPS transport, device registration, PostgreSQL sync endpoints, and end-to-end tests remain outstanding.

## Stage 11 browser client
A responsive Pashto RTL browser client now lives in `client/`. See `docs/STAGE11_CLIENT_UI.md` for startup instructions and current limits. The client is a UI/API foundation; it is not yet a complete transaction-entry application or a packaged desktop/mobile app.


### Stage 12 transaction-entry boundary

Customer/supplier lists are read-only. Purchase draft headers and purchase draft lines can be entered. Sales draft headers can be entered, but sales lines and posting are not available. Neither draft workflow changes inventory balances. See `docs/STAGE12_TRANSACTION_ENTRY.md`.

### Stage 13 status — Batch-aware sales entry
The browser client can now open a sales draft, view its lines, choose an active/unexpired batch for the invoice branch, see its available quantity and add/remove draft lines. The API checks user branch access and returns only batches with positive stock. Invoice posting remains intentionally disabled; no stock deduction or accounting posting occurs yet. Client JavaScript syntax check passed. SQLite tests: 80 passed; backup tests: 4 passed; sync tests: 6 passed. TypeScript build and live API integration remain unverified because dependencies were not installed in this build environment.

### Stage 14 — Purchase posting
`POST /purchases/invoices/:id/post` now posts a draft purchase invoice. It requires `purchase.post`, branch access, a non-empty invoice, an open financial year, and configured `INVENTORY` / `AP` system accounts (plus `TAX_INPUT` when tax applies). The journal is posted before the invoice within one transaction; existing database triggers then receive stock into batches and append stock movements. See `docs/STAGE14_PURCHASE_POSTING.md`.

### Stage 17 — Customer & supplier ledger reports
Read-only customer/supplier balance summaries and individual chronological sub-ledger statements are available through `scripts/party_ledger.py`. Reports support date filters, optional branch filtering, running balances, JSON and CSV output. Opening balances are displayed separately and are not merged into journal movements until a formal opening-balance posting rule is implemented. See `docs/STAGE17_PARTY_LEDGERS.md`.

### Stage 18 — Printable customer & supplier statements
`scripts/render_party_statement.py` renders Stage 17 ledger JSON into standalone A4 landscape HTML, with English LTR and Pashto RTL layouts and a browser Print → Save as PDF action. Opening balance remains clearly separate from journal movement. See `docs/STAGE18_PRINT_REPORTS.md`.


### Stage 19 — Browser-integrated party ledgers
The browser client now has a **حسابونه** page for searching customer/supplier accounts, viewing branch-scoped balances and journal history, filtering by date, and printing A4 RTL statements through the browser. The API excludes opening voucher rows from period movement while showing the party opening balance separately. See [docs/STAGE19_PARTY_LEDGER_UI.md](docs/STAGE19_PARTY_LEDGER_UI.md).

Stage 19 validation: 112 Python tests passed and the browser JavaScript syntax check passed. The TypeScript server build could not be completed because npm dependencies/type packages are absent; live API and browser testing remain pending.

### Stage 20 — Workspace and integration hardening
See [docs/STAGE20_INTEGRATION_HARDENING.md](docs/STAGE20_INTEGRATION_HARDENING.md). All declared npm workspaces now have manifests, Express 4 type definitions are aligned, and workspace contract tests are included. Stage 20 validation: 116 Python tests passed and the browser JavaScript syntax check passed. npm installation timed out in the build environment, so TypeScript compilation and live API integration remain unverified. This is not a packaged desktop or Android release.


## Stage 21 status

Purchase and sales browser draft views now call the existing posting endpoints, and invoice printing uses authenticated fetch. This is a UI/API wiring step, not a live end-to-end certification. Run `node --check client/src/app.js`, `python -m unittest discover -s database/tests -v`, and `python -m unittest discover -s tests -v`. The TypeScript server build, live API, PostgreSQL, Windows installer and Android APK are still unverified/not included.

## Stage 22 — API integration hardening

Stage 22 adds SQL-aware placeholder conversion for both database adapters, strict placeholder/parameter count validation, database readiness and process liveness endpoints, and graceful server shutdown. The dependency-free SQL adapter tests can be run with `npm run test:server-db-adapter`.

Validation in this environment: 80 database tests, 44 project feature tests, and 5 Node.js adapter tests passed. The npm dependency installation timed out, so the TypeScript build and live API/PostgreSQL tests remain unverified. This project is still an evolving foundation, not yet a production-ready packaged desktop/mobile ERP.


## Stage 24 — Platform compatibility audit

See [docs/STAGE24_PLATFORM_COMPATIBILITY.md](docs/STAGE24_PLATFORM_COMPATIBILITY.md). Run `python scripts/preflight.py` for a read-only check of OS and tool availability. Current Node.js 20+ API stack is not a supported Windows 7 target; Windows 10/11 and Android packaging are not certified or included. No Setup.exe or APK is produced at this stage.

## Stage 25 — Windows desktop packaging foundation

A Windows 10/11 x64 Electron shell and NSIS packaging configuration are now present. See `docs/STAGE25_WINDOWS_DESKTOP.md` and `desktop/README.md`. The actual installer has **not** been generated in this Linux environment. The Windows preparation and build commands must be run and tested on Windows 10/11 x64. Windows 7 32-bit and Android APK remain unsupported/unbuilt.

## Stage 26 — Windows installer workflow

For Windows 10/11 x64 with Node.js 22.x x64 installed, open PowerShell in the project root and run:

```powershell
npm run desktop:release:win
```

The workflow installs root dependencies, downloads the official Node.js 22.16.0 Windows x64 runtime and verifies its SHA-256 checksum, builds the TypeScript API, stages production API dependencies, checks packaging contracts, and invokes electron-builder for an NSIS x64 installer. The expected output is under `release/`.

To run only the static contract checks:

```bash
python scripts/verify_desktop_package.py
```

To validate generated staging files after preparation:

```bash
python scripts/verify_desktop_package.py --prepared
```

This workflow has not been executed on Windows in this environment. A generated installer must still be installed and tested on a clean Windows 10/11 x64 machine. Windows 7 32-bit remains unsupported.

## Stage 27 — Android-installable PWA shell

The browser client now includes a web app manifest, service worker, SVG icon, and browser install prompt. The service worker caches only static application-shell assets. It deliberately does not cache API responses, login data, invoices, inventory, or financial records. Therefore this stage supports opening the cached app shell offline, but **does not support offline ERP transactions**. Android installation requires HTTPS and a supported browser; no APK/AAB has been generated. See `docs/STAGE27_ANDROID_PWA.md`.


## Stage 28 — Offline viewing cache

The browser client now stores a limited, user-scoped cache of selected GET responses in IndexedDB. When the network is unavailable, the client can display previously fetched medicine, party, expiry, and report data. The cache is cleared for the active user on logout. No credentials or transaction writes are cached. This does **not** provide offline purchase/sales posting or live device synchronization; those require server-side idempotent sync endpoints and PostgreSQL integration.


Stage 28 automated verification: 80 database tests and 69 project tests passed (149 total). Client syntax/package checks passed. These tests do not constitute a live Android, PostgreSQL, or production API sync test.

### Stage 29 sync relay status

Authenticated sync relay foundations are available at `/api/sync/devices`, `/api/sync/push`, `/api/sync/pull`, and `/api/sync/ack`. See `docs/STAGE29_SYNC_RELAY.md`. These endpoints store and relay event envelopes only; they do not apply business changes to authoritative tables and must not yet be used for production financial/stock synchronization.


## 0.30.0 — Stage 30
- Added `last_delivered_seq` to SQLite and PostgreSQL sync device records via migration 016.
- Pull rejects cursors ahead of the last cursor delivered to that device.
- Pull advances the delivered cursor only to the last event actually returned.
- Acknowledgements cannot advance beyond the last delivered cursor or move backwards.
- Added five regression tests covering cursor guards and SQLite migration behavior.
- `npm install` timed out in this environment; TypeScript build and live Express/PostgreSQL tests remain unverified.

## 0.31.0 — Stage 31
- Added explicit local conflict review and resolution: keep local, use server, merge, or dismiss.
- Preserved the incoming sync operation in `sync_conflicts.server_op` using migration 017 for SQLite and PostgreSQL.
- Server-wins delete handling is restricted to soft-delete tables; no automatic destructive hard delete is performed.
- Resolution is manual and local-only; live server-side business-table application and multi-device financial sync remain unimplemented.
- See `docs/STAGE31_SYNC_CONFLICTS.md`.


## Stage 32 — Sync monitoring and potential conflict review

The browser client now includes a branch-scoped Sync monitor for registered devices and recent relay events. It highlights records touched by multiple devices as **potential** concurrent changes. This is not a definitive conflict detector or resolver: the relay does not yet apply events to canonical business tables, and the Stage 31 local SQLite conflict resolver is not connected to the central API. See [docs/STAGE32_SYNC_MONITOR.md](docs/STAGE32_SYNC_MONITOR.md).

## Stage 33 — guarded master-data sync application

Stage 33 adds a local SQLite apply utility for versioned sync events on `categories`, `companies`, `medicines`, `customers`, and `suppliers`. It uses fixed writable-field allowlists, exact base-version checks, idempotency logging, conflict recording, customer branch checks, and soft deletes. It explicitly rejects stock and posted financial tables. This is **not** a live HTTP apply endpoint or full multi-device replication; PostgreSQL apply and end-to-end device sync remain unimplemented. See `docs/STAGE33_MASTER_SYNC_APPLY.md`.



## Stage 34 — authenticated master-data apply

The authenticated sync API now exposes `POST /api/sync/apply-master` for version-checked master-data events in categories, companies, medicines, customers, and suppliers. It uses a fixed field allowlist, registered-device/branch checks, soft deletes, and a server apply log. SQLite and PostgreSQL migration files are under `server/db/migrations/`. Stock and financial records remain excluded. The apply and audit-log writes are not yet one atomic transaction; see `docs/STAGE34_SERVER_MASTER_APPLY.md` before production use.


## Stage 35 — Master-data schema compatibility

The server master-data apply route now uses the actual schema column `row_version` (not `version`) and no longer writes the nonexistent `origin_device_id` column into master tables. Its allowlists now match the SQLite and PostgreSQL master-data migrations: `company_type`, `customer_code`, and `supplier_code` are used instead of mismatched field names. Stock and financial tables remain excluded. Contract tests compare every allowlisted field against both dialect schemas.

This stage fixes schema compatibility at source level; it does not claim a successful live API or PostgreSQL deployment test.


### Stage 36 — Atomic master-data apply
Master-data changes and successful apply-log records are now grouped in a database transaction per event. This improves crash consistency, but live HTTP, PostgreSQL, and multi-device end-to-end verification are still outstanding.

### Stage 38 — inbound Sync preview
The Sync monitor now offers a manual preview of inbound relay events for the registered device. It calls the authenticated `/api/sync/pull` route and displays up to 100 events. This is **preview only**: no local business-table apply, ACK, or cursor advancement is performed. Automatic outbox generation, bidirectional replication, and two-device end-to-end verification remain future work. Financial and stock sync remain excluded.

### Stage 39 inbound pull apply
A SQLite CLI utility can now apply a previously downloaded authenticated `/api/sync/pull` response to the five supported master-data tables. See `docs/STAGE39_INBOUND_MASTER_APPLY.md`. It does not yet fetch or ACK over HTTP automatically, and is not a completed two-device sync implementation.


Stage 40 adds an authenticated one-cycle HTTP master-data sync client (`scripts/sync_http_client.py`). It performs pull → local SQLite apply → ACK, persists a pending ACK cursor for crash/network recovery, and requests only the five supported master-data tables. Server/local field aliases and intentionally ignored server-only fields are documented in `docs/STAGE40_HTTP_SYNC.md`. This is not a background scheduler and does not push local outbox events; live deployed-server and two-device testing remain outstanding.


## Stage 41 — outbound master-data relay

The one-cycle HTTP sync client now pushes pending outbox events for categories, companies, medicines, customers, and suppliers to the authenticated relay, then pulls/applies remote master changes and ACKs the cursor. Event UUIDs are persisted before network I/O for safe retries. Only relay-acknowledged events are marked sent; this does not mean a remote device has applied them. Hard deletes remain pending because the outbox lacks their original base version. Financial and stock tables are excluded. This remains a one-cycle command, not a scheduler, and live server/two-device testing is still required. See `docs/STAGE41_BIDIRECTIONAL_MASTER_SYNC.md`.


## Stage 42 update

Stage 42 adds versioned local tombstones for hard-deleted master records. Apply SQLite migration 018 before syncing. Only tombstones carrying the exact deleted row version are pushed; older pending delete rows without a captured version are intentionally not sent. Tombstones are cleared only after the sync relay acknowledges the event. This remains a relay-level acknowledgement, not proof that another device has applied the delete. Live API, PostgreSQL and two-device end-to-end tests remain outstanding. See `docs/STAGE42_MASTER_TOMBSTONES.md`.


## Stage 43 — canonical server apply before outbound relay

The outbound HTTP sync client now posts pending master-data events to authenticated `POST /api/sync/apply-master` first. It relays only events confirmed as applied, or idempotent duplicates whose original server result was applied. Server version conflicts remain pending in the local outbox with `MASTER_VERSION_CONFLICT`; they are not marked sent and are not distributed to other devices. If the server applies an event but the HTTP response is lost, retrying the same persisted `event_uuid` is safe; the apply endpoint returns a duplicate result and the client can continue to relay it.

This stage still covers only `categories`, `companies`, `medicines`, `customers`, and `suppliers`. Financial and stock tables are excluded. The automated tests use a mocked HTTP transport; no live server, PostgreSQL, Windows installer, or two-device end-to-end test was performed. See `docs/STAGE43_CANONICAL_MASTER_PUSH.md`.


## Stage 44 — local Sync status report

A read-only diagnostic command now summarizes local master-data outbox state, pending conflicts, pull/ACK cursors, and tombstones without printing raw business payloads or credentials. Run `python scripts/sync_status_report.py data/ansary.db`. It reports local state only; it does not prove remote-device delivery or resolve conflicts. See `docs/STAGE44_SYNC_STATUS_REPORT.md`.


### Stage 45 — controlled retry of failed master-data Sync events
Stage 45 adds `scripts/sync_retry_outbox.py` for explicitly re-queuing failed outbox entries from the five supported master-data tables only. It requires `--confirm`, preserves event UUID/payload/base version/attempt count, and writes a transactional audit row. Financial/inventory events, sent rows, and unknown sequence IDs are rejected. The command makes no network request; run the normal HTTP sync client afterward. See `docs/STAGE45_FAILED_OUTBOX_RETRY.md`. Automated tests do not replace live server or two-device verification.

## Stage 46 — conflict preview and field guards

Stage 46 restricts local conflict resolution to the five supported master-data tables and their explicit writable fields. Server-provided version values are not trusted; the conflict record's server version is authoritative. Merge versions advance beyond both sides. `python scripts/sync_conflict_preview.py data/ansary.db --conflict-id CONFLICT_ID` previews changed field names without exposing business values. This is a local SQLite feature, not a live server or two-device verification. See `docs/STAGE46_CONFLICT_PREVIEW_AND_FIELD_GUARDS.md`.


## Stage 47 — stock and financial sync readiness

Stage 47 adds a read-only schema audit (`python scripts/sync_transaction_readiness.py`) for stock movement source identity and append-only guards, journal posting/reversal protections, invoice lifecycle/idempotency fields, and the narrow master-data allowlist. The SQLite schema passes 7/7 checks. **Stock and financial sync remain disabled**: a server-authoritative immutable transaction protocol, atomic parent/child application, PostgreSQL runtime parity, and real two-device verification are still required. See `docs/STAGE47_TRANSACTION_SYNC_READINESS.md`.

## Stage 48 — Transaction event envelope contract

A strict, side-effect-free v1 envelope builder/validator is available at
`scripts/sync_transaction_envelope.py`. It checks an explicit event allowlist,
canonical event UUID, branch/device/actor identifiers, timezone-aware event
time, device sequence, and canonical payload SHA-256. This is only a local
contract: financial and inventory transaction sync remains disabled until the
server-side authorization, atomic application, replay/idempotency, PostgreSQL,
and two-device requirements are implemented and verified. See
`docs/STAGE48_TRANSACTION_EVENT_ENVELOPE.md`.

## Stage 49 — Durable transaction inbox

A local SQLite reference inbox now persists Stage 48-valid envelopes with
idempotent retries and per-device sequence uniqueness. See
`docs/STAGE49_TRANSACTION_INBOX.md`. This is not a production sync endpoint and
never applies financial or stock transactions.

### Stage 50 transaction sync authorization
A SQLite reference authorization registry is available in `scripts/sync_transaction_auth.py`. It requires an active device token, active actor, and explicit actor/device/branch/event-type grant before `TransactionInbox.accept_authorized()` accepts an event. This is a contract-test implementation, not a production identity provider or a live HTTP integration. See `docs/STAGE50_TRANSACTION_AUTHORIZATION.md`.


### Stage 52 — Device token lifecycle
Device tokens can be rotated or revoked through branch-scoped authenticated API endpoints. See `docs/STAGE52_DEVICE_TOKEN_LIFECYCLE.md`.

## Stage 56 sync safety boundary
The current server relay is intentionally limited to the five supported master-data tables: categories, companies, medicines, customers, and suppliers. Financial and stock tables are rejected by the event schema and are never delivered by `/api/sync/pull`, including with `scope=all`. Financial and stock synchronization remains disabled pending dedicated atomic-posting, idempotency, and end-to-end tests. See `docs/STAGE56_FINANCIAL_RELAY_GUARD.md`.

## Stage 57 sync event UUID integrity
The push endpoint now treats an event UUID as idempotent only when the existing
stored event has the same device, table, row, operation, base version, and
canonical JSON payload. Reusing a UUID with changed content is rejected rather
than acknowledged. This does not enable financial or stock synchronization;
the relay remains limited to the five master-data tables. See
`docs/STAGE57_SYNC_EVENT_UUID_INTEGRITY.md`.


### Stage 58 — partial batch outcomes
The authenticated master-data `/api/sync/push` endpoint now reports successful event UUIDs in `acknowledged` and individual failures in `rejected` (with stable error codes and retryability hints). A failed event no longer hides other events that were safely accepted in the same batch. The client marks only acknowledged rows as sent; rejected rows stay pending with their event UUID and payload unchanged. Financial and inventory tables remain excluded. See `docs/STAGE58_PARTIAL_BATCH_OUTCOMES.md`.


### Stage 62 — Device management
The Sync monitor now supports permission-gated device registration, token rotation, revocation, and token audit history. Existing databases must be re-seeded with the production seed after backup to receive `sync.manage` for administrator roles. This is still a device-management stage, not proof of production-ready network synchronization. Live API, PostgreSQL, and two-device end-to-end tests remain outstanding. See `docs/STAGE62_DEVICE_MANAGEMENT_UI.md`.

## Stage 67 — Authentication endpoint protection

Public login and initial setup endpoints now have a dependency-free, in-process IP rate limiter. Login allows 10 requests and initial setup allows 5 requests per 15-minute window per client IP. Blocked requests receive HTTP 429 and a `Retry-After` header. See `docs/STAGE67_AUTH_RATE_LIMITING.md` for limits and deployment caveats. This does not replace the existing per-account lockout. The limiter is process-local; use a shared store before running multiple API instances.

## Standalone API deployment bundle (Stage 69)

To create an API-only source bundle without installing the Electron/client workspace dependencies:

```bash
npm run package:server
```

The bundle is written to `release/server/`. On a machine with npm registry access, run `npm install --no-audit --no-fund` and `npm run build` inside that folder. This generates an isolated API package; it is not a prebuilt installer. See `docs/STAGE69_STANDALONE_SERVER_BUNDLE.md` for deployment and validation boundaries.


## Stage 86 — API port configuration

The API uses port `3000` when `PORT` is unset. If `PORT` is supplied, it must be a whole decimal number from `1` to `65535`; invalid values stop startup before the database is opened. Run `npm run test:api-port-config` for the dependency-free unit tests.


## Stage 88 — API listener startup diagnostics

If the API cannot bind its configured TCP port, startup now prints a specific diagnostic. `EADDRINUSE` means another process already uses the port; stop that process or set `PORT` to a free port. Permission errors recommend an unprivileged port above 1024. The database connection is closed on listener startup failure. Run `npm run test:api-listen-errors` for dependency-free tests.

## Stage 88 — API dependency preflight
The API build checks every declared production and development dependency before TypeScript starts. Missing packages are listed together under `SERVER_DEPENDENCIES_MISSING`, avoiding confusing secondary compiler errors. This is a diagnostic improvement, not an automatic installer: dependencies must still be installed online or from a complete prepared offline npm cache.

## Stage 89 — API dependency setup diagnostics

Run `npm run setup:server` to install the API workspace dependencies. The command now saves a structured `SERVER_DEPENDENCY_SETUP_REPORT.json` in the project root after success or terminal failure. Registry credentials and query parameters are removed from the saved report. Offline mode performs one attempt; online mode may retry transient registry errors within the configured retry limit.

## Stage 90 — Version-driven Windows API preparation

The Windows API preparation script now derives its release folder, ZIP name, log, JSON report and reported version from the root `package.json`. The standalone API README generator uses the same version to document the correct `release/server-stageN` transfer path. This prevents future releases from silently continuing to target an older stage folder. Windows execution and registry-backed dependency installation still require validation on a supported Windows x64 machine.

## Stage 99 dependency preparation

On a computer with a working npm registry connection, run `npm run prepare:server:cache`.
The preparation step is bounded and writes `SERVER_DEPENDENCY_PREPARATION_REPORT.json`.
Configure `ANSARY_PREPARE_RETRIES` (1–5, default 3) and
`ANSARY_PREPARE_TIMEOUT_MS` (15,000–600,000 ms, default 300,000 ms) if needed.
The command only publishes the offline cache manifest after it verifies both the
workspace `package-lock.json` and the npm `_cacache/index-v5` structure. Then copy
the whole project and the complete npm cache to the offline target computer.

## Stage 103 — npm registry connectivity diagnostics

The read-only API build preflight now checks registry HTTP connectivity after DNS
resolution and distinguishes transport/server failures from authentication-required
responses. Registry URL credentials, query strings, and fragments are stripped
before the probe. Run `node scripts/server-build-preflight.mjs` for a concise report
or add `--json` for machine-readable output. This check does not install dependencies.

The current release still requires a successful online dependency preparation
(`npm run prepare:server:cache`) or a complete transferred offline npm cache before
the TypeScript API build can run. See `docs/STAGE103_REGISTRY_CONNECTIVITY_PREFLIGHT.md`.
